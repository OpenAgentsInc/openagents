#!/usr/bin/env python3
"""Record only the owned native cleanup operations' states."""
import json
import os
from pathlib import Path
import urllib.request

report_path = Path.home()/'evidence/upload-cleanup-11812.json'
report = json.loads(report_path.read_text())
observed = []
for operation in [report['cleanup_retry']['parent_operation'], report['cleanup_retry']['accepted_operation']]:
    request = urllib.request.Request(os.environ['SPACE_API_URL']+'/v1/operations/'+operation,
        headers={'Authorization': 'Bearer '+os.environ['SPACE_API_TOKEN']})
    with urllib.request.urlopen(request, timeout=30) as response:
        value = json.load(response)
    terminal = value.get('terminal_error') or {}
    observed.append({'id':operation, 'state':value['state'],
        'terminal_error_kind':terminal.get('kind'),
        'invalid_lifecycle_reported':'invalid lifecycle' in str(terminal or value.get('progress_message') or '')})
report['cleanup_operation_states_after_collection'] = observed
report_path.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'owned_cleanup_operation_states':observed}))
