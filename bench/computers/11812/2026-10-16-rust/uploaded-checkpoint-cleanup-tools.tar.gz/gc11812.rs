//! One-shot test adapter for the pinned native snapshot-storage collector.
//! Only explicitly named orphan IDs are visible to this collector instance.
use sqlx::{
    PgPool,
    postgres::{PgConnectOptions, PgPoolOptions, PgSslMode},
};
use std::time::Duration;
use uuid::Uuid;
#[path = "../src/env_config.rs"]
mod env_config;
#[path = "../src/snapshot_storage_sweeper/mod.rs"]
mod snapshot_storage_sweeper;
use snapshot_storage_sweeper::{
    Reconciler, ReconcilerConfig, SnapshotStorageDbStore, SweepCandidate, SweeperSink,
};

struct OwnedSink {
    pool: PgPool,
    ids: Vec<Uuid>,
    native: SnapshotStorageDbStore,
}
impl SweeperSink for OwnedSink {
    async fn list_candidates(
        &self,
        limit: i64,
        after: Option<Uuid>,
        min_age: Option<Duration>,
    ) -> Result<Vec<SweepCandidate>, sqlx::Error> {
        assert!(min_age.is_none());
        let rows: Vec<(Uuid, String, bool)> = sqlx::query_as(
            "SELECT ssl.id, ssl.storage_connection_string,
               EXISTS(SELECT 1 FROM snapshot_storage_location_encrypted_fields e WHERE e.snapshot_storage_location_id=ssl.id)
             FROM snapshot_storage_locations ssl
             WHERE ssl.id=ANY($1) AND ssl.snapshot_id IS NULL AND ssl.orphaned_at IS NOT NULL
               AND ($2::uuid IS NULL OR ssl.id>$2)
             ORDER BY ssl.id LIMIT $3")
            .bind(&self.ids).bind(after).bind(limit).fetch_all(&self.pool).await?;
        Ok(rows
            .into_iter()
            .map(|(id, uri, has_encrypted_fields)| {
                // The same disposable store is exposed on the VM's loopback port.
                // Change only its transport address, never the bucket or prefix.
                assert!(uri.contains("endpoint=http://object-store:8333"));
                SweepCandidate {
                    id,
                    storage_connection_string: uri.replace(
                        "endpoint=http://object-store:8333",
                        "endpoint=http://127.0.0.1:8333",
                    ),
                    has_encrypted_fields,
                }
            })
            .collect())
    }
    async fn delete_storage_location_if_orphan(&self, id: Uuid) -> Result<bool, sqlx::Error> {
        assert!(self.ids.contains(&id));
        self.native.delete_storage_location_if_orphan(id).await
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let ids: Vec<Uuid> = serde_json::from_str(&std::env::var("GC_OWNED_IDS")?)?;
    assert_eq!(ids.len(), 10);
    let options = PgConnectOptions::new()
        .host("127.0.0.1")
        .port(std::env::var("PGPORT")?.parse()?)
        .username(&std::env::var("PGUSER")?)
        .password(&std::env::var("PGPASSWORD")?)
        .database(&std::env::var("PGDATABASE")?)
        .ssl_mode(PgSslMode::Prefer);
    let pool = PgPoolOptions::new()
        .max_connections(2)
        .connect_with(options)
        .await?;
    // The failed supplemental test left an invalid terminal native row after
    // runtime teardown. Use the native locked finalizer, never rewrite its
    // state or remove still-attached upload locations by hand.
    let resource = Uuid::parse_str("01a14771-109b-77ed-bd39-097363ae84c8")?;
    let state: Option<(String, String, Option<Uuid>, Option<Uuid>)> = sqlx::query_as(
        "SELECT lifecycle,placement,active_node_id,target_node_id FROM sandboxes WHERE id=$1",
    )
    .bind(resource)
    .fetch_optional(&pool)
    .await?;
    if let Some((lifecycle, placement, active, target)) = state {
        assert_eq!(lifecycle, "deleted");
        assert_eq!(placement, "unplaced");
        assert!(active.is_none() && target.is_none());
        let creating: i64 = sqlx::query_scalar(
            "SELECT count(*) FROM snapshots WHERE sandbox_id=$1 AND state='creating'",
        )
        .bind(resource)
        .fetch_one(&pool)
        .await?;
        assert_eq!(creating, 0);
        pplx_space_api::reconcile_queue::finalize_sandbox_db_delete_user_initiated(
            &pool,
            pplx_space_common_core::types::SandboxId::from_uuid(resource),
        )
        .await?;
    }
    let sink = OwnedSink {
        native: SnapshotStorageDbStore::new(pool.clone()),
        pool,
        ids,
    };
    let aws = aws_config::load_defaults(aws_config::BehaviorVersion::latest()).await;
    let backend = pplx_space_snapshot_storage::s3::S3StorageBackend::from_sdk_config(&aws);
    let config = ReconcilerConfig {
        min_age: None,
        scoped_bucket: Some("snapshots".into()),
        max_per_tick: 10,
        concurrency: 2,
        ..Default::default()
    };
    let mut collector = Reconciler::new(config, sink, backend);
    let result = collector.tick().await;
    println!(
        "{}",
        serde_json::json!({"scanned":result.scanned,"deleted":result.deleted,"already_gone":result.already_gone,"s3_errors":result.s3_errors,"db_errors":result.db_errors,"skipped_encrypted":result.skipped_encrypted,"parse_errors":result.parse_errors,"bucket_out_of_scope":result.bucket_out_of_scope,"drift_skips":result.drift_skips})
    );
    // The normal hourly collector may reclaim an older owned location while
    // this test binary builds. The final inventory still checks every prefix.
    assert!(result.scanned <= 10);
    assert_eq!(result.deleted + result.already_gone, result.scanned);
    assert_eq!(
        result.s3_errors
            + result.db_errors
            + result.skipped_encrypted
            + result.parse_errors
            + result.bucket_out_of_scope
            + result.drift_skips,
        0
    );
    Ok(())
}
