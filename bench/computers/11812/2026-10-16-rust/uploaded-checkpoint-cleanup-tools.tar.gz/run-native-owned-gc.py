#!/usr/bin/env python3
"""Run the pinned native collector against only the ten owned test locations."""
import base64
import hashlib
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess
import time
import urllib.parse
import urllib.request

HOME = Path.home()
REPORT = HOME / 'evidence/upload-cleanup-11812.json'
report = json.loads(REPORT.read_text())
ids = [row['location_id'] for row in report['before']]
assert len(ids) == len(set(ids)) == 10

def kube(*argv):
    return subprocess.check_output(['kubectl', *argv], text=True, stderr=subprocess.DEVNULL)

def sql(query):
    command = 'PGPASSWORD=${POSTGRES_PASSWORD:-} psql -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-postgres}" -Atc ' + shlex.quote(query)
    return json.loads(kube('exec', '-n', 'space', 'space-postgres-0', '--', 'sh', '-c', command))

owned = ','.join("'" + value + "'" for value in ids)
rows = json.loads((HOME/'evidence/upload-cleanup-control-11812.json').read_text())
assert len(rows) == 10
expected = {row['id']: row['storage_connection_string'] for row in rows}
current = sql("SELECT COALESCE(json_agg(json_build_object('id',id,'uri',storage_connection_string)), '[]'::json) FROM snapshot_storage_locations WHERE id IN ("+owned+")")
assert all(expected[row['id']] == row['uri'] for row in current)
for row in rows:
    uri = urllib.parse.urlsplit(row['storage_connection_string'])
    assert uri.netloc == 'snapshots'
    assert sum('/'+resource.removeprefix('sbx_')+'/' in uri.path for resource in report['resources']) == 1
# No live runtime remains for the invalid old row; the native locked helper
# still checks upload/fork state before detaching its settled locations.
assert subprocess.run(['docker', 'exec', 'space-local-worker', 'test', '!', '-e', '/space/cache/firecracker/sandboxes/01a14771-109b-77ed-bd39-097363ae84c8']).returncode == 0
report['finalizer_preconditions']=sql("SELECT json_build_object('lifecycle',lifecycle,'placement',placement,'active_node_absent',active_node_id IS NULL,'target_node_absent',target_node_id IS NULL,'creating_snapshots',(SELECT count(*) FROM snapshots WHERE sandbox_id=sandboxes.id AND state='creating')) FROM sandboxes WHERE id='01a14771-109b-77ed-bd39-097363ae84c8'")
report['finalizer_preconditions']['worker_directory_absent']=True
operation=report['cleanup_retry']['accepted_operation']
request=urllib.request.Request(os.environ['SPACE_API_URL']+'/v1/operations/'+operation,headers={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN']})
with urllib.request.urlopen(request,timeout=30) as response:
    value=json.load(response)
report['cleanup_retry']['state']=value['state']
report['cleanup_retry']['invalid_lifecycle_reported']='invalid lifecycle' in str(value.get('terminal_error') or value.get('progress_message') or '')
deploy = json.loads(kube('get', 'deploy', '-n', 'space', 'space-cluster-controller', '-o', 'json'))
variables = {e['name']:e for c in deploy['spec']['template']['spec']['containers'] for e in c.get('env', [])}

def variable(name):
    entry=variables[name]
    if 'value' in entry:
        return entry['value']
    ref=entry['valueFrom']['secretKeyRef']
    secret=json.loads(kube('get','secret','-n','space',ref['name'],'-o','json'))
    return base64.b64decode(secret['data'][ref['key']]).decode()

def pg_variable(name, fallback):
    value=kube('exec','-n','space','space-postgres-0','--','sh','-c','printf %s "${' + name + ':-' + fallback + '}"')
    return value

env=dict(os.environ, AWS_ACCESS_KEY_ID=variable('AWS_ACCESS_KEY_ID'), AWS_SECRET_ACCESS_KEY=variable('AWS_SECRET_ACCESS_KEY'),
    AWS_REGION='us-east-1', AWS_DEFAULT_REGION='us-east-1', AWS_EC2_METADATA_DISABLED='true', AWS_PAGER='',
    PGUSER=pg_variable('POSTGRES_USER','postgres'), PGPASSWORD=pg_variable('POSTGRES_PASSWORD',''),
    PGDATABASE=pg_variable('POSTGRES_DB','postgres'), GC_OWNED_IDS=json.dumps(ids))
with socket.socket() as selected:
    selected.bind(('127.0.0.1',0))
    port=selected.getsockname()[1]
env['PGPORT']=str(port)
binary=HOME/'gc11812-bin/gc11812'
assert binary.is_file()
report['collector_binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
with (HOME/'evidence/native-gc-port-forward.log').open('wb') as log:
    proxy=subprocess.Popen(['kubectl','port-forward','-n','space','pod/space-postgres-0',str(port)+':5432','--address','127.0.0.1'],stdout=log,stderr=log)
    try:
        for _ in range(50):
            assert proxy.poll() is None
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=.2):
                    break
            except OSError:
                time.sleep(.1)
        else:
            raise RuntimeError('The isolated native database forward did not start')
        result=subprocess.run([str(binary)],env=env,capture_output=True,text=True,timeout=300)
        if result.returncode != 0:
            failure = HOME/'evidence/native-gc-private-error.log'
            failure.write_text(result.stdout + result.stderr)
            failure.chmod(0o600)
        assert result.returncode == 0, 'The scoped native collector did not finish'
        report['collector_result']=json.loads(result.stdout.strip().splitlines()[-1])
    finally:
        proxy.terminate()
        proxy.wait(timeout=15)

after=[]
for row in rows:
    uri=urllib.parse.urlsplit(row['storage_connection_string'])
    prefix=uri.path.lstrip('/').rstrip('/')+'/'
    assert uri.netloc=='snapshots' and sum('/'+r.removeprefix('sbx_')+'/' in prefix for r in report['resources'])==1
    call=subprocess.run(['aws','s3api','list-objects-v2','--bucket','snapshots','--prefix',prefix,'--region','us-east-1','--endpoint-url','http://127.0.0.1:8333','--output','json'],env=env,capture_output=True,text=True,timeout=60)
    assert call.returncode==0
    objects=json.loads(call.stdout).get('Contents',[])
    after.append({'location_id':row['id'],'prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest(), 'objects':len(objects),'bytes':sum(o['Size'] for o in objects)})
remaining=sql('SELECT json_build_object(\'locations\',(SELECT count(*) FROM snapshot_storage_locations WHERE id IN ('+owned+')),\'old_sandbox\',(SELECT count(*) FROM sandboxes WHERE id=\'01a14771-109b-77ed-bd39-097363ae84c8\'))')
assert remaining['locations']==remaining['old_sandbox']==0
assert all(row['objects']==row['bytes']==0 for row in after)
report['after']=after
report['remaining_native_rows']=remaining
report['native_finalizer_for_stale_owned_row']=True
report['same_store_loopback_endpoint_for_test']=True
report['passed']=True
REPORT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'owned_prefixes':10,'before_objects':sum(r['objects'] for r in report['before']),'before_bytes':sum(r['bytes'] for r in report['before']),'after_objects':0,'after_bytes':0,'collector_result':report['collector_result']}))
