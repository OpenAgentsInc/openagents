No explorer ran before you. The host gathered the evidence below before you started, and Jev, a decision model, judged what bears on the task. Treat it as evidence to check, not as orders.

## The task

Create a Python function called `async run_tasks(tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int) -> None` where each task is an async job to be run and `max_concurrent` is the max number of tasks that can be run concurrently. Put the function in a file called run.py so that it can be imported using `from run import run_tasks`.

Sometimes I cancel runs via keyboard interrupt but I want the tasks' cleanup code to still run.

## Requirements and whether Jev judged them met

- Create a Python function called `async run_tasks(tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int) -> None` where each task is an async job to be run and `max_concurrent` is the max number of tasks that can be run concurrently. (not judged)
- Put the function in a file called run.py so that it can be imported using `from run import run_tasks`. (not judged)
- Sometimes I cancel runs via keyboard interrupt but I want the tasks' cleanup code to still run. (not judged)

## What the explorer concluded

No explorer ran: the policy gives it no steps. The evidence below is what the host gathered before you started.

## What to do

Complete the task in the current working directory. Nobody answers questions, so decide from the task and the environment. An automated checker grades the final state of the environment against the task, so verify every requirement, including exact paths, names, and formats, before you stop. The files and command outputs in this briefing were gathered just before you started and are current: use them instead of re-running those commands, and go straight to the work. End with a short summary of what you changed and how you checked it.
