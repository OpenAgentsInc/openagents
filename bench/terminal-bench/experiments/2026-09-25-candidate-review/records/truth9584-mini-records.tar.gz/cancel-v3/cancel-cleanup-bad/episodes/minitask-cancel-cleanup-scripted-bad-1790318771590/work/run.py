import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    semaphore = asyncio.Semaphore(max_concurrent)

    async def one(task):
        async with semaphore:
            await task()

    workers = [asyncio.create_task(one(task)) for task in tasks]
    try:
        await asyncio.wait(workers)
    except asyncio.CancelledError:
        for worker_task in workers:
            worker_task.cancel()
        return
