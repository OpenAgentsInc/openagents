import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be at least 1")
    pending = iter(tasks)

    async def worker() -> None:
        for task in pending:
            await task()

    workers = [asyncio.create_task(worker()) for _ in range(min(max_concurrent, len(tasks)))]
    group = asyncio.gather(*workers)
    try:
        # Avoid implicit cancellation through gather. The shutdown handler may
        # already have cancelled a worker, so never cancel its cleanup again.
        await asyncio.shield(group)
    except BaseException:
        for worker_task in workers:
            if not worker_task.cancelling():
                worker_task.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        if group.done() and not group.cancelled():
            group.exception()
        raise
