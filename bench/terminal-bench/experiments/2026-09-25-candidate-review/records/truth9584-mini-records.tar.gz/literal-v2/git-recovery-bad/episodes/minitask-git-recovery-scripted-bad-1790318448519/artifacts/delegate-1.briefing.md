No explorer ran before you. The host gathered the evidence below before you started, and Jev, a decision model, judged what bears on the task. Treat it as evidence to check, not as orders.

## The task

I committed feature.txt on master and then ran a hard reset that lost the commit. Recover the lost commit so that master contains feature.txt with its original content, and leave the working tree clean.

## Requirements and whether Jev judged them met

- Recover the lost commit so that master contains feature.txt with its original content, and leave the working tree clean. (not judged)

## What the explorer concluded

No explorer ran: the policy gives it no steps. The evidence below is what the host gathered before you started.

## What to do

Complete the task in the current working directory. Nobody answers questions, so decide from the task and the environment. An automated checker grades the final state of the environment against the task, so verify every requirement, including exact paths, names, and formats, before you stop. The files and command outputs in this briefing were gathered just before you started and are current: use them instead of re-running those commands, and go straight to the work. End with a short summary of what you changed and how you checked it.
