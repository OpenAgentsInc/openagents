A repository with one feature.
