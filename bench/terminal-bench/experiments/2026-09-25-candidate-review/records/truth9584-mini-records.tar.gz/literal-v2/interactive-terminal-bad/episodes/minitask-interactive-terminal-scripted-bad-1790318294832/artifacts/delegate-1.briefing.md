No explorer ran before you. The host gathered the evidence below before you started, and Jev, a decision model, judged what bears on the task. Treat it as evidence to check, not as orders.

## The task

Implement the provided `BaseTerminal` interface in base_terminal.py. It provides a simple python interface to send keys to a headless terminal.

Make sure it supports the following functionality.

- Mimics a terminal, where the process starts as an interactive bash shell and commands are typically executed by typing characters and hitting Enter.
- Supports interactive programs.
- Has support for modifier keys like `"\x03"` for control C, etc.

Call your implementation `HeadlessTerminal(BaseTerminal)` and put it in a file called headless_terminal.py so that it can be imported as `from headless_terminal import HeadlessTerminal`.

## Requirements and whether Jev judged them met

- Implement the provided `BaseTerminal` interface in base_terminal.py. (not judged)
- Make sure it supports the following functionality. (not judged)
- - Mimics a terminal, where the process starts as an interactive bash shell and commands are typically executed by typing characters and hitting Enter. (not judged)
- - Supports interactive programs. (not judged)
- - Has support for modifier keys like `"\x03"` for control C, etc. (not judged)
- Call your implementation `HeadlessTerminal(BaseTerminal)` and put it in a file called headless_terminal.py so that it can be imported as `from headless_terminal import HeadlessTerminal`. (not judged)

## What the explorer concluded

No explorer ran: the policy gives it no steps. The evidence below is what the host gathered before you started.

## What to do

Complete the task in the current working directory. Nobody answers questions, so decide from the task and the environment. An automated checker grades the final state of the environment against the task, so verify every requirement, including exact paths, names, and formats, before you stop. The files and command outputs in this briefing were gathered just before you started and are current: use them instead of re-running those commands, and go straight to the work. End with a short summary of what you changed and how you checked it.
