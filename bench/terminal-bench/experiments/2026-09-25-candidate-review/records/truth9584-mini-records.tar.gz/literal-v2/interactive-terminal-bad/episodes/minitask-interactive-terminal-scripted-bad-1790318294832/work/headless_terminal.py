import subprocess

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """Runs each typed line with bash -c."""

    def __init__(self):
        self.buffer = ""
        self.output = ""

    def send_keystrokes(self, keystrokes, wait_sec=0.0):
        for ch in keystrokes:
            if ch == "\x03":
                self.buffer = ""
            elif ch in "\r\n":
                line, self.buffer = self.buffer, ""
                if line.strip():
                    done = subprocess.run(
                        ["bash", "-c", line],
                        capture_output=True,
                        text=True,
                        stdin=subprocess.DEVNULL,
                    )
                    self.output += done.stdout + done.stderr
            else:
                self.buffer += ch

    def close(self):
        pass
