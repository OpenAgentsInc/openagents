import os
import pty
import select
import signal
import time

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """An interactive Bash shell on a pseudo-terminal."""

    def __init__(self):
        pid, fd = pty.fork()
        if pid == 0:
            os.execvp("bash", ["bash", "-i"])
        self.pid = pid
        self.fd = fd
        self.output = ""
        self._drain(0.3)

    def _drain(self, seconds):
        end = time.monotonic() + seconds
        while True:
            left = max(end - time.monotonic(), 0)
            ready, _, _ = select.select([self.fd], [], [], left)
            if not ready:
                return
            try:
                data = os.read(self.fd, 65536)
            except OSError:
                return
            if not data:
                return
            self.output += data.decode(errors="replace")

    def send_keystrokes(self, keystrokes, wait_sec=0.0):
        os.write(self.fd, keystrokes.encode())
        self._drain(max(wait_sec, 0.05))

    def close(self):
        try:
            os.kill(self.pid, signal.SIGKILL)
            os.waitpid(self.pid, 0)
        except OSError:
            pass
