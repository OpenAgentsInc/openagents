No explorer ran before you. The host gathered the evidence below before you started, and Jev, a decision model, judged what bears on the task. Treat it as evidence to check, not as orders.

## The task

The directory logs/ holds log files named YYYY-MM-DD_<source>.log, each holding the logs of that date. Each log line contains an event with a severity level. Count how many times each severity appears in the following date ranges:
Today (the current date)
Last 7 days (including today)
Total (all log files combined, regardless of date)

The severity levels to count are exactly: ERROR, WARNING, and INFO.
Write a CSV file summary.csv with the following structure (including the header):
period,severity,count
today,ERROR,<count>
today,WARNING,<count>
today,INFO,<count>
last_7_days,ERROR,<count>
last_7_days,WARNING,<count>
last_7_days,INFO,<count>
total,ERROR,<count>
total,WARNING,<count>
total,INFO,<count>

The current date is 2025-08-12. Use this as the reference date for all calculations.
Keep the program that writes the summary as summarize.py, runnable as `python3 summarize.py LOG_DIR OUTPUT_CSV`.

## Requirements and whether Jev judged them met

- Count how many times each severity appears in the following date ranges: (not judged)
- Today (the current date) (not judged)
- Last 7 days (including today) (not judged)
- Total (all log files combined, regardless of date) (not judged)
- The severity levels to count are exactly: ERROR, WARNING, and INFO. (not judged)
- Write a CSV file summary.csv with the following structure (including the header): (not judged)
- period,severity,count today,ERROR,<count> today,WARNING,<count> today,INFO,<count> last_7_days,ERROR,<count> last_7_days,WARNING,<count> last_7_days,INFO,<count> total,ERROR,<count> total,WARNING,<count> total,INFO,<count> (not judged)
- Use this as the reference date for all calculations. (not judged)
- Keep the program that writes the summary as summarize.py, runnable as `python3 summarize.py LOG_DIR OUTPUT_CSV`. (not judged)

## What the explorer concluded

No explorer ran: the policy gives it no steps. The evidence below is what the host gathered before you started.

## What to do

Complete the task in the current working directory. Nobody answers questions, so decide from the task and the environment. An automated checker grades the final state of the environment against the task, so verify every requirement, including exact paths, names, and formats, before you stop. The files and command outputs in this briefing were gathered just before you started and are current: use them instead of re-running those commands, and go straight to the work. End with a short summary of what you changed and how you checked it.
