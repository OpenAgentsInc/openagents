import re
import sys
from collections import Counter
from datetime import date
from pathlib import Path

LEVELS = ("ERROR", "WARNING", "INFO")
REFERENCE = date(2025, 8, 12)
FIELD = re.compile(r"^\S+ \S+ \[(ERROR|WARNING|INFO)\]")


def main(logs, out):
    counts = {period: Counter() for period in ("today", "last_7_days", "total")}
    for path in sorted(Path(logs).glob("*.log")):
        age = (REFERENCE - date.fromisoformat(path.name[:10])).days
        for line in path.read_text().splitlines():
            match = FIELD.match(line)
            if not match:
                continue
            level = match.group(1)
            counts["total"][level] += 1
            if age == 0:
                counts["today"][level] += 1
            if 0 <= age < 7:
                counts["last_7_days"][level] += 1
    rows = ["period,severity,count"]
    for period in ("today", "last_7_days", "total"):
        rows += [f"{period},{level},{counts[period][level]}" for level in LEVELS]
    Path(out).write_text("\n".join(rows) + "\n")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "logs", sys.argv[2] if len(sys.argv) > 2 else "summary.csv")
