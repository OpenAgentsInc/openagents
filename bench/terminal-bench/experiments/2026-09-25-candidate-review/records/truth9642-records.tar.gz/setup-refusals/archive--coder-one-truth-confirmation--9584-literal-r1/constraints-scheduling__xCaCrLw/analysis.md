# Run analysis: `constraints-scheduling`, Coder One · truth-confirmation

Written by `gym runs analyze` (runs-analysis-v1). Code computed every number; Jev judged only the acceptance-test and verifier-test pairs the rules left open.

- Job: `archive--coder-one-truth-confirmation--9584-literal-r1`
- Trial: `constraints-scheduling__xCaCrLw`
- Read it with `gym runs show archive--coder-one-truth-confirmation--9584-literal-r1 --transcript`.

## Summary

- **Not graded: the harness hit an error (ContaminationError: the contamination check refused this trial: task-id 'distributed-dedup' at crate).**
- Cost $0, as Harbor reports it.

## Outcome

### The verifier

The trial kept no verifier test results. Outcome: not graded: the harness hit an error (ContaminationError: the contamination check refused this trial: task-id 'distributed-dedup' at crate).

### Time

| Span | Start (UTC) | Duration |
| --- | --- | ---: |
| Environment setup | 07:06:14.942 | 3.4 s |
| Agent setup | 07:06:18.387 | 0.2 s |
| Trial | 07:06:14.908 | 6.5 s |

### Cost

No per-session records: the cost is $0.

## Reversals

The run kept no session patches to compare, so reversals can't be rebuilt.

## Anomalies

None found.

