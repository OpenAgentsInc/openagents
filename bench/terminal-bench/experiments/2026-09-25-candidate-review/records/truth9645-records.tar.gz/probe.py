import json,math,subprocess
values = [1, 4, 8, 12, 41, 42, 107, 220, 209, 366, 144, 1681, 1764, 11449, 48400, 43681, 143, 1680, 1763, 11448, 48399, 43680, 145, 1682, 1765, 11450, 48401, 43682, 0, 65535, 65536, 99999, 100000, 100001, 1000000, 16777216, 4294967295]
mask=(1<<32)-1
f=[0,1]
for i in range(2,65536): f.append((f[-1]+f[-2]) & mask)
def doubling(n):
 if n==0:return (0,1)
 a,b=doubling(n//2)
 c=(a*(2*b-a)) & mask; d=(a*a+b*b) & mask
 return (d,(c+d)&mask) if n%2 else (c,d)
rows=[]
for n in values:
 k=math.isqrt(n); expected=f[k]
 assert expected==doubling(k)[0]
 p=subprocess.run(['/tmp/audit-sim',str(n)],capture_output=True,text=True,timeout=10)
 try:actual=int(p.stdout.strip())
 except ValueError:actual=None
 rows.append(dict(input=n,isqrt=k,expected=expected,actual=actual,exit=p.returncode,
                  stdout=p.stdout,stderr=p.stderr,matched=p.returncode==0 and actual==expected))
print(json.dumps(rows,indent=2))
