Write a script to result.txt.
