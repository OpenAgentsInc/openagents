Write scratch.txt. Clean up with:
```sh
rm scratch.txt
```
