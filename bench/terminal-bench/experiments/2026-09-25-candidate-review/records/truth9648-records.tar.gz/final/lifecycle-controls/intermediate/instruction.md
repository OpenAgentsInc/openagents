Write scratch.txt as an intermediate file, then delete it before finishing.
