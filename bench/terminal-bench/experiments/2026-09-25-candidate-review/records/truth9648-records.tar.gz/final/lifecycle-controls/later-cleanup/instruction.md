Write scratch.txt. Delete scratch.txt when finished.
