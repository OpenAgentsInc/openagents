Write result.txt. Delete /tmp/old.txt.
