Write /tmp/literal-lifecycle-umm1xo0h/work/nested/scratch.txt. Remove /tmp/literal-lifecycle-umm1xo0h/work/nested when finished.
