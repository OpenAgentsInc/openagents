Write scratch.txt. Remove it before finishing.
