Write scratch.txt. Rename scratch.txt to result.txt.
