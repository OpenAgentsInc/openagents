Write scratch.txt. Write result.txt. Delete scratch.txt.
