#!/bin/sh
set -eu
f=docs/coder/delegate.md
checks=0
passed=0
check() { checks=$((checks+1)); if eval "$1"; then passed=$((passed+1)); else echo "FAIL: $2"; fi; }
check "grep -q '\[../programs.md\]' '$f'" 'links to programs docs'
check "! sed -n '/## What is not built/,$ p' '$f' | grep -q \"Reaching a fan-out from an operator's sentence\"" 'stale unbuilt bullet removed'
check "grep -q 'git worktree list' '$f'" 'reviewer worktree instruction'
check "grep -q 'merge or remove' '$f'" 'reviewer completion options'
check "grep -q '\.coder/worktrees' '$f'" 'retained path stated'
echo "SCORE $passed $checks"
