#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
s=Path('docs/coder/delegate.md').read_text()
checks={
'runtime routing links to programs': all(x in s for x in ('coder::turn::run','openagents.program.v1','Runtime::run','../programs.md#how-a-sentence-reaches-it')),
'stale not-built bullet removed': "**Reaching a fan-out from an operator's sentence.**" not in s,
'reviewer can list, inspect, and finish': all(x in s for x in ('git worktree list','inspect its changes','merge them into your branch or remove the worktree')),
'writes retained under coder worktrees': '.coder/worktrees' in s and "writing delegation's stays where" in s,
'not-built section lists real missing feature': '## What is not built' in s and 'Grading what a delegate changed' in s,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + label)
print(f'SCORE {sum(checks.values())} {len(checks)}')
PY
