#!/bin/sh
set -eu
ok=0; total=5
[ -x scripts/coderdev ] && ok=$((ok+1))
grep -q 'cargo +1.97.1 build --package coder --bin coder' scripts/coderdev 2>/dev/null && ok=$((ok+1))
grep -q 'CARGO_TARGET_DIR' scripts/coderdev 2>/dev/null && ok=$((ok+1))
grep -q 'coderdev' README.md && ok=$((ok+1))
[ -f scripts/test-coderdev.sh ] && ok=$((ok+1))
echo "SCORE $ok $total"
