#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
src = Path('crates/coder/src/delegate.rs').read_text()
checks = [
    ('separate answer field', 'pub answer: String' in src),
    ('grading uses answer', 'normalize(&self.answer)' in src),
    ('stdout transcript preserved', 'output: reported.output' in src),
    ('final output extraction', 'fn final_message(transcript: &str)' in src),
    ('narration test covers done', 'final_message_separates_answer_without_discarding_narration' in src),
]
for label, passed in checks:
    print(f'{"PASS" if passed else "FAIL"}: {label}')
print(f'SCORE {sum(ok for _, ok in checks)} {len(checks)}')
PY
