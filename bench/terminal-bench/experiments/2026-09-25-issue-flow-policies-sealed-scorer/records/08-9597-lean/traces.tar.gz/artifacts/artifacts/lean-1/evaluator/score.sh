#!/bin/sh
set -eu
n=0; p=0
check(){ n=$((n+1)); if eval "$1"; then p=$((p+1)); else echo "FAIL: $2"; fi }
grep -qi 'fast local screen' docs/coder/guides/coder-one-minitasks.md && a=0 || a=1
check '[ "$a" -eq 0 ]' 'docs describe mini tasks as fast local screen'
check 'grep -qi "TB4\|Terminal-Bench 4" docs/coder/guides/coder-one-minitasks.md' 'TB4 relation documented'
check 'grep -qi "fast screens" crates/gym/src/coder_minitasks.rs' 'Gym view explains screen'
check 'grep -qi "cost\|\$0" docs/coder/guides/coder-one-minitasks.md' 'cost stated'
echo "SCORE $p $n"
