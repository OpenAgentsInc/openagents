#!/bin/sh
set -eu
f=docs/coder/delegate.md
p=0;t=4
if grep -Fq 'What is not built' "$f"; then p=$((p+1)); else echo 'FAIL: section'; fi
if grep -Fq '../programs.md' "$f" && ! grep -Fq "Reaching a fan-out from an operator's sentence." "$f"; then p=$((p+1)); else echo 'FAIL: stale bullet or missing program link'; fi
if grep -Fq 'git worktree list' "$f"; then p=$((p+1)); else echo 'FAIL: worktree reviewer instructions'; fi
if grep -Fq '.coder/worktrees' "$f" && grep -Fq 'merge' "$f" && grep -Fq 'remove' "$f"; then p=$((p+1)); else echo 'FAIL: retained worktree disposition'; fi
echo "SCORE $p $t"
