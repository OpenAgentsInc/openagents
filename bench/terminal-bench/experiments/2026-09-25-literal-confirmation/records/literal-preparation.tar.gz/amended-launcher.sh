#!/bin/sh
cd "$HOME/.cache/openagents/worktrees/truth-confirmation-gym" || exit
export PYTHONPATH=bench/terminal-bench
exec "$HOME/openagents/bench/terminal-bench/.venv/bin/python" bench/terminal-bench/experiments/2026-09-25-literal-confirmation/study.py "$@" \
 --protocol bench/terminal-bench/experiments/2026-09-25-literal-confirmation/protocol.json \
 --out "$HOME/.openagents/terminal-bench/experiments/truth-review-9584-literal-confirmation-v2" \
 --jobs "$HOME/.openagents/terminal-bench/jobs" \
 --binary "$HOME/.cache/openagents/artifacts/coder-one-retained-5e9aa12daf" \
 --check-binary "$HOME/.cache/openagents/artifacts/coder-one-literals-24e7864537" \
 --review-binary "$HOME/.cache/openagents/artifacts/coder-one-review-ca3c91b581" \
 --runtime "$HOME/.cache/openagents/artifacts/contract-runtime-ca3c91b581" \
 --preflight "$HOME/.openagents/terminal-bench/experiments/truth-review-9584-literal-confirmation-preflight" \
 --upstream "$HOME/.openagents/terminal-bench/upstream/terminal-bench"
