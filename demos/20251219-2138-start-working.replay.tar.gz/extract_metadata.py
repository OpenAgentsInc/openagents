import sys
import json
import re
from pathlib import Path

rlog_path = Path(sys.argv[1])
session_id = sys.argv[2]
date_dir = sys.argv[3]

metadata = {
    'session_id': session_id,
    'date': date_dir,
    'file_size_kb': round(rlog_path.stat().st_size / 1024, 1),
    'model': None,
    'tokens_in': 0,
    'tokens_out': 0,
    'tokens_cached': 0,
    'repo_sha': None,
    'branch': None,
    'tools_used': [],
}

with open(rlog_path, 'r') as f:
    in_header = False
    for line in f:
        if line.strip() == '---':
            if in_header:
                break
            in_header = True
            continue

        if in_header:
            if match := re.match(r'^(\w+):\s*(.+)', line):
                key, value = match.groups()
                if key in ['model', 'repo_sha', 'branch']:
                    metadata[key] = value.strip()
                elif key == 'tokens_total_in':
                    metadata['tokens_in'] = int(value)
                elif key == 'tokens_total_out':
                    metadata['tokens_out'] = int(value)
                elif key == 'tokens_cached':
                    metadata['tokens_cached'] = int(value)

    # Scan for tool usage
    f.seek(0)
    for line in f:
        if match := re.search(r't!:(\w+)', line):
            tool = match.group(1)
            if tool not in metadata['tools_used']:
                metadata['tools_used'].append(tool)

print(json.dumps(metadata, indent=2))
