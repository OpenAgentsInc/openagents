# Autopilot Demo Session

This bundle contains a complete autopilot session replay for demonstration purposes.

## Contents

- `session.rlog` - Complete session transcript in rlog format
- `metadata.json` - Session metrics and metadata
- `changes.diff` - Git diff of changes made during session
- `README.md` - This file

## Viewing the Replay

### Web Viewer

Upload `session.rlog` to the demo gallery viewer at:
https://openagents.com/demos/viewer

### CLI Replay (if available)

```bash
cargo run --bin replay-viewer session.rlog
```

## Session Details

See `metadata.json` for:
- Model used
- Token usage
- Tools invoked
- Files modified
- Completion status

## Quality Score

This session was selected based on:
- ✅ Successful completion
- ✅ Multiple tool usage (demonstrating capabilities)
- ✅ Real code changes
- ✅ Clear narrative flow
- ✅ Appropriate duration

## License

This replay log is provided for demonstration purposes as part of the OpenAgents project.
