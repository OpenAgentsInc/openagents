use atif::{Log, Session, Source, Step, log};
use coderbench::{Ending, Task, Verdict, Workspace};
use serde_json::json;
use std::fs;
use std::path::Path;

fn sample(path: &Path) -> Vec<Vec<u8>> {
    let session = Session::opening(
        "independent-trace",
        "fixture",
        "test",
        "/workspace",
        "fixture",
    );
    let mut writer = Log::create_at(path, &session).unwrap();
    writer
        .append(&Step::said(Source::User, "retained prefix"))
        .unwrap();
    writer
        .append(&Step::said(Source::Agent, "caf\u{e9} \u{1f680} suffix"))
        .unwrap();
    writer.finish(log::ENDED).unwrap();
    fs::read(path)
        .unwrap()
        .split_inclusive(|byte| *byte == b'\n')
        .map(Vec::from)
        .collect()
}

fn task() -> Task {
    serde_json::from_value(json!({
        "schema": coderbench::TASK_SCHEMA, "id": "independent-trace", "family": "trace",
        "request": "Read without changing the workspace", "requires": {},
        "grade": {"kind": "trace", "writes_expected": 0}, "timeout_secs": 1
    }))
    .unwrap()
}

fn verdict(path: &Path) -> Result<Verdict, String> {
    let mut observed = coderbench::observe(path)?;
    observed.ending = Ending::Answered;
    observed.workspace = Some(Workspace::default());
    Ok(task().judge(&observed).verdict)
}

#[test]
fn clean_round_trip_and_writer_closure() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("clean.jsonl");
    sample(&path);
    let recording = log::read(&path).unwrap();
    assert!(recording.ended());
    assert_eq!(recording.steps.len(), 2);
    assert_eq!(recording.unreadable_lines, 0);
    assert_eq!(verdict(&path).unwrap(), Verdict::Passed);

    let session = Session::opening("closed-writer", "fixture", "test", "/workspace", "fixture");
    let closed = directory.path().join("closed.jsonl");
    let mut writer = Log::create_at(&closed, &session).unwrap();
    writer
        .append(&Step::said(Source::User, "before closure"))
        .unwrap();
    writer.finish(log::ENDED).unwrap();
    let before = fs::read(&closed).unwrap();
    writer.finish(log::ENDED).unwrap();
    assert_eq!(fs::read(&closed).unwrap(), before);
    assert!(
        writer
            .append(&Step::said(Source::Agent, "after closure"))
            .is_err()
    );
    assert_eq!(fs::read(&closed).unwrap(), before);
}

#[test]
fn every_suffix_byte_keeps_the_valid_prefix_and_interruption_visible() {
    let directory = tempfile::tempdir().unwrap();
    let records = sample(&directory.path().join("template.jsonl"));
    assert_eq!(records.len(), 4);
    let prefix = [records[0].as_slice(), records[1].as_slice()].concat();
    let mut suffix = serde_json::to_vec(&json!({
        "record": "step",
        "step": Step::said(Source::Agent, "caf\u{e9} \u{1f680} suffix")
    }))
    .unwrap();
    suffix.push(b'\n');
    let path = directory.path().join("cut.jsonl");
    for cut in 0..=suffix.len() {
        let bytes = [prefix.as_slice(), &suffix[..cut]].concat();
        fs::write(&path, bytes).unwrap();
        let recording = log::read(&path).unwrap_or_else(|error| panic!("cut {cut}: {error}"));
        let complete = serde_json::from_slice::<serde_json::Value>(&suffix[..cut]).is_ok();
        if cut == suffix.len() {
            assert_eq!(recording.steps.len(), 2, "cut {cut}");
        } else if complete {
            assert!((1..=2).contains(&recording.steps.len()), "cut {cut}");
        } else {
            assert_eq!(recording.steps.len(), 1, "cut {cut}");
        }
        assert_eq!(recording.steps[0].message, "retained prefix");
        if recording.steps.len() == 2 {
            assert_eq!(recording.steps[1].message, "caf\u{e9} \u{1f680} suffix");
        }
        assert!(!recording.ended(), "cut {cut}");
        if cut > 0 && !complete {
            assert!(
                recording.unreadable_lines > 0,
                "cut {cut} hides its damaged suffix"
            );
        }
        if let Ok(result) = verdict(&path) {
            assert_ne!(result, Verdict::Passed, "cut {cut}");
        }
    }
}

#[test]
fn damaged_or_incomplete_records_never_become_successful_grades() {
    let directory = tempfile::tempdir().unwrap();
    let records = sample(&directory.path().join("template.jsonl"));
    let clean = records.concat();
    let cases = [
        (
            "repeated header",
            [records[0].clone(), clean.clone()].concat(),
        ),
        ("repeated end", [clean.clone(), records[3].clone()].concat()),
        (
            "step after end",
            [clean.clone(), records[1].clone()].concat(),
        ),
        (
            "malformed interior",
            [
                records[0].clone(),
                b"{broken}\n".to_vec(),
                records[1..].concat(),
            ]
            .concat(),
        ),
        (
            "invalid UTF-8 interior",
            [
                records[0].clone(),
                vec![0xf0, 0x9f, b'\n'],
                records[1..].concat(),
            ]
            .concat(),
        ),
        ("missing end", records[..3].concat()),
    ];
    let path = directory.path().join("damaged.jsonl");
    for (name, bytes) in cases {
        fs::write(&path, bytes).unwrap();
        if let Ok(recording) = log::read(&path) {
            if name == "missing end" {
                assert!(!recording.ended());
            } else if name == "malformed interior" || name == "invalid UTF-8 interior" {
                assert!(
                    recording.unreadable_lines > 0,
                    "{name}: corruption was hidden"
                );
            }
        }
        if let Ok(result) = verdict(&path) {
            assert_ne!(
                result,
                Verdict::Passed,
                "{name}: damaged evidence was graded"
            );
        }
    }
}
