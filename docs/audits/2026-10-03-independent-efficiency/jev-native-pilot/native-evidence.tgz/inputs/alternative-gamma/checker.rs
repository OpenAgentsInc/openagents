use std::io::{BufRead, BufReader, Read, Write};
use std::net::TcpListener;
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

use indexmap::IndexMap;
use jev::{
    BlockingClient, Choice, Client, Config, Entry, Error, Noul, Questions, RawResponse,
    RetryPolicy, Score, SystemOneRequest, SystemOneResponse,
};
use serde_json::{Value, json};

fn envelope(answer: Value) -> Value {
    json!({"model":"synthetic", "answers":{"q":answer}, "usage":{"input_tokens":1,"output_tokens":1}})
}

fn decode(value: Value) -> jev::Result<SystemOneResponse> {
    SystemOneResponse::decode(RawResponse {
        status: 200,
        headers: Default::default(),
        bytes: serde_json::to_vec(&value).unwrap(),
    })
}

fn rejected(result: jev::Result<SystemOneResponse>, label: &str) {
    match result {
        Err(
            Error::ResponseValidation { .. }
            | Error::MissingAnswer { .. }
            | Error::AnswerType { .. },
        ) => {}
        other => panic!("{label}: expected structured response rejection, got {other:?}"),
    }
}

fn valid_answers() -> Value {
    json!({
        "n":{"type":"noul","noul":0.2,"selected":"yes"},
        "c":{"type":"choice","choice":"right","confidence":0.3,"probabilities":{"left":0.8,"right":0.2}},
        "s":{"type":"score","score":0.4,"confidence":0.3,"selected":"2","legend":{"0":"Low","1":"Medium","2":"High"},"probabilities":{"0":0.7,"1":0.2,"2":0.1}}
    })
}

fn legacy_answers() -> Value {
    let mut answers = valid_answers();
    answers["s"]
        .as_object_mut()
        .unwrap()
        .remove("probabilities");
    answers["s"].as_object_mut().unwrap().remove("selected");
    answers
}

fn response(answers: Value) -> Value {
    json!({"model":"synthetic","answers":answers})
}

fn request() -> SystemOneRequest {
    let mut options = IndexMap::new();
    options.insert("left".to_string(), Some(Entry::from("Left option")));
    options.insert("right".to_string(), Some(Entry::from("Right option")));
    let questions = Questions::new()
        .with(
            "n",
            Noul::new("Does the synthetic fixture satisfy the condition?"),
        )
        .with("c", Choice::new("Which fixture option applies?", options))
        .with(
            "s",
            Score::new(
                "Rate the synthetic fixture.",
                vec![
                    Some(Entry::from("Low")),
                    Some(Entry::from("Medium")),
                    Some(Entry::from("High")),
                ],
            ),
        );
    SystemOneRequest::new("An offline transport fixture", questions)
}

fn config(base: &str) -> Config {
    Config::new()
        .api_key("synthetic-fixture-not-a-real-key")
        .base_url(base)
        .timeout(Duration::from_secs(2))
        .retry(RetryPolicy {
            max_retries: 0,
            ..RetryPolicy::default()
        })
}

fn serve(body: Value) -> (String, JoinHandle<()>) {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    listener.set_nonblocking(true).unwrap();
    let address = format!("http://{}", listener.local_addr().unwrap());
    let body = serde_json::to_vec(&body).unwrap();
    let worker = std::thread::spawn(move || {
        let deadline = Instant::now() + Duration::from_secs(3);
        let mut socket = loop {
            match listener.accept() {
                Ok((socket, _)) => break socket,
                Err(error)
                    if error.kind() == std::io::ErrorKind::WouldBlock
                        && Instant::now() < deadline =>
                {
                    std::thread::sleep(Duration::from_millis(2))
                }
                other => panic!("mock request did not arrive: {other:?}"),
            }
        };
        socket
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        socket
            .set_write_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let mut reader = BufReader::new(socket.try_clone().unwrap());
        let mut length = 0usize;
        loop {
            let mut line = String::new();
            assert!(reader.read_line(&mut line).unwrap() > 0);
            if line == "\r\n" {
                break;
            }
            if let Some(value) = line.to_ascii_lowercase().strip_prefix("content-length:") {
                length = value.trim().parse().unwrap();
            }
        }
        assert!(length < 65536);
        let mut request_body = vec![0; length];
        reader.read_exact(&mut request_body).unwrap();
        let headers = format!(
            "HTTP/1.1 200 OK\r\ncontent-type: application/json\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
            body.len()
        );
        socket.write_all(headers.as_bytes()).unwrap();
        socket.write_all(&body).unwrap();
        socket.flush().unwrap();
    });
    (address, worker)
}

#[test]
fn numeric_contract_rejects_invalid_answers_and_keeps_valid_calibrated_values() {
    for value in [0.0, 1.0] {
        assert!(decode(envelope(json!({"type":"noul","noul":value}))).is_ok());
    }
    let valid = valid_answers();
    assert!(decode(response(valid.clone())).is_ok());
    assert!(decode(response(legacy_answers())).is_ok());
    let malformed = [
        json!({"type":"noul","noul":-2.0}),
        json!({"type":"noul","noul":1.2}),
        json!({"type":"choice","choice":"a","confidence":-0.2,"probabilities":{"a":0.5,"b":0.5}}),
        json!({"type":"choice","choice":"a","confidence":1.2,"probabilities":{"a":0.5,"b":0.5}}),
        json!({"type":"choice","choice":"a","confidence":0.5,"probabilities":{"a":-0.2,"b":1.2}}),
        json!({"type":"choice","choice":"a","confidence":0.5,"probabilities":{"a":0.1,"b":0.1}}),
        json!({"type":"choice","choice":"outside","confidence":0.5,"probabilities":{"a":0.5,"b":0.5}}),
        json!({"type":"choice","choice":"a","confidence":0.5,"probabilities":{}}),
        json!({"type":"score","score":-1.0,"confidence":0.5,"legend":{"0":"Low","1":"High"},"probabilities":{"0":0.5,"1":0.5}}),
        json!({"type":"score","score":3.0,"confidence":0.5,"legend":{"0":"Low","1":"High"},"probabilities":{"0":0.5,"1":0.5}}),
        json!({"type":"score","score":0.5,"confidence":1.2,"legend":{"0":"Low","1":"High"},"probabilities":{"0":0.5,"1":0.5}}),
        json!({"type":"score","score":0.5,"confidence":0.5,"legend":{},"probabilities":{}}),
        json!({"type":"score","score":0.5,"confidence":0.5,"legend":{"0":"Low","1":"High"},"probabilities":{"0":-0.1,"1":1.1}}),
        json!({"type":"score","score":0.5,"confidence":0.5,"legend":{"0":"Low","1":"High"},"probabilities":{"0":0.1,"1":0.1}}),
        json!({"type":"score","score":0.5,"confidence":0.5,"legend":{"0":"Low","1":"High"},"probabilities":{"0":0.5,"2":0.5}}),
    ];
    for (index, answer) in malformed.into_iter().enumerate() {
        rejected(decode(envelope(answer)), &format!("numeric case {index}"));
    }
}

fn request_mismatches() -> Vec<Value> {
    let mut missing = valid_answers();
    missing.as_object_mut().unwrap().remove("n");
    let mut wrong_kind = valid_answers();
    wrong_kind["n"] = json!({"type":"choice","choice":"yes","confidence":0.5,"probabilities":{"yes":0.5,"no":0.5}});
    let mut option = valid_answers();
    option["c"] = json!({"type":"choice","choice":"left","confidence":0.5,"probabilities":{"left":0.6,"outside":0.4}});
    let mut score = valid_answers();
    score["s"] = json!({"type":"score","score":0.4,"confidence":0.3,"selected":"1","legend":{"0":"Low","1":"Medium"},"probabilities":{"0":0.6,"1":0.4}});
    vec![missing, wrong_kind, option, score]
}

#[tokio::test]
async fn async_typed_calls_validate_the_requested_answer_and_option_set() {
    for answers in [valid_answers(), legacy_answers()] {
        let (base, worker) = serve(response(answers));
        let result = Client::new(config(&base))
            .unwrap()
            .system_one(request())
            .await;
        worker.join().unwrap();
        assert!(
            result.is_ok(),
            "valid calibrated or legacy response: {result:?}"
        );
    }
    for (index, answers) in request_mismatches().into_iter().enumerate() {
        let (base, worker) = serve(response(answers));
        let result = Client::new(config(&base))
            .unwrap()
            .system_one(request())
            .await;
        worker.join().unwrap();
        rejected(result, &format!("request case {index}"));
    }
}

#[test]
fn blocking_typed_calls_apply_the_same_request_contract() {
    for answers in [valid_answers(), legacy_answers()] {
        let (base, worker) = serve(response(answers));
        let result = BlockingClient::new(config(&base))
            .unwrap()
            .system_one(request());
        worker.join().unwrap();
        assert!(
            result.is_ok(),
            "valid calibrated or legacy blocking response: {result:?}"
        );
    }
    for (index, answers) in request_mismatches().into_iter().enumerate() {
        let (base, worker) = serve(response(answers));
        let result = BlockingClient::new(config(&base))
            .unwrap()
            .system_one(request());
        worker.join().unwrap();
        rejected(result, &format!("blocking request case {index}"));
    }
}

#[tokio::test]
async fn raw_transport_keeps_the_unvalidated_response_available() {
    let body = response(json!({"n":{"type":"noul","noul":-2.0}}));
    let (base, worker) = serve(body.clone());
    let client = Client::new(config(&base)).unwrap();
    let raw = client.system_one_raw(request()).await.unwrap();
    assert_eq!(raw.status().as_u16(), 200);
    let observed: Value = raw.json().await.unwrap();
    worker.join().unwrap();
    assert_eq!(observed, body);
}
