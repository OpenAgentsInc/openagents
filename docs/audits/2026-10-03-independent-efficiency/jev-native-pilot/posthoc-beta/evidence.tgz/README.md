# Retrospective beta diagnostic draft

`posthoc_trace_integrity.rs` is an uncompiled, unexecuted draft for a separate integration target in `coderbench`. It uses only public APIs available at task source `7ec5f6e83d018ab2f25d7a61ff695de81f2f55f6`. No model, Cargo command, candidate repair, or checker change has been performed.

Three tests cover a clean positive control, a valid step moved before its session header, and a form-feed byte inserted before a valid interior record. The latter retains a later valid step and an end record, so it is an interior-corruption case. Each malformed test first verifies its own clean trace succeeds. The consumer may reject the damaged trace or return any non-Passed verdict; no candidate-specific diagnostic field or implementation strategy is required.

The before-header case follows the pinned ATIF format's statement that the session record comes first. The form-feed case follows JSON syntax and the public requirement that malformed interior evidence cannot become a successful benchmark grade. Setting the independently observed ending to Answered and workspace to unchanged reproduces the public consumer's driver inputs; it does not modify the trace's integrity observations.

This draft was prepared after static review of anonymized candidates. It is post hoc and must remain separate from the frozen primary checker, acceptance scores, and pilot decisions. Do not expose it to active executors. Any later execution should use the unchanged draft across all beta candidates being compared, preserve every result and candidate identity, and report its time and failures separately. A failure demonstrates the named case, not general incorrectness; passing these three cases is not exhaustive verification.

## Runner draft

`run_posthoc.py` is also unexecuted. Only Python syntax parsing was performed. It refuses to start unless the original panel receipt says complete, binds the frozen plan, names all 12 original attempts, and every original receipt has confirmed closure, accounting, and safe continuation. It also takes the panel lock and the existing agent3 calibration lock; it never starts or resumes a native session.

The runner verifies the frozen harness closure and diagnostic hash, then checks eight revisions sequentially: the separately qualified historical reference, the unchanged base, and all six beta native candidates from the plan. Candidate artifacts and primary receipts are read only. The reference payload is bound to the prior qualification's exact hashes. Control manifests are created from private copies against the same source archive. It expects the reference to pass and the base to pass ordinary tests but fail the new diagnostic; a surprising control result stops the diagnostic without tuning or retry.

For every revision, it reuses `check_candidate.py` with exactly the task's source, seed, package scope, feature settings, toolchain and 240-second deadline. Only the independent checker path/target changes to `posthoc_trace_integrity`. This re-runs ordinary tests and formatting because the existing acceptance harness composes those phases; it is not a claim that only the three diagnostic functions consume time. All failures, check logs, timing, candidate identities and cleanup receipts are retained outside the primary attempt directories. Unknown execution closure or failed cleanup stops the sequence. No model or network inference is called.

Upload the runner, diagnostic, and only the two reference payload files to a private directory outside every executor mount. The source reference files are currently retained locally at:

`~/.codex/analyses/openagents/delegation-study-4/eligibility-alternatives/screen-2/qualification/alternative-beta/inputs/reference/{candidate.tar.gz,changes.json}`

After the native panel has finished, the root agent can invoke:

```sh
python3 /private/posthoc-beta/run_posthoc.py \
  --plan /home/user/jev-native-pilot/plan/plan.json \
  --panel-receipt /path/to/completed-panel/panel.json \
  --harness-dir /home/user/jev-native-pilot/bench/delegation-study \
  --reference-candidate /private/posthoc-beta/reference \
  --diagnostic /private/posthoc-beta/posthoc_trace_integrity.rs \
  --output /private/posthoc-beta/results
```

The output must be new. There is no automatic resume or retry. The private result maps new blind IDs to original run UUIDs but does not need arm names; keep that mapping away from a blinded source reviewer. Historical full beta checks took about 18 seconds per revision; eight unchanged-cost checks would be about 2.4 minutes, but new compilation, test failures, and cleanup can make this longer. The upper phase allowance is eight times 240 seconds plus driver validation and cleanup, not a promised completion time.
