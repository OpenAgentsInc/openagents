import json,os,shutil,urllib.request
from pathlib import Path
h=Path.home(); s=h/'evidence/environment-11811-state-attempt5'
v=json.loads((h/'evidence/environment-11811-create-v1-outcome.json').read_text());assert v['/v1/operations/op_01a1467f-e4fc-733f-8f23-cbcdddd3d3fe']['body']['state']=='failed';assert v['/v1/sandboxes/sbx_01a1467f-e4fa-71ac-9530-eca0eb410aa1']['status']==404
f=s/'failed-fresh-space-v1';f.mkdir();shutil.move(s/'fresh-verifier.json',f/'fresh-verifier.json');shutil.move(s/'environment-build/evidence/bj-ba9692505d5371a90120d557/space-publication',f/'space-publication')
p=s/'published-template.json';shutil.copyfile(p,s/'published-template-builder.json')
u='http://127.0.0.1:8080/admin/api/v1/templates/oaenv-build-8-6d90501c6584ca4cc0f87404-space';headers={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN']};http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with http.open(urllib.request.Request(u,headers=headers),timeout=30) as r:z=json.load(r)
assert z['content_hash']=='sha256:e6acdf145f1ae239fce3c8de014d8aaa975ab3aceb7106557a6ca587defddef2';p.write_text(json.dumps(z,indent=2));print(json.dumps({'previous_create_terminal':'failed','previous_sandbox':404,'publication_refreshed':True,'snapshots':z['snapshots']}))
