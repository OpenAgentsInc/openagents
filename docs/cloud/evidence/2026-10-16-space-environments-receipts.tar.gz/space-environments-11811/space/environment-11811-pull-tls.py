import json,os,socket,subprocess,time,urllib.request,urllib.error
from pathlib import Path
h=Path.home(); assert str(h)=='/var/lib/space-spike/home'; assert socket.gethostname().startswith('oa-space-spike-11811')
s=h/'evidence/environment-11811-state-attempt5'; w=json.loads((s/'publication-work.json').read_text()); p=json.loads((s/'published-template.json').read_text())
assert p['name']==w['accepted']['template_name'] and p['content_hash']==w['rootfs']
assert p['name']=='oaenv-build-8-6d90501c6584ca4cc0f87404-space'
b=h/'evidence/environment-11811-worker-pull-tls.json'; assert not b.exists()
req={'template_id':p['name'],'content_hash':w['rootfs'],'sources':[{'node':{'address':'172.18.0.4:9800'}}],'include_snapshot':True,'snapshot_vcpu':2,'snapshot_memory_mib':4096,'skip_if_exists':True,'block_on_snapshot_policy_achieved':True}
r={'request':req,'started_ms':int(time.time()*1000),'method':'space.node.api.v1.WorkerApi/PullTemplate'}; b.write_text(json.dumps(r,indent=2))
k=['kubectl','-n','space']; pod=json.loads(subprocess.check_output(k+['get','pods','-o','json'],text=True))['items']; pod=next(p['metadata']['name'] for p in pod if p['metadata']['name'].startswith('space-api-') and p['status']['phase']=='Running')
ca=h/'evidence/node-api-public-ca.crt'; ca.write_bytes(subprocess.check_output(k+['exec',pod,'--','cat','/etc/space-rpc-ca/ca.crt']))
node_token=subprocess.check_output(k+['exec',pod,'--','cat','/var/run/space-auth/node-api.token'],text=True).strip()
env=dict(os.environ,OA_NODE_API_TOKEN=node_token)
cmd=[str(h/'grpcurl-11811'),'-max-time','600','-cacert',str(ca),'-authority','space-node-api','-expand-headers','-H','authorization: Bearer ${OA_NODE_API_TOKEN}','-import-path',str(h/'SPACE/proto'),'-proto','node/api/v1/worker.proto','-d',json.dumps(req),'172.18.0.3:9800',r['method']]
z=subprocess.run(cmd,text=True,capture_output=True,timeout=610,env=env); r.update(code=z.returncode,stdout=z.stdout,stderr=z.stderr,finished_ms=int(time.time()*1000)); b.write_text(json.dumps(r,indent=2)); print(json.dumps(r)); assert z.returncode==0
for f in ['template-inventory','node-status']:
 z=subprocess.run(['docker','exec','space-local-worker','/space/bin/space-nodectl','reconcile','--facet',f],text=True,capture_output=True); print(f,z.returncode,z.stdout,z.stderr)
