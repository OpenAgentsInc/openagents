import subprocess,json,os,urllib.request
k=['kubectl','-n','space']; patch={'spec':{'template':{'spec':{'containers':[{'name':'node-ctl','args':['--poll-interval-secs=5']}]}}}}
subprocess.run(k+['patch','daemonset','space-node-ctl','--type=strategic','--patch',json.dumps(patch)],check=True)
subprocess.run(k+['rollout','status','daemonset/space-node-ctl','--timeout=120s'],check=True)
h={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN'],'Content-Type':'application/json'};http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for path,method,data in [('/admin/api/v1/nodes:refresh-status','POST',json.dumps({'role':'worker','force':True}).encode()),('/admin/api/v1/nodes?include_occupancy=false','GET',None)]:
 with http.open(urllib.request.Request('http://127.0.0.1:8080'+path,method=method,data=data,headers=h),timeout=60) as r:
  out=json.load(r)
  if isinstance(out,list):out=[x for x in out if x.get('role')=='worker' and x.get('managed_by')=='space']
  print(json.dumps(out))
