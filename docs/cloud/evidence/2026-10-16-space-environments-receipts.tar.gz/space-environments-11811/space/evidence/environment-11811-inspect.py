import os,json,subprocess,urllib.request,urllib.error
from pathlib import Path
home=Path.home(); assert str(home)=='/var/lib/space-spike/home'
w=json.loads((home/'evidence/environment-11811-state-attempt4/publication-work.json').read_text());j=json.loads((home/'evidence/frozen-build-7.json').read_text());name=j['inputs']['image_name']+'-space'
k=['kubectl','--context','kind-space-local','-n','space']
pods=json.loads(subprocess.check_output(k+['get','pods','-l','app.kubernetes.io/name=space-postgres','-o','json']))['items'];assert len(pods)==1
sql="SELECT template_id,build_id,daemon_job_id,builder_node_id FROM template_build_jobs WHERE template_id='"+name+"';"
r=subprocess.run(k+['exec','-i',pods[0]['metadata']['name'],'--','sh','-c','exec psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -At -v ON_ERROR_STOP=1'],input=sql,text=True,capture_output=True,check=True);print('BUILD_ROWS',r.stdout)
http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
req=urllib.request.Request('http://127.0.0.1:8080/admin/api/v1/nodes?include_occupancy=false',headers={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN']})
with http.open(req,timeout=30) as r: nodes=json.load(r)
print('NODES',json.dumps([{a:n.get(a) for a in ('id','role','managed_by','state','scheduling_status','address','name','node_api_endpoint')} for n in nodes]))
for n in ('space-local-worker4','space-local-worker5'):
 r=subprocess.run(['docker','exec',n,'sh','-c','find /space/cache/firecracker/builds -mindepth 1 -maxdepth 2 -type d'],text=True,capture_output=True,check=True);print('BUILDER_CACHE',n,r.stdout)

refresh=urllib.request.Request('http://127.0.0.1:8080/admin/api/v1/nodes:refresh-status',method='POST',data=json.dumps({'role':'builder','force':True}).encode(),headers={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN'],'Content-Type':'application/json'})
with http.open(refresh,timeout=60) as r: print('BUILDER_REFRESH',r.status,r.read(10000).decode().replace(os.environ['SPACE_API_TOKEN'],'[credential]'))
sql="SELECT n.id,n.managed_by,nss.reachable,nss.stale_after > NOW(),nss.scheduling_status FROM nodes n LEFT JOIN node_status_snapshots nss ON nss.node_id=n.id WHERE n.role='builder';"
r=subprocess.run(k+['exec','-i',pods[0]['metadata']['name'],'--','sh','-c','exec psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -At -v ON_ERROR_STOP=1'],input=sql,text=True,capture_output=True,check=True);print('CACHED_BUILDER_STATUS',r.stdout)
probe='/admin/api/v1/templates/'+name+'/builds/00000000-0000-4000-8000-000000011811'
req=urllib.request.Request('http://127.0.0.1:8080'+probe,headers={'Authorization':'Bearer '+os.environ['SPACE_API_TOKEN']})
try:r=http.open(req,timeout=60)
except urllib.error.HTTPError as e:r=e
with r: print('READ_ONLY_BUILD_ROUTE',r.status,r.read(4096).decode().replace(os.environ['SPACE_API_TOKEN'],'[credential]'))

for n in nodes:
 if n.get('managed_by')=='space' and n.get('role')=='builder': print('BUILDER_STATUS_FIELDS',{a:n.get('status',{}).get(a) for a in ('observed_at','stale_after','stale','reachable','scheduling')})
