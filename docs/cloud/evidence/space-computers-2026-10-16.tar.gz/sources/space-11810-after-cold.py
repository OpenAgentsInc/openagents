import hashlib,json,os,subprocess,time
from pathlib import Path
home=Path.home();assert home==Path('/var/lib/space-spike/home')
evidence=home/'evidence';journal=evidence/'direct-positive-sequence-11810.json'
assert not journal.exists()
report={'steps':[]}
def save(step):
 report['steps'].append({'step':step,'at_unix':time.time()});journal.write_text(json.dumps(report,indent=2)+'\n')
def bench(name,count):
 result=subprocess.run(['python3',str(home/'computers-bench-qualified-11810.py'),'snapshot',str(evidence/name),'--count',str(count),'--binary',str(home/'oa-computers-11810-operation-wait'),'--observer',str(home/'boot-mode.py')])
 data=json.loads((evidence/name).read_text())
 assert data['count']==count and len(data['samples'])==count and not data['cleanup_errors']
 assert all(row['passed'] for row in data['samples'])
 if count==20: assert result.returncode==0 and data['passed']
 save(name)
save('waiting for the cold run; no concurrent guests')
deadline=time.monotonic()+1800
while subprocess.run(['systemctl','is-active','--quiet','space-computers-cold20-11810'],stdout=subprocess.DEVNULL).returncode==0:
 assert time.monotonic()<deadline
 time.sleep(1)
cold=json.loads((evidence/'direct-cold20-11810.json').read_text());assert cold['passed'] and cold['count']==20 and all(r['deleted'] for r in cold['samples'])
runner=home/'computers-bench-qualified-11810.py';assert hashlib.sha256(runner.read_bytes()).hexdigest()=='6fc7d4c91249b09579b4d5f439e3f806507d71fa23f1a352e4ecedb2bbedb25d'
save('twenty actual cold creates and cleanup passed')
subprocess.run(['python3',str(home/'prepare-snapshot.py'),'on',str(evidence/'direct-base-on-11810.json')],check=True)
save('clean two-vCPU 1024-MiB base snapshot prepared')
bench('direct-snapshot-pilot-11810.json',1)
bench('direct-snapshot20-11810.json',20)
report['passed']=True;save('positive qualification passed')
