import json,subprocess,time
from pathlib import Path
home=Path.home();assert home==Path('/var/lib/space-spike/home')
evidence=home/'evidence';journal=evidence/'direct-fault-sequence-11810.json';assert not journal.exists()
report={'steps':[]}
def save(step):
 report['steps'].append({'step':step,'at_unix':time.time()});journal.write_text(json.dumps(report,indent=2)+'\n')
def bench(arm,name,*options):
 subprocess.run(['python3',str(home/'computers-bench-faults-11810.py'),arm,str(evidence/name),'--count','1','--binary',str(home/'oa-computers-11810-operation-wait'),'--observer',str(home/'boot-mode.py'),*options],check=True)
 data=json.loads((evidence/name).read_text());assert data['passed'] and not data['cleanup_errors'] and data['database_fixture_removed'];save(name)
save('waiting for the twenty-snapshot run; no concurrent guests')
deadline=time.monotonic()+2400
while subprocess.run(['systemctl','is-active','--quiet','space-computers-positive-sequence-11810'],stdout=subprocess.DEVNULL).returncode==0:
 assert time.monotonic()<deadline
 time.sleep(1)
positive=json.loads((evidence/'direct-positive-sequence-11810.json').read_text());assert positive['passed']
with (evidence/'direct-conformance-11810.txt').open('w') as log:
 result=subprocess.run([str(home/'computer-conformance-11810-operation-wait'),'--space','--size','small'],stdout=log,stderr=subprocess.STDOUT)
report['conformance_exit']=result.returncode;save('Core/Suspend and unsupported Snapshot/Fork conformance finished')
assert result.returncode==0
bench('cold','direct-incompatible-medium-11810.json','--size','medium','--vcpu','4','--memory-mib','4096','--scenario','incompatible-shape')
bench('cold','direct-incompatible-large-11810.json','--size','large','--vcpu','8','--memory-mib','8192','--scenario','incompatible-shape')
try:
 subprocess.run(['python3',str(home/'corrupt-snapshot.py'),'corrupt'],check=True)
 save('only the clean base VM-state file is corrupt; verified original backup kept')
 bench('snapshot','direct-corrupt-refusal-11810.json','--scenario','corrupt-snapshot','--expect-refusal')
finally:
 path=evidence/'direct-corruption-11810.json'
 if path.exists() and json.loads(path.read_text()).get('backup_verified'):
  subprocess.run(['python3',str(home/'corrupt-snapshot.py'),'restore'],check=True)
  save('original clean base VM-state file restored and its hash verified')
report['passed']=True;save('conformance and fault checks passed')
