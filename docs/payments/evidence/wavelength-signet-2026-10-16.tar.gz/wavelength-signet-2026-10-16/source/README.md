# Wavelength signet spike

This is a throwaway Rust gRPC client for OpenAgents issue #11770. It is
outside the product workspace and refuses any daemon network other than signet.
It has no wallet creation, unlock, seed, signing, or credential-provisioning
command. Provision the wallet and its scoped macaroon through `wavecli`.

The wallet proto comes unchanged from Lightning Labs Wavelength v0.1.2,
commit `903aec7f1bb38475b563a1a7b49e0711e2df20a5`. Its SHA-256 is
`40cc8df4dd735cc15f852cd22ecc64aafe4b34020bc72403f1f6eebb576266bf`.
The upstream MIT license is in `proto/LICENSE`.
The boarding call uses the same tag's `waverpc/daemon.proto`, SHA-256
`cf18b7b4a31fef98ba9881474260d943bb7405122c57c5e73f9e7d8dbed6ba33`.
The diagnostic proof call uses `swapclientrpc/swap_client.proto`, SHA-256
`24e7715e624efbc9153520c30688e7c3cf3304af445e5fb8ef5b11f9c7189495`.

Build with Rust 1.97.1 and `protoc`. Set `CARGO_TARGET_DIR` to an existing
target directory outside this scratch source. The `WAVE_SPIKE_ROOT`
environment variable names the scratch directory on the test machine.

The client expects TLS on loopback port 10029, a trusted CA at `tls/ca.crt`,
and a provisioned `agent.macaroon`. Use a CA-signed localhost leaf certificate:
the daemon's generated CA certificate fails Rust's end-entity certificate check.
The setup script creates only scratch TLS material. It assumes a fresh signet
wallet was already created through the CLI and its daemon PID was saved.

Available commands:

- `status`, `balance`, `activity`, `vtxos`, and `onchain` read wallet state.
- `deposit` creates a boarding address with a 100,000-sat accounting hint.
- `board` queues two boarding outputs through `waverpc`, using a separate
  `board.macaroon` that allows only that method.
- `recv SATS` creates a Lightning invoice.
- `prepare INVOICE_FILE` obtains a quote with a 100-sat fee cap.
- `send INTENT_ID` consumes a previously reviewed send intent once.
- `plan OUTPOINT`, `exit OUTPOINT [ACK]`, and `exit-status OUTPOINT` inspect
  and request exits. The acknowledgement is the upstream exact string.
- `watch HASH SECONDS` observes one payment, checks activity uniqueness, and
  verifies a returned preimage against its hash. `proof HASH` checks the
  payment proof without printing the preimage.
- `raw-proof HASH` checks the lower-level swap response with a separate
  `diagnostic.macaroon` allowing only `GetSwap`. v0.1.2 credit activity omits
  the proof and fee; the diagnostic response supplies both, but its principal
  is zero. Use the original invoice for the exact amount.
- `decode INVOICE_FILE` reports invoice terms without contacting a daemon.

Mutations have no automatic retry. After an uncertain response, inspect the
original payment or activity ID before doing anything else. `send` consumes
an expiring intent; a quote alone does not prove payment or fee enforcement.
The latency field covers the measured wallet RPC after TLS connection and a
network check, not startup or settlement. `watch` measures settlement separately.

The Python and shell files orchestrate test infrastructure. They use only
fresh signet state under `~/wavelength-spike`. Funding uses the faucet linked
by Wavelength's network documentation and follows its published PoW protocol.
The boarding script waits at most 45 minutes for funding confirmation.

`esplora-proxy` listens only on loopback port 3042 and checks the signet
genesis before forwarding to the fixed public signet API. It normalizes the
optional trailing `/tx/` path to `/tx`. It has no wallet authority. The tested
Lightning Labs endpoint rejects broadcasts; the installed client source uses
`/tx`, so the error text does not establish a client path bug. Direct LDK
broadcasting to the default public endpoint was not isolated in this run.

The newer `85cfb979` research snapshot fails against the public operator
with an Ark protocol-version mismatch and migrates the database beyond the
release's supported version. The test retains both the pre-upgrade copy and
the full upgraded state. Its pending payment is not retried. Do not treat the
snapshot build as a successful wallet test.

The evidence bundle excludes seeds, wallet databases, passwords, macaroons,
private keys, and raw payment preimages. Restore or repeat the test with a
fresh wallet; this bundle cannot restore the test wallet.
