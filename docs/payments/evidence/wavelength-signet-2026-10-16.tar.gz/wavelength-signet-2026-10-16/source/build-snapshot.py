import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

root=Path.home()/'wavelength-spike'
def extract(archive, destination):
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not (member.isfile() or member.isdir()) or not (destination/member.name).resolve().is_relative_to(destination.resolve()):
                raise RuntimeError(f'unsupported archive member: {member.name}')
        tar.extractall(destination)
revision='85cfb97905a27c420338c2a5bd688a4a7d2147b1'
pin=json.loads((root/'go-toolchain-pin.json').read_text())
archive=root/pin['filename']
subprocess.run(['curl','-fsSL','--max-time','180',f'https://go.dev/dl/{pin["filename"]}','-o',str(archive)],check=True)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==pin['sha256']
toolchain=root/'go-toolchain'
toolchain.mkdir(exist_ok=True)
extract(archive,toolchain)
source_archive=root/'snapshot-source.tar.gz'
subprocess.run(['curl','-fsSL','--max-time','180',f'https://codeload.github.com/lightninglabs/wavelength/tar.gz/{revision}','-o',str(source_archive)],check=True)
extract(source_archive,root)
source=root/f'wavelength-{revision}'
output=root/'snapshot-bin'
output.mkdir(exist_ok=True)
environment=dict(os.environ,PATH=f'{toolchain}/go/bin:'+os.environ['PATH'],GOWORK='off',CGO_ENABLED='0',GOMAXPROCS='6')
for name in ['waved','wavecli']:
    subprocess.run(['go','build','-p','6','-trimpath','-tags=wavewalletrpc,swapruntime','-ldflags',f'-s -w -X github.com/lightninglabs/wavelength/build.Commit={revision}','-o',str(output/name),f'./cmd/{name}'],cwd=source,env=environment,check=True)
    print(name,hashlib.sha256((output/name).read_bytes()).hexdigest(),flush=True)
