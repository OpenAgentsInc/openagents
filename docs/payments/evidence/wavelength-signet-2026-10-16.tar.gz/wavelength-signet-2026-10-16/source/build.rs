fn main() {
    tonic_build::configure()
        .build_server(false)
        .type_attribute(".", "#[derive(serde::Serialize)]")
        .compile_protos(
            &[
                "proto/wallet.proto",
                "proto/daemon.proto",
                "proto/swap_client.proto",
            ],
            &["proto"],
        )
        .unwrap();
}
