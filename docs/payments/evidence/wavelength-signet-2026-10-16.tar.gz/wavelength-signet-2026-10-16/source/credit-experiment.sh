#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
cp before-restart.json first-crash-before.json
cp after-restart.json first-crash-after.json
kill -TERM "$(cat daemon.pid)" 2>/dev/null || true
sleep 3
echo 'credit.autoredeemdisabled=true' > credit-test.conf
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --configfile="$PWD/credit-test.conf" --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
cli=(./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt")
"${cli[@]}" unlock --wallet-password-file="$PWD/wallet-password" > credit-unlock.json 2> credit-unlock.stderr
"${cli[@]}" dev swapclientrpc.SwapClientService CreateCredit --request-json '{"idempotency_key":"openagents-11770-credit-500-v1","source":"CREDIT_FUNDING_SOURCE_LIGHTNING_RECEIVE","amount_sat":500,"memo":"OpenAgents signet credit test"}' > credit-topup-invoice.json
python3 - <<'PY'
import json
from pathlib import Path
d=json.loads(Path('credit-topup-invoice.json').read_text())
assert d['invoice'].startswith('lntbs')
Path('credit-topup-request.json').write_text(json.dumps({'rail':'lightning','destination':d['invoice'],'amount_sats':500}))
PY
curl -sS --max-time 60 -D credit-topup-faucet.headers https://arkfaucet.com/api/request -H 'Content-Type: application/json' --data-binary @credit-topup-request.json -o credit-topup-faucet.json
cat credit-topup-faucet.json
export WAVE_SPIKE_ROOT="$PWD"
"$HOME/openagents-target-agent2/debug/wavelength-spike" balance > credit-funded-balance.json
cat credit-funded-balance.json
