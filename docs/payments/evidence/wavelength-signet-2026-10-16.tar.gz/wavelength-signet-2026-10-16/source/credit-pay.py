import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path.home()/'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT']=str(root)
binary=str(Path.home()/'openagents-target-agent2/debug/wavelength-spike')
label=sys.argv[1] if len(sys.argv)>1 else 'credit'
invoice_file=sys.argv[2] if len(sys.argv)>2 else 'external-500.txt'
def call(*args):
    return json.loads(subprocess.check_output([binary,*args],timeout=80))
def save(name,data):
    (root/(label+'-'+name)).write_text(json.dumps(data,indent=2))

prepared=call('prepare',str(root/invoice_file))
save('credit-prepare.json',prepared)
terms=prepared['result']['ok']
assert terms['amount_sat']==500
assert terms['fee_known'] and terms['expected_fee_sat']<=100
assert terms['credit_preview']['credit_shortfall_sat']==0
intent=terms['send_intent_id']
payment_hash=terms['payment_hash']
start=time.monotonic()
sent=call('send',intent)
save('credit-send.json',sent)
assert 'ok' in sent['result'],sent
watched=call('watch',payment_hash,'60')
save('credit-send-watch.json',watched)
assert watched['status']==2,watched
proof=call('proof',payment_hash)
save('credit-send-proof.json',proof)
elapsed=time.monotonic()-start
repeated=call('send',intent)
save('credit-repeat-send.json',repeated)
assert 'error' in repeated['result'],repeated
balance=call('balance')
save('credit-after-pay-balance.json',balance)
summary={'payment_hash':payment_hash,'dispatch_to_verified_seconds':elapsed,'watch':watched,'proof':proof,'balance':balance,'repeat':repeated}
save('credit-pay-summary.json',summary)
print(json.dumps(summary,indent=2))
assert proof['matching_entries']==1 and len(proof['proofs'])==1,proof
assert proof['proofs'][0]['verified']
