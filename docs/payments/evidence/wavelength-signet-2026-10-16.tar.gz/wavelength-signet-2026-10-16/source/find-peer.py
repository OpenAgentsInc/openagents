import concurrent.futures
import json
from pathlib import Path
import socket
import subprocess

root=Path.home()/'wavelength-spike'
nodes=[node for node in json.loads((root/'signet-liquidity-nodes.json').read_text()) if 1 < node.get('channels',0) and node.get('capacity',0) < 300_000_000][:45]
def probe(node):
    pubkey=node['publicKey']
    result=subprocess.run(['curl','-fsSL','--max-time','10',f'https://mempool.space/signet/api/v1/lightning/nodes/{pubkey}'],capture_output=True,text=True)
    if result.returncode:
        return None
    info=json.loads(result.stdout)
    for address in info.get('sockets','').split(','):
        if '.onion' in address or address.count(':')!=1:
            continue
        host,port=address.rsplit(':',1)
        try:
            with socket.create_connection((host,int(port)),timeout=2):
                return {'pubkey':pubkey,'alias':info.get('alias'),'address':address}
        except OSError:
            continue
    return None
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    live=[result for result in pool.map(probe,nodes) if result]
(root/'live-peers.json').write_text(json.dumps(live,indent=2))
print(json.dumps(live,indent=2))
