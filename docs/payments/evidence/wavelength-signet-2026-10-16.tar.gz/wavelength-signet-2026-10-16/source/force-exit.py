import json
import os
from pathlib import Path
import subprocess
import sys
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
wave = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
outpoint = sys.argv[1]
marker = root / 'force-exit-started.json'
if marker.exists():
    raise RuntimeError('inspect the existing exit instead of starting another')

def call(*args):
    return json.loads(subprocess.check_output([wave, *args], timeout=50))

def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2))

inventory = call('vtxos')
save('vtxos-before-force-exit.json', inventory)
vtxos = inventory['result']['ok']['body']['Vtxos']['vtxos']
target = next(v for v in vtxos if v['outpoint'] == outpoint)
assert target['status'] == 'live' and target['amount_sat'] >= 10000
plan = call('plan', outpoint)
save('force-exit-plan-final.json', plan)
assert plan['result']['ok']['can_start'], plan
save('force-exit-started.json', {'requested_at_unix':time.time(), 'target':target})
response = call('exit', outpoint, 'I_KNOW_WHAT_I_AM_DOING')
save('force-exit-request.json', response)
print(json.dumps(response), flush=True)
assert response['result']['ok']['mode'] == 2, response
time.sleep(15)
status = call('exit-status', outpoint)
save('force-exit-status-initial.json', status)
print(json.dumps(status), flush=True)
