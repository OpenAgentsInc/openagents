import json
import os
from pathlib import Path
import subprocess
import time

root = Path.home() / 'wavelength-spike'
binary = str(Path.home() / 'openagents-target-agent2/debug/openagents')
wave = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
os.environ['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
os.environ['WAVE_SPIKE_ROOT'] = str(root)
def cli(*args):
    return json.loads(subprocess.check_output([binary, '--json', 'x402', 'node', *args], timeout=40))
deadline = time.monotonic() + 2700
while True:
    info = cli('info')
    if info['balance']['onchain_spendable_sats'] >= 900_000:
        break
    if time.monotonic() > deadline:
        raise RuntimeError('signet funding still unconfirmed after 45 minutes')
    print('Waiting for signet funding confirmation.', flush=True)
    time.sleep(30)
deposits = [json.loads((root / 'deposit.json').read_text())]
deposits.append(json.loads(subprocess.check_output([wave, 'deposit'])))
results = []
for deposit in deposits:
    address = deposit['result']['ok']['onchain_address']
    result = cli('send', address, '--sats', '100000')
    results.append({'address': address, 'result': result})
    (root / 'boarding-funding.json').write_text(json.dumps(results, indent=2))
    print(json.dumps(result), flush=True)
# This is the public signet Lightning hop in Wavelength's route hints.
peer = '022b9e44b3a8093d9512b61f5f83a72d5634201efc49718efd34f2ee851b3afa8e@50.112.25.211:9735'
result = cli('channel', 'open', peer, '--sats', '500000', '--wait', '25')
(root / 'ldk-channel-open.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result), flush=True)
