import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
result = root / 'force-exit-funding.json'
marker = root / 'force-exit-funding-started.json'
if result.exists() or marker.exists():
    raise RuntimeError('funding was already attempted; inspect its original transaction')
plan = json.loads((root / 'force-exit-plan-initial.json').read_text())['result']['ok']['plans'][0]
assert plan['funding_shortfall_sat'] == 10000
assert plan['required_fee_utxo_count'] == 1
assert plan['required_confirmations'] == 1
marker.write_text(json.dumps({'requested_at_unix':time.time(), 'address':plan['funding_address'], 'amount_sat':10000}))
sent = json.loads(subprocess.check_output([str(Path.home() / 'openagents-target-agent2/debug/openagents'), '--json', 'x402', 'node', 'send', plan['funding_address'], '--sats', '10000'], timeout=50))
result.write_text(json.dumps(sent, indent=2))
for attempt in range(20):
    try:
        transaction = json.load(urllib.request.urlopen('https://mempool.space/signet/api/tx/' + sent['txid'], timeout=15))
    except Exception:
        if attempt == 19:
            raise
        time.sleep(1)
        continue
    assert any(output.get('scriptpubkey_address') == plan['funding_address'] and output['value'] == 10000 for output in transaction['vout'])
    (root / 'force-exit-funding-transaction.json').write_text(json.dumps(transaction, indent=2))
    print(json.dumps({'txid':sent['txid'], 'mempool_verified':True, 'fee_sat':transaction['fee'], 'status':transaction['status']}))
    break
