import hashlib
import json
from pathlib import Path
import time
import subprocess
import sys

root = Path.home() / 'wavelength-spike'
base = 'https://robinet.eldamar.icu'
def get(path):
    return json.loads(subprocess.check_output(['curl', '-fsSL', '--max-time', '20', base + path]))

info = get('/api/info')
assert info['network'] == 'signet'
challenge = get('/api/challenge')
assert 0 < challenge['difficulty'] <= 24
address = json.loads((root / 'ldk-fund.json').read_text())['address']
assert address.startswith('tb1')
target = 1 << (256 - challenge['difficulty'])
start = time.monotonic()
for nonce in range(100_000_000):
    if int.from_bytes(hashlib.sha256(f"{challenge['challenge']}:{nonce}".encode()).digest(), 'big') < target:
        break
else:
    raise RuntimeError('bounded PoW exhausted')
assert time.monotonic() - start < challenge['expires_in_seconds']
body = json.dumps({'address': address, 'challenge': challenge['challenge'], 'nonce': str(nonce)})
result = json.loads(subprocess.check_output(['curl', '-fsSL', '--max-time', '30', base + '/api/faucet', '-H', 'Content-Type: application/json', '--data-binary', body]))
(root / (sys.argv[1] if len(sys.argv)>1 else 'faucet-funding.json')).write_text(json.dumps(result))
print(json.dumps(result))
