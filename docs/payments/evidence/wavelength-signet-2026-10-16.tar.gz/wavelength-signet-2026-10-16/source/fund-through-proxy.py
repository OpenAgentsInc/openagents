import json
import os
from pathlib import Path
import subprocess
import time

root=Path.home()/'wavelength-spike'
os.environ['OPENAGENTS_WALLET_HOME']=str(root/'ldk-home')
binary=str(Path.home()/'openagents-target-agent2/debug/openagents')
base='https://mempool.space/signet/api'
parent=json.loads((root/'faucet-tx.json').read_text())
address=json.loads((root/'ldk-fund.json').read_text())['address']
index=next(i for i,output in enumerate(parent['vout']) if output.get('scriptpubkey_address')==address and output['value']==1_000_000)
outspend=json.loads(subprocess.check_output(['curl','-fsSL','--max-time','20',f"{base}/tx/{parent['txid']}/outspend/{index}"]))
assert not outspend['spent'],outspend
destination=json.loads((root/'deposit.json').read_text())['result']['ok']['onchain_address']
sent=json.loads(subprocess.check_output([binary,'--json','x402','node','send',destination,'--sats','200000'],timeout=40))
(root/'proxy-boarding-send.json').write_text(json.dumps(sent,indent=2))
for _ in range(20):
    result=subprocess.run(['curl','-fsSL','--max-time','10',f"{base}/tx/{sent['txid']}"],capture_output=True,text=True)
    if result.returncode==0:
        transaction=json.loads(result.stdout)
        assert any(output.get('scriptpubkey_address')==destination and output['value']==200_000 for output in transaction['vout'])
        (root/'proxy-boarding-transaction.json').write_text(json.dumps(transaction,indent=2))
        print(json.dumps({'send':sent,'mempool_verified':True,'fee_sat':transaction['fee'],'status':transaction['status']},indent=2))
        break
    time.sleep(1)
else:
    raise RuntimeError('transaction not observed; do not resend')
