import json
from pathlib import Path
import subprocess
root = Path.home() / 'wavelength-spike'
invoice = json.loads((root / 'receive-20000.json').read_text())['result']['ok']['invoice']
alphabet = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l'
words = [alphabet.index(c) for c in invoice[invoice.rfind('1')+1:]][7:-110]
peers = []
while words:
    tag, size = words[0], words[1]*32+words[2]
    data, words = words[3:3+size], words[3+size:]
    if alphabet[tag] != 'r':
        continue
    bits = ''.join(format(word,'05b') for word in data)
    raw = bytes(int(bits[i:i+8],2) for i in range(0,len(bits)-7,8))
    for i in range(0,len(raw),51):
        pubkey = raw[i:i+33].hex()
        result = subprocess.run(['curl','-fsSL','--max-time','15',f'https://mempool.space/signet/api/v1/lightning/nodes/{pubkey}'], capture_output=True, text=True)
        try:
            node = json.loads(result.stdout)
        except ValueError:
            node = {'error':result.stderr}
        peers.append({'pubkey':pubkey,'node':node})
(root / 'hint-peers.json').write_text(json.dumps(peers,indent=2))
print(json.dumps(peers,indent=2))
