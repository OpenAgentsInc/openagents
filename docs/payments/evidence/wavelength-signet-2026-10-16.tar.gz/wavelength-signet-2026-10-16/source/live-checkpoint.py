"""Read public study state without starting or changing a payment or process."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path.home() / "wavelength-spike"
TARGET = Path.home() / "openagents-target-agent2/debug"
EXIT = "10bcde0580829913ebb155f231de4c92edf13ddc4836253171047b21e4cab391:0"
SOAK = "cb9088727d056affd32327e525c9b2e408072eb3c71b960469f1a904702cd417:0"
COMMITMENT = "edf30424944a141672523445ce3eb7beb18bdc4c1d9bc9cb6bcf7068ac7bc24f"

def read(name):
    return json.loads((ROOT / name).read_text())

def fetch(path):
    with urllib.request.urlopen("http://127.0.0.1:3042/" + path, timeout=20) as response:
        return json.load(response)

def process(name, expected):
    pid = int((ROOT / (name + ".pid")).read_text())
    cmdline = Path(f"/proc/{pid}/cmdline")
    actual = cmdline.read_bytes().split(b"\0") if cmdline.exists() else []
    return {"pid": pid, "running_expected_process": bool(actual) and expected.encode() in actual[0]}

def wave(method, *args):
    env = os.environ.copy()
    env["WAVE_SPIKE_ROOT"] = str(ROOT)
    return json.loads(subprocess.check_output([str(TARGET / "wavelength-spike"), method, *args], env=env, timeout=50))

def ldk(method):
    env = os.environ.copy()
    env["OPENAGENTS_WALLET_HOME"] = str(ROOT / "ldk-home")
    return json.loads(subprocess.check_output([str(TARGET / "openagents"), "--json", "x402", "node", method], env=env, timeout=40))

control = read("observer-state.json")
assert control["exit_target"] == EXIT and control["soak_target"] == SOAK
started = read("force-exit-started.json")
assert started["target"]["outpoint"] == EXIT
inventory = wave("vtxos")
target = next(v for v in inventory["result"]["ok"]["body"]["Vtxos"]["vtxos"] if v["outpoint"] == SOAK)
assert target["status"] == "live" and target["amount_sat"] == 20000
core = json.loads(subprocess.check_output(["docker", "exec", "oa-signet-research", "bitcoin-cli", "-datadir=/data", "-signet", "getblockchaininfo"], timeout=25))
indexes = json.loads(subprocess.check_output(["docker", "exec", "oa-signet-research", "bitcoin-cli", "-datadir=/data", "-signet", "getindexinfo"], timeout=25))
transaction = fetch("tx/" + COMMITMENT)
checkpoint = {
    "issue": 11770,
    "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "check_type": "read_only_resume_audit",
    "new_payment_created": False,
    "processes_changed": False,
    "observer": control,
    "processes": {name: process(name, expected) for name, expected in [
        ("observer", "python3"), ("daemon", "wavelength-linux-amd64-v0.1.2/waved"),
        ("esplora-proxy", "esplora-proxy"), ("ldk-resident", "openagents")
    ]},
    "observer_source_sha256": hashlib.sha256((ROOT / "observe-signet.py").read_bytes()).hexdigest(),
    "proxy_tip": fetch("blocks/tip/height"),
    "core": {key: core[key] for key in ["chain", "blocks", "headers", "bestblockhash", "verificationprogress", "initialblockdownload"]},
    "core_indexes": indexes,
    "exit": wave("exit-status", EXIT),
    "balance": wave("balance"),
    "vtxos": inventory,
    "offline_window": {"target": SOAK, "start_height": target["batch_expiry"] - 504,
        "resume_height": target["batch_expiry"] - 504 + 12, "expiry_height": target["batch_expiry"]},
    "ldk_status": ldk("status"),
    "ldk_info": ldk("info"),
    "ldk_commitment": {key: transaction[key] for key in ["txid", "status", "fee", "vout"]},
    "ldk_commitment_outspends": {str(index): fetch(f"tx/{COMMITMENT}/outspend/{index}") for index in range(len(transaction["vout"]))},
}
print(json.dumps(checkpoint, indent=2))
