import json
from pathlib import Path
import selectors
import subprocess

root = Path.home() / 'wavelength-spike'
command = [str(root / 'wavelength-linux-amd64-v0.1.2/wavecli'), '--network=signet', f'--datadir={root}/state', f'--tlscertpath={root}/tls/ca.crt', f'--macaroonpath={root}/agent.macaroon', 'mcp', 'serve']
with (root / 'mcp.stderr').open('w') as errors:
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, text=True, bufsize=1)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    def request(method, params, identifier):
        process.stdin.write(json.dumps({'jsonrpc':'2.0','id':identifier,'method':method,'params':params}) + '\n')
        process.stdin.flush()
        for _ in range(20):
            assert selector.select(20), f'timeout: {method}'
            value = json.loads(process.stdout.readline())
            if 'id' not in value:
                continue
            assert value['id'] == identifier
            return value
        raise RuntimeError('too many notifications')
    try:
        initialization = request('initialize', {'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'signet-spike','version':'0'}}, 1)
        process.stdin.write(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'})+'\n')
        process.stdin.flush()
        tools = request('tools/list', {}, 2)
        names = [tool['name'] for tool in tools['result']['tools']]
        assert all(not any(word in name.lower() for word in ['create','unlock','seed']) for name in names)
        balance = request('tools/call', {'name':'balance','arguments':{}}, 3)
        denied = request('tools/call', {'name':'create','arguments':{}}, 4)
        result = {'tools':names,'balance':balance,'absent_create':denied,'initialization':initialization}
        (root / 'mcp-evidence.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))
    finally:
        process.stdin.close()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait(timeout=5)
