"""Observe the existing exit, then cross a refresh window with only waved off."""
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request

os.umask(0o077)
ROOT = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(ROOT)
WAVE = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
EXIT = '10bcde0580829913ebb155f231de4c92edf13ddc4836253171047b21e4cab391:0'
SOAK = 'cb9088727d056affd32327e525c9b2e408072eb3c71b960469f1a904702cd417:0'
STATE = ROOT / 'observer-state.json'
LOCK = (ROOT / 'observer.lock').open('a')
fcntl.flock(LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)

def save(name, value):
    target = ROOT / name
    temp = target.with_name(target.name + '.new')
    with temp.open('w') as output:
        json.dump(value, output, indent=2)
        output.flush()
        os.fsync(output.fileno())
    temp.replace(target)

def call(method, *args):
    assert method in ('exit-status', 'vtxos', 'balance', 'status', 'activity', 'onchain')
    return json.loads(subprocess.check_output([WAVE, method, *args], timeout=50))

def tip():
    return int(urllib.request.urlopen('http://127.0.0.1:3042/blocks/tip/height', timeout=20).read())

def daemon():
    p = ROOT / 'daemon.pid'
    if not p.exists():
        return None
    pid = int(p.read_text())
    command = Path(f'/proc/{pid}/cmdline')
    if not command.exists() or not command.read_bytes():
        return None
    args = command.read_bytes().split(b'\0')
    assert args[0] == str(ROOT / 'wavelength-linux-amd64-v0.1.2/waved').encode()
    assert f'--datadir={ROOT}/state'.encode() in args
    return pid

def stop_wallet():
    pid = daemon()
    if pid is None:
        return
    os.kill(pid, signal.SIGTERM)
    for _ in range(40):
        if daemon() is None:
            return
        time.sleep(0.5)
    raise RuntimeError('The scratch wallet did not stop.')

def start_wallet():
    if daemon() is not None:
        try:
            inventory = call('vtxos')
            if inventory['result']['ok']['body']['Vtxos']['vtxos']:
                return
        except Exception:
            pass
        with (ROOT / 'observer-unlock-private.json').open('w') as output:
            subprocess.run([str(ROOT / 'wavelength-linux-amd64-v0.1.2/wavecli'), '--network=signet',
                f'--datadir={ROOT}/state', f'--tlscertpath={ROOT}/tls/ca.crt', 'unlock',
                f'--wallet-password-file={ROOT}/wallet-password'], stdout=output,
                stderr=subprocess.DEVNULL, timeout=45, check=True)
        return
    with socket.socket() as sock:
        if sock.connect_ex(('127.0.0.1', 10029)) == 0:
            raise RuntimeError('The wallet port is already in use by another process.')
    with (ROOT / 'daemon-resume.log').open('a') as log:
        proc = subprocess.Popen([str(ROOT / 'wavelength-linux-amd64-v0.1.2/waved'),
            '--network=signet', '--wallet.type=lwwallet', '--wallet.esploraurl=http://127.0.0.1:3042',
            f'--datadir={ROOT}/state', '--rpc.listenaddr=127.0.0.1:10029',
            f'--rpc.tlscertpath={ROOT}/tls/server.crt', f'--rpc.tlskeypath={ROOT}/tls/server.key'],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (ROOT / 'daemon.pid').write_text(str(proc.pid))
    for _ in range(45):
        if proc.poll() is not None:
            raise RuntimeError('The scratch wallet exited during startup.')
        with socket.socket() as sock:
            if sock.connect_ex(('127.0.0.1', 10029)) == 0:
                break
        time.sleep(1)
    else:
        raise RuntimeError('The scratch wallet RPC did not start.')
    with (ROOT / 'observer-unlock-private.json').open('w') as output:
        subprocess.run([str(ROOT / 'wavelength-linux-amd64-v0.1.2/wavecli'), '--network=signet',
            f'--datadir={ROOT}/state', f'--tlscertpath={ROOT}/tls/ca.crt', 'unlock',
            f'--wallet-password-file={ROOT}/wallet-password'], stdout=output,
            stderr=subprocess.DEVNULL, timeout=45, check=True)

if '--read-only' in sys.argv:
    assert json.load(open(ROOT / 'force-exit-started.json'))['target']['outpoint'] == EXIT
    print(json.dumps({'exit':call('exit-status', EXIT), 'height':tip(), 'daemon_running':daemon() is not None}))
    raise SystemExit(0)

assert json.load(open(ROOT / 'force-exit-started.json'))['target']['outpoint'] == EXIT
control = json.load(open(STATE)) if STATE.exists() else {
    'phase':'waiting_exit', 'started_at_unix':time.time(),
    'deadline_unix':time.time()+9*86400, 'exit_target':EXIT, 'soak_target':SOAK,
    'new_payment_created':False,
}
assert control['exit_target'] == EXIT and control['soak_target'] == SOAK
save(STATE.name, control)
last = None
while True:
    try:
        if time.time() >= control['deadline_unix']:
            control['phase_at_deadline'] = control['phase']
            control['phase'] = 'time_limit'
            if control['phase_at_deadline'] in ('offline', 'stopping', 'resuming'):
                try:
                    start_wallet()
                except Exception as error:
                    control['phase'] = 'time_limit_resume_failed'
                    control['last_error'] = type(error).__name__
            save(STATE.name, control)
            break
        phase = control['phase']
        if phase == 'waiting_exit':
            result = call('exit-status', EXIT)
            status = result['result']['ok']
            save('force-exit-status-latest.json', result)
            key = (status['current_height'], status['status'], status.get('sweep_txid'))
            if key != last:
                with (ROOT / 'exit-observation-history.ndjson').open('a') as log:
                    log.write(json.dumps({'observed_at_unix':time.time(),'status':status})+'\n')
                last = key
            if status['status'] == 6:
                control['phase'] = 'exit_failed'
                save(STATE.name, control)
                break
            if status['found'] and status['status'] == 5 and status['sweep_txid']:
                txid = status['sweep_txid']
                assert len(txid) == 64 and all(c in '0123456789abcdef' for c in txid)
                confirmation = json.load(urllib.request.urlopen(f'http://127.0.0.1:3042/tx/{txid}/status', timeout=20))
                if confirmation.get('confirmed'):
                    inventory = call('vtxos')
                    target = next(v for v in inventory['result']['ok']['body']['Vtxos']['vtxos'] if v['outpoint'] == SOAK)
                    assert target['status'] == 'live' and target['amount_sat'] == 20000
                    height = tip()
                    window = target['batch_expiry'] - 504
                    assert height < window, 'The offline test must start before the refresh window.'
                    save('exit-completed-observed.json', {'observed_at_unix':time.time(),'exit':result,'confirmation':confirmation,'balance':call('balance')})
                    control.update(phase='stopping', offline_start_height=height, offline_requested_at_unix=time.time(),
                        window_start_height=window, resume_height=window+12, expiry_height=target['batch_expiry'])
                    save('vtxos-offline-start.json', inventory)
                    save(STATE.name, control)
        elif phase == 'stopping':
            stop_wallet()
            control.update(phase='offline', stopped_at_unix=time.time())
            save(STATE.name, control)
        elif phase == 'offline':
            if daemon() is not None:
                control.update(phase='offline_interrupted', interrupted_at_unix=time.time())
                save(STATE.name, control)
                break
            height = tip()
            if height >= control['resume_height']:
                control.update(phase='resuming', observed_window_height=height,
                    resume_requested_at_unix=time.time(), late_resume=height >= control['expiry_height'])
                save(STATE.name, control)
        elif phase == 'resuming':
            start_wallet()
            inventory = call('vtxos')
            if inventory['result']['ok']['body']['Vtxos']['vtxos']:
                control.update(phase='observing_refresh', resumed_at_unix=time.time(), observe_until_unix=time.time()+7200)
                save('vtxos-after-offline-resume.json', inventory)
                save('balance-after-offline-resume.json', call('balance'))
                save(STATE.name, control)
        elif phase == 'observing_refresh':
            save('vtxos-after-offline-latest.json', call('vtxos'))
            save('activity-after-offline-latest.json', call('activity'))
            if time.time() >= control['observe_until_unix']:
                control.update(phase='window_observation_saved', finished_at_unix=time.time(),
                    refresh_completion_requires_review=True)
                save(STATE.name, control)
                break
        else:
            break
        control.pop('last_error', None)
        save(STATE.name, control)
    except Exception as error:
        control['last_error'] = type(error).__name__
        control['last_error_at_unix'] = time.time()
        save(STATE.name, control)
    time.sleep(45)
print(json.dumps(control))
