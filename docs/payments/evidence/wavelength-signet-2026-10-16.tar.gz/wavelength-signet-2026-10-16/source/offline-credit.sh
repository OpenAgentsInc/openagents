#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
export WAVE_SPIKE_ROOT="$PWD"
cli=(./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt")
"${cli[@]}" dev swapclientrpc.SwapClientService CreateCredit --request-json '{"idempotency_key":"openagents-11770-offline-credit-500-v1","source":"CREDIT_FUNDING_SOURCE_LIGHTNING_RECEIVE","amount_sat":500,"memo":"OpenAgents signet offline receive"}' > offline-credit-invoice.json
python3 - <<'PY'
import json
from pathlib import Path
d=json.loads(Path('offline-credit-invoice.json').read_text())
assert d['invoice'].startswith('lntbs')
Path('offline-credit-request.json').write_text(json.dumps({'rail':'lightning','destination':d['invoice'],'amount_sats':500}))
Path('offline-credit-hash.txt').write_text(d['payment_hash'])
PY
date -u +%FT%TZ > offline-credit-stopped.txt
kill -KILL "$(cat daemon.pid)"
curl -sS --max-time 60 -D offline-credit-faucet.headers https://arkfaucet.com/api/request -H 'Content-Type: application/json' --data-binary @offline-credit-request.json -o offline-credit-faucet.json
cat offline-credit-faucet.json
# Restore default automatic credit redemption. The expected balance is 999 sats,
# below the operator's 1,000-sat VTXO floor.
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
"${cli[@]}" unlock --wallet-password-file="$PWD/wallet-password" > offline-credit-unlock.json 2> offline-credit-unlock.stderr
date -u +%FT%TZ > offline-credit-unlocked.txt
"$HOME/openagents-target-agent2/debug/wavelength-spike" watch "$(cat offline-credit-hash.txt)" 60 > offline-credit-watch.json
"$HOME/openagents-target-agent2/debug/wavelength-spike" balance > offline-credit-balance.json
python3 - <<'PY'
import json
from pathlib import Path
watch=json.loads(Path('offline-credit-watch.json').read_text())
balance=json.loads(Path('offline-credit-balance.json').read_text())['result']['ok']
assert watch['status']==2 and watch['matching_entries']==1,watch
assert balance['credit_available_sat']==999,balance
print(json.dumps({'watch':watch,'balance':balance},indent=2))
PY
