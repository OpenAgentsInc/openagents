import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
os.environ['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
target = Path.home() / 'openagents-target-agent2/debug'
wave = str(target / 'wavelength-spike')
node = str(target / 'openagents')
if (root / 'online-receive-invoice.json').exists():
    raise RuntimeError('inspect the original invoice instead of repeating this case')
received = json.loads((root / 'routed-receive-summary.json').read_text())
assert received.get('proof_verified') and received['watch']['status'] == 2

def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2))

receive = json.loads(subprocess.check_output([wave, 'recv', '20000'], timeout=50))
save('online-receive-invoice.json', receive)
terms = receive['result']['ok']
assert terms['credit_receive'] is None
payment_hash = terms['entry']['progress']['payment_hash']
started = time.monotonic()
with (root / 'online-payer-private.json').open('w') as output, (root / 'online-payer.stderr').open('w') as errors:
    payer = subprocess.Popen([node, '--json', 'x402', 'node', 'pay', terms['invoice'], '--max-fee-msat', '1000000', '--wait', '180'], stdout=output, stderr=errors)
    watched = json.loads(subprocess.check_output([wave, 'watch', payment_hash, '120'], timeout=170))
    save('online-receive-watch.json', watched)
    payer.wait(timeout=75)
summary = {'payment_hash': payment_hash, 'elapsed_seconds': time.monotonic() - started, 'payer_exit': payer.returncode, 'watch': watched}
if payer.returncode == 0:
    proof = json.loads((root / 'online-payer-private.json').read_text())
    preimage = bytes.fromhex(proof['preimage'])
    summary['proof_verified'] = len(preimage) == 32 and hashlib.sha256(preimage).hexdigest() == payment_hash
    summary['payer'] = {key:value for key,value in proof.items() if key != 'preimage'}
save('online-receive-summary.json', summary)
print(json.dumps(summary, indent=2), flush=True)
assert watched['status'] == 2 and watched['matching_entries'] == 1, summary
assert summary.get('proof_verified'), summary
