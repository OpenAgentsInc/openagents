import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.request

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
wave = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
marker = root / 'confirmation-wait-start.json'
if marker.exists():
    raise RuntimeError('preserve the existing confirmation-wait record')
base = 'https://mempool.space/signet/api'
height = int(urllib.request.urlopen(base + '/blocks/tip/height', timeout=20).read())
if height != 326549:
    raise RuntimeError('the chain advanced; inspect the pending transactions before stopping')
transactions = {'leave':'cddb2e674c8b26af6d4495c00891e364f25c21ffa3e317df00ef6d0e71dcec49', 'refresh':'50f1c81bddaddec518837bdb9dbb982a405c37ec1f2d71cb9b97cdb4c7f9cc1c', 'fee_funding':'fbebd47032ec11231e9b6ce1e1909793c9ff18707d040f0a6f291b182622cd92'}
statuses = {}
for name, txid in transactions.items():
    statuses[name] = json.load(urllib.request.urlopen(base + '/tx/' + txid + '/status', timeout=20))
    if statuses[name]['confirmed']:
        raise RuntimeError('a transaction confirmed; inspect it before stopping')
for method in ('activity','balance','vtxos'):
    value = json.loads(subprocess.check_output([wave, method], timeout=50))
    (root / ('confirmation-wait-' + method + '.json')).write_text(json.dumps(value, indent=2))
record = {'pause_requested_at_unix':time.time(), 'height':height, 'phase':'waiting_for_initial_exit_confirmations', 'transactions':transactions, 'statuses':statuses, 'unilateral_exit_started':False, 'expiry_window_observed':False, 'mainnet_funds_used':False}
marker.write_text(json.dumps(record, indent=2))
for name, token, shutdown_signal in [('daemon', b'wavelength-linux-amd64-v0.1.2/waved', signal.SIGTERM), ('ldk-resident', b'openagents', signal.SIGINT), ('esplora-proxy', b'esplora-proxy', signal.SIGTERM)]:
    pid = int((root / (name + '.pid')).read_text())
    assert token in Path(f'/proc/{pid}/cmdline').read_bytes()
    if name == 'ldk-resident':
        assert f'OPENAGENTS_WALLET_HOME={root}/ldk-home'.encode() in Path(f'/proc/{pid}/environ').read_bytes()
    os.kill(pid, shutdown_signal)
    for _ in range(30):
        path = Path(f'/proc/{pid}/cmdline')
        if not path.exists() or not path.read_bytes():
            break
        time.sleep(1)
    else:
        raise RuntimeError(name + ' did not stop')
record['processes_stopped_at_unix'] = time.time()
marker.write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
