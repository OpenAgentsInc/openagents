import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.request

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
wave = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
marker = root / 'offline-study-start.json'
if marker.exists():
    raise RuntimeError('an offline observation already started; preserve its original record')

def call(*args):
    return json.loads(subprocess.check_output([wave, *args], timeout=50))

def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2))

started = json.loads((root / 'force-exit-started.json').read_text())
exit_status = call('exit-status', started['target']['outpoint'])
save('force-exit-status-checkpoint.json', exit_status)
assert exit_status['result']['ok']['found']
assert exit_status['result']['ok']['status'] != 6, exit_status
inventory = call('vtxos')
save('vtxos-offline-start.json', inventory)
vtxos = inventory['result']['ok']['body']['Vtxos']['vtxos']
soak = next(v for v in vtxos if v['status'] == 'live' and v['amount_sat'] == 20000 and v['batch_expiry'] > 326840)
balance = call('balance')
save('balance-offline-start.json', balance)
height = int(urllib.request.urlopen('https://mempool.space/signet/api/blocks/tip/height', timeout=20).read())
record = {'stopped_at_unix':time.time(), 'height':height, 'soak_target':soak, 'free_refresh_starts_at_height':soak['batch_expiry']-504, 'expiry_height':soak['batch_expiry'], 'unilateral_exit_target':started['target'], 'unilateral_exit_status':exit_status, 'pending_send_hashes':['eebdafab0d92aa5e97c130282efda985fec428758b8ef7f86883f4bb2a9fb2a2','98a0302daa9e24c9d6e58c15e64092f4e3c0c073ef4c012f59d3e55831ea3f96'], 'expiry_observed':False}

def stop(name, token, shutdown_signal):
    pid = int((root / (name + '.pid')).read_text())
    command = Path(f'/proc/{pid}/cmdline').read_bytes()
    assert token in command, name
    if name == 'ldk-resident':
        environment = Path(f'/proc/{pid}/environ').read_bytes()
        assert f'OPENAGENTS_WALLET_HOME={root}/ldk-home'.encode() in environment
    os.kill(pid, shutdown_signal)
    for _ in range(30):
        path = Path(f'/proc/{pid}/cmdline')
        if not path.exists() or not path.read_bytes():
            return
        time.sleep(1)
    raise RuntimeError(f'{name} did not stop; inspect the original process')

save('offline-study-start.json', record)
stop('daemon', b'wavelength-linux-amd64-v0.1.2/waved', signal.SIGTERM)
stop('ldk-resident', b'openagents', signal.SIGINT)
stop('esplora-proxy', b'esplora-proxy', signal.SIGTERM)
record['processes_stopped_at_unix'] = time.time()
save('offline-study-start.json', record)
print(json.dumps({'processes_stopped':True, 'height':height, 'refresh_window_starts':record['free_refresh_starts_at_height'], 'expiry':record['expiry_height'], 'exit_phase':exit_status['result']['ok']['phase_detail']}))
