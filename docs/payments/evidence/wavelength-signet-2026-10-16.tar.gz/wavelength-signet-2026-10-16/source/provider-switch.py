import json
import os
from pathlib import Path
import signal
import subprocess
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
wave = str(Path.home() / 'openagents-target-agent2/debug/wavelength-spike')
if (root / 'provider-switch-summary.json').exists():
    raise RuntimeError('this provider switch already ran')
old_plan = root / 'force-exit-plan-final.json'
if old_plan.exists():
    (root / 'force-exit-plan-before-provider-switch.json').write_bytes(old_plan.read_bytes())
for name, token, sig in [('daemon', b'wavelength-linux-amd64-v0.1.2/waved', signal.SIGTERM), ('ldk-resident', b'openagents', signal.SIGINT), ('esplora-proxy', b'esplora-proxy', signal.SIGTERM)]:
    pid = int((root / (name + '.pid')).read_text())
    assert token in Path(f'/proc/{pid}/cmdline').read_bytes()
    if name == 'ldk-resident':
        assert f'OPENAGENTS_WALLET_HOME={root}/ldk-home'.encode() in Path(f'/proc/{pid}/environ').read_bytes()
    os.kill(pid, sig)
    for _ in range(30):
        path = Path(f'/proc/{pid}/cmdline')
        if not path.exists() or not path.read_bytes():
            break
        time.sleep(1)
    else:
        raise RuntimeError(name + ' did not stop')
subprocess.run(['python3', str(root / 'resume-study.py')], check=True, timeout=60)
summary = {'switched_at_unix':time.time(), 'read_backend':'https://mempool-signet.testnet.lightningcluster.com/api', 'broadcast_backend':'https://mempool.space/signet/api', 'fresh_payment_created':False}
(root / 'provider-switch-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
