import json,os,signal,subprocess,time
from pathlib import Path
os.umask(0o077)
r=Path.home()/'wavelength-spike'
pid=int((r/'esplora-proxy.pid').read_text())
assert b'esplora-proxy' in Path(f'/proc/{pid}/cmdline').read_bytes()
os.kill(pid,signal.SIGTERM)
for _ in range(30):
 p=Path(f'/proc/{pid}/cmdline')
 if not p.exists() or not p.read_bytes():break
 time.sleep(0.2)
else:raise RuntimeError('proxy still running')
with (r/'esplora-proxy-resume.log').open('a') as out:
 p=subprocess.Popen([str(Path.home()/'openagents-target-agent2/debug/esplora-proxy')],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
(r/'esplora-proxy.pid').write_text(str(p.pid))
time.sleep(2)
env=os.environ.copy();env['WAVE_SPIKE_ROOT']=str(r)
wave=str(Path.home()/'openagents-target-agent2/debug/wavelength-spike')
plan=json.loads(subprocess.check_output([wave,'plan','10bcde0580829913ebb155f231de4c92edf13ddc4836253171047b21e4cab391:0'],env=env,timeout=50))
(r/'force-exit-plan-synced.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(plan),flush=True)
assert plan['result']['ok']['can_start']
assert plan['result']['ok']['fee_rate_sat_per_vbyte']<=5
subprocess.run(['python3',str(r/'force-exit.py'),'10bcde0580829913ebb155f231de4c92edf13ddc4836253171047b21e4cab391:0'],env=env,timeout=120,check=True)
