import json
import os
from pathlib import Path
import subprocess
import sys
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
os.environ['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
target = Path.home() / 'openagents-target-agent2/debug'
wave = str(target / 'wavelength-spike')
node = str(target / 'openagents')
amount_msat = int(sys.argv[1]) if len(sys.argv) > 1 else 21001
assert amount_msat in (21000, 21001, 21000000)
label = f'request-hash-{amount_msat}'
if (root / (label + '-invoice.json')).exists():
    raise RuntimeError('this case already has an invoice; inspect its original hash instead of starting again')
received = json.loads((root / 'routed-receive-summary.json').read_text())
assert received.get('proof_verified') and received['watch']['status'] == 2

def call(command, timeout=50):
    return json.loads(subprocess.check_output(command, timeout=timeout))

def save(suffix, value):
    (root / f'{label}-{suffix}.json').write_text(json.dumps(value, indent=2))

invoice = call([node, '--json', 'x402', 'node', 'invoice', '--msat', str(amount_msat), '--request-hash', '08' * 32, '--expiry', '600'])
save('invoice', invoice)
assert invoice['amount_msat'] == amount_msat
assert invoice['description_hash'] == '08' * 32
invoice_file = root / (label + '-invoice.txt')
invoice_file.write_text(invoice['bolt11'])
decoded = call([wave, 'decode', str(invoice_file)])
save('decoded', decoded)
assert decoded['currency'] == 'Signet' and decoded['amount_msat'] == amount_msat
assert '08' * 32 in decoded['description']
before = call([wave, 'balance'])
save('balance-before', before)
prepared = call([wave, 'prepare', str(invoice_file)])
save('prepare', prepared)
if 'ok' not in prepared['result']:
    save('summary', {'status':'prepare_rejected','invoice_terms':decoded,'prepare':prepared})
    print(json.dumps({'case':label,'status':'prepare_rejected','result':prepared['result']}))
    raise SystemExit(1)
terms = prepared['result']['ok']
assert terms['payment_hash'] == invoice['payment_hash']
assert terms['fee_known'] and terms['expected_fee_sat'] <= 100
assert terms['credit_preview']['credit_shortfall_sat'] == 0
started = time.monotonic()
sent = call([wave, 'send', terms['send_intent_id']])
save('send', sent)
assert 'ok' in sent['result'], sent
watched = call([wave, 'watch', invoice['payment_hash'], '120'], timeout=170)
save('watch', watched)
after = call([wave, 'balance'])
save('balance-after', after)
summary = {'invoice_terms':decoded,'watch':watched,'elapsed_seconds':time.monotonic()-started,'balance_before':before,'balance_after':after}
if watched['status'] == 2:
    proof = call([wave, 'raw-proof', invoice['payment_hash']])
    save('proof', proof)
    lookup = call([node, '--json', 'x402', 'node', 'lookup', invoice['payment_hash']])
    save('lookup', lookup)
    summary['proof'] = proof
    record = lookup['payment']
    summary['receiver'] = {key:value for key,value in record.items() if key not in ('preimage','bolt11')}
    assert proof['verified'] and proof['state'] == 6
    assert record['status'] == 'succeeded' and record['amount_msat'] == amount_msat
save('summary', summary)
print(json.dumps(summary, indent=2), flush=True)
assert watched['status'] == 2 and watched['matching_entries'] == 1, summary
