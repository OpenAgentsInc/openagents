#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
export WAVE_SPIKE_ROOT="$PWD"
"$HOME/openagents-target-agent2/debug/wavelength-spike" activity > before-restart.json
date -u +%FT%TZ > restart-started.txt
kill -KILL "$(cat daemon.pid)"
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" unlock --wallet-password-file="$PWD/wallet-password" > restart-unlock.json 2> restart-unlock.stderr
"$HOME/openagents-target-agent2/debug/wavelength-spike" activity > after-restart.json
"$HOME/openagents-target-agent2/debug/wavelength-spike" balance > balance-after-restart.json
date -u +%FT%TZ > restart-finished.txt
python3 - <<'PY'
import json
from collections import Counter
from pathlib import Path
def entries(path):
    return json.loads(Path(path).read_text())['result']['ok']['body']['Activity']['entries']
before,after=entries('before-restart.json'),entries('after-restart.json')
assert Counter(e['id'] for e in before)==Counter(e['id'] for e in after)
assert all(n==1 for n in Counter(e['id'] for e in after).values())
balance=json.loads(Path('balance-after-restart.json').read_text())['result']['ok']
print(json.dumps({'entries_before':len(before),'entries_after':len(after),'unique_ids':True,'credit_available_sat':balance['credit_available_sat'],'pending':sum(e['status']==1 for e in after)}))
PY
