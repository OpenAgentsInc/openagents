import json,os,signal,subprocess,time
from pathlib import Path
os.umask(0o077)
r=Path.home()/'wavelength-spike'
assert (r/'force-exit-started.json').exists()
for name,token in [('daemon',b'wavelength-linux-amd64-v0.1.2/waved'),('esplora-proxy',b'esplora-proxy')]:
 pid=int((r/(name+'.pid')).read_text());assert token in Path(f'/proc/{pid}/cmdline').read_bytes();os.kill(pid,signal.SIGTERM)
 for _ in range(40):
  p=Path(f'/proc/{pid}/cmdline')
  if not p.exists() or not p.read_bytes():break
  time.sleep(.25)
 else:raise RuntimeError(name+' did not stop')
def launch(name,args):
 with (r/(name+'-resume.log')).open('a') as log:
  p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (r/(name+'.pid')).write_text(str(p.pid));return p
launch('esplora-proxy',[str(Path.home()/'openagents-target-agent2/debug/esplora-proxy')]);time.sleep(2)
p=launch('daemon',[str(r/'wavelength-linux-amd64-v0.1.2/waved'),'--network=signet','--wallet.type=lwwallet','--wallet.esploraurl=http://127.0.0.1:3042',f'--datadir={r}/state','--rpc.listenaddr=127.0.0.1:10029',f'--rpc.tlscertpath={r}/tls/server.crt',f'--rpc.tlskeypath={r}/tls/server.key'])
time.sleep(5);assert p.poll() is None
with (r/'existing-exit-unlock-private.json').open('w') as out:
 subprocess.run([str(r/'wavelength-linux-amd64-v0.1.2/wavecli'),'--network=signet',f'--datadir={r}/state',f'--tlscertpath={r}/tls/ca.crt','unlock',f'--wallet-password-file={r}/wallet-password'],stdout=out,stderr=subprocess.DEVNULL,check=True,timeout=45)
os.environ['WAVE_SPIKE_ROOT']=str(r)
raw=subprocess.check_output([str(Path.home()/'openagents-target-agent2/debug/wavelength-spike'),'exit-status','10bcde0580829913ebb155f231de4c92edf13ddc4836253171047b21e4cab391:0'],timeout=45)
(r/'force-exit-resumed.json').write_bytes(raw)
print(raw.decode())
