import os
from pathlib import Path
import socket
import subprocess
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
target = Path.home() / 'openagents-target-agent2/debug'
for port in (10029, 3042):
    with socket.socket() as connection:
        connection.settimeout(1)
        if connection.connect_ex(('127.0.0.1', port)) == 0:
            raise RuntimeError(f'port {port} is already serving; inspect it before resuming')

def launch(name, command, environment=None):
    with (root / (name + '-resume.log')).open('a') as log:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
    (root / (name + '.pid')).write_text(str(process.pid))
    return process

launch('esplora-proxy', [str(target / 'esplora-proxy')])
time.sleep(2)
environment = os.environ.copy()
environment['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
launch('ldk-resident', [str(target / 'openagents'), '--json', 'x402', 'node', 'serve'], environment)
daemon = launch('daemon', [str(root / 'wavelength-linux-amd64-v0.1.2/waved'), '--network=signet', '--wallet.type=lwwallet', '--wallet.esploraurl=https://mempool.space/signet/api', f'--datadir={root}/state', '--rpc.listenaddr=127.0.0.1:10029', f'--rpc.tlscertpath={root}/tls/server.crt', f'--rpc.tlskeypath={root}/tls/server.key'])
for _ in range(30):
    if daemon.poll() is not None:
        raise RuntimeError('daemon exited; inspect its private log')
    with socket.socket() as connection:
        if connection.connect_ex(('127.0.0.1', 10029)) == 0:
            break
    time.sleep(1)
else:
    raise RuntimeError('RPC did not start')
with (root / 'resume-unlock-private.json').open('w') as output, (root / 'resume-unlock.stderr').open('w') as errors:
    subprocess.run([str(root / 'wavelength-linux-amd64-v0.1.2/wavecli'), '--network=signet', f'--datadir={root}/state', f'--tlscertpath={root}/tls/ca.crt', 'unlock', f'--wallet-password-file={root}/wallet-password'], stdout=output, stderr=errors, timeout=45, check=True)
print('Signet study resumed. Inspect the saved exit and soak targets; do not create new invoices or payments.')
