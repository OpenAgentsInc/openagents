#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
test ! -d private-snapshot-state
kill -TERM "$(cat daemon.pid)"
for i in {1..30}; do
  if ! ss -ltn | grep -q '127.0.0.1:10029'; then break; fi
  sleep 1
done
if ss -ltn | grep -q '127.0.0.1:10029'; then exit 1; fi
cp -a state private-snapshot-state
chmod 700 private-snapshot-state
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --wallet.esploraurl=https://mempool.space/signet/api --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> returned-release.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" unlock --wallet-password-file="$PWD/wallet-password" > returned-release-unlock.json 2> returned-release-unlock.stderr
./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" getinfo > returned-release-getinfo.json
export WAVE_SPIKE_ROOT="$PWD"
"$HOME/openagents-target-agent2/debug/wavelength-spike" status
