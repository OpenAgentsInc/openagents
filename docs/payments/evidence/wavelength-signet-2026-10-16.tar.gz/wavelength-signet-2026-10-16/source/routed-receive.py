import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

os.umask(0o077)
root = Path.home() / 'wavelength-spike'
os.environ['WAVE_SPIKE_ROOT'] = str(root)
os.environ['OPENAGENTS_WALLET_HOME'] = str(root / 'ldk-home')
target = Path.home() / 'openagents-target-agent2/debug'
wave = str(target / 'wavelength-spike')
node = str(target / 'openagents')
if (root / 'routed-receive-invoice.json').exists():
    raise RuntimeError('the receive test already has an invoice; inspect its original hash instead of starting again')

def run_json(command, timeout=50):
    return json.loads(subprocess.check_output(command, timeout=timeout))

def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2))

deadline = time.monotonic() + 1800
while True:
    channels = run_json([node, '--json', 'x402', 'node', 'channel', 'list'])
    save('ldk-channel-current.json', channels)
    if any(channel['usable'] for channel in channels['channels']):
        break
    if time.monotonic() > deadline:
        raise RuntimeError('no usable signet channel after 30 minutes')
    print('Waiting for three funding confirmations.', flush=True)
    time.sleep(20)

receive = run_json([wave, 'recv', '100000'])
save('routed-receive-invoice.json', receive)
terms = receive['result']['ok']
assert terms['credit_receive'] is None
invoice = terms['invoice']
payment_hash = terms['entry']['progress']['payment_hash']
assert invoice.startswith('lntbs')

pid = int((root / 'daemon.pid').read_text())
command = Path(f'/proc/{pid}/cmdline').read_bytes()
assert b'wavelength-linux-amd64-v0.1.2/waved' in command
os.kill(pid, signal.SIGKILL)
started = time.monotonic()
with (root / 'routed-payer-private.json').open('w') as payer_output, (root / 'routed-payer.stderr').open('w') as payer_error:
    payer = subprocess.Popen([node, '--json', 'x402', 'node', 'pay', invoice, '--max-fee-msat', '1000000', '--wait', '180'], stdout=payer_output, stderr=payer_error)
    # The invoice exists durably before the incoming HTLC is attempted.
    # Keep the receiver stopped while the payer starts that attempt.
    time.sleep(10)
    with (root / 'routed-daemon.log').open('a') as daemon_log:
        daemon = subprocess.Popen([str(root / 'wavelength-linux-amd64-v0.1.2/waved'), '--network=signet', '--wallet.type=lwwallet', '--wallet.esploraurl=https://mempool.space/signet/api', f'--datadir={root}/state', '--rpc.listenaddr=127.0.0.1:10029', f'--rpc.tlscertpath={root}/tls/server.crt', f'--rpc.tlskeypath={root}/tls/server.key'], stdin=subprocess.DEVNULL, stdout=daemon_log, stderr=subprocess.STDOUT, start_new_session=True)
    (root / 'daemon.pid').write_text(str(daemon.pid))
    time.sleep(3)
    with (root / 'routed-unlock-private.json').open('w') as output, (root / 'routed-unlock.stderr').open('w') as errors:
        subprocess.run([str(root / 'wavelength-linux-amd64-v0.1.2/wavecli'), '--network=signet', f'--datadir={root}/state', f'--tlscertpath={root}/tls/ca.crt', 'unlock', f'--wallet-password-file={root}/wallet-password'], stdout=output, stderr=errors, timeout=45, check=True)
    print('Receiver restarted and unlocked; observing the original payment.', flush=True)
    watched = run_json([wave, 'watch', payment_hash, '120'], timeout=170)
    save('routed-receive-watch.json', watched)
    try:
        payer.wait(timeout=45)
    except subprocess.TimeoutExpired:
        payer.terminate()
        payer.wait(timeout=10)

summary = {'payment_hash': payment_hash, 'receiver_offline_seconds': 10, 'elapsed_seconds': time.monotonic() - started, 'payer_exit': payer.returncode, 'watch': watched}
if payer.returncode == 0:
    proof = json.loads((root / 'routed-payer-private.json').read_text())
    preimage = bytes.fromhex(proof['preimage'])
    summary['proof_verified'] = len(preimage) == 32 and hashlib.sha256(preimage).hexdigest() == payment_hash
    summary['payer'] = {key:value for key,value in proof.items() if key != 'preimage'}
else:
    summary['payer_error_sha256'] = hashlib.sha256((root / 'routed-payer.stderr').read_bytes()).hexdigest()
save('routed-receive-summary.json', summary)
print(json.dumps(summary, indent=2), flush=True)
assert watched['status'] == 2 and watched['matching_entries'] == 1, summary
assert summary.get('proof_verified'), summary
