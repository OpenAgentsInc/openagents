#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
mkdir -p tls
openssl req -x509 -newkey rsa:2048 -nodes -keyout tls/ca.key -out tls/ca.crt -days 14 -subj /CN=Wavelength-signet-spike-CA > tls/generation.log 2>&1
openssl req -newkey rsa:2048 -nodes -keyout tls/server.key -out tls/server.csr -subj /CN=localhost >> tls/generation.log 2>&1
cat > tls/server.ext <<'EOF'
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=DNS:localhost,IP:127.0.0.1
EOF
openssl x509 -req -in tls/server.csr -CA tls/ca.crt -CAkey tls/ca.key -CAcreateserial -out tls/server.crt -days 14 -extfile tls/server.ext >> tls/generation.log 2>&1
kill -TERM "$(cat daemon.pid)"
for i in {1..20}; do
  if ! kill -0 "$(cat daemon.pid)" 2>/dev/null; then break; fi
  sleep 1
done
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" unlock --wallet-password-file="$PWD/wallet-password" > unlock-after-restart.json 2> unlock-after-restart.stderr
echo 'Restarted and unlocked through CLI.'
