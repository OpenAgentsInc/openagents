use std::{
    env,
    error::Error,
    fs,
    time::{Duration, Instant},
};
use tonic::{
    Request,
    transport::{Certificate, ClientTlsConfig, Endpoint},
};
mod rpc {
    tonic::include_proto!("wavewalletrpc");
}
mod daemon {
    tonic::include_proto!("waverpc");
}
mod swap {
    tonic::include_proto!("swapclientrpc");
}
use rpc::*;
use sha2::{Digest, Sha256};

fn emit<T: serde::Serialize>(method: &str, start: Instant, result: Result<T, tonic::Status>) {
    let result = match result {
        Ok(value) => serde_json::json!({"ok": value}),
        Err(error) => {
            serde_json::json!({"error":error.message(),"code":format!("{:?}",error.code())})
        }
    };
    println!(
        "{}",
        serde_json::json!({"method":method,"latency_ms":start.elapsed().as_millis(),"result":result})
    );
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    let method = args.get(1).ok_or("provide status, balance, activity, deposit, recv, prepare, send, plan, exit, or exit-status")?;
    if method == "decode" {
        let invoice = fs::read_to_string(args.get(2).ok_or("invoice file required")?)?
            .trim()
            .parse::<lightning_invoice::Bolt11Invoice>()?;
        println!(
            "{}",
            serde_json::json!({"amount_msat":invoice.amount_milli_satoshis(),"description":format!("{:?}",invoice.description()),"payment_hash":invoice.payment_hash().to_string(),"payee":invoice.recover_payee_pub_key().to_string(),"currency":format!("{:?}",invoice.currency())})
        );
        return Ok(());
    }
    let root = env::var("WAVE_SPIKE_ROOT")?;
    let tls = ClientTlsConfig::new()
        .domain_name("localhost")
        .ca_certificate(Certificate::from_pem(fs::read(format!(
            "{root}/tls/ca.crt"
        ))?));
    let channel = Endpoint::from_static("https://127.0.0.1:10029")
        .tls_config(tls)?
        .connect_timeout(Duration::from_secs(10))
        .timeout(Duration::from_secs(40))
        .connect()
        .await?;
    let mac = hex::encode(fs::read(format!("{root}/agent.macaroon"))?)
        .parse::<tonic::metadata::MetadataValue<_>>()?;
    let board_channel = channel.clone();
    let mut client = wallet_service_client::WalletServiceClient::with_interceptor(
        channel,
        move |mut req: Request<()>| {
            req.metadata_mut().insert("macaroon", mac.clone());
            Ok(req)
        },
    );
    let status_start = Instant::now();
    let status = client.status(StatusRequest {}).await?.into_inner();
    if status.network != "signet" {
        return Err("refusing a non-signet daemon".into());
    }
    let start = Instant::now();
    macro_rules! call {
        ($name:ident, $req:expr) => {
            emit(
                method,
                start,
                client.$name($req).await.map(|r| r.into_inner()),
            )
        };
    }
    let value = || args.get(2).ok_or("missing argument");
    match method.as_str() {
        "status" => emit(method, status_start, Ok(status)),
        "balance" => call!(balance, BalanceRequest {}),
        "activity" | "vtxos" | "onchain" => call!(
            list,
            ListRequest {
                view: match method.as_str() {
                    "vtxos" => 2,
                    "onchain" => 3,
                    _ => 1,
                },
                limit: 100,
                ..Default::default()
            }
        ),
        "deposit" => call!(
            deposit,
            DepositRequest {
                amt_sat_hint: 100_000
            }
        ),
        "board" => {
            let board_mac = hex::encode(fs::read(format!("{root}/board.macaroon"))?)
                .parse::<tonic::metadata::MetadataValue<_>>()?;
            let mut daemon = daemon::daemon_service_client::DaemonServiceClient::with_interceptor(
                board_channel,
                move |mut request: Request<()>| {
                    request.metadata_mut().insert("macaroon", board_mac.clone());
                    Ok(request)
                },
            );
            emit(
                method,
                start,
                daemon
                    .board(daemon::BoardRequest {
                        target_vtxo_count: 2,
                        no_persist: false,
                    })
                    .await
                    .map(|r| r.into_inner()),
            );
        }
        "raw-proof" => {
            let hash = value()?;
            let token = hex::encode(fs::read(format!("{root}/diagnostic.macaroon"))?)
                .parse::<tonic::metadata::MetadataValue<_>>()?;
            let mut swaps =
                swap::swap_client_service_client::SwapClientServiceClient::with_interceptor(
                    board_channel,
                    move |mut request: Request<()>| {
                        request.metadata_mut().insert("macaroon", token.clone());
                        Ok(request)
                    },
                );
            let record = swaps
                .get_swap(swap::GetSwapRequest {
                    payment_hash: hash.clone(),
                })
                .await?
                .into_inner()
                .swap
                .ok_or("swap missing")?;
            let preimage = hex::decode(&record.preimage)?;
            if preimage.len() != 32 || hex::encode(Sha256::digest(preimage)) != *hash {
                return Err("invalid payment proof".into());
            }
            println!(
                "{}",
                serde_json::json!({"method":"raw-proof","payment_hash":record.payment_hash,"verified":true,"amount_sat":record.amount_sat,"fee_sat":record.fee_sat,"state":record.state})
            );
        }
        "recv" => call!(
            recv,
            RecvRequest {
                amt_sat: value()?.parse()?,
                memo: "OpenAgents signet spike".into(),
                ..Default::default()
            }
        ),
        "prepare" => call!(
            prepare_send,
            PrepareSendRequest {
                destination: Some(prepare_send_request::Destination::Invoice(
                    fs::read_to_string(value()?)?.trim().into()
                )),
                max_fee_sat: 100,
                note: "OpenAgents signet spike".into(),
                ..Default::default()
            }
        ),
        "send" => call!(
            send,
            SendRequest {
                send_intent_id: value()?.into()
            }
        ),
        "plan" => call!(
            get_exit_plan,
            GetExitPlanRequest {
                outpoints: vec![value()?.into()],
                ..Default::default()
            }
        ),
        "exit" => call!(
            exit,
            ExitRequest {
                outpoint: value()?.into(),
                force_unroll_ack: args.get(3).cloned().unwrap_or_default(),
                ..Default::default()
            }
        ),
        "exit-status" => call!(
            exit_status,
            ExitStatusRequest {
                outpoint: value()?.into(),
                detailed: true
            }
        ),
        "proof" => {
            let hash = value()?;
            let response = client
                .list(ListRequest {
                    view: 1,
                    limit: 100,
                    ..Default::default()
                })
                .await?
                .into_inner();
            let Some(list_response::Body::Activity(activity)) = response.body else {
                return Err("activity missing".into());
            };
            let entries: Vec<_> = activity
                .entries
                .iter()
                .filter(|entry| {
                    entry
                        .progress
                        .as_ref()
                        .is_some_and(|p| &p.payment_hash == hash)
                })
                .collect();
            let mut proofs = Vec::new();
            for entry in &entries {
                let progress = entry.progress.as_ref().unwrap();
                if progress.preimage.is_empty() {
                    continue;
                }
                let preimage = hex::decode(&progress.preimage)?;
                if preimage.len() != 32 || hex::encode(Sha256::digest(&preimage)) != *hash {
                    return Err("invalid payment proof".into());
                }
                proofs.push(serde_json::json!({"id":entry.id,"status":entry.status,"amount_sat":entry.amount_sat,"fee_sat":entry.fee_sat,"verified":true}));
            }
            println!(
                "{}",
                serde_json::json!({"method":"proof","matching_entries":entries.len(),"proofs":proofs})
            );
        }
        "watch" => {
            let hash = value()?;
            let deadline = Instant::now()
                + Duration::from_secs(args.get(3).ok_or("duration required")?.parse()?);
            loop {
                let response = client
                    .list(ListRequest {
                        view: 1,
                        limit: 100,
                        ..Default::default()
                    })
                    .await?
                    .into_inner();
                let Some(list_response::Body::Activity(activity)) = response.body else {
                    return Err("activity missing".into());
                };
                let entries: Vec<_> = activity
                    .entries
                    .iter()
                    .filter(|entry| {
                        entry
                            .progress
                            .as_ref()
                            .is_some_and(|p| &p.payment_hash == hash)
                    })
                    .collect();
                if entries.len() > 1 {
                    return Err("expected exactly one activity entry".into());
                }
                if entries.is_empty() {
                    if Instant::now() >= deadline {
                        println!(
                            "{}",
                            serde_json::json!({"method":"watch","elapsed_ms":start.elapsed().as_millis(),"matching_entries":0,"status":0})
                        );
                        break;
                    }
                    tokio::time::sleep(Duration::from_millis(250)).await;
                    continue;
                }
                let entry = entries[0];
                if entry.status == 2 || entry.status == 3 || Instant::now() >= deadline {
                    let progress = entry.progress.as_ref().unwrap();
                    let verified = if progress.preimage.is_empty() {
                        false
                    } else {
                        let preimage = hex::decode(&progress.preimage)?;
                        preimage.len() == 32 && hex::encode(Sha256::digest(preimage)) == *hash
                    };
                    println!(
                        "{}",
                        serde_json::json!({"method":"watch","elapsed_ms":start.elapsed().as_millis(),"matching_entries":entries.len(),"id":entry.id,"status":entry.status,"amount_sat":entry.amount_sat,"fee_sat":entry.fee_sat,"phase":progress.phase_label,"preimage_verified":verified})
                    );
                    break;
                }
                tokio::time::sleep(Duration::from_millis(250)).await;
            }
        }
        _ => return Err("unknown command".into()),
    }
    Ok(())
}
