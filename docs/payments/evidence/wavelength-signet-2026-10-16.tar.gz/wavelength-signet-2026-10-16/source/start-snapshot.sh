#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
test -x snapshot-bin/waved
test ! -d private-release-state
kill -TERM "$(cat daemon.pid)"
for i in {1..30}; do
  if ! ss -ltn | grep -q '127.0.0.1:10029'; then break; fi
  sleep 1
done
if ss -ltn | grep -q '127.0.0.1:10029'; then exit 1; fi
cp -a state private-release-state
chmod 700 private-release-state
nohup ./snapshot-bin/waved --network=signet --wallet.type=lwwallet --wallet.esploraurl=https://mempool.space/signet/api --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> snapshot-daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
./snapshot-bin/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" unlock --wallet-password-file="$PWD/wallet-password" > snapshot-unlock.json 2> snapshot-unlock.stderr
./snapshot-bin/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt" getinfo > snapshot-getinfo.json
export WAVE_SPIKE_ROOT="$PWD"
"$HOME/openagents-target-agent2/debug/wavelength-spike" proof 440c13018cd83829dea75d56da00abdd1ce9ed00b5ecc91d86c01e7d9e6ce7d2 > snapshot-old-credit-proof.json
cat snapshot-old-credit-proof.json
