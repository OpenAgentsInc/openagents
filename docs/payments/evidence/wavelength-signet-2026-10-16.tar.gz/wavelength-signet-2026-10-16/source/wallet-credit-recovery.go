// Recover two independently observed signet credits in the scratch wallet.
// No private key is opened, decrypted, printed, or changed.
package main
import (
 "bytes"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "time"
 address "github.com/btcsuite/btcd/address/v2"
 "github.com/btcsuite/btcd/chaincfg/v2"
 "github.com/btcsuite/btcd/chainhash/v2"
 "github.com/btcsuite/btcd/txscript/v2"
 "github.com/btcsuite/btcwallet/waddrmgr"
 "github.com/btcsuite/btcwallet/walletdb"
 _ "github.com/btcsuite/btcwallet/walletdb/bdb"
 "github.com/btcsuite/btcwallet/wtxmgr"
)
type Credit struct { Txid string `json:"txid"`; Hex string `json:"hex"`; Height int32 `json:"height"`; BlockHash string `json:"block_hash"`; BlockTime int64 `json:"block_time"`; Address string `json:"address"`; Value int64 `json:"value"` }
func main() {
 raw,err:=os.ReadFile(os.Args[2]); if err!=nil {panic(err)}
 var credits []Credit; if err=json.Unmarshal(raw,&credits); err!=nil {panic(err)}
 if len(credits)!=2 {panic("exactly two scratch credits are required")}
 expected:=map[string]int64{"fbebd47032ec11231e9b6ce1e1909793c9ff18707d040f0a6f291b182622cd92":10000,"cddb2e674c8b26af6d4495c00891e364f25c21ffa3e317df00ef6d0e71dcec49":199202}
 db,err:=walletdb.Open("bdb",os.Args[1],true,time.Second,false); if err!=nil {panic(err)}; defer db.Close()
 summary:=map[string]any{"network":"signet","private_key_access":false}
 err=walletdb.Update(db,func(tx walletdb.ReadWriteTx) error {
  ns:=tx.ReadWriteBucket([]byte("waddrmgr"))
  mgr,err:=waddrmgr.Open(ns,[]byte("lwwallet"),&chaincfg.SigNetParams); if err!=nil {return err}; defer mgr.Close()
  txns:=tx.ReadWriteBucket([]byte("wtxmgr"))
  store,err:=wtxmgr.Open(txns,&chaincfg.SigNetParams); if err!=nil {return err}
  before,err:=store.UnspentOutputs(txns); if err!=nil {return err}; summary["unspent_before"]=len(before)
  beforeRows:=[]map[string]any{}; for _,c:=range before {beforeRows=append(beforeRows,map[string]any{"txid":c.OutPoint.Hash.String(),"height":c.Height,"value_sat":int64(c.Amount)})}; summary["credits_before"]=beforeRows
  for _,c:=range credits {
   if expected[c.Txid]!=c.Value || c.Value<=0 || c.Height<326551 || c.Height>326553 {return fmt.Errorf("unexpected scratch credit")}
   b,err:=hex.DecodeString(c.Hex); if err!=nil {return err}; if len(b)>400000 {return fmt.Errorf("transaction too large")}
   rec,err:=wtxmgr.NewTxRecord(b,time.Unix(c.BlockTime,0)); if err!=nil {return err}
   rec,err=wtxmgr.NewTxRecordFromMsgTx(&rec.MsgTx,time.Unix(c.BlockTime,0)); if err!=nil {return err}
   if rec.Hash.String()!=c.Txid || len(rec.MsgTx.TxOut)==0 {return fmt.Errorf("transaction hash mismatch")}
   addr,err:=address.DecodeAddress(c.Address,&chaincfg.SigNetParams); if err!=nil {return err}
   if _,err=mgr.Address(ns,addr); err!=nil {return fmt.Errorf("funding address is not owned: %w",err)}
   script,err:=txscript.PayToAddrScript(addr); if err!=nil {return err}
   if rec.MsgTx.TxOut[0].Value!=c.Value || !bytes.Equal(rec.MsgTx.TxOut[0].PkScript,script) {return fmt.Errorf("output mismatch")}
   h,err:=chainhash.NewHashFromStr(c.BlockHash); if err!=nil {return err}
   block:=&wtxmgr.BlockMeta{Block:wtxmgr.Block{Hash:*h,Height:c.Height},Time:time.Unix(c.BlockTime,0)}
   if err=store.InsertTx(txns,rec,block); err!=nil {return err}
   if err=store.AddCredit(txns,rec,block,0,false); err!=nil {return err}
  }
  after,err:=store.UnspentOutputs(txns); if err!=nil {return err}
  var total int64; for _,c:=range after {total+=int64(c.Amount)}
  summary["unspent_after"]=len(after); summary["unspent_amount_sat"]=total
  if len(after)!=2 || total!=209202 {return fmt.Errorf("unexpected recovery balance")}
  return nil
 }); if err!=nil {panic(err)}
 b,_:=json.MarshalIndent(summary,"","  "); fmt.Println(string(b))
}
