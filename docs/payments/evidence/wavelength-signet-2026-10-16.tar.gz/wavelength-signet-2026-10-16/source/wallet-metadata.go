// Read only public synchronization metadata from a stopped scratch wallet copy.
package main
import (
 "encoding/binary"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "time"
 bolt "go.etcd.io/bbolt"
)
func main() {
 db,err:=bolt.Open(os.Args[1],0600,&bolt.Options{ReadOnly:true,Timeout:time.Second}); if err!=nil {panic(err)}; defer db.Close()
 result:=map[string]any{}
 err=db.View(func(tx *bolt.Tx) error {
  ns:=tx.Bucket([]byte("waddrmgr")); if ns==nil {return fmt.Errorf("missing address manager")}
  sync:=ns.Bucket([]byte("sync")); if sync==nil {return fmt.Errorf("missing sync metadata")}
  for _,key:=range []string{"syncedto","startblock","birthdayblock"} {
   v:=sync.Get([]byte(key)); row:=map[string]any{"bytes":len(v),"public_metadata_hex":hex.EncodeToString(v)}
   if len(v)>=4 {row["first_u32_le"]=binary.LittleEndian.Uint32(v[:4])}; result[key]=row
  }; return nil
 }); if err!=nil {panic(err)}
 b,_:=json.MarshalIndent(result,"","  "); fmt.Println(string(b))
}
