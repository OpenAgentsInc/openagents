#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/wavelength-spike"
umask 077
export WAVE_SPIKE_ROOT="$PWD"
cli=(./wavelength-linux-amd64-v0.1.2/wavecli --network=signet --datadir="$PWD/state" --tlscertpath="$PWD/tls/ca.crt")
"$HOME/openagents-target-agent2/debug/wavelength-spike" recv 500 > wallet-offline-credit-invoice.json
python3 - <<'PYCODE'
import json
from pathlib import Path
response=json.loads(Path('wallet-offline-credit-invoice.json').read_text())['result']['ok']
assert response['credit_receive'] is not None
Path('wallet-offline-credit-request.json').write_text(json.dumps({'rail':'lightning','destination':response['invoice'],'amount_sats':500}))
Path('wallet-offline-credit-hash.txt').write_text(response['entry']['progress']['payment_hash'])
PYCODE
date -u +%FT%TZ > wallet-offline-credit-stopped.txt
kill -KILL "$(cat daemon.pid)"
curl -sS --max-time 60 -D wallet-offline-credit-faucet.headers https://arkfaucet.com/api/request -H 'Content-Type: application/json' --data-binary @wallet-offline-credit-request.json -o wallet-offline-credit-faucet.json
cat wallet-offline-credit-faucet.json
# Restart the released daemon with its default credit policy.
nohup ./wavelength-linux-amd64-v0.1.2/waved --network=signet --wallet.type=lwwallet --wallet.esploraurl=https://mempool.space/signet/api --datadir="$PWD/state" --rpc.listenaddr=127.0.0.1:10029 --rpc.tlscertpath="$PWD/tls/server.crt" --rpc.tlskeypath="$PWD/tls/server.key" >> daemon.log 2>&1 < /dev/null &
echo $! > daemon.pid
sleep 3
"${cli[@]}" unlock --wallet-password-file="$PWD/wallet-password" > wallet-offline-credit-unlock.json 2> wallet-offline-credit-unlock.stderr
date -u +%FT%TZ > wallet-offline-credit-unlocked.txt
"$HOME/openagents-target-agent2/debug/wavelength-spike" watch "$(cat wallet-offline-credit-hash.txt)" 60 > wallet-offline-credit-watch.json
"$HOME/openagents-target-agent2/debug/wavelength-spike" balance > wallet-offline-credit-balance.json
python3 - <<'PY'
import json
from pathlib import Path
watch=json.loads(Path('wallet-offline-credit-watch.json').read_text())
balance=json.loads(Path('wallet-offline-credit-balance.json').read_text())['result']['ok']
assert watch['status']==2 and watch['matching_entries']==1,watch
assert watch['amount_sat']==500,watch
print(json.dumps({'watch':watch,'balance':balance},indent=2))
PY
