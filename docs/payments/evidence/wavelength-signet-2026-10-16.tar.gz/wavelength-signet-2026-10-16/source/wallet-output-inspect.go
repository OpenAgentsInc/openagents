// Inspect public output metadata in a stopped scratch wallet copy.
package main
import (
 "encoding/json"
 "fmt"
 "os"
 "time"
 "github.com/btcsuite/btcd/chaincfg/v2"
 "github.com/btcsuite/btcd/txscript/v2"
 "github.com/btcsuite/btcwallet/waddrmgr"
 "github.com/btcsuite/btcwallet/wallet"
 "github.com/btcsuite/btcwallet/walletdb"
 _ "github.com/btcsuite/btcwallet/walletdb/bdb"
 "github.com/btcsuite/btcwallet/wtxmgr"
)
func main() {
 db,err:=walletdb.Open("bdb",os.Args[1],true,time.Second,true); if err!=nil {panic(err)}; defer db.Close()
 w,err:=wallet.Open(db,[]byte("lwwallet"),nil,&chaincfg.SigNetParams,0); if err!=nil{panic(err)}
 outputs,err:=w.ListUnspent(1,2147483647,"");if err!=nil{panic(err)}
 result:=map[string]any{"private_key_access":false,"list_unspent":outputs}
 err=walletdb.View(db,func(tx walletdb.ReadTx) error {
  ns:=tx.ReadBucket([]byte("waddrmgr"))
  mgr,err:=waddrmgr.Open(ns,[]byte("lwwallet"),&chaincfg.SigNetParams); if err!=nil {return err}; defer mgr.Close()
  result["synced_height"]=mgr.SyncedTo().Height
  txns:=tx.ReadBucket([]byte("wtxmgr"))
  store,err:=wtxmgr.Open(txns,&chaincfg.SigNetParams); if err!=nil {return err}
  credits,err:=store.UnspentOutputs(txns); if err!=nil {return err}
  rows:=[]map[string]any{}
  for _,c:=range credits {
   class,addrs,_,err:=txscript.ExtractPkScriptAddrs(c.PkScript,&chaincfg.SigNetParams); if err!=nil{return err}
   row:=map[string]any{"txid":c.OutPoint.Hash.String(),"height":c.Height,"value_sat":int64(c.Amount),"coinbase":c.FromCoinBase,"class":class.String(),"confirmations":mgr.SyncedTo().Height-c.Height+1}
   for _,a:=range addrs {sm,acct,err:=mgr.AddrAccount(ns,a); if err!=nil {return err}; name,err:=sm.AccountName(ns,acct); if err!=nil{return err}; row["account"]=name; row["scope"]=sm.Scope();row["address"]=a.EncodeAddress()}
   rows=append(rows,row)
  };result["credits"]=rows;return nil
 });if err!=nil{panic(err)}
 b,_:=json.MarshalIndent(result,"","  ");fmt.Println(string(b))
}
