// Inspect public ownership metadata in a stopped scratch wallet copy.
package main
import (
 "encoding/json"
 "fmt"
 "os"
 "time"
 address "github.com/btcsuite/btcd/address/v2"
 "github.com/btcsuite/btcd/chaincfg/v2"
 "github.com/btcsuite/btcwallet/waddrmgr"
 "github.com/btcsuite/btcwallet/walletdb"
 _ "github.com/btcsuite/btcwallet/walletdb/bdb"
)
func main() {
 db,err:=walletdb.Open("bdb",os.Args[1],true,time.Second,true); if err!=nil {panic(err)}; defer db.Close()
 result:=map[string]any{}
 err=walletdb.View(db,func(tx walletdb.ReadTx) error {
  ns:=tx.ReadBucket([]byte("waddrmgr"))
  manager,err:=waddrmgr.Open(ns,[]byte("lwwallet"),&chaincfg.SigNetParams); if err!=nil {return err}; defer manager.Close()
  for _,text:=range []string{"tb1pjfrwlaafuy8cta7xw4qp9p7k4lquv9hyfsudfsh9hdm9cc5yxp3s3ukfx2","tb1p4u5k8j29laqlu7ck0rkdn00hquycr3k8hl9pyd2lag97wl6qlfqqhszu4z"} {
   addr,err:=address.DecodeAddress(text,&chaincfg.SigNetParams); if err!=nil {return err}
   managed,err:=manager.Address(ns,addr)
   row:=map[string]any{"owned":err==nil}
   if err!=nil {row["error"]=err.Error()} else {row["imported"]=managed.Imported()}
   result[text]=row
  }; return nil
 }); if err!=nil {panic(err)}
 b,_:=json.MarshalIndent(result,"","  "); fmt.Println(string(b))
}
