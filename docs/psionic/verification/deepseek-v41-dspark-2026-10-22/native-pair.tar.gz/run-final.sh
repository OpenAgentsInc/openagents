#!/usr/bin/env bash
set -euo pipefail
cd /mnt/maya/dspark-final
export LD_LIBRARY_PATH=/mnt/maya/bin/lib PSIONIC_REQUIRE_CUDA=1 TMPDIR=/mnt/maya/dspark-tmp
backend=compact/psionic_backend_cuda-aae56e8838fb3dce
stage_main=compact/psionic_v41_stage-711e979ed2305167
stage_lib=compact/psionic_v41_stage-eb0af08d3fb5fcf5
integration=compact/cuda-eafa423b1158ed37
{
  date -u +%FT%TZ
  nvidia-smi --query-gpu=name,uuid,driver_version,memory.used --format=csv
  sha256sum worker "$backend" "$stage_main" "$stage_lib" "$integration"
  "$backend" dspark_ --test-threads=1 --nocapture
  "$backend" v41_calibration_ --test-threads=1 --nocapture
  "$backend" consumer_q_ --test-threads=1 --nocapture
  "$stage_main" dspark_ --test-threads=1 --nocapture
  "$stage_lib" dspark_ --test-threads=1 --nocapture
  "$integration" dspark_ --test-threads=1 --nocapture
  "$integration" batched_teacher_forcing --test-threads=1 --nocapture
  date -u +%FT%TZ
} > controls.log 2>&1
date -u +%FT%TZ > controls-complete.txt
bash run-paired.sh
date -u +%FT%TZ > run-finished.txt
