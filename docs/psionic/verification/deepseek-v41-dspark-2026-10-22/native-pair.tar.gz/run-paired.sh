#!/usr/bin/env bash
set -euo pipefail
cd /mnt/maya/dspark-final
export LD_LIBRARY_PATH=/mnt/maya/bin/lib TMPDIR=/mnt/maya/dspark-tmp
mkdir -p paired
sha256sum worker oracle-prompts-all.jsonl > paired/input-sha256.txt
sha256sum /mnt/maya/bin/lib/*.so.13 > paired/library-sha256.txt
python3 - <<'PY' > paired/checkpoint-metadata.json
import pathlib,hashlib,json
root=pathlib.Path('/mnt/maya/ckpt')
print(json.dumps({'revision':'1bae0e1088993b9b82de08f59de5be5a34e42170',
    'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.json'))}},indent=2))
PY
./worker build-info > paired/build-info.json
nvidia-smi --query-gpu=name,uuid,memory.total,driver_version --format=csv > paired/gpu.csv
nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu --format=csv -l 2 > paired/memory.csv &
monitor=$!
trap 'kill "$monitor" 2>/dev/null || true' EXIT
args=(chain --weights /mnt/maya/ckpt --split 0-40 --gpus 0
  --max-context 32768 --max-step-tokens 4096 --prefill-chunk 4096
  --experts file --expert-cache 40 --engram file --prefill layer-major
  --kv packed --prompts-jsonl oracle-prompts-all.jsonl --max-tokens 32 --repeat-answer 9)
date -u +%FT%TZ > paired/dspark-started.txt
/usr/bin/time -v ./worker "${args[@]}" --dspark --answers-out paired/dspark.answers.jsonl > paired/dspark.report.json 2> paired/dspark.stderr.log
date -u +%FT%TZ > paired/dspark-finished.txt
date -u +%FT%TZ > paired/plain-started.txt
/usr/bin/time -v ./worker "${args[@]}" --answers-out paired/plain.answers.json > paired/plain.report.json 2> paired/plain.stderr.log
date -u +%FT%TZ > paired/plain-finished.txt
nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv > paired/gpu-after.csv
