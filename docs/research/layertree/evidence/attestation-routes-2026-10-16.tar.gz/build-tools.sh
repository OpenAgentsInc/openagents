#!/usr/bin/env bash
set -euo pipefail
umask 077
root="$HOME/layertree-attestation-spike"
mkdir -p "$root/bin"
export PATH="$HOME/wavelength-spike/go-toolchain/go/bin:$PATH"
export CGO_ENABLED=0
for item in go-sev-guest:9c5dffcd8230247336e07c70804a31f6b39ab3c9 go-tdx-guest:23b3eac9db39ba4e1df1426bacb3bfa3a7018e97; do
  repo=${item%%:*}
  revision=${item#*:}
  if [[ ! -d "$root/$repo-$revision" ]]; then
    curl -fsSL "https://api.github.com/repos/google/$repo/tarball/$revision" -o "$root/$repo-source.tar.gz"
    mkdir "$root/$repo-$revision"
    tar -xzf "$root/$repo-source.tar.gz" --strip-components=1 -C "$root/$repo-$revision"
  fi
  cd "$root/$repo-$revision"
  go build -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o "$root/bin/$repo-attest" ./tools/attest
  go version -m "$root/bin/$repo-attest" > "$root/bin/$repo-build.txt"
  sha256sum "$root/bin/$repo-attest"
done
