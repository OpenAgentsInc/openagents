import hashlib
import json
from pathlib import Path
import os
import subprocess

root = Path('/home/christopherdavid/layertree-probe')
marker = root / 'test-image.json'
marker.write_bytes(b'{"issue":11787,"purpose":"RTMR extension probe","not_a_boot_image":true}\n')
register = Path('/sys/class/misc/tdx_guest/measurements/rtmr3:sha384')
before = register.read_bytes()
assert len(before) == 48
image_digest = hashlib.sha384(marker.read_bytes()).digest()
nonce = os.urandom(64)
(root / 'tdx-challenge.hex').write_text(nonce.hex())
fd = os.open(register, os.O_WRONLY)
try:
    assert os.pwrite(fd, image_digest, 0) == 48
finally:
    os.close(fd)
after = register.read_bytes()
assert after == hashlib.sha384(before + image_digest).digest()
subprocess.run([str(root / 'go-tdx-guest-attest'), '-inform', 'hex', '-in', nonce.hex(), '-outform', 'bin', '-out', str(root / 'tdx-marker-quote.bin')], check=True)
quote = (root / 'tdx-marker-quote.bin').read_bytes()
assert int.from_bytes(quote[:2], 'little') == 4
assert quote[520:568] == after
assert quote[568:632] == nonce
summary = {'test_image_sha384':image_digest.hex(), 'rtmr3_before':before.hex(), 'rtmr3_after':after.hex(), 'expected_rtmr3':hashlib.sha384(before+image_digest).hexdigest(), 'report_data':nonce.hex(), 'rtmr3_matches_quote':True, 'quote_sha256':hashlib.sha256(quote).hexdigest(), 'proves_boot_image':False, 'signature_verification':'separate check required'}
(root / 'tdx-marker-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
