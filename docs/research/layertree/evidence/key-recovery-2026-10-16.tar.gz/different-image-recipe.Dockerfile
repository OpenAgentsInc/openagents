FROM us-central1-docker.pkg.dev/openagentsgemini/layertree-research/attestation-probe@sha256:79bf22d374f8c33a58f4c126ce36da9f729501d881ac80b48707d007653bf100
LABEL org.openagents.research.variant="wrong-image-denial"
