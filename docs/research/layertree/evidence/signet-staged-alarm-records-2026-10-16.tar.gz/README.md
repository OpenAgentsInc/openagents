# Staged signet alarm records

These are the public capture records, without four complete block bodies.
The full capture is named by the repository's bench-artifacts.json manifest.
To fill the missing blocks from your synced signet Bitcoin Core node, run
this from the extracted directory, then run layertree-export-stage:

```sh
for scenario in genesis withheld mismatch theft; do
  block_hash=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["hash"])' "tree/core/$scenario-header.json")
  bitcoin-cli -signet getblock "$block_hash" 0 > "tree/core/$scenario-block.hex"
done
```

The exporter checks the blocks' hashes, Merkle roots, transaction inclusion
and coinbase heights. It does not replace signet consensus validation.
