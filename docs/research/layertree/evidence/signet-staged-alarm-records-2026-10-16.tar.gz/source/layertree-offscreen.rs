//! Scratch-only offscreen driver for the existing LayerTree Verse scene.
#[path = "/Users/christopherdavid/.openagents/scratch/claude-code-c3160c08-2f00-4201-a8dd-1358376c9832/signet-resume/crates/verse/examples/layertree/mod.rs"]
mod layertree;
use layertree::{scene, Set};
use std::path::PathBuf;
use verse::ui::Atlas;
#[derive(Clone)]
struct Options {
    events: PathBuf,
    video: Option<PathBuf>,
    shot: Option<PathBuf>,
    seconds: f32,
    fps: u32,
    at: Option<u64>,
    play: bool,
    compare_progress: bool,
    caption: Option<String>,
    from: u64,
    to: Option<u64>,
    rate: f32,
    capture_every: Option<f32>,
    capture: Option<PathBuf>,
    size: [u32; 2],
    scale: f32,
}

fn options() -> Result<Options, String> {
    let mut out = Options {
        events: PathBuf::new(),
        video: None,
        shot: None,
        seconds: 12.0,
        fps: 24,
        at: None,
        play: false,
        compare_progress: false,
        caption: None,
        from: 0,
        to: None,
        rate: 0.6,
        capture_every: None,
        capture: None,
        size: [1920, 1080],
        scale: 1.5,
    };
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        let mut value = || args.next().ok_or_else(|| format!("{arg} needs a value."));
        match arg.as_str() {
            "--events" => out.events = value()?.into(),
            "--video" => out.video = Some(value()?.into()),
            "--shot" => out.shot = Some(value()?.into()),
            "--seconds" => out.seconds = value()?.parse().map_err(|_| "Choose video seconds.")?,
            "--fps" => out.fps = value()?.parse().map_err(|_| "Choose frames per second.")?,
            "--caption" => out.caption = Some(value()?),
            "--at" => out.at = Some(value()?.parse().map_err(|_| "Choose an event number.")?),
            "--capture" => out.capture = Some(value()?.into()),
            "--scale" => {
                out.scale = value()?
                    .parse()
                    .map_err(|_| "Choose a text scale from 1 to 4.")?
            }
            "--size" => {
                let size = value()?;
                let (w, h) = size.split_once('x').ok_or("Use --size WIDTHxHEIGHT.")?;
                out.size = [
                    w.parse().map_err(|_| "Choose a pixel width.")?,
                    h.parse().map_err(|_| "Choose a pixel height.")?,
                ];
            }
            "--play" => out.play = true,
            "--compare-progress" => out.compare_progress = true,
            "--from" => out.from = value()?.parse().map_err(|_| "Choose a start event.")?,
            "--to" => out.to = Some(value()?.parse().map_err(|_| "Choose an end event.")?),
            "--rate" => out.rate = value()?.parse().map_err(|_| "Choose events per second.")?,
            "--capture-every" => {
                out.capture_every = Some(
                    value()?
                        .parse()
                        .map_err(|_| "Choose seconds between frames.")?,
                )
            }
            "--visual" => {}
            "--help" | "-h" => {
                println!(
                    "layertree --events FILE [--at EVENT] [--play --from N --to N --rate EVENTS_PER_SECOND] [--visual] [--capture FILE.png] [--capture-every SECONDS] [--size WIDTHxHEIGHT] [--scale 1..4]"
                );
                std::process::exit(0);
            }
            _ => return Err(format!("Unknown option: {arg}.")),
        }
    }
    if let Some(path) = &out.shot {
        let spec: serde_json::Value =
            serde_json::from_slice(&std::fs::read(path).map_err(|e| e.to_string())?)
                .map_err(|e| e.to_string())?;
        let scene = &spec["scene"];
        if scene["kind"] != "layer_tree" || spec["subframes"] != 1 || spec["prewarm"] != 0 {
            return Err(
                "This helper supports a LayerTree shot with one sample and no prewarm.".into(),
            );
        }
        out.events = scene["events"]
            .as_str()
            .ok_or("The shot needs an event file.")?
            .into();
        out.at = scene["at"].as_u64();
        out.play = scene["play"].as_bool().unwrap_or(false);
        out.from = scene["from"].as_u64().unwrap_or(0);
        out.to = scene["to"].as_u64();
        out.rate = scene["rate"].as_f64().unwrap_or(0.6) as f32;
        out.caption = scene["caption"].as_str().map(str::to_owned);
        out.compare_progress = scene["compare_progress"].as_bool().unwrap_or(false);
        out.size = [
            spec["width"].as_u64().ok_or("The shot needs a width.")? as u32,
            spec["height"].as_u64().ok_or("The shot needs a height.")? as u32,
        ];
        out.seconds = spec["duration"]
            .as_f64()
            .ok_or("The shot needs a duration.")? as f32;
        let fps = spec["fps"].as_f64().ok_or("The shot needs a frame rate.")?;
        if fps.fract() != 0.0 {
            return Err("This helper needs a whole-number frame rate.".into());
        }
        out.fps = fps as u32;
    }
    if out.events.as_os_str().is_empty() {
        return Err("Choose an event file with --events FILE.".into());
    }
    if !out.scale.is_finite() || !(1.0..=4.0).contains(&out.scale) {
        return Err("Choose a text scale from 1 to 4.".into());
    }
    if out.size.iter().any(|n| !(64..=8192).contains(n)) {
        return Err("Choose image dimensions from 64 to 8192 pixels.".into());
    }
    if out
        .capture_every
        .is_some_and(|n| !n.is_finite() || n < 0.05)
    {
        return Err("Choose at least 0.05 seconds between frames.".into());
    }
    if out.capture_every.is_some() && (!out.play || out.capture.is_none()) {
        return Err("Frame capture needs --play and --capture DIRECTORY.".into());
    }
    if !out.seconds.is_finite()
        || !(0.1..=120.0).contains(&out.seconds)
        || !(1..=60).contains(&out.fps)
    {
        return Err("Choose 0.1–120 seconds and 1–60 frames per second.".into());
    }
    if out.video.is_some() && out.capture.is_some() {
        return Err("Choose --video or --capture.".into());
    }
    Ok(out)
}

struct Fonts {
    raster: Atlas,
    layout: Atlas,
    scale: f32,
}
impl Fonts {
    fn new(scale: f32) -> Self {
        let raster = Atlas::new((14.0 * scale).round());
        let layout = raster
            .layout_at_scale(scale)
            .unwrap_or_else(|| Atlas::new(14.0));
        Self {
            raster,
            layout,
            scale,
        }
    }
}

fn run() -> Result<(), String> {
    let options = options()?;
    let mut set = Set::load(&options.events, options.at)?;
    set.compare_progress = options.compare_progress;
    set.caption = options.caption.clone();
    if options.play {
        set.play(options.from, options.to, options.rate)?;
    }
    let rig = options
        .shot
        .as_ref()
        .map(
            |path| -> Result<verse_engine::camera_rig::CameraRig, String> {
                let spec: serde_json::Value =
                    serde_json::from_slice(&std::fs::read(path).map_err(|e| e.to_string())?)
                        .map_err(|e| e.to_string())?;
                verse_engine::camera_rig::CameraRig::from_json(
                    &serde_json::to_vec(&spec["rig"]).map_err(|e| e.to_string())?,
                )
            },
        )
        .transpose()?;
    if let Some(path) = &options.video {
        use std::io::Write;
        use std::process::{Command, Stdio};
        let fonts = if options.shot.is_some() {
            Fonts {
                raster: Atlas::new(14.0),
                layout: Atlas::new(14.0),
                scale: 1.0,
            }
        } else {
            Fonts::new(options.scale)
        };
        let mut renderer = scene::renderer(options.size, &fonts.raster)?;
        let frames = (options.seconds * options.fps as f32).round().max(1.0) as u32;
        let mut encoder = Command::new("ffmpeg")
            .args([
                "-hide_banner",
                "-loglevel",
                "warning",
                "-y",
                "-f",
                "rawvideo",
                "-pixel_format",
                "rgba",
                "-video_size",
                &format!("{}x{}", options.size[0], options.size[1]),
                "-framerate",
                &options.fps.to_string(),
                "-i",
                "pipe:0",
                "-an",
                "-c:v",
                "libx264",
                "-preset",
                "medium",
                "-crf",
                "12",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
            ])
            .arg(path)
            .stdin(Stdio::piped())
            .stdout(Stdio::null())
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| format!("Could not start ffmpeg: {e}"))?;
        let mut pipe = encoder
            .stdin
            .take()
            .ok_or("Could not open the encoder input.")?;
        let rendered = (|| -> Result<(), String> {
            for frame in 0..frames {
                set.advance(frame as f32 / options.fps as f32 - set.time);
                let view = if let Some(rig) = &rig {
                    let sample = rig.sample(frame as f32 / options.fps as f32);
                    let (view_proj, eye) = verse_engine::camera_rig::lens_view_projection(
                        &sample,
                        options.size[0] as f32 / options.size[1] as f32,
                        0.1,
                        2000.0,
                        glam::Vec2::ZERO,
                    );
                    verse::render::View { view_proj, eye }
                } else {
                    scene::camera(
                        &set,
                        options.size[0] as f32 / options.size[1] as f32,
                        0.18,
                        1.0,
                    )
                };
                let size = options.size.map(|v| v as f32 / fonts.scale);
                renderer.set_overlay_size(size[0], size[1]);
                let ui = scene::overlay(&set, view, size, &fonts.layout, None, false);
                let pixels = renderer.draw(view, &scene::frame(&set), &ui, &scene::lighting())?;
                pipe.write_all(&pixels)
                    .map_err(|e| format!("Could not encode frame {frame}: {e}"))?;
                if frame % options.fps == 0 {
                    eprintln!("Rendered {frame}/{frames} frames.");
                }
            }
            Ok(())
        })();
        drop(pipe);
        let status = encoder
            .wait()
            .map_err(|e| format!("Could not finish ffmpeg: {e}"))?;
        rendered?;
        if !status.success() {
            return Err("ffmpeg did not finish the video.".into());
        }
        println!(
            "Wrote {} ({} frames at {} fps)",
            path.display(),
            frames,
            options.fps
        );
        return Ok(());
    }
    if let Some(path) = &options.capture {
        let fonts = Fonts::new(options.scale);
        let mut renderer = scene::renderer(options.size, &fonts.raster)?;
        let duration = set.duration();
        let step = options.capture_every.unwrap_or(duration.max(1.0));
        let frames = if options.capture_every.is_some() {
            (duration / step).ceil() as usize + 1
        } else {
            1
        };
        for frame in 0..frames {
            if frame > 0 {
                set.advance(step);
            } else if options.play && options.capture_every.is_none() {
                set.advance(duration);
            }
            let view = scene::camera(
                &set,
                options.size[0] as f32 / options.size[1] as f32,
                0.18,
                1.0,
            );
            let size = options.size.map(|v| v as f32 / fonts.scale);
            renderer.set_overlay_size(size[0], size[1]);
            let ui = scene::overlay(&set, view, size, &fonts.layout, None, false);
            let pixels = renderer.draw(view, &scene::frame(&set), &ui, &scene::lighting())?;
            let output = if options.capture_every.is_some() {
                path.join(format!("{frame:05}.png"))
            } else {
                path.clone()
            };
            scene::write_png(&output, options.size, &pixels)?;
        }
        println!("Wrote {}", path.display());
        return Ok(());
    }
    Err("This offscreen helper needs --capture FILE or --video FILE.".into())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(1);
    }
}
