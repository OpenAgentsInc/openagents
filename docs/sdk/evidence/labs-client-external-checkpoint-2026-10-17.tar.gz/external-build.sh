#!/bin/bash
set -euo pipefail
umask 077
export PATH=/var/lib/space-spike/home/openagents-tools/bin:$PATH
export CARGO_HOME=/var/lib/space-spike/home/openagents-cargo
export CARGO_TARGET_DIR=/var/lib/space-spike/home/openagents-target-agent2
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR=/var/lib/space-spike/home/evidence/schema-private-tmp
export OPENAGENTS_SCRATCH=$TMPDIR
cd /var/lib/space-spike/home/sdk-labs-external
cargo build --locked --manifest-path Cargo.toml > /var/lib/space-spike/home/evidence/labs-sdk/external-build.log 2>&1
sha256sum Cargo.lock /var/lib/space-spike/home/openagents-target-agent2/debug/sdk-labs-example
