#!/usr/bin/env bash
set -euo pipefail
umask 077
schema_home=/var/lib/space-spike/home
cd "$schema_home/schema-11868"
git diff --binary > "$schema_home/schema-11868-tested.patch"
git rev-parse b4f5df67e4 > "$schema_home/schema-11868-upstream-example.txt"
files=(schema-11868-app-export.log schema-11868-computers-export.log schema-11868-connections-tests.log schema-11868-connections-initial-umask002.log schema-11868-computers-tests.log schema-11868-app-schema-tests.log schema-11868-sdk-tests.log schema-11868-sdk-initial-target-mode775.log schema-11868-auth-prerequisite.log schema-11868-app-repeat.log schema-11868-computers-repeat.log schema-11868-public-inventory.log schema-11868-public-reference.log schema-11868-inventory-initial.log schema-11868-final-evidence.txt schema-11868-before-export.status schema-11868-private-file-trace.log schema-11868-tested.patch schema-11868-upstream-example.txt)
cd "$schema_home"
sha256sum "${files[@]}" > schema-11868-log-hashes.txt
files+=(schema-11868-log-hashes.txt)
tar -czf schema-11868-remote-evidence.tar.gz "${files[@]}"
sha256sum schema-11868-remote-evidence.tar.gz
