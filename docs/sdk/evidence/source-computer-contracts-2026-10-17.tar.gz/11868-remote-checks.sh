#!/usr/bin/env bash
set -euo pipefail
umask 077
export TMPDIR=/var/lib/space-spike/home/evidence/schema-private-tmp
export OPENAGENTS_SCRATCH="$TMPDIR"
mkdir -p "$TMPDIR"
chmod 700 "$TMPDIR"
export PATH=/var/lib/space-spike/home/openagents-tools/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_HOME=/var/lib/space-spike/home/openagents-cargo
export CARGO_TARGET_DIR=/var/lib/space-spike/home/openagents-target-agent2
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd /var/lib/space-spike/home/schema-11868
test "$(git rev-parse --short=10 HEAD)" = 7ff99a23bb
run() {
  local name="$1"
  shift
  "$@" > "/var/lib/space-spike/home/schema-11868-${name}.log" 2>&1
  tail -n5 "/var/lib/space-spike/home/schema-11868-${name}.log"
}
run connections-tests cargo test -p openagents-web connections::tests --lib
run computers-tests cargo test -p openagents-web computers_api --lib
run app-schema-tests cargo test -p openagents-web app_openapi --lib
run sdk-tests cargo test -p openagents-sdk
cargo run -p openagents-web --example app_openapi > /var/lib/space-spike/home/schema-11868-app-repeat.json 2> /var/lib/space-spike/home/schema-11868-app-repeat.log
cmp docs/sdk/openapi.app.json /var/lib/space-spike/home/schema-11868-app-repeat.json
cargo run -p openagents-web --example computers_openapi > /var/lib/space-spike/home/schema-11868-computers-repeat.json 2> /var/lib/space-spike/home/schema-11868-computers-repeat.log
cmp docs/sdk/openapi.computers.json /var/lib/space-spike/home/schema-11868-computers-repeat.json
run public-inventory python3 scripts/api/public_reference.py --write-inventory --schema docs/sdk/openapi.app.json --slice
run public-reference python3 -m unittest discover -s scripts/api -p test_public_reference.py
{
  git rev-parse HEAD
  git status --short
  rustc --version
  cargo --version
  sha256sum docs/sdk/openapi.app.json docs/sdk/openapi.computers.json crates/openagents-sdk/src/generated/computers.rs docs/sdk/computers-operations.json docs/sdk/route-inventory.json
  sha256sum "$CARGO_TARGET_DIR/debug/examples/app_openapi" "$CARGO_TARGET_DIR/debug/examples/computers_openapi"
  find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'openagents_web-*' -o -name 'openagents_sdk-*' -o -name 'computers-*' -o -name 'computers_contract-*' \) -executable -exec sha256sum {} +
} > /var/lib/space-spike/home/schema-11868-final-evidence.txt
cat /var/lib/space-spike/home/schema-11868-final-evidence.txt
