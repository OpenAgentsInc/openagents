#!/usr/bin/env bash
set -euo pipefail
export PATH=/var/lib/space-spike/home/openagents-tools/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_HOME=/var/lib/space-spike/home/openagents-cargo
export CARGO_TARGET_DIR=/var/lib/space-spike/home/openagents-target-agent2
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd /var/lib/space-spike/home/schema-11868
git fetch origin codex/grid-ready
git checkout -B schema-final FETCH_HEAD
test "$(git rev-parse --short=10 HEAD)" = 7ff99a23bb
git status --porcelain > /var/lib/space-spike/home/schema-11868-before-export.status
cargo run -p openagents-web --example app_openapi > docs/sdk/openapi.app.json 2> /var/lib/space-spike/home/schema-11868-app-export.log
cargo run -p openagents-web --example computers_openapi > docs/sdk/openapi.computers.json 2> /var/lib/space-spike/home/schema-11868-computers-export.log
git rev-parse HEAD
sha256sum docs/sdk/openapi.app.json docs/sdk/openapi.computers.json
tail -n 8 /var/lib/space-spike/home/schema-11868-computers-export.log
