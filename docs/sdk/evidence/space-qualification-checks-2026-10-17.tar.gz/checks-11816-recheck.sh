#!/usr/bin/env bash
set -euo pipefail
umask 077
exec > /var/lib/oa-sdk-build/scratch/checks-11816-recheck.log 2>&1
export PATH=/var/lib/oa-sdk-build/home/.cargo/bin:/usr/local/bin:/usr/bin:/bin
export CARGO_TARGET_DIR=/var/lib/oa-sdk-build/target CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
sdk_test_pg=/var/lib/oa-sdk-build/scratch/postgres-11816
sdk_test_pg_started=
finish() {
 sdk_test_exit=$?
 if [[ -n $sdk_test_pg_started ]]; then pg_ctl -D "$sdk_test_pg" -m fast stop || true; fi
 printf '{"exit_code":%s}\n' "$sdk_test_exit" > /var/lib/oa-sdk-build/scratch/checks-11816-recheck-status.json
 exit "$sdk_test_exit"
}
trap finish EXIT
cd /var/lib/oa-sdk-build/source
git fetch /var/lib/oa-sdk-build/home/scratch/sdk-11816-integrated.bundle HEAD
git reset --hard FETCH_HEAD
for sdk_test_bin in /usr/lib/postgresql/*/bin; do export PATH="$sdk_test_bin:$PATH"; done
if [[ ! -f $sdk_test_pg/PG_VERSION ]]; then initdb -D "$sdk_test_pg" -U postgres --auth=trust; fi
sdk_test_port=$(python3 -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1]);s.close()')
pg_ctl -D "$sdk_test_pg" -o "-p $sdk_test_port -k '' -c listen_addresses=127.0.0.1" -l /var/lib/oa-sdk-build/scratch/postgres.log start
sdk_test_pg_started=1
export OA_COMPUTERS_TEST_DATABASE_URL="host=127.0.0.1 port=$sdk_test_port user=postgres dbname=postgres"
cargo test -p oa-computers --features space
cargo test -p openagents-sdk
cargo build -p oa-computers --features space --bin oa-computers-usage
cargo build -p openagents-sdk --example computers
cargo fmt -p oa-computers -p openagents-sdk --check

/var/lib/oa-sdk-build/target/debug/oa-computers-usage qualification-template > /var/lib/oa-sdk-build/scratch/space-qualification-pending-11816.json
for stage in named test; do
 args=(); if [[ $stage == test ]]; then args+=(--test-accounts); fi
 set +e
 /var/lib/oa-sdk-build/target/debug/oa-computers-usage qualify /var/lib/oa-sdk-build/scratch/space-qualification-pending-11816.json "${args[@]}" > "/var/lib/oa-sdk-build/scratch/space-qualification-$stage-assessment-11816.json"
 status=$?
 set -e
 [[ $status == 1 ]]
done
