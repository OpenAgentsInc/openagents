from pathlib import Path
import hashlib,json,subprocess,sys,os,time,importlib.util,re
ROOT=Path("/tmp/openagents-12625-complete-20261101").resolve();GEN=Path("/tmp/coax-12625-native/final-v4/coax");OUT=Path(sys.argv[1]);mod=sys.argv[2];OUT.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
deps=json.loads(subprocess.check_output([str(GEN),"deps",str(ROOT/"coax/tests/results-cache-policy.coax")],cwd=ROOT));pins={}
for name in deps["sources"]:
 p=Path(name);rel=p.relative_to(ROOT);q=OUT/rel;q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(p.read_bytes());pins[str(rel)]=sha(p)
original=(ROOT/("coax/lib/compiler/"+mod+".coax")).read_text();ext=(ROOT/"coax/tests/results-cache-policy.coax").read_text();ext="\n".join(l for l in ext.splitlines() if not l.startswith("#load "))
prior=ROOT/"coax/tests/results-borrow-policy.coax";pins[str(prior.relative_to(ROOT))]=sha(prior);ext+="\n"+"\n".join(l for l in prior.read_text().splitlines() if not l.startswith("#load "))
if mod=="query-index":
 starts=list(re.finditer(r"(?m)^(CB_\w+) :: ",original));kept=[];moved=[];names=[]
 for i,m in enumerate(starts):
  text=original[m.start():starts[i+1].start() if i+1<len(starts) else len(original)]
  if m.group(1)=="CB_index_probe":kept.append(text)
  else:moved.append(text);names.append(m.group(1))
 (OUT/("coax/lib/compiler/"+mod+".coax")).write_text("#authority;\n"+"".join(kept));body="".join(moved)
else:
 (OUT/("coax/lib/compiler/"+mod+".coax")).write_text("// Exact source module moved into entry for stock root-only mutation.\n");body=original;names=re.findall(r"(?m)^(CB_\w+) :: ",original)
entry=OUT/"scope.coax";entry.write_text(ext+'\n#load "coax/lib/compiler/checker.coax";\n'+body)
private={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob("*.coax")}
(OUT/"setup.json").write_text(json.dumps({"schema":"coax.12625.cache.scope.v1","module":mod,"production_module_sha256":hashlib.sha256(original.encode()).hexdigest(),"moved_procedures":names,"source_pins":pins,"private_pins":private,"compiler_sha256":sha(GEN),"scope":"stock root-only exact production function bytes; new independent oracles first and all loaded old baseline checks retained; index_probe unchanged qualified body stays dependency"},indent=2)+"\n")
spec=importlib.util.spec_from_file_location("bp",ROOT/"coax/tools/bounded_process.py");bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp);t=time.monotonic();r=bp.run([str(GEN),"mutate",str(entry),"--root-only","--jobs","4"],ROOT,dict(os.environ),840,8388608,time.monotonic()+845,quiet_faults=True)
for k in ["stdout","stderr"]:(OUT/(k+".log")).write_bytes(r.pop(k))
r["elapsed_seconds"]=time.monotonic()-t;r["private_inputs_unchanged"]=all(sha(OUT/p)==v for p,v in private.items());r["shared_inputs_unchanged"]=all(sha(ROOT/p)==v for p,v in pins.items());(OUT/"process.json").write_text(json.dumps(r,indent=2)+"\n");print(r,flush=True)
