// C emitter: one self-contained C11 file per program. The runtime that
// Basic needs (print, checked arithmetic, bounds and cast checks) is written
// into the file, so the output builds with any C compiler and no Coax
// install: Xcode, Emscripten and plain cc treat it like any other C source.
//
// Runtime operands are evaluated left to right (spec §7.3): when an operand
// list has a call and another operand that could trap or call, the operands
// are stored in temporaries first, in source order, inside one C comma
// expression. Short-circuit operators and ifx keep C's own ordering.
#include "coax.h"

#include <cmath>
#include <algorithm>
#include <functional>
#include <map>
#include <set>
#include <filesystem>

namespace coax {

static const char *RUNTIME = R"COAXRT(/* Coax float arithmetic is plain IEEE, one rounding per operation: no fused
   multiply-add, so results match compile-time evaluation and other compilers. */
#pragma STDC FP_CONTRACT OFF
/* Generated code carries the whole runtime and keeps every declared local. */
#if defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#endif
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct { const char *data; int64_t count; } coax_string;
#define COAX_STR(lit, n) ((coax_string){(lit), (n)})

static void coax_trap(const char *what, int32_t line) {
  fflush(stdout);
  fprintf(stderr, "%s:%d: %s\n", coax_source_path, line, what);
  abort();
}

/* Checked arithmetic for every integer width. Debug builds call the
   checked forms, release builds the wrapping ones (spelled with the
   overflow builtins so no C undefined behavior remains). Division by zero,
   bad shifts, bounds and casts trap in every build. */
#define COAX_INT_OPS(T, N, SIGNED, MIN)                                                                  \
  static T coax_add_##N(T a, T b, int32_t l) { T r; if (__builtin_add_overflow(a, b, &r)) coax_trap("integer overflow in '+'", l); return r; } \
  static T coax_sub_##N(T a, T b, int32_t l) { T r; if (__builtin_sub_overflow(a, b, &r)) coax_trap("integer overflow in '-'", l); return r; } \
  static T coax_mul_##N(T a, T b, int32_t l) { T r; if (__builtin_mul_overflow(a, b, &r)) coax_trap("integer overflow in '*'", l); return r; } \
  static T coax_neg_##N(T a, int32_t l) { T r; if (__builtin_sub_overflow((T)0, a, &r)) coax_trap("integer overflow in unary '-'", l); return r; } \
  static T coax_wadd_##N(T a, T b) { T r; __builtin_add_overflow(a, b, &r); return r; }                \
  static T coax_wsub_##N(T a, T b) { T r; __builtin_sub_overflow(a, b, &r); return r; }                \
  static T coax_wmul_##N(T a, T b) { T r; __builtin_mul_overflow(a, b, &r); return r; }                \
  static T coax_wneg_##N(T a) { T r; __builtin_sub_overflow((T)0, a, &r); return r; }                  \
  static T coax_div_##N(T a, T b, int32_t l) {                                                          \
    if (b == 0) coax_trap("division by zero", l);                                                       \
    if (SIGNED && a == MIN && b == (T)-1) coax_trap("integer overflow in '/'", l);                      \
    return (T)(a / b);                                                                                  \
  }                                                                                                     \
  static T coax_mod_##N(T a, T b, int32_t l) {                                                          \
    if (b == 0) coax_trap("division by zero in '%'", l);                                                \
    if (SIGNED && b == (T)-1) return 0;                                                                 \
    return (T)(a % b);                                                                                  \
  }                                                                                                     \
  static T coax_shl_##N(T a, int64_t b, int32_t l) {                                                    \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) coax_trap("shift amount out of range", l);              \
    return (T)((uint64_t)a << b);                                                                       \
  }                                                                                                     \
  static T coax_shr_##N(T a, int64_t b, int32_t l) {                                                    \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) coax_trap("shift amount out of range", l);              \
    return (T)(a >> b);                                                                                 \
  }
COAX_INT_OPS(int8_t, s8, 1, INT8_MIN)
COAX_INT_OPS(int16_t, s16, 1, INT16_MIN)
COAX_INT_OPS(int32_t, s32, 1, INT32_MIN)
COAX_INT_OPS(int64_t, s64, 1, INT64_MIN)
COAX_INT_OPS(uint8_t, u8, 0, 0)
COAX_INT_OPS(uint16_t, u16, 0, 0)
COAX_INT_OPS(uint32_t, u32, 0, 0)
COAX_INT_OPS(uint64_t, u64, 0, 0)

static int64_t coax_index(int64_t i, int64_t n, int32_t l) {
  if (i < 0 || i >= n) coax_trap("index out of bounds", l);
  return i;
}
static void coax_slice_check(int64_t lo, int64_t hi, int64_t n, int32_t l) {
  if (lo < 0 || hi < lo || hi > n) coax_trap("slice out of bounds", l);
}
static uint8_t coax_byte(coax_string s, int64_t i, int32_t l) { return (uint8_t)s.data[coax_index(i, s.count, l)]; }
static coax_string coax_substr(coax_string s, int64_t lo, int64_t hi, int32_t l) {
  coax_slice_check(lo, hi, s.count, l);
  coax_string r = {s.data + lo, hi - lo};
  return r;
}
static _Bool coax_string_eq(coax_string a, coax_string b) {
  return a.count == b.count && (a.count == 0 || memcmp(a.data, b.data, (size_t)a.count) == 0);
}

/* Checked casts: the value must fit the target, in every build. */
static int64_t coax_cast_ss(int64_t v, int64_t lo, int64_t hi, int32_t l) {
  if (v < lo || v > hi) coax_trap("cast out of range", l);
  return v;
}
static uint64_t coax_cast_su(int64_t v, uint64_t hi, int32_t l) {
  if (v < 0 || (uint64_t)v > hi) coax_trap("cast out of range", l);
  return (uint64_t)v;
}
static int64_t coax_cast_us(uint64_t v, int64_t hi, int32_t l) {
  if (v > (uint64_t)hi) coax_trap("cast out of range", l);
  return (int64_t)v;
}
static uint64_t coax_cast_uu(uint64_t v, uint64_t hi, int32_t l) {
  if (v > hi) coax_trap("cast out of range", l);
  return v;
}
static int64_t coax_ftoi_s(double v, int64_t lo, int64_t hi, int32_t l) {
  if (!(v >= -9223372036854775808.0 && v < 9223372036854775808.0)) coax_trap("cast out of range", l);
  int64_t i = (int64_t)v;
  if (i < lo || i > hi) coax_trap("cast out of range", l);
  return i;
}
static _Bool coax_bytes_overlap(const void *a, int64_t n, const void *b, int64_t m) {
  if(n<=0 || m<=0) return 0;
  uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
  return x<=y ? y-x<(uint64_t)n : x-y<(uint64_t)m;
}
static float coax_f32_from_bits(uint32_t x){float f;memcpy(&f,&x,4);return f;}
static double coax_f64_from_bits(uint64_t x){double f;memcpy(&f,&x,8);return f;}
static uint32_t coax_f32_bits(float f){uint32_t x;memcpy(&x,&f,4);return x;}
static uint64_t coax_f64_bits(double f){uint64_t x;memcpy(&x,&f,8);return x;}
static float coax_to_f32(double v, int32_t l) {
  /* Finite values that would round to infinity do not fit; inf and nan stay. */
  if (isfinite(v) && fabs(v) >= 3.4028235677973366e38) coax_trap("cast out of range", l);
  return (float)v;
}
static uint64_t coax_ftoi_u(double v, uint64_t hi, int32_t l) {
  if (!(v > -1.0 && v < 18446744073709551616.0)) coax_trap("cast out of range", l);
  uint64_t u = (uint64_t)v;
  if (u > hi) coax_trap("cast out of range", l);
  return u;
}

/* Output. Floats print the shortest text that reads back as the same
   value, with a ".0" when it would otherwise look like an integer. */
static void coax_put(coax_string s) { fwrite(s.data, 1, (size_t)s.count, stdout); }
static void coax_print_int(int64_t v) { printf("%lld", (long long)v); }
static void coax_print_uint(uint64_t v) { printf("%llu", (unsigned long long)v); }
static void coax_print_bool(_Bool v) { fputs(v ? "true" : "false", stdout); }
static void coax_print_float(double v, int is_f32) {
  char buf[64];
  if (v != v) { fputs("nan", stdout); return; }
  if (v > 1.7976931348623157e308) { fputs("inf", stdout); return; }
  if (v < -1.7976931348623157e308) { fputs("-inf", stdout); return; }
  int p = 1;
  for (; p < 17; p++) {
    snprintf(buf, sizeof buf, "%.*e", p - 1, v);
    if (is_f32 ? (float)strtod(buf, 0) == (float)v : strtod(buf, 0) == v) break;
  }
  const char *e = strchr(buf, 'e');
  int exponent = e ? atoi(e + 1) : 0;
  if (exponent >= -5 && exponent < 17) {
    int decimals = p - 1 - exponent;
    snprintf(buf, sizeof buf, "%.*f", decimals > 0 ? decimals : 0, v);
    fputs(buf, stdout);
    if (!strchr(buf, '.')) fputs(".0", stdout);
  } else {
    snprintf(buf, sizeof buf, "%.*g", p, v);
    fputs(buf, stdout);
  }
}
static void coax_show_string(coax_string s) {
  fputc('"', stdout);
  for (int64_t i = 0; i < s.count; i++) {
    char c = s.data[i];
    if (c == '"' || c == '\\') { fputc('\\', stdout); fputc(c, stdout); }
    else if (c == '\n') fputs("\\n", stdout);
    else if (c == '\t') fputs("\\t", stdout);
    else if (c == '\r') fputs("\\r", stdout);
    else if (c == 0) fputs("\\0", stdout);
    else fputc(c, stdout);
  }
  fputc('"', stdout);
}
)COAXRT";
// Emitted only into programs that use value_barrier, so the seeds stay as they are.
static const char *BARRIER_RUNTIME = R"COAXRT(/* value_barrier (spec section 9): the value comes back unchanged, and the
   optimizer can't see through it to branch on a secret. Native: an empty asm
   that claims to change the register. wasm32 has no such asm: a call to an
   identity that is never inlined, through a volatile. */
#if defined(__wasm__) || !defined(__GNUC__)
#if defined(__GNUC__)
__attribute__((noinline))
#endif
static uint64_t coax_value_barrier_u64(uint64_t x){volatile uint64_t v=x;return v;}
#if defined(__GNUC__)
__attribute__((noinline))
#endif
static uint32_t coax_value_barrier_u32(uint32_t x){volatile uint32_t v=x;return v;}
#else
static inline uint64_t coax_value_barrier_u64(uint64_t x){__asm__("" : "+r"(x));return x;}
static inline uint32_t coax_value_barrier_u32(uint32_t x){__asm__("" : "+r"(x));return x;}
#endif
)COAXRT";

/* Loop versioning (Emitter::versioned_for): a loop whose indexes are affine
   in for-counters with invariant bounds first computes each index's
   interval, and every subexpression's, in exact int64 endpoints. When every
   endpoint fits and every index is inside its view or array, a copy of the
   loop without those checks runs; otherwise the checked loop runs, so a trap
   happens exactly where it would have. */
static const char *IV_RUNTIME = R"COAXRT(
typedef struct { int64_t lo, hi; } coax_iv;
static inline __attribute__((unused)) int coax_iv_add(coax_iv a, coax_iv b, coax_iv *r) {
  return !__builtin_add_overflow(a.lo, b.lo, &r->lo) && !__builtin_add_overflow(a.hi, b.hi, &r->hi);
}
static inline __attribute__((unused)) int coax_iv_sub(coax_iv a, coax_iv b, coax_iv *r) {
  return !__builtin_sub_overflow(a.lo, b.hi, &r->lo) && !__builtin_sub_overflow(a.hi, b.lo, &r->hi);
}
static inline __attribute__((unused)) int coax_iv_mul(coax_iv a, coax_iv b, coax_iv *r) {
  int64_t p[4];
  if (__builtin_mul_overflow(a.lo, b.lo, &p[0]) || __builtin_mul_overflow(a.lo, b.hi, &p[1]) ||
      __builtin_mul_overflow(a.hi, b.lo, &p[2]) || __builtin_mul_overflow(a.hi, b.hi, &p[3])) return 0;
  r->lo = p[0]; r->hi = p[0];
  for (int i = 1; i < 4; i++) { if (p[i] < r->lo) r->lo = p[i]; if (p[i] > r->hi) r->hi = p[i]; }
  return 1;
}
)COAXRT";

static const char *WRAP_RUNTIME = R"COAXRT(
static uint32_t coax_add_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a+b);}
static uint32_t coax_sub_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a-b);}
static uint32_t coax_mul_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a*b);}
static uint32_t coax_rotl_u32(uint32_t a,uint32_t b){unsigned k=(unsigned)(b&31u);return (uint32_t)((a<<k)|(a>>((32u-k)&31u)));}
static uint32_t coax_rotr_u32(uint32_t a,uint32_t b){unsigned k=(unsigned)(b&31u);return (uint32_t)((a>>k)|(a<<((32u-k)&31u)));}
static uint64_t coax_add_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a+b);}
static uint64_t coax_sub_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a-b);}
static uint64_t coax_mul_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a*b);}
static uint64_t coax_rotl_u64(uint64_t a,uint64_t b){unsigned k=(unsigned)(b&63u);return (uint64_t)((a<<k)|(a>>((64u-k)&63u)));}
static uint64_t coax_rotr_u64(uint64_t a,uint64_t b){unsigned k=(unsigned)(b&63u);return (uint64_t)((a>>k)|(a<<((64u-k)&63u)));}
)COAXRT";

// The device runtime of `coax cuda`: the same checks as RUNTIME, spelled for
// NVRTC (C++, no libc headers, no overflow builtins). A failed check executes
// a trap instruction: the launch fails and the host sees the error.
static const char *CUDA_RUNTIME = R"COAXRT(/* Coax float arithmetic is plain IEEE, one rounding per operation. Compile
   with --fmad=false (and the default --prec-div=true --prec-sqrt=true
   --ftz=false) so +, -, *, / and sqrt round exactly as the C build does. */
typedef signed char int8_t; typedef short int16_t; typedef int int32_t; typedef long long int64_t;
typedef unsigned char uint8_t; typedef unsigned short uint16_t; typedef unsigned int uint32_t; typedef unsigned long long uint64_t;
#define INT64_C(x) x##LL
#define UINT64_C(x) x##ULL
#define INT64_MIN (-9223372036854775807LL - 1)
#define INT64_MAX 9223372036854775807LL
#define UINT64_MAX 18446744073709551615ULL
#pragma nv_diag_suppress 177
#define COAX_DEV static __device__ inline
COAX_DEV void coax_trap(const char *what, int32_t line) { (void)what; (void)line; __trap(); }
/* Narrow integers are computed in 64 bits and range checked. */
#define COAX_NARROW_OPS(T, N, LO, HI)                                                                     \
  COAX_DEV T coax_add_##N(T a, T b, int32_t l) { int64_t r = (int64_t)a + (int64_t)b; if (r < LO || r > HI) coax_trap("integer overflow in '+'", l); return (T)r; } \
  COAX_DEV T coax_sub_##N(T a, T b, int32_t l) { int64_t r = (int64_t)a - (int64_t)b; if (r < LO || r > HI) coax_trap("integer overflow in '-'", l); return (T)r; } \
  COAX_DEV T coax_mul_##N(T a, T b, int32_t l) { int64_t r = (int64_t)a * (int64_t)b; if (r < LO || r > HI) coax_trap("integer overflow in '*'", l); return (T)r; } \
  COAX_DEV T coax_neg_##N(T a, int32_t l) { int64_t r = -(int64_t)a; if (r < LO || r > HI) coax_trap("integer overflow in unary '-'", l); return (T)r; } \
  COAX_DEV T coax_wadd_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a + (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wsub_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a - (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wmul_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a * (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wneg_##N(T a) { return (T)(uint64_t)(0ULL - (uint64_t)(int64_t)a); }
#define COAX_SHIFT_DIV_OPS(T, N, SIGNED, MIN)                                                             \
  COAX_DEV T coax_div_##N(T a, T b, int32_t l) {                                                          \
    if (b == 0) coax_trap("division by zero", l);                                                       \
    if (SIGNED && a == MIN && b == (T)-1) coax_trap("integer overflow in '/'", l);                      \
    return (T)(a / b);                                                                                  \
  }                                                                                                     \
  COAX_DEV T coax_mod_##N(T a, T b, int32_t l) {                                                          \
    if (b == 0) coax_trap("division by zero in '%'", l);                                                \
    if (SIGNED && b == (T)-1) return 0;                                                                 \
    return (T)(a % b);                                                                                  \
  }                                                                                                     \
  COAX_DEV T coax_shl_##N(T a, int64_t b, int32_t l) {                                                    \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) coax_trap("shift amount out of range", l);              \
    return (T)((uint64_t)a << b);                                                                       \
  }                                                                                                     \
  COAX_DEV T coax_shr_##N(T a, int64_t b, int32_t l) {                                                    \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) coax_trap("shift amount out of range", l);              \
    return (T)(a >> b);                                                                                 \
  }
COAX_NARROW_OPS(int8_t, s8, -128LL, 127LL)
COAX_NARROW_OPS(int16_t, s16, -32768LL, 32767LL)
COAX_NARROW_OPS(int32_t, s32, -2147483648LL, 2147483647LL)
COAX_NARROW_OPS(uint8_t, u8, 0LL, 255LL)
COAX_NARROW_OPS(uint16_t, u16, 0LL, 65535LL)
COAX_NARROW_OPS(uint32_t, u32, 0LL, 4294967295LL)
COAX_DEV int64_t coax_add_s64(int64_t a, int64_t b, int32_t l) { int64_t r = (int64_t)((uint64_t)a + (uint64_t)b); if (((a ^ r) & (b ^ r)) < 0) coax_trap("integer overflow in '+'", l); return r; }
COAX_DEV int64_t coax_sub_s64(int64_t a, int64_t b, int32_t l) { int64_t r = (int64_t)((uint64_t)a - (uint64_t)b); if (((a ^ b) & (a ^ r)) < 0) coax_trap("integer overflow in '-'", l); return r; }
COAX_DEV int64_t coax_mul_s64(int64_t a, int64_t b, int32_t l) {
  int64_t r = (int64_t)((uint64_t)a * (uint64_t)b);
  if ((a == -1 && b == INT64_MIN) || (b == -1 && a == INT64_MIN) || (a != 0 && (r / a != b))) coax_trap("integer overflow in '*'", l);
  return r;
}
COAX_DEV int64_t coax_neg_s64(int64_t a, int32_t l) { if (a == INT64_MIN) coax_trap("integer overflow in unary '-'", l); return -a; }
COAX_DEV int64_t coax_wadd_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a + (uint64_t)b); }
COAX_DEV int64_t coax_wsub_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a - (uint64_t)b); }
COAX_DEV int64_t coax_wmul_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a * (uint64_t)b); }
COAX_DEV int64_t coax_wneg_s64(int64_t a) { return (int64_t)(0ULL - (uint64_t)a); }
COAX_DEV uint64_t coax_add_u64(uint64_t a, uint64_t b, int32_t l) { uint64_t r = a + b; if (r < a) coax_trap("integer overflow in '+'", l); return r; }
COAX_DEV uint64_t coax_sub_u64(uint64_t a, uint64_t b, int32_t l) { if (b > a) coax_trap("integer overflow in '-'", l); return a - b; }
COAX_DEV uint64_t coax_mul_u64(uint64_t a, uint64_t b, int32_t l) { uint64_t r = a * b; if (a != 0 && r / a != b) coax_trap("integer overflow in '*'", l); return r; }
COAX_DEV uint64_t coax_neg_u64(uint64_t a, int32_t l) { if (a != 0) coax_trap("integer overflow in unary '-'", l); return 0; }
COAX_DEV uint64_t coax_wadd_u64(uint64_t a, uint64_t b) { return a + b; }
COAX_DEV uint64_t coax_wsub_u64(uint64_t a, uint64_t b) { return a - b; }
COAX_DEV uint64_t coax_wmul_u64(uint64_t a, uint64_t b) { return a * b; }
COAX_DEV uint64_t coax_wneg_u64(uint64_t a) { return 0ULL - a; }
COAX_SHIFT_DIV_OPS(int8_t, s8, 1, (int8_t)-128)
COAX_SHIFT_DIV_OPS(int16_t, s16, 1, (int16_t)-32768)
COAX_SHIFT_DIV_OPS(int32_t, s32, 1, (int32_t)(-2147483647 - 1))
COAX_SHIFT_DIV_OPS(int64_t, s64, 1, INT64_MIN)
COAX_SHIFT_DIV_OPS(uint8_t, u8, 0, 0)
COAX_SHIFT_DIV_OPS(uint16_t, u16, 0, 0)
COAX_SHIFT_DIV_OPS(uint32_t, u32, 0, 0)
COAX_SHIFT_DIV_OPS(uint64_t, u64, 0, 0)
/* n is a count, never negative, so one unsigned comparison is the whole check. */
COAX_DEV int64_t coax_index(int64_t i, int64_t n, int32_t l) { if ((uint64_t)i >= (uint64_t)n) coax_trap("index out of bounds", l); return i; }
COAX_DEV void coax_slice_check(int64_t lo, int64_t hi, int64_t n, int32_t l) { if ((uint64_t)hi > (uint64_t)n || (uint64_t)lo > (uint64_t)hi) coax_trap("slice out of bounds", l); }
COAX_DEV int64_t coax_cast_ss(int64_t v, int64_t lo, int64_t hi, int32_t l) { if (v < lo || v > hi) coax_trap("cast out of range", l); return v; }
COAX_DEV uint64_t coax_cast_su(int64_t v, uint64_t hi, int32_t l) { if (v < 0 || (uint64_t)v > hi) coax_trap("cast out of range", l); return (uint64_t)v; }
COAX_DEV int64_t coax_cast_us(uint64_t v, int64_t hi, int32_t l) { if (v > (uint64_t)hi) coax_trap("cast out of range", l); return (int64_t)v; }
COAX_DEV uint64_t coax_cast_uu(uint64_t v, uint64_t hi, int32_t l) { if (v > hi) coax_trap("cast out of range", l); return v; }
COAX_DEV int64_t coax_ftoi_s(double v, int64_t lo, int64_t hi, int32_t l) {
  if (!(v >= -9223372036854775808.0 && v < 9223372036854775808.0)) coax_trap("cast out of range", l);
  int64_t i = (int64_t)v; if (i < lo || i > hi) coax_trap("cast out of range", l); return i;
}
COAX_DEV uint64_t coax_ftoi_u(double v, uint64_t hi, int32_t l) {
  if (!(v > -1.0 && v < 18446744073709551616.0)) coax_trap("cast out of range", l);
  uint64_t u = (uint64_t)v; if (u > hi) coax_trap("cast out of range", l); return u;
}
COAX_DEV float coax_f32_from_bits(uint32_t x) { return __int_as_float((int)x); }
COAX_DEV double coax_f64_from_bits(uint64_t x) { return __longlong_as_double((long long)x); }
COAX_DEV uint32_t coax_f32_bits(float f) { return (uint32_t)__float_as_int(f); }
COAX_DEV uint64_t coax_f64_bits(double f) { return (uint64_t)__double_as_longlong(f); }
COAX_DEV float coax_to_f32(double v, int32_t l) {
  if (v == v && v - v == 0.0 && fabs(v) >= 3.4028235677973366e38) coax_trap("cast out of range", l);
  return (float)v;
}
COAX_DEV uint32_t coax_add_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a+b);}
COAX_DEV uint32_t coax_sub_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a-b);}
COAX_DEV uint32_t coax_mul_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a*b);}
COAX_DEV uint32_t coax_rotl_u32(uint32_t a,uint32_t b){unsigned k=(unsigned)(b&31u);return (uint32_t)((a<<k)|(a>>((32u-k)&31u)));}
COAX_DEV uint32_t coax_rotr_u32(uint32_t a,uint32_t b){unsigned k=(unsigned)(b&31u);return (uint32_t)((a>>k)|(a<<((32u-k)&31u)));}
COAX_DEV uint64_t coax_add_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a+b);}
COAX_DEV uint64_t coax_sub_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a-b);}
COAX_DEV uint64_t coax_mul_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a*b);}
COAX_DEV uint64_t coax_rotl_u64(uint64_t a,uint64_t b){unsigned k=(unsigned)(b&63u);return (uint64_t)((a<<k)|(a>>((64u-k)&63u)));}
COAX_DEV uint64_t coax_rotr_u64(uint64_t a,uint64_t b){unsigned k=(unsigned)(b&63u);return (uint64_t)((a>>k)|(a<<((64u-k)&63u)));}
)COAXRT";

// Uses the named Coax record declared in Types; inserted only when used.
static const char *WIDE_RUNTIME = R"COAXRT(
static coax_t_CoaxU64Product coax_mul_wide(uint64_t a,uint64_t b) {
#if defined(__SIZEOF_INT128__) && !defined(__wasm__)
  unsigned __int128 p=(unsigned __int128)a*b;
  return (coax_t_CoaxU64Product){(uint64_t)(p>>64),(uint64_t)p};
#else
  uint64_t a0=(uint32_t)a,a1=a>>32,b0=(uint32_t)b,b1=b>>32;
  uint64_t p00=a0*b0,p01=a0*b1,p10=a1*b0,p11=a1*b1;
  uint64_t carry=(p00>>32)+(uint32_t)p01+(uint32_t)p10;
  return (coax_t_CoaxU64Product){p11+(p01>>32)+(p10>>32)+(carry>>32),
                              (p00&UINT64_C(0xffffffff))|(carry<<32)};
#endif
}
)COAXRT";

// Warp kernels (compute.cpp fills this before emission): lane loops,
// per-lane arrays and their element offsets, and the MMA primitive's calls.
struct WarpInfo {
  std::set<const Stmt *> lane_loops, lane_arrays;
  std::map<const Expr *, int64_t> lane_index;  // index expression lane*k+c -> k
  std::set<const ProcDecl *> warp_kernels;
  std::set<const Expr *> mma_calls;
  // Group kernels: thread loops and per-thread arrays by group size T,
  // per-thread indexes thread*k+c -> k, each kernel's threadgroup arrays,
  // matrix accumulators and the Apple matrix primitives' calls by kind.
  std::map<const Stmt *, int64_t> thread_loops, thread_arrays;
  std::map<const Expr *, int64_t> thread_index;
  std::map<const ProcDecl *, int64_t> group_kernels;
  std::map<const ProcDecl *, std::vector<const Stmt *>> shared_arrays;
  std::set<const Stmt *> shared_decls, accumulators;
  std::map<const Expr *, int> apple_calls;
};
WarpInfo g_warp;
static bool is_mma_primitive(const ProcDecl *p) { return p && str_eq(p->name, "cu_mma_bf16_16x8x16"); }
// Every device primitive: its Coax body is the CPU meaning; the device emitters lower calls to it.
static bool is_device_primitive(const ProcDecl *p) {
  return p && (is_mma_primitive(p) || str_eq(p->name, "am_sg_mma_64x32x32") || str_eq(p->name, "am_sg_spill_64x32") || str_eq(p->name, "am_matmul_bf16"));
}
// The integer value of a constant expression (a literal or a named constant).
static int64_t constant_of_expr(const Expr *e) {
  if (e && e->kind == ExprKind::ident && e->constant && e->constant->expr) e = e->constant->expr;
  return e && e->kind == ExprKind::int_lit ? (int64_t)e->int_value : -1;
}

// ---- 32-bit integers in Metal kernels ----
// An Apple GPU adds, multiplies and compares 64-bit integers in several
// 32-bit steps, so `coax metal-compute` emits a second body of each kernel
// whose int locals, loop counters and operations are 32-bit wherever a
// bound proves the 64-bit value fits. The entry runs that body only when
// the launch meets the bounds the proof assumed: the item count and every
// int parameter the proof relies on at most NARROW_BOUND in magnitude, and,
// when a 32-bit index checks a view parameter, every view parameter's
// count below 2^31. Otherwise it runs the 64-bit body. Both bodies compute
// the same values, so the result never depends on which one ran.
//
// The bounds are intervals, flow-insensitive: a local's interval holds
// every value any of its assignments can store (iterated to a fixed point,
// a local that keeps growing is unbounded), a loop counter's its bounds',
// a thread loop's counter [0, T - 1]. An interval carries the parameters
// it assumed (mask: bit 0 the item count, bit i parameter i, bit 63 the
// view counts).
static const int64_t NARROW_BOUND = (int64_t)1 << 20;
struct NIv {
  int64_t lo = 1, hi = 0;  // empty until assigned
  uint64_t mask = 0;
  bool empty() const { return lo > hi; }
  bool fits32() const { return !empty() && lo >= INT32_MIN && hi <= INT32_MAX; }
  bool operator==(const NIv &o) const { return lo == o.lo && hi == o.hi && mask == o.mask; }
};
static NIv niv_full() { return {INT64_MIN, INT64_MAX, 0}; }
static NIv niv_make(__int128 lo, __int128 hi, uint64_t mask) {
  if (lo < INT64_MIN || hi > INT64_MAX) return niv_full();
  NIv r; r.lo = (int64_t)lo; r.hi = (int64_t)hi; r.mask = mask;
  if (r.lo == INT64_MIN && r.hi == INT64_MAX) r.mask = 0;
  return r;
}
static NIv niv_join(const NIv &a, const NIv &b) {
  if (a.empty()) return b;
  if (b.empty()) return a;
  return niv_make(std::min(a.lo, b.lo), std::max(a.hi, b.hi), a.mask | b.mask);
}
static NIv niv_range(Type t) {
  Type b = t->kind == TypeKind::enum_ ? t->elem : t;
  if (!b || b->kind != TypeKind::integer || b->bits >= 64) return b && !b->is_signed && b->bits >= 64 ? niv_make(0, INT64_MAX, 0) : niv_full();
  if (b->is_signed) return niv_make(-((__int128)1 << (b->bits - 1)), ((__int128)1 << (b->bits - 1)) - 1, 0);
  return niv_make(0, ((__int128)1 << b->bits) - 1, 0);
}
static NIv niv_binary(Tok op, const NIv &a, const NIv &b) {
  if (a.empty() || b.empty()) return NIv{};
  uint64_t m = a.mask | b.mask;
  __int128 al = a.lo, ah = a.hi, bl = b.lo, bh = b.hi;
  switch (op) {
    case Tok::plus: return niv_make(al + bl, ah + bh, m);
    case Tok::minus: return niv_make(al - bh, ah - bl, m);
    case Tok::star: {
      // Each corner fits in 127 bits: the operands are 64-bit.
      __int128 p[4] = {al * bl, al * bh, ah * bl, ah * bh};
      return niv_make(std::min(std::min(p[0], p[1]), std::min(p[2], p[3])), std::max(std::max(p[0], p[1]), std::max(p[2], p[3])), m);
    }
    case Tok::slash: case Tok::percent: {
      // A divisor of zero traps, and the checked operation then yields 0.
      if (b.lo < 0) {
        // Either sign: |a / b| <= |a|, and |a % b| < |b| with a's sign.
        if (a.lo == INT64_MIN || b.lo == INT64_MIN) return niv_full();
        __int128 A = std::max(-al, ah), M = std::max(-bl, bh);
        if (op == Tok::slash) return niv_make(-A, A, m);
        return niv_make(a.lo >= 0 ? 0 : -std::min(A, M - 1), a.hi <= 0 ? 0 : std::min(A, M - 1), m);
      }
      if (b.hi == 0) return niv_make(0, 0, m);
      NIv r;
      if (bl < 1) { bl = 1; r = niv_make(0, 0, m); }
      if (op == Tok::slash) {
        __int128 q[4] = {al / bl, al / bh, ah / bl, ah / bh};  // truncation toward zero, as C and Coax
        return niv_join(r, niv_make(std::min(std::min(q[0], q[1]), std::min(q[2], q[3])), std::max(std::max(q[0], q[1]), std::max(q[2], q[3])), m));
      }
      if (a.lo >= 0) return niv_join(r, niv_make(0, std::min(ah, bh - 1), m));  // the remainder takes the dividend's sign
      if (a.hi <= 0) return niv_join(r, niv_make(std::max(al, -(bh - 1)), 0, m));
      return niv_join(r, niv_make(-(bh - 1), bh - 1, m));
    }
    case Tok::amp:
      if (a.lo >= 0 && b.lo >= 0) return niv_make(0, std::min(ah, bh), m);
      if (a.lo >= 0) return niv_make(0, ah, a.mask);
      if (b.lo >= 0) return niv_make(0, bh, b.mask);
      return niv_full();
    case Tok::shr:
      if (b.lo < 0 || b.hi > 63) return niv_full();
      if (a.lo >= 0) return niv_make(al >> bh, ah >> bl, m);
      return niv_make(al >> bl, a.hi >= 0 ? ah >> bl : ah >> bh, m);
    default: return niv_full();
  }
}

struct Narrow {
  const ProcDecl *proc = nullptr;
  int64_t threads = 32;                            // a thread loop's counter is below this
  std::map<const Expr *, const Stmt *> local;      // an identifier's int local (a var or a for counter)
  std::map<const Expr *, int32_t> param;           // an identifier's parameter
  std::map<const Expr *, const Stmt *> vlocal;     // an identifier's view local
  std::set<const Stmt *> vassigned;                // view locals assigned after their declaration
  // A call to a procedure whose body is one `return` of an int: that
  // expression's interval, with the callee's parameters at the arguments'.
  std::map<const Expr *, int32_t> callee_param;
  std::set<const ProcDecl *> callees_resolved;
  std::vector<std::vector<NIv>> frames;
  std::map<const Stmt *, std::vector<const Stmt *>> assigns;  // a local's assignments
  std::vector<const Stmt *> loops;                 // the loops around the statement being resolved
  std::map<const Stmt *, size_t> depth;            // a local's: how many loops are around its declaration
  std::map<const Stmt *, std::vector<const Stmt *>> around;  // an assignment's loops
  std::set<int32_t> assigned_params;
  std::map<const Stmt *, NIv> var;                 // each int local's interval
  std::map<const Expr *, NIv> iv;                  // each integer expression's (the last pass)
  std::set<const Stmt *> narrow_vars;              // int locals and counters the 32-bit body declares int32_t
  uint64_t guard = 0;                              // what the 32-bit body assumed
  bool any = false;
  bool recording = false;

  bool is_local(const Stmt *s) const { return (s->kind == StmtKind::var || s->kind == StmtKind::for_range) && s->type == T_INT; }

  // Identifiers to their declarations; each local's assignments.
  void resolve_expr(const Expr *e, std::vector<std::map<std::string, const Stmt *>> &scopes, const std::map<std::string, int32_t> &params) {
    if (!e) return;
    if (e->kind == ExprKind::ident && !e->constant) {
      std::string n(e->text.data, (size_t)e->text.count);
      bool found = false;
      for (size_t i = scopes.size(); i-- > 0 && !found;) {
        auto f = scopes[i].find(n);
        if (f != scopes[i].end()) {
          found = true;
          if (f->second && is_local(f->second)) local[e] = f->second;
          else if (f->second) vlocal[e] = f->second;
        }
      }
      if (!found) { auto p = params.find(n); if (p != params.end()) param[e] = p->second; }
    }
    resolve_expr(e->lhs, scopes, params); resolve_expr(e->rhs, scopes, params); resolve_expr(e->third, scopes, params);
    for (int32_t k = 0; k < e->args.count; k++) resolve_expr(e->args[k], scopes, params);
    for (int32_t k = 0; k < e->fields.count; k++) resolve_expr(e->fields[k].value, scopes, params);
  }
  void declare(Str name, const Stmt *s, std::vector<std::map<std::string, const Stmt *>> &scopes) {
    // Any declaration hides a parameter of that name; int scalars and views are tracked.
    bool view = s && s->kind == StmtKind::var && s->type->kind == TypeKind::view;
    scopes.back()[std::string(name.data, (size_t)name.count)] = s && (is_local(s) || view) ? s : nullptr;
  }
  void resolve(const Stmt *s, std::vector<std::map<std::string, const Stmt *>> &scopes, const std::map<std::string, int32_t> &params) {
    if (!s) return;
    switch (s->kind) {
      case StmtKind::block:
        scopes.push_back({});
        for (int32_t k = 0; k < s->body.count; k++) resolve(s->body[k], scopes, params);
        scopes.pop_back();
        break;
      case StmtKind::var:
        resolve_expr(s->expr, scopes, params);
        declare(s->name, s, scopes);
        if (is_local(s)) { assigns[s]; depth[s] = loops.size(); }
        break;
      case StmtKind::assign:
        resolve_expr(s->target, scopes, params); resolve_expr(s->expr, scopes, params);
        around[s] = loops;
        if (s->target && s->target->kind == ExprKind::ident) {
          auto l = local.find(s->target);
          if (l != local.end()) assigns[l->second].push_back(s);
          auto p = param.find(s->target);
          if (p != param.end()) assigned_params.insert(p->second);
          auto v = vlocal.find(s->target);
          if (v != vlocal.end()) vassigned.insert(v->second);
        }
        break;
      case StmtKind::for_range:
        resolve_expr(s->expr, scopes, params); resolve_expr(s->expr2, scopes, params);
        scopes.push_back({});
        declare(s->name, s, scopes);
        if (is_local(s)) assigns[s];
        loops.push_back(s);
        resolve(s->then_, scopes, params);
        loops.pop_back();
        scopes.pop_back();
        break;
      case StmtKind::for_each:
        resolve_expr(s->expr, scopes, params);
        scopes.push_back({});
        declare(s->name, nullptr, scopes);
        if (s->name2.count) declare(s->name2, nullptr, scopes);
        loops.push_back(s);
        resolve(s->then_, scopes, params);
        loops.pop_back();
        scopes.pop_back();
        break;
      case StmtKind::while_:
        resolve_expr(s->expr, scopes, params);
        loops.push_back(s);
        resolve(s->then_, scopes, params);
        loops.pop_back();
        break;
      default:
        resolve_expr(s->expr, scopes, params); resolve_expr(s->expr2, scopes, params); resolve_expr(s->target, scopes, params);
        resolve(s->then_, scopes, params); resolve(s->else_, scopes, params);
        break;
    }
  }

  NIv param_iv(int32_t i) const {
    Type t = proc->params[i].type;
    if (t != T_INT) return niv_range(t);
    if (assigned_params.count(i)) return niv_full();
    if (i == 0) return niv_make(0, NARROW_BOUND - 1, 1);  // the item: below the item count
    if (i >= 63) return niv_full();
    return niv_make(0, NARROW_BOUND, (uint64_t)1 << i);
  }
  NIv eval(const Expr *e) {
    NIv r = eval_inner(e);
    if (recording && e && is_int(e->type)) iv[e] = r;
    return r;
  }
  NIv eval_inner(const Expr *e) {
    if (!e || !is_int(e->type)) { if (e && recording) eval_children(e); return niv_full(); }
    if (e->type != T_INT) { eval_children(e); return e->kind == ExprKind::int_lit ? niv_make((int64_t)e->int_value, (int64_t)e->int_value, 0) : niv_range(e->type); }
    switch (e->kind) {
      case ExprKind::int_lit: return niv_make((int64_t)e->int_value, (int64_t)e->int_value, 0);
      case ExprKind::ident: {
        if (e->constant) {
          const Expr *c = e->constant->expr;
          return c && c->kind == ExprKind::int_lit ? niv_make((int64_t)c->int_value, (int64_t)c->int_value, 0) : niv_full();
        }
        auto l = local.find(e);
        if (l != local.end()) { auto v = var.find(l->second); return v == var.end() ? niv_full() : v->second; }
        if (!frames.empty()) {
          auto c = callee_param.find(e);
          return c == callee_param.end() || c->second >= (int32_t)frames.back().size() ? niv_full() : frames.back()[(size_t)c->second];
        }
        auto p = param.find(e);
        if (p != param.end()) return param_iv(p->second);
        return niv_full();
      }
      case ExprKind::call: {
        const ProcDecl *f = e->proc;
        std::vector<NIv> args;
        for (int32_t k = 0; k < e->args.count; k++) args.push_back(eval(e->args[k]));
        if (!f || f->foreign || !f->body || f->body->body.count != 1 || frames.size() >= 4) return niv_full();
        const Stmt *r = f->body->body[0];
        if (r->kind != StmtKind::ret || !r->expr || r->expr->type != T_INT || f->params.count != e->args.count) return niv_full();
        if (!callees_resolved.count(f)) {
          callees_resolved.insert(f);
          std::map<std::string, int32_t> ps;
          for (int32_t i = 0; i < f->params.count; i++) ps[std::string(f->params[i].name.data, (size_t)f->params[i].name.count)] = i;
          std::function<void(const Expr *)> mark = [&](const Expr *x) {
            if (!x) return;
            if (x->kind == ExprKind::ident && !x->constant) {
              auto q = ps.find(std::string(x->text.data, (size_t)x->text.count));
              if (q != ps.end()) callee_param[x] = q->second;
            }
            mark(x->lhs); mark(x->rhs); mark(x->third);
            for (int32_t k = 0; k < x->args.count; k++) mark(x->args[k]);
          };
          mark(r->expr);
        }
        bool saved = recording;
        recording = false;  // the callee's expressions are not this kernel's
        frames.push_back(args);
        NIv v = eval(r->expr);
        frames.pop_back();
        recording = saved;
        return v;
      }
      case ExprKind::binary: {
        NIv a = eval(e->lhs), b = eval(e->rhs);
        return niv_binary(e->op, a, b);
      }
      case ExprKind::unary: {
        NIv a = eval(e->lhs);
        if (e->op != Tok::minus || a.empty()) return a.empty() ? a : niv_full();
        return niv_make(-(__int128)a.hi, -(__int128)a.lo, a.mask);
      }
      case ExprKind::cast: {
        NIv a = eval(e->lhs);
        if (!is_int(e->lhs->type)) return niv_full();
        if (e->trunc && e->lhs->type->bits > 64) return niv_full();
        if (e->lhs->type == T_INT || (e->lhs->type->is_signed && e->lhs->type->bits <= 64) || e->lhs->type->bits < 64) return a;
        return niv_full();
      }
      case ExprKind::ifx: {
        eval(e->lhs);
        return niv_join(eval(e->rhs), eval(e->third));
      }
      case ExprKind::field:
        eval_children(e);
        if (e->field_index == -2 && e->lhs->type->kind == TypeKind::view) {
          if (e->lhs->kind == ExprKind::ident && param.count(e->lhs) && !assigned_params.count(param.at(e->lhs)))
            return niv_make(0, INT32_MAX, (uint64_t)1 << 63);
          return niv_make(0, INT64_MAX, 0);
        }
        if (e->field_index == -2 && e->lhs->type->kind == TypeKind::array) return niv_make(e->lhs->type->length, e->lhs->type->length, 0);
        return niv_full();
      default:
        eval_children(e);
        return niv_full();
    }
  }
  void eval_children(const Expr *e) {
    if (!recording || !e) return;
    eval(e->lhs); eval(e->rhs); eval(e->third);
    for (int32_t k = 0; k < e->args.count; k++) eval(e->args[k]);
    for (int32_t k = 0; k < e->fields.count; k++) eval(e->fields[k].value);
  }
  // Every value a local's assignments can store, under the current intervals.
  NIv defs(const Stmt *l) {
    NIv r;
    if (l->kind == StmtKind::for_range) {
      if (g_warp.thread_loops.count(l)) return niv_make(0, g_warp.thread_loops.at(l) - 1, 0);
      if (g_warp.lane_loops.count(l)) return niv_make(0, 31, 0);
      NIv lo = eval(l->expr), hi = eval(l->expr2);
      if (lo.empty() || hi.empty()) return NIv{};
      r = niv_make(lo.lo, std::max((__int128)lo.lo, (__int128)hi.hi - 1), lo.mask | hi.mask);
    } else if (l->expr) r = eval(l->expr);
    else r = l->uninit ? niv_full() : niv_make(0, 0, 0);
    // Increments (v += e, v = v + e, e not negative and not reading v) add at
    // most e's largest value once per pass of the loops between v's
    // declaration and the increment: a thread loop's body runs once, a
    // for loop's its bounds' count of times, a while or for-each loop
    // without a bound.
    __int128 added = 0;
    uint64_t added_mask = 0;
    bool bounded = true;
    std::vector<const Stmt *> rest;
    for (const Stmt *a : assigns[l]) {
      const Expr *inc = increment(a, l);
      if (!inc || l->kind != StmtKind::var) { rest.push_back(a); continue; }
      NIv e = eval(inc);
      if (e.empty()) continue;
      __int128 trips = 1;
      const std::vector<const Stmt *> &ls = around[a];
      for (size_t k = depth[l]; k < ls.size() && bounded; k++) {
        const Stmt *L = ls[k];
        if (g_warp.thread_loops.count(L) || g_warp.lane_loops.count(L)) continue;
        if (L->kind != StmtKind::for_range) { bounded = false; break; }
        NIv lo = eval(L->expr), hi = eval(L->expr2);
        if (lo.empty() || hi.empty() || !lo.fits32() || !hi.fits32()) { bounded = false; break; }
        trips *= std::max((__int128)0, (__int128)hi.hi - lo.lo);
        added_mask |= lo.mask | hi.mask;
        if (trips > ((__int128)1 << 40)) bounded = false;
      }
      if (e.lo < 0 || !e.fits32()) bounded = false;
      if (!bounded) break;
      added += trips * e.hi;
      added_mask |= e.mask;
    }
    if (!bounded) { rest = assigns[l]; added = 0; added_mask = 0; }
    for (const Stmt *a : rest) {
      NIv v = eval(a->expr);
      if (a->op != Tok::equal) {
        static const std::map<Tok, Tok> base = {{Tok::plus_equal, Tok::plus}, {Tok::minus_equal, Tok::minus}, {Tok::star_equal, Tok::star},
                                                {Tok::slash_equal, Tok::slash}, {Tok::percent_equal, Tok::percent}, {Tok::amp_equal, Tok::amp},
                                                {Tok::shr_equal, Tok::shr}};
        auto b = base.find(a->op);
        auto cur = var.find(l);
        v = b == base.end() || cur == var.end() ? niv_full() : niv_binary(b->second, cur->second, v);
      }
      r = niv_join(r, v);
    }
    if (added && !r.empty()) r = niv_make(r.lo, (__int128)r.hi + added, r.mask | added_mask);
    return r;
  }
  bool reads(const Expr *e, const Stmt *l) const {
    if (!e) return false;
    if (e->kind == ExprKind::ident) { auto f = local.find(e); if (f != local.end() && f->second == l) return true; }
    if (reads(e->lhs, l) || reads(e->rhs, l) || reads(e->third, l)) return true;
    for (int32_t k = 0; k < e->args.count; k++) if (reads(e->args[k], l)) return true;
    for (int32_t k = 0; k < e->fields.count; k++) if (reads(e->fields[k].value, l)) return true;
    return false;
  }
  // The amount an assignment adds to l, when it is v += e or v = v + e (e + v).
  const Expr *increment(const Stmt *a, const Stmt *l) const {
    if (a->op == Tok::plus_equal) return reads(a->expr, l) ? nullptr : a->expr;
    if (a->op != Tok::equal || !a->expr || a->expr->kind != ExprKind::binary || a->expr->op != Tok::plus) return nullptr;
    const Expr *x = a->expr->lhs, *y = a->expr->rhs;
    auto self = [&](const Expr *v) { auto f = v->kind == ExprKind::ident ? local.find(v) : local.end(); return f != local.end() && f->second == l; };
    if (self(x) && !reads(y, l)) return y;
    if (self(y) && !reads(x, l)) return x;
    return nullptr;
  }
  void walk(const Stmt *s) {
    if (!s) return;
    eval(s->expr); eval(s->expr2); eval(s->target);
    for (int32_t k = 0; k < s->body.count; k++) walk(s->body[k]);
    walk(s->then_); walk(s->else_);
  }

  void analyze(const ProcDecl *p) {
    proc = p;
    std::map<std::string, int32_t> params;
    for (int32_t i = 0; i < p->params.count; i++) params[std::string(p->params[i].name.data, (size_t)p->params[i].name.count)] = i;
    std::vector<std::map<std::string, const Stmt *>> scopes;
    resolve(p->body, scopes, params);
    // A fixed point: intervals only grow, and a local that grew six times is unbounded.
    // Every local starts empty (no value yet); one still empty at the fixed
    // point becomes unbounded, and the iteration goes on from there.
    std::map<const Stmt *, int> grew;
    for (auto &[l, unused] : assigns) { (void)unused; var[l] = NIv{}; }
    for (bool again = true; again;) {
      for (bool changed = true; changed;) {
        changed = false;
        for (auto &[l, unused] : assigns) {
          (void)unused;
          NIv n = niv_join(var[l], defs(l));
          if (n == var[l]) continue;
          if (++grew[l] > 6) n = niv_full();
          if (n == var[l]) continue;
          var[l] = n;
          changed = true;
        }
      }
      again = false;
      for (auto &[l, v] : var) if (v.empty()) { v = niv_full(); again = true; }
    }
    recording = true;
    walk(p->body);
    recording = false;
    for (auto &[l, v] : var) {
      if (!v.fits32()) continue;
      if (l->kind == StmtKind::for_range && !g_warp.thread_loops.count(l) && !g_warp.lane_loops.count(l) &&
          !(iv.count(l->expr) && iv[l->expr].fits32() && iv.count(l->expr2) && iv[l->expr2].fits32())) continue;
      narrow_vars.insert(l);
      guard |= v.mask;
      if (l->kind == StmtKind::for_range && iv.count(l->expr)) guard |= iv[l->expr].mask | iv[l->expr2].mask;
      any = true;
    }
    sites(p->body);
  }
  // e is computed in 32 bits: an int value whose interval fits.
  bool fits(const Expr *e) const { auto f = iv.find(e); return e && e->type == T_INT && f != iv.end() && f->second.fits32(); }
  uint64_t mask(const Expr *e) const { auto f = iv.find(e); return f == iv.end() ? 0 : f->second.mask; }
  static bool comparison(Tok op) { return op == Tok::eqeq || op == Tok::noteq || op == Tok::lt || op == Tok::le || op == Tok::gt || op == Tok::ge; }
  // A binary operation the 32-bit body computes in 32 bits: + - * of values
  // that fit with a result that fits, / and % by a positive divisor, or a
  // comparison of two values that fit.
  bool binary_site(const Expr *e) const {
    if (!e || e->kind != ExprKind::binary || !fits(e->lhs) || !fits(e->rhs)) return false;
    if (comparison(e->op)) return true;
    if (e->op != Tok::plus && e->op != Tok::minus && e->op != Tok::star && e->op != Tok::slash && e->op != Tok::percent) return false;
    return fits(e);
  }
  // A view parameter, or a view local declared as a slice of one and never
  // assigned: its count is at most the parameter's.
  bool view_param(const Expr *v, int depth = 0) const {
    if (!v || v->kind != ExprKind::ident || depth > 16) return false;
    auto p = param.find(v);
    if (p != param.end()) return !assigned_params.count(p->second);
    auto l = vlocal.find(v);
    if (l == vlocal.end() || vassigned.count(l->second)) return false;
    const Expr *init = l->second->expr;
    return init && init->kind == ExprKind::slice && view_param(init->lhs, depth + 1);
  }
  // An index the 32-bit body checks in 32 bits: a fitting index into a
  // fixed array or a view parameter (whose count the entry checked).
  bool index_site(const Expr *e) const {
    if (!e || e->kind != ExprKind::index || !fits(e->rhs)) return false;
    Type t = e->lhs->type;
    if (t->kind == TypeKind::array) return t->length <= INT32_MAX;
    return t->kind == TypeKind::view && view_param(e->lhs);
  }
  void sites(const Expr *e) {
    if (!e) return;
    if (binary_site(e)) { guard |= mask(e->lhs) | mask(e->rhs) | mask(e); any = true; }
    if (index_site(e)) { guard |= mask(e->rhs) | (e->lhs->type->kind == TypeKind::view ? (uint64_t)1 << 63 : 0); any = true; }
    sites(e->lhs); sites(e->rhs); sites(e->third);
    for (int32_t k = 0; k < e->args.count; k++) sites(e->args[k]);
    for (int32_t k = 0; k < e->fields.count; k++) sites(e->fields[k].value);
  }
  void sites(const Stmt *s) {
    if (!s) return;
    sites(s->expr); sites(s->expr2); sites(s->target);
    for (int32_t k = 0; k < s->body.count; k++) sites(s->body[k]);
    sites(s->then_); sites(s->else_);
  }
};
std::map<const ProcDecl *, Narrow> g_narrow;

// Set while `coax metal-compute` emits: f64 is the float-float pair coax_ff.
static bool g_metal_compute = false;

namespace {

// A unique, kind-prefixed spelling of a type for generated names.
std::string tag(Type t) {
  if (t->physical) return tag(t->physical);
  switch (t->kind) {
    case TypeKind::integer: return t == T_INT ? "s64" : t->name;
    case TypeKind::floating: return t->name;
    case TypeKind::bool_: return "bool";
    case TypeKind::string_: return "string";
    case TypeKind::struct_: case TypeKind::enum_:
      // A generic struct instance is its template's name and its bindings' key: t_Pair__3int.
      if (t->kind == TypeKind::struct_ && t->struct_decl->key.count) {
        std::string k = to_std(t->struct_decl->name) + "__" + to_std(t->struct_decl->key);
        return t->scope ? "q" + std::to_string(t->scope) + "t_" + k : "t_" + k;
      }
      // A name two modules declare is spelled by its module scope; coax_q never comes from a user name.
      if (t->scope) return "q" + std::to_string(t->scope) + "t_" + to_std(t->kind == TypeKind::struct_ ? t->struct_decl->name : t->enum_decl->name);
      return "t_" + t->name;
    case TypeKind::union_: return (t->scope ? "q"+std::to_string(t->scope) : "")+"u_"+to_std(t->union_decl->name);
    case TypeKind::result: {std::string a=tag(t->elem),b=tag(t->sum_error);return "r_"+std::to_string(a.size())+"_"+a+"_"+std::to_string(b.size())+"_"+b;}
    case TypeKind::optional: {std::string a=tag(t->elem);return "o_"+std::to_string(a.size())+"_"+a;}
    case TypeKind::array: return "a" + std::to_string(t->length) + "_" + tag(t->elem);
    case TypeKind::view: return "v_" + tag(t->elem);
    default: return "void";
  }
}

std::string c_type(Type t) {
  if (t->physical) return c_type(t->physical);
  switch (t->kind) {
    case TypeKind::void_: return "void";
    case TypeKind::integer: return std::string(t->is_signed ? "int" : "uint") + std::to_string(t->bits) + "_t";
    case TypeKind::floating: return t == &T_F32 ? "float" : g_metal_compute ? "coax_ff" : "double";
    case TypeKind::bool_: return "_Bool";
    case TypeKind::string_: return "coax_string";
    default: return "coax_" + tag(t);
  }
}

int32_t sum_count(Type t) {return t->kind==TypeKind::union_ ? t->union_decl->variants.count : 2;}
Type sum_payload(Type t,int32_t alternative) {
  if(t->kind==TypeKind::union_)return t->union_decl->variants[alternative].type;
  if(t->kind==TypeKind::result)return alternative==0 ? t->elem : t->sum_error;
  return alternative==0 ? &T_VOID : t->elem;
}
std::string sum_member(int32_t alternative){return "v"+std::to_string(alternative);}
std::string sum_construct(Type t,int32_t alternative,const std::string &payload) {
  std::string text="(("+c_type(t)+"){.tag = "+std::to_string(alternative);
  if(sum_payload(t,alternative)!=&T_VOID)text+=", .payload."+sum_member(alternative)+" = "+payload;
  return text+"})";
}

std::string int_tag(Type t) {
  Type base = t->kind == TypeKind::enum_ ? t->elem : t;
  return std::string(base->is_signed ? "s" : "u") + std::to_string(base->bits);
}

bool needs_init(Type t) {
  if (t->physical) return false;
  if (t->kind == TypeKind::array) return needs_init(t->elem);
  if (t->kind != TypeKind::struct_) return false;
  for (const Field &f : t->struct_decl->fields)
    if (f.init || needs_init(f.type)) return true;
  return false;
}

std::string c_string_text(Str s) {
  std::string out = "\"";
  for (int32_t i = 0; i < s.count; i++) {
    unsigned char c = (unsigned char)s.data[i];
    if (c == '"' || c == '\\') { out += '\\'; out += (char)c; }
    else if (c == '\n') out += "\\n";
    else if (c == '\t') out += "\\t";
    else if (c == '\r') out += "\\r";
    else if (c < 0x20 || c >= 0x7f || c == '?') {
      char buf[8];
      snprintf(buf, sizeof buf, "\\%03o", c);  // octal: never swallows a following digit
      out += buf;
    } else out += (char)c;
  }
  return out + "\"";
}

std::string int_text(Type t, uint64_t bits) {
  Type base = t->kind == TypeKind::enum_ ? t->elem : t;
  if (base->is_signed) {
    int64_t v = (int64_t)bits;
    std::string lit = v == INT64_MIN ? "INT64_MIN" : "INT64_C(" + std::to_string(v) + ")";
    return base == T_INT && t == base ? lit : "((" + c_type(t) + ")" + lit + ")";
  }
  std::string lit = "UINT64_C(" + std::to_string(bits) + ")";
  return base == &T_U64 && t == base ? lit : "((" + c_type(t) + ")" + lit + ")";
}

std::string float_text(Type t, double v) {
  if (std::isnan(v)) return t == &T_F32 ? "((float)__builtin_nan(\"\"))" : "__builtin_nan(\"\")";
  if (std::isinf(v)) return std::string(v < 0 ? "(-" : "(") + (t == &T_F32 ? "__builtin_inff())" : "__builtin_inf())");
  char buf[64];
  snprintf(buf, sizeof buf, "%a", v);  // exact: no decimal rounding between Coax and C
  return std::string(buf) + (t == &T_F32 ? "f" : "");
}

// Expressions that cannot trap, call or observe order.
bool trivial(const Expr *e) {
  switch (e->kind) {
    case ExprKind::int_lit: case ExprKind::float_lit: case ExprKind::bool_lit: case ExprKind::string_lit:
    case ExprKind::enum_value: case ExprKind::ct_value: case ExprKind::ident:
      return true;
    case ExprKind::field: return trivial(e->lhs);
    default: return false;
  }
}

// Ordered lowering decisions (r1a-ordered-lowering), shared by the C emitter
// and `coax lower`: both read the checked graph's effects (CK_effects), so the
// inspected order is the executed one. `traps` is false where trap order is
// not observable (GPU and shader emission).
struct LoweringPolicy { bool wrapping = false, traps = true; };
bool lowering_may_trap(const Expr *e, LoweringPolicy p) {
  return p.traps && !trivial(e) && (e->effects & (2 | (p.wrapping ? 0 : 4)));
}
// Operands are evaluated through temporaries in source order when one calls
// and another is not trivial, or when two may trap.
bool lowering_sequenced(const std::vector<const Expr *> &ops, LoweringPolicy p) {
  int calls = 0, nontrivial = 0, traps = 0;
  for(const Expr *e:ops)if(e && (e->effects & 8))return true;
  for (const Expr *e : ops) {
    if (has_call(e)) calls++;
    if (!trivial(e)) nontrivial++;
    if (lowering_may_trap(e, p)) traps++;
  }
  return (calls > 0 && nontrivial >= 2) || traps >= 2;
}
// `place = value`: the place's address is taken before the value runs.
bool lowering_place_first(const Expr *target, const Expr *value, LoweringPolicy p) {
  if((target->effects|value->effects)&8)return true;
  return (has_call(target) && !trivial(value)) || (has_call(value) && !trivial(target)) ||
         (lowering_may_trap(target, p) && lowering_may_trap(value, p));
}
// True when some operation inside e evaluates its operands through
// temporaries: e's C text assigns them, so it must not be spelled twice.
bool lowering_inner_sequenced(const Expr *e, LoweringPolicy p) {
  if (!e) return false;
  std::vector<const Expr *> ops;
  for (const Expr *x : {e->lhs, e->rhs, e->third}) if (x) ops.push_back(x);
  for (const Expr *a : e->args) ops.push_back(a);
  for (const FieldInit &f : e->fields) if (f.value) ops.push_back(f.value);
  if (ops.size() >= 2 && lowering_sequenced(ops, p)) return true;
  for (const Expr *x : ops) if (lowering_inner_sequenced(x, p)) return true;
  return false;
}
// `place op= value`: false when the place may be spelled twice in C. A place
// whose indexes are sequenced (`c[a[i-1]*256+a[i]] += 1`) is staged too, or
// `place = place op value` would assign its temporaries twice in one
// expression, which C leaves undefined.
bool lowering_compound_staged(const Expr *target, const Expr *value, LoweringPolicy p) {
  if((target->effects|value->effects)&8)return true;
  return has_call(target) || has_call(value) || (lowering_may_trap(target, p) && lowering_may_trap(value, p)) ||
         lowering_inner_sequenced(target, p);
}

// An lvalue in the generated C.
bool is_place(const Expr *e) {
  switch (e->kind) {
    case ExprKind::ident: return !e->constant;
    case ExprKind::field: return e->field_index >= 0 && is_place(e->lhs);
    case ExprKind::index: return e->lhs->type->kind == TypeKind::view || (e->lhs->type->kind == TypeKind::array && is_place(e->lhs));
    default: return false;
  }
}

struct Operand {
  const Expr *e;
  bool lvalue;
};

std::string escape_path(const std::string &path);

std::string debug_path(const Source *src, Loc loc) {
  return std::filesystem::absolute(source_point(src,loc).path).lexically_normal().string();
}

std::string debug_line(const File *file, Loc loc) {
  auto point=source_point(file->src,loc);
  return "#line "+std::to_string(point.loc.line)+" \""+escape_path(debug_path(file->src,loc))+"\"\n";
}

struct Emitter {
  const File *file;
  EmitOptions opts;
  bool verification = false;
  bool versioned = false;               // a loop was versioned: the output needs IV_RUNTIME
  int version_depth = 0;                // inside either copy of a versioned loop: no nested versioning
  std::set<const Expr *> unchecked;     // the fast copy's indexes, proven in range by its guard
  const Narrow *n32 = nullptr;          // emitting a Metal kernel's 32-bit body (Narrow)
  std::map<const ProcDecl *, std::string> verification_names;
  std::map<const Expr *, int32_t> verification_ct_ids;
  std::string out;          // the current function body
  int32_t indent = 0;
  int32_t temp_count = 0;
  std::vector<std::string> temps;           // declarations at the top of the current function
  std::vector<const Expr *> ct_values;      // compile-time aggregates, emitted as static constants
  bool wrapping = false;
  bool wide = false;
  bool barrier = false;                       // value_barrier is used: emit its helpers
  std::vector<std::vector<const Stmt *>> defers;  // per open block
  std::vector<size_t> loop_scopes;          // defers.size() when each open loop began
  const ProcDecl *current = nullptr;
  bool ret_temp = false;
  Loc debug_location{};
  bool mapping_active=false;

  void line_start() {
    if(opts.debug_info && mapping_active)out+=debug_line(file,debug_location);
    out.append((size_t)indent * 2,' ');
  }
  void line(const std::string &s) {
    line_start();
    out += s;
    out += '\n';
  }

  std::string new_temp(const std::string &type) {
    std::string name = "coax_t" + std::to_string(temp_count++);
    temps.push_back(type + " " + name + ";");
    return name;
  }

  std::string local_name(Str s) { return "l_" + to_std(s); }

  // "(x == y)" rather than "((x == y))", which compilers warn about.
  std::string condition(const Expr *e) {
    std::string c = ex(e);
    if (c.size() >= 2 && c.front() == '(' && c.back() == ')') {
      int depth = 0;
      size_t i = 0;
      for (; i < c.size(); i++) {
        depth += c[i] == '(' ? 1 : c[i] == ')' ? -1 : 0;
        if (depth == 0) break;
      }
      if (i == c.size() - 1) return c;
    }
    return "(" + c + ")";
  }

  // Device code: CUDA (coax cuda) or Metal (coax metal-compute).
  bool device() const { return opts.cuda || opts.metal_compute; }
  std::string group_barrier() const {
    return opts.metal_compute ? "threadgroup_barrier(mem_flags::mem_threadgroup | mem_flags::mem_device);" : "__syncthreads();";
  }
  bool apple_tensor = false;  // an am_matmul_bf16 call: the module needs Metal 4 tensor ops
  // The pointer type of a temporary holding the address of a place. Metal
  // pointers name their address space: a view's elements are device memory,
  // locals are thread memory.
  std::string pointer_type(const Expr *place) {
    if (!opts.metal_compute) return c_type(place->type) + " *";
    const Expr *e = place;
    bool space_device = false;
    while (e && (e->kind == ExprKind::index || e->kind == ExprKind::field)) {
      if (e->kind == ExprKind::index && e->lhs->type->kind == TypeKind::view) { space_device = true; break; }
      e = e->lhs;
    }
    // A group kernel's threadgroup array (matched by name, as compute.cpp admits it).
    bool space_group = false;
    if (!space_device && e && e->kind == ExprKind::ident && g_warp.shared_arrays.count(current))
      for (const Stmt *d : g_warp.shared_arrays.at(current)) if (str_eq(e->text, d->name)) space_group = true;
    return std::string(space_device ? "device " : space_group ? "threadgroup " : "thread ") + c_type(place->type) + " *";
  }
  // C's math.h names, with the float variants for f32; Metal overloads.
  std::string math_name(const Expr *e) {
    std::string name = e->intrinsic == Intrinsic::abs ? "fabs" : to_std(e->text);
    if (opts.metal_compute) {
      if (e->type != &T_F32) return "coax_ff_" + to_std(e->text);  // exp, log, sqrt, floor, abs (admission)
      if (e->intrinsic == Intrinsic::abs || e->intrinsic == Intrinsic::floor) return name;
      return "precise::" + name;
    }
    if (opts.metal) return e->intrinsic == Intrinsic::abs ? "abs" : name;
    return name + (e->type == &T_F32 ? "f" : "");
  }
  std::string proc_name(const ProcDecl *p) {
    if (verification) {
      auto found = verification_names.find(p);
      if (found != verification_names.end()) return found->second;
    }
    if (device() && p->export_c) return "coax_k_" + to_std(p->name);  // the kernel wrapper keeps the name
    if (p->export_c || p->foreign) return to_std(p->name);
    std::string base = p->scope ? "coax_q" + std::to_string(p->scope) + "p_" + to_std(p->name) : "coax_p_" + to_std(p->name);
    return p->origin ? base + "__" + to_std(p->key) : base;
  }

  // Evaluate operands left to right when order is observable; build() gets
  // the C text for each operand. A place (an lvalue in Coax) stays one in C:
  // a comma expression is not, so its address is taken inside it,
  // `(*(t = ..., &(place)))`, and it can be assigned to or addressed again.
  // The checked graph's effects (CK_effects) decide it: an operand that calls,
  // or two that may trap, are evaluated in Coax order through temporaries,
  // never left to C's unspecified operand order.
  LoweringPolicy policy() const { return {opts.wrapping, !device() && !opts.metal}; }
  template <class F> std::string ordered(const std::vector<Operand> &ops, F build, bool place = false) {
    std::vector<const Expr *> exprs;
    for (const Operand &o : ops) exprs.push_back(o.e);
    std::vector<std::string> texts;
    if (!lowering_sequenced(exprs, policy())) {
      for (const Operand &o : ops) texts.push_back(ex(o.e));
      return build(texts);
    }
    std::string prefix;
    for (const Operand &o : ops) {
      if (trivial(o.e)) {
        texts.push_back(ex(o.e));
        continue;
      }
      if (o.lvalue) {
        std::string t = new_temp(pointer_type(o.e));
        prefix += t + " = &(" + ex(o.e) + "), ";
        texts.push_back("(*" + t + ")");
      } else {
        std::string t = new_temp(c_type(o.e->type));
        prefix += t + " = " + ex(o.e) + ", ";
        texts.push_back(t);
      }
    }
    if (place) return "(*(" + prefix + "&(" + build(texts) + ")))";
    return "(" + prefix + build(texts) + ")";
  }

  std::string zero_value(Type t) {
    if (t->physical) return zero_value(t->physical);
    if (device() && (t->kind == TypeKind::array || t->kind == TypeKind::view)) return c_type(t) + "{}";
    if (opts.metal_compute && t == &T_F64) return "coax_ff_make(0.0f, 0.0f)";
    if (needs_init(t)) return "coax_init_" + tag(t) + "()";
    switch (t->kind) {
      case TypeKind::string_: return "COAX_STR(0, 0)";
      case TypeKind::optional: return sum_construct(t,t->sum_default,"");
      case TypeKind::struct_: case TypeKind::array: case TypeKind::view: return "((" + c_type(t) + "){0})";
      case TypeKind::floating: return t == &T_F32 ? "0.0f" : "0.0";
      default: return "((" + c_type(t) + ")0)";
    }
  }

  std::string ct_name(const Expr *e) {
    if (verification) {
      auto found = verification_ct_ids.find(e);
      if (found == verification_ct_ids.end()) {
        int32_t id = (int32_t)ct_values.size();
        verification_ct_ids.emplace(e, id);
        ct_values.push_back(e);
        return "coax_k" + std::to_string(id);
      }
      return "coax_k" + std::to_string(found->second);
    }
    Expr *m = (Expr *)e;
    if (m->ct_id < 0) {
      m->ct_id = (int32_t)ct_values.size();
      ct_values.push_back(e);
    }
    return "coax_k" + std::to_string(m->ct_id);
  }

  // A compile-time value as a static initializer.
  std::string init_list(const Value &v) {
    Type t = v.type;
    if(t->physical) return init_list((*v.agg)[0]);
    switch (t->kind) {
      case TypeKind::integer: case TypeKind::enum_: return int_text(t, v.bits);
      case TypeKind::bool_: return v.bits ? "1" : "0";
      case TypeKind::floating: return float_text(t, v.f);
      case TypeKind::string_: return "{" + c_string_text(v.s) + ", " + std::to_string(v.s.count) + "}";
      case TypeKind::union_: case TypeKind::result: case TypeKind::optional: {
        std::string text="{.tag = "+std::to_string(v.sum_tag);
        if(sum_payload(t,(int32_t)v.sum_tag)!=&T_VOID)text+=", .payload."+sum_member((int32_t)v.sum_tag)+" = "+init_list((*v.agg)[0]);
        return text+"}";
      }
      case TypeKind::struct_: {
        std::string s = "{";
        const StructDecl *d = t->struct_decl;
        for (int32_t i = 0; i < d->fields.count; i++) {
          if (i) s += ", ";
          s += "." + to_std(d->fields[i].name) + " = " + init_list((*v.agg)[(size_t)i]);
        }
        if (!d->fields.count) s += "0";
        return s + "}";
      }
      case TypeKind::array: {
        std::string s = "{{";
        for (size_t i = 0; i < v.agg->size(); i++) {
          if (i) s += ", ";
          s += init_list((*v.agg)[i]);
        }
        return s + "}}";
      }
      default: return "{0}";
    }
  }

  // ---- expressions ----

  std::string arith(const char *name, const Expr *e) {
    std::string fn = std::string("coax_") + (opts.wrapping && (strcmp(name, "add") == 0 || strcmp(name, "sub") == 0 || strcmp(name, "mul") == 0) ? "w" : "") +
                     name + "_" + int_tag(e->type);
    bool wrapping = fn.compare(0, 6, "coax_w") == 0;
    std::string line = std::to_string(e->loc.line);
    return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
      return fn + "(" + t[0] + ", " + t[1] + (wrapping ? "" : ", " + line) + ")";
    });
  }

  std::string cast(const Expr *e) {
    Type to = e->type, from = e->lhs->type;
    std::string x = ex(e->lhs), line = std::to_string(e->loc.line);
    if (from == to) return x;
    if (to == &T_STRING) return "coax_string_of_bytes(" + x + ")";
    if (opts.metal_compute && is_float(to)) {
      if (to == &T_F32 && from == &T_F64) return "coax_ff_to_f32(" + x + ", " + line + ")";
      if (to == &T_F64) {
        if (from == &T_F32) return "coax_ff_from_f32(" + x + ")";
        Type b = from->kind == TypeKind::enum_ ? from->elem : from;
        return std::string(b->is_signed ? "coax_ff_from_s64((int64_t)(" : "coax_ff_from_u64((uint64_t)(") + x + "))";
      }
    }
    if (opts.metal_compute && from == &T_F32 && !is_float(to) && to->kind != TypeKind::enum_) {
      Type tb = to;
      std::string lo = tb->is_signed ? (tb->bits == 64 ? "INT64_MIN" : "INT64_C(" + std::to_string(-(int64_t)1 << (tb->bits - 1)) + ")") : "0";
      std::string hi_s = "INT64_C(" + std::to_string(tb->bits == 64 ? INT64_MAX : ((int64_t)1 << (tb->bits - 1)) - 1) + ")";
      std::string hi_u = "UINT64_C(" + std::to_string(tb->bits == 64 ? UINT64_MAX : ((uint64_t)1 << tb->bits) - 1) + ")";
      return "((" + c_type(to) + ")" + (tb->is_signed ? "coax_ftoi_s((float)(" + x + "), " + lo + ", " + hi_s + ", " + line + ")"
                                                      : "coax_ftoi_u((float)(" + x + "), " + hi_u + ", " + line + ")") + ")";
    }
    if (to == &T_F32 && from == &T_F64 && !opts.metal) return "coax_to_f32(" + x + ", " + line + ")";
    if (is_float(to)) return "((" + c_type(to) + ")(" + x + "))";
    if (to->kind == TypeKind::enum_) {
      Type b = from->kind == TypeKind::enum_ ? from->elem : from;
      return b->is_signed ? "coax_to_" + tag(to) + "((int64_t)(" + x + "), 0, 1, " + line + ")"
                          : "coax_to_" + tag(to) + "(0, (uint64_t)(" + x + "), 0, " + line + ")";
    }
    Type tb = to->kind == TypeKind::enum_ ? to->elem : to;
    std::string ct = c_type(to);
    std::string lo = tb->is_signed ? (tb->bits == 64 ? "INT64_MIN" : "INT64_C(" + std::to_string(-(int64_t)1 << (tb->bits - 1)) + ")") : "0";
    std::string hi_s = "INT64_C(" + std::to_string(tb->bits == 64 ? INT64_MAX : ((int64_t)1 << (tb->bits - 1)) - 1) + ")";
    std::string hi_u = "UINT64_C(" + std::to_string(tb->bits == 64 ? UINT64_MAX : ((uint64_t)1 << tb->bits) - 1) + ")";
    if (is_float(from)) {
      return "((" + ct + ")" + (tb->is_signed ? "coax_ftoi_s((double)(" + x + "), " + lo + ", " + hi_s + ", " + line + ")"
                                              : "coax_ftoi_u((double)(" + x + "), " + hi_u + ", " + line + ")") + ")";
    }
    if (e->trunc) return "((" + ct + ")(" + x + "))";
    Type fb = from->kind == TypeKind::enum_ ? from->elem : from;
    std::string fn;
    if (fb->is_signed) fn = tb->is_signed ? "coax_cast_ss((int64_t)(" + x + "), " + lo + ", " + hi_s
                                          : "coax_cast_su((int64_t)(" + x + "), " + hi_u;
    else fn = tb->is_signed ? "coax_cast_us((uint64_t)(" + x + "), " + hi_s : "coax_cast_uu((uint64_t)(" + x + "), " + hi_u;
    return "((" + ct + ")" + fn + ", " + line + "))";
  }

  std::map<const Expr *,std::string> lowered;
  bool control(const Expr *e) const {
    if(!e)return false;
    if((e->effects&8) || e->kind==ExprKind::try_ || e->kind==ExprKind::or_else)return true;
    for(const Expr *child:{e->lhs,e->rhs,e->third})if(control(child))return true;
    for(const Expr *child:e->args)if(control(child))return true;
    for(const FieldInit &field:e->fields)if(control(field.value))return true;
    return false;
  }
  std::string capture(const Expr *e,bool address=false) {
    std::string value=ex(e);
    if(e->type==&T_VOID){line(value+";");return "((void)0)";}
    std::string temp=new_temp(address ? pointer_type(e) : c_type(e->type));
    line(temp+" = "+(address ? "&("+value+")" : value)+";");
    return address ? "(*"+temp+")" : temp;
  }
  std::string lower_control(const Expr *e) {
    if(e->kind==ExprKind::try_ || e->kind==ExprKind::or_else){
      std::string value=capture(e->lhs);
      line("if ("+value+".tag >= "+std::to_string(sum_count(e->lhs->type))+") coax_trap(\"invalid sum tag\", "+std::to_string(e->loc.line)+");");
      int32_t success=e->lhs->type->kind==TypeKind::optional ? 1 : 0;
      std::string payload="("+value+").payload."+sum_member(success);
      if(e->kind==ExprKind::try_){
        line("if ("+value+".tag != "+std::to_string(success)+") {");indent++;
        std::string error=sum_payload(e->lhs->type,1-success)==&T_VOID ? "" : "("+value+").payload."+sum_member(1-success);
        std::string returned=new_temp(c_type(e->propagate_type));
        line(returned+" = "+sum_construct(e->propagate_type,e->sum_variant,error)+";");
        emit_defers_from(0);line("return "+returned+";");indent--;line("}");
        return e->type==&T_VOID ? "((void)0)" : payload;
      }
      std::string result=e->type==&T_VOID ? "" : new_temp(c_type(e->type));
      line("if ("+value+".tag == "+std::to_string(success)+") {");indent++;
      if(!result.empty())line(result+" = "+payload+";");
      indent--;line("} else {");indent++;
      std::string fallback=ex(e->rhs);line((result.empty()?"":result+" = ")+fallback+";");
      indent--;line("}");return result.empty()?"((void)0)":result;
    }
    if(e->kind==ExprKind::ifx || (e->kind==ExprKind::binary && (e->op==Tok::andand || e->op==Tok::oror))){
      std::string condition=capture(e->lhs),result=new_temp(c_type(e->type));
      line("if ("+condition+") {");indent++;
      if(e->kind==ExprKind::ifx){std::string yes=ex(e->rhs);line(result+" = "+yes+";");}
      else if(e->op==Tok::andand){std::string rhs=ex(e->rhs);line(result+" = "+rhs+";");}
      else line(result+" = 1;");
      indent--;line("} else {");indent++;
      if(e->kind==ExprKind::ifx){std::string no=ex(e->third);line(result+" = "+no+";");}
      else if(e->op==Tok::oror){std::string rhs=ex(e->rhs);line(result+" = "+rhs+";");}
      else line(result+" = 0;");
      indent--;line("}");return result;
    }
    std::vector<const Expr *> children;
    auto stage=[&](const Expr *child,bool address=false){if(child){lowered[child]=capture(child,address);children.push_back(child);}};
    if(e->kind==ExprKind::slice)stage(e->lhs,e->lhs->type->kind==TypeKind::array && is_place(e->lhs));
    else if(e->kind==ExprKind::index)stage(e->lhs,e->lhs->type->kind==TypeKind::array && is_place(e->lhs));
    else if(e->kind==ExprKind::field)stage(e->lhs,is_place(e->lhs));
    else stage(e->lhs);
    stage(e->rhs);stage(e->third);
    for(const Expr *arg:e->args)stage(arg);
    for(const FieldInit &field:e->fields)stage(field.value);
    std::string text=raw_ex(e);
    for(const Expr *child:children)lowered.erase(child);
    return text;
  }
  std::string ex(const Expr *e) {
    auto found=lowered.find(e);if(found!=lowered.end())return found->second;
    return control(e) ? lower_control(e) : raw_ex(e);
  }

  std::string raw_ex(const Expr *e) {
    std::string line = std::to_string(e->loc.line);
    if (n32 && n32->binary_site(e)) {
      const char *op = e->op == Tok::plus ? " + " : e->op == Tok::minus ? " - " : e->op == Tok::star ? " * " : e->op == Tok::slash ? " / " :
                       e->op == Tok::percent ? " % " : e->op == Tok::eqeq ? " == " : e->op == Tok::noteq ? " != " : e->op == Tok::lt ? " < " :
                       e->op == Tok::le ? " <= " : e->op == Tok::gt ? " > " : " >= ";
      // The intervals prove no 32-bit step overflows (so no INT32_MIN / -1);
      // a divisor that may be zero or negative keeps the checked helper.
      bool zero = (e->op == Tok::slash || e->op == Tok::percent) && n32->iv.at(e->rhs).lo <= 0;
      return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &x) {
        if (zero) return std::string(e->op == Tok::slash ? "coax_div32(" : "coax_mod32(") + "(int32_t)(" + x[0] + "), (int32_t)(" + x[1] + "), " + line + ")";
        return "((int32_t)(" + x[0] + ")" + op + "(int32_t)(" + x[1] + "))";
      });
    }
    switch (e->kind) {
      case ExprKind::int_lit: return int_text(e->type, e->int_value);
      case ExprKind::enum_value: return int_text(e->type, e->int_value);
      case ExprKind::float_lit:
        if (opts.metal) {
          // Metal gets decimal text: 9 digits round-trip any f32.
          char buf[64];
          snprintf(buf, sizeof buf, "%.9g", e->float_value);
          std::string t = buf;
          if (t.find_first_of(".eEn") == std::string::npos) t += ".0";
          return t + "f";
        }
        if (opts.metal_compute) {
          // Decimal text: 9 digits round-trip any f32. An f64 is the pair
          // hi = f32(v), lo = f32(v - hi).
          auto text = [](float f) -> std::string {
            if (std::isnan(f)) return "as_type<float>(0x7fc00000u)";
            if (std::isinf(f)) return f < 0 ? "as_type<float>(0xff800000u)" : "as_type<float>(0x7f800000u)";
            char buf[64];
            snprintf(buf, sizeof buf, "%.9g", (double)f);
            std::string t = buf;
            if (t.find_first_of(".eEn") == std::string::npos) t += ".0";
            return t + "f";
          };
          if (e->type == &T_F32) return text((float)e->float_value);
          float hi = (float)e->float_value;
          float lo = std::isfinite(hi) ? (float)(e->float_value - (double)hi) : 0.0f;
          return "coax_ff_make(" + text(hi) + ", " + text(lo) + ")";
        }
        if (opts.cuda && !std::isfinite(e->float_value)) {
          // NVRTC has no __builtin_nan/inf: spell the bit pattern.
          bool f32 = e->type == &T_F32, nan = std::isnan(e->float_value), neg = e->float_value < 0;
          if (f32) return std::string("__int_as_float((int)") + (nan ? "0x7fc00000u" : neg ? "0xff800000u" : "0x7f800000u") + ")";
          return std::string("__longlong_as_double((long long)") + (nan ? "0x7ff8000000000000ULL" : neg ? "0xfff0000000000000ULL" : "0x7ff0000000000000ULL") + ")";
        }
        return float_text(e->type, e->float_value);
      case ExprKind::bool_lit: return e->int_value ? "1" : "0";
      case ExprKind::string_lit: return "COAX_STR(" + c_string_text(e->text) + ", " + std::to_string(e->text.count) + ")";
      case ExprKind::ct_value: return ct_name(e);
      case ExprKind::ident: return e->constant ? ex(e->constant->expr) : local_name(e->text);
      case ExprKind::run:
        // Evaluation must replace every #run with a target-independent literal.
        fputs("coax: internal error: unevaluated #run reached the C emitter\n", stderr);
        abort();
      case ExprKind::call: {
        if (e->byte_intrinsic != ByteIntrinsic::none) {
          if (e->byte_intrinsic == ByteIntrinsic::bytes_overlap) {
            std::string a=new_temp(c_type(e->args[0]->type)),b=new_temp(c_type(e->args[1]->type));
            std::string x=ex(e->args[0]); std::string y=ex(e->args[1]);  // in source order (operands of + are unsequenced)
            return "("+a+" = "+x+", "+b+" = "+y+", coax_bytes_overlap("+a+".data, "+a+".count, "+b+".data, "+b+".count))";
          }
          if (e->byte_intrinsic == ByteIntrinsic::mul_wide) {
            wide=true;
            std::string a=new_temp("uint64_t"),b=new_temp("uint64_t");
            std::string x=ex(e->args[0]); std::string y=ex(e->args[1]);
            return "("+a+" = "+x+", "+b+" = "+y+", coax_mul_wide("+a+", "+b+"))";
          }
          if (e->byte_intrinsic >= ByteIntrinsic::add_wrap) {
            wrapping=true;
            std::string a=new_temp(c_type(e->type)),b=new_temp(c_type(e->type));
            std::string x=ex(e->args[0]); std::string y=ex(e->args[1]);
            return "("+a+" = "+x+", "+b+" = "+y+", coax_"+to_std(e->text)+(e->type==&T_U32?"_u32(":"_u64(")+a+", "+b+"))";
          }
          if (e->byte_intrinsic == ByteIntrinsic::value_barrier) barrier = true;
          if (e->byte_intrinsic == ByteIntrinsic::value_barrier)
            return std::string(e->type == &T_U32 ? "coax_value_barrier_u32(" : "coax_value_barrier_u64(") + ex(e->args[0]) + ")";
          return "coax_"+to_std(e->text)+"("+ex(e->args[0])+")";
        }
        if (opts.cuda && g_warp.mma_calls.count(e)) {
          // One warp-wide tensor-core multiply-add on the lanes' fragment registers.
          std::string a = local_name(e->args[0]->lhs->text), b = local_name(e->args[1]->lhs->text), c = local_name(e->args[2]->lhs->text);
          return "asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\" : \"+f\"(" +
                 c + "[0]), \"+f\"(" + c + "[1]), \"+f\"(" + c + "[2]), \"+f\"(" + c + "[3]) : \"r\"(" + a + "[0]), \"r\"(" + a + "[1]), \"r\"(" + a +
                 "[2]), \"r\"(" + a + "[3]), \"r\"(" + b + "[0]), \"r\"(" + b + "[1]))";
        }
        if (opts.metal_compute && g_warp.mma_calls.count(e)) {
          // The simdgroup's 16x8x16 product, lane by lane (coax_mma_bf16_16x8x16 in the runtime).
          // coax_mc keeps the A fragment's gathered rows between calls on the same A.
          static const std::string cache = "coax_mma_cache coax_mc = {};";
          if (std::find(temps.begin(), temps.end(), cache) == temps.end()) temps.push_back(cache);
          return "coax_mma_bf16_16x8x16(" + local_name(e->args[0]->lhs->text) + ", " + local_name(e->args[1]->lhs->text) + ", " +
                 local_name(e->args[2]->lhs->text) + ", coax_lane, coax_mc)";
        }
        if (opts.metal_compute && g_warp.apple_calls.count(e)) {
          int kind = g_warp.apple_calls.at(e);
          auto whole = [&](int i) { return local_name(e->args[i]->lhs->text); };
          if (kind == 1) return "coax_am_sg_mma(" + whole(0) + ", " + whole(1) + ".e, " + whole(2) + ".e, coax_lane)";
          if (kind == 2) return "(" + group_barrier().substr(0, group_barrier().size() - 1) + ", coax_am_sg_spill(" + whole(0) + ", " + whole(1) + ".e, coax_lane), " +
                                group_barrier().substr(0, group_barrier().size() - 1) + ")";
          apple_tensor = true;
          auto value = [&](int i) { return std::to_string(constant_of_expr(e->args[i])); };
          std::string s = "coax_am_matmul<" + value(1) + ", " + value(2) + ", " + std::to_string(g_warp.group_kernels.at(current) / 32) + ">(";
          for (int i = 3; i < 11; i++) s += ex(e->args[i]) + ", ";
          return s + line + ", coax_err)";
        }
        std::vector<Operand> ops;
        for (const Expr *a : e->args) ops.push_back({a, false});
        std::string name = e->intrinsic != Intrinsic::none ? math_name(e) : proc_name(e->proc);
        bool hidden = opts.metal_compute && e->intrinsic == Intrinsic::none;  // the lane and the error word
        return ordered(ops, [&](const std::vector<std::string> &t) {
          std::string s = name + "(";
          for (size_t i = 0; i < t.size(); i++) s += (i ? ", " : "") + t[i];
          if (hidden) s += std::string(t.empty() ? "" : ", ") + "coax_lane, coax_err";
          return s + ")";
        });
      }
      case ExprKind::sum: case ExprKind::some:
        return sum_construct(e->type,e->sum_variant,e->lhs ? ex(e->lhs) : "");
      case ExprKind::null_: return sum_construct(e->type,0,"");
      case ExprKind::try_: case ExprKind::or_else: return lower_control(e);
      case ExprKind::unary:
        if (e->op == Tok::bang) return "(!" + ex(e->lhs) + ")";
        if (is_float(e->type)) return "(-" + ex(e->lhs) + ")";
        if (opts.wrapping) return "coax_wneg_" + int_tag(e->type) + "(" + ex(e->lhs) + ")";
        return "coax_neg_" + int_tag(e->type) + "(" + ex(e->lhs) + ", " + line + ")";
      case ExprKind::binary: return binary(e);
      case ExprKind::field:
        if(e->lhs->type->physical) return ex(e->lhs);
        if (e->field_index == -2) {
          Type lt = e->lhs->type;
          if (lt->kind == TypeKind::array) {
            std::string n = "INT64_C(" + std::to_string(lt->length) + ")";
            return has_call(e->lhs) ? "((void)(" + ex(e->lhs) + "), " + n + ")" : n;
          }
          return "(" + ex(e->lhs) + ").count";
        }
        return "(" + ex(e->lhs) + ")." + to_std(e->text);
      case ExprKind::index: {
        if (device()) {
          auto th = g_warp.thread_index.find(e);
          // This thread's own element: index - thread*k, which folds to the offset.
          if (th != g_warp.thread_index.end())
            return local_name(e->lhs->text) + "[(" + ex(e->rhs) + ") - l_thread * " + std::to_string(th->second) + "]";
          auto at = g_warp.lane_index.find(e);
          // The element is this lane's own: index - lane*k, which folds to the offset.
          if (at != g_warp.lane_index.end())
            return local_name(e->lhs->text) + "[(" + ex(e->rhs) + ") - l_lane * " + std::to_string(at->second) + "]";
        }
        Type lt = e->lhs->type;
        if (n32 && n32->index_site(e)) {
          if (lt->kind == TypeKind::view)
            return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
              return "(*coax_elem32_" + tag(lt) + "(" + t[0] + ", (int32_t)(" + t[1] + "), " + line + "))";
            }, true);
          return ordered({{e->lhs, is_place(e->lhs)}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
            return "(" + t[0] + ").e[coax_index32((int32_t)(" + t[1] + "), " + std::to_string(lt->length) + ", " + line + ")]";
          }, is_place(e));
        }
        if (!unchecked.empty() && unchecked.count(e)) {
          std::string object = ex(e->lhs);
          std::string at = plain_index(e->rhs);
          return "(" + object + (lt->kind == TypeKind::view ? ").data[" : ").e[") + at + "]";
        }
        if (lt == &T_STRING)
          return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
            return "coax_byte(" + t[0] + ", " + t[1] + ", " + line + ")";
          });
        if (lt->kind == TypeKind::view)
          return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
            return "(*coax_elem_" + tag(lt) + "(" + t[0] + ", " + t[1] + ", " + line + "))";
          }, true);
        return ordered({{e->lhs, is_place(e->lhs)}, {e->rhs, false}}, [&](const std::vector<std::string> &t) {
          return "(" + t[0] + ").e[coax_index(" + t[1] + ", " + std::to_string(lt->length) + ", " + line + ")]";
        }, is_place(e));
      }
      case ExprKind::slice: {
        Type lt = e->lhs->type;
        std::vector<Operand> ops = {{e->lhs, lt->kind == TypeKind::array}};
        if (e->rhs) { ops.push_back({e->rhs, false}); ops.push_back({e->third, false}); }
        return ordered(ops, [&](const std::vector<std::string> &t) {
          std::string lo = e->rhs ? "(int64_t)(" + t[1] + ")" : "0", hi;
          if (lt == &T_STRING) {
            hi = e->rhs ? "(int64_t)(" + t[2] + ")" : "-1";
            return e->rhs ? "coax_substr(" + t[0] + ", " + lo + ", " + hi + ", " + line + ")" : t[0];
          }
          if (lt->kind == TypeKind::view) {
            if (!e->rhs) return t[0];
            return "coax_reslice_" + tag(lt) + "(" + t[0] + ", " + lo + ", (int64_t)(" + t[2] + "), " + line + ")";
          }
          std::string n = std::to_string(lt->length);
          hi = e->rhs ? "(int64_t)(" + t[2] + ")" : n;
          return "coax_mkview_" + tag(e->type) + "((" + t[0] + ").e, " + n + ", " + lo + ", " + hi + ", " + line + ")";
        });
      }
      case ExprKind::struct_lit: {
        if(e->type->physical) return e->fields.count ? ex(e->fields[0].value) : zero_value(e->type->physical);
        const StructDecl *d = e->type->struct_decl;
        std::vector<Operand> ops;
        for (const FieldInit &fi : e->fields) ops.push_back({fi.value, false});
        return ordered(ops, [&](const std::vector<std::string> &t) {
          std::string s = "((" + c_type(e->type) + "){";
          bool first = true;
          for (int32_t k = 0; k < d->fields.count; k++) {
            const Field &f = d->fields[k];
            std::string value;
            for (int32_t i = 0; i < e->fields.count; i++)
              if (e->fields[i].field == k) value = t[(size_t)i];
            if (value.empty()) {
              if (f.init) value = ex(f.init);
              else if (needs_init(f.type)) value = zero_value(f.type);
              else continue;  // a compound literal zeroes what it does not name
            }
            s += (first ? "." : ", .") + to_std(f.name) + " = " + value;
            first = false;
          }
          if (first) s += "0";
          return s + "})";
        });
      }
      case ExprKind::array_lit: {
        std::vector<Operand> ops;
        for (const Expr *a : e->args) ops.push_back({a, false});
        return ordered(ops, [&](const std::vector<std::string> &t) {
          std::string s = device() ? c_type(e->type) + "{{" : "((" + c_type(e->type) + "){{";
          for (size_t i = 0; i < t.size(); i++) s += (i ? ", " : "") + t[i];
          return s + (device() ? "}}" : "}})");
        });
      }
      case ExprKind::cast: return cast(e);
      case ExprKind::ifx: {
        // Emit operands in source order: the operands of + are unsequenced, and
        // each ex() may number temporaries, so GCC and Clang would differ.
        std::string c = ex(e->lhs); std::string a = ex(e->rhs); std::string b = ex(e->third);
        return "(" + c + " ? " + a + " : " + b + ")";
      }
    }
    return "0";
  }

  std::string binary(const Expr *e) {
    Type t = e->lhs->type;
    std::string line = std::to_string(e->loc.line);
    if(t->kind==TypeKind::optional){
      // Coax admits only optional/null equality here, never payload equality.
      std::string a=new_temp(c_type(t)),b=new_temp(c_type(t));
      std::string left=ex(e->lhs);std::string right=ex(e->rhs);
      return "("+a+" = "+left+", "+b+" = "+right+", (("+a+".tag >= 2 || "+b+".tag >= 2) ? (coax_trap(\"invalid sum tag\", "+line+"), 0) : ("+a+".tag"+(e->op==Tok::noteq?" != ":" == ")+b+".tag)))";
    }
    if (is_int(t)) {
      switch (e->op) {
        case Tok::plus: return arith("add", e);
        case Tok::minus: return arith("sub", e);
        case Tok::star: return arith("mul", e);
        case Tok::slash: return arith("div", e);
        case Tok::percent: return arith("mod", e);
        case Tok::shl: case Tok::shr: {
          std::string fn = std::string(e->op == Tok::shl ? "coax_shl_" : "coax_shr_") + int_tag(t);
          return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &x) {
            return fn + "(" + x[0] + ", (int64_t)(" + x[1] + "), " + line + ")";
          });
        }
        default: break;
      }
    }
    if (t == &T_STRING && (e->op == Tok::eqeq || e->op == Tok::noteq))
      return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &x) {
        return std::string(e->op == Tok::noteq ? "(!" : "(") + "coax_string_eq(" + x[0] + ", " + x[1] + "))";
      });
    const char *op = "";
    switch (e->op) {
      case Tok::plus: op = " + "; break;
      case Tok::minus: op = " - "; break;
      case Tok::star: op = " * "; break;
      case Tok::slash: op = " / "; break;
      case Tok::amp: op = " & "; break;
      case Tok::pipe: op = " | "; break;
      case Tok::caret: op = " ^ "; break;
      case Tok::eqeq: op = " == "; break;
      case Tok::noteq: op = " != "; break;
      case Tok::lt: op = " < "; break;
      case Tok::le: op = " <= "; break;
      case Tok::gt: op = " > "; break;
      case Tok::ge: op = " >= "; break;
      case Tok::andand: op = " && "; break;
      case Tok::oror: op = " || "; break;
      default: break;
    }
    if (e->op == Tok::andand || e->op == Tok::oror) {
      // Left operand first: ex() numbers temporaries, and + leaves the order unspecified.
      std::string l = ex(e->lhs); std::string r = ex(e->rhs);
      return "(" + l + op + r + ")";
    }
    bool bits = e->op == Tok::amp || e->op == Tok::pipe || e->op == Tok::caret;
    return ordered({{e->lhs, false}, {e->rhs, false}}, [&](const std::vector<std::string> &x) {
      std::string s = "(" + x[0] + op + x[1] + ")";
      return bits ? "((" + c_type(e->type) + ")" + s + ")" : s;
    });
  }

  // ---- print: split the checked format at compile time ----

  std::string show_call(Type t, const std::string &v, bool top) {
    if(t->physical) return show_call(t->physical,v,top);
    switch (t->kind) {
      case TypeKind::integer: return t->is_signed ? "coax_print_int(" + v + ")" : "coax_print_uint(" + v + ")";
      case TypeKind::floating: return "coax_print_float(" + v + (t == &T_F32 ? ", 1)" : ", 0)");
      case TypeKind::bool_: return "coax_print_bool(" + v + ")";
      case TypeKind::string_: return top ? "coax_put(" + v + ")" : "coax_show_string(" + v + ")";
      case TypeKind::enum_: return "coax_show_" + tag(t) + "(" + v + ")";
      default: return "coax_show_" + tag(t) + "(&" + v + ")";
    }
  }

  void print(const Expr *e) {
    Str fmt = e->args[0]->text;
    std::vector<std::string> values;
    bool all_trivial = true;
    for (int32_t i = 1; i < e->args.count; i++) all_trivial = all_trivial && trivial(e->args[i]);
    std::vector<const Expr *> staged;
    for(int32_t i=1;i<e->args.count;i++)if(control(e->args[i])){
      for(int32_t k=1;k<e->args.count;k++){lowered[e->args[k]]=capture(e->args[k]);staged.push_back(e->args[k]);}
      break;
    }
    line_start();
    out += "{";
    for (int32_t i = 1; i < e->args.count; i++) {
      const Expr *a = e->args[i];
      bool aggregate = is_aggregate(a->type) || a->type->kind == TypeKind::view;
      if ((all_trivial && !aggregate) || (all_trivial && is_place(a))) {
        values.push_back(ex(a));
      } else {
        // Every value is computed, in order, before anything is written.
        std::string t = "coax_a" + std::to_string(i);
        out += " " + c_type(a->type) + " " + t + " = " + ex(a) + ";";
        values.push_back(t);
      }
    }
    int32_t run = 0;
    size_t next = 0;
    auto flush = [&](int32_t upto) {
      if (upto > run) out += " coax_put(COAX_STR(" + c_string_text(Str{fmt.data + run, upto - run}) + ", " +
                             std::to_string(upto - run) + "));";
    };
    for (int32_t i = 0; i < fmt.count; i++) {
      if (fmt.data[i] != '%') continue;
      if (i + 1 < fmt.count && fmt.data[i + 1] == '%') {
        flush(i + 1);  // keep one '%'
        i++;
        run = i + 1;
        continue;
      }
      flush(i);
      run = i + 1;
      const Expr *a = e->args[(int32_t)next + 1];
      out += " " + show_call(a->type, values[next], true) + ";";
      next++;
    }
    flush(fmt.count);
    out += " }\n";
    for(const Expr *a:staged)lowered.erase(a);
  }

  // ---- statements ----

  void emit_defers_from(size_t depth) {
    for (size_t s = defers.size(); s-- > depth;)
      for (size_t i = defers[s].size(); i-- > 0;) stmt(defers[s][i]);
  }

  bool any_defers_from(size_t depth) {
    for (size_t s = depth; s < defers.size(); s++)
      if (!defers[s].empty()) return true;
    return false;
  }

  void block_body(const Stmt *s, const std::vector<std::string> &prelude = {}) {
    line("{");
    indent++;
    for (const std::string &p : prelude) line(p);
    defers.push_back({});
    for (const Stmt *c : s->body) {
      if (c->kind == StmtKind::defer) defers.back().push_back(c->then_);
      else stmt(c);
    }
    // Normal exit: cleanup in reverse registration order.
    std::vector<const Stmt *> mine = defers.back();
    defers.pop_back();
    for (size_t i = mine.size(); i-- > 0;) stmt(mine[i]);
    indent--;
    line("}");
  }

  static Tok compound_op(Tok op) {
    switch (op) {
      case Tok::plus_equal: return Tok::plus;
      case Tok::minus_equal: return Tok::minus;
      case Tok::star_equal: return Tok::star;
      case Tok::slash_equal: return Tok::slash;
      case Tok::percent_equal: return Tok::percent;
      case Tok::amp_equal: return Tok::amp;
      case Tok::pipe_equal: return Tok::pipe;
      case Tok::caret_equal: return Tok::caret;
      case Tok::shl_equal: return Tok::shl;
      case Tok::shr_equal: return Tok::shr;
      default: return Tok::eof;
    }
  }

  void assign(const Stmt *s) {
    const Expr *target = s->target;
    if (s->op == Tok::equal) {
      bool order = control(target) || control(s->expr) || lowering_place_first(target, s->expr, policy());
      if (!order) {
        // Same order as the C the old emitter produced under Clang: target, then value.
        std::string to = ex(target); std::string value = ex(s->expr);
        line(to + " = " + value + ";");
      } else {
        // The place first, then the value (spec §7.3).
        std::string p = new_temp(pointer_type(target));
        line(p + " = &(" + ex(target) + ");");
        line("*" + p + " = " + ex(s->expr) + ";");
      }
      return;
    }
    // A 32-bit local updated by + - or * of a 32-bit value: the local's
    // interval holds every value it stores, so the update fits as well.
    if (n32 && target->kind == ExprKind::ident && (s->op == Tok::plus_equal || s->op == Tok::minus_equal || s->op == Tok::star_equal)) {
      auto l = n32->local.find(target);
      if (l != n32->local.end() && n32->narrow_vars.count(l->second) && n32->fits(s->expr)) {
        std::string t = ex(target);
        const char *op = s->op == Tok::plus_equal ? " + " : s->op == Tok::minus_equal ? " - " : " * ";
        line(t + " = (int32_t)(" + t + ")" + op + "(int32_t)(" + ex(s->expr) + ");");
        return;
      }
    }
    // x op= v: the place is evaluated once, then v, then the update.
    Expr place{}, value{}, bin{};
    bool direct = !control(target) && !control(s->expr) && !lowering_compound_staged(target, s->expr, policy());
    std::string p, v;
    if (!direct) {
      p = new_temp(pointer_type(target));
      v = new_temp(c_type(s->expr->type));
      line(p + " = &(" + ex(target) + ");");
      line(v + " = " + ex(s->expr) + ";");
    }
    // Build `place op value` as a binary node over stand-in identifiers.
    place.kind = ExprKind::ident;
    place.type = target->type;
    value.kind = ExprKind::ident;
    value.type = s->expr->type;
    bin.kind = ExprKind::binary;
    bin.loc = s->loc;
    bin.type = target->type;
    bin.op = compound_op(s->op);
    std::string target_text = direct ? ex(target) : "(*" + p + ")";
    std::string marker_a = "\x01", marker_b = "\x02";
    place.text = Str{marker_a.c_str(), 1};
    value.text = Str{marker_b.c_str(), 1};
    bin.lhs = &place;
    bin.rhs = direct ? s->expr : &value;
    std::string text = binary(&bin);
    // Replace the stand-ins with the real C text.
    std::string a = local_name(place.text), b = local_name(value.text);
    for (size_t at; (at = text.find(a)) != std::string::npos;) text.replace(at, a.size(), target_text);
    for (size_t at; (at = text.find(b)) != std::string::npos;) text.replace(at, b.size(), v);
    line(target_text + " = " + text + ";");
  }

  void stmt(const Stmt *s) {
    struct Restore {Loc &target;Loc old;~Restore(){target=old;}} restore{debug_location,debug_location};
    debug_location=s->loc;
    switch (s->kind) {
      case StmtKind::block: block_body(s); break;
      case StmtKind::expr:
        if (s->expr->kind == ExprKind::call && s->expr->builtin_print) print(s->expr);
        else line(ex(s->expr) + ";");
        break;
      case StmtKind::var: {
        if (device() && g_warp.lane_arrays.count(s)) {
          // Lane l keeps elements l*k .. l*k+k-1: this lane's k values.
          line(c_type(s->type->elem) + " " + local_name(s->name) + "[" + std::to_string(s->type->length / 32) + "] = {};");
          break;
        }
        if (device() && g_warp.thread_arrays.count(s)) {
          // Thread t keeps elements t*k .. t*k+k-1 in registers.
          line(c_type(s->type->elem) + " " + local_name(s->name) + "[" + std::to_string(s->type->length / g_warp.thread_arrays.at(s)) + "] = {};");
          break;
        }
        if (device() && g_warp.shared_decls.count(s)) {
          // Threadgroup memory: the kernel entry owns it; zeroed by the whole group.
          std::string n = local_name(s->name), c = c_type(s->type), T = std::to_string(g_warp.group_kernels.at(current));
          if (opts.metal_compute) line("threadgroup " + c + " &" + n + " = *coax_tg_" + n + ";");
          else { line("__shared__ " + c + " coax_tg_" + n + ";"); line(c + " &" + n + " = coax_tg_" + n + ";"); }
          if (s->uninit) break;  // `---`: the kernel writes each element before it reads it

          // An f64 element on Metal is a float-float pair, which 0 does not convert to.
          std::string zero = opts.metal_compute && zero_value(s->type->elem) == "coax_ff_make(0.0f, 0.0f)" ? zero_value(s->type->elem) : "0";
          line(std::string(n32 ? "for (int32_t coax_z = (int32_t)coax_lane" : opts.metal_compute ? "for (int64_t coax_z = (int64_t)coax_lane" : "for (int64_t coax_z = (int64_t)threadIdx.x") + "; coax_z < " +
               std::to_string(s->type->length) + "; coax_z += " + T + ") " + n + ".e[coax_z] = " + zero + ";");
          line(group_barrier());
          break;
        }
        if (device() && g_warp.accumulators.count(s)) {
          // A matrix accumulator: each simdgroup's 8x8 tiles of it, in its own registers.
          std::string n = local_name(s->name);
          line("simdgroup_float8x8 " + n + "[8];");
          line("for (int coax_z = 0; coax_z < 8; coax_z++) " + n + "[coax_z] = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);");
          break;
        }
        std::string decl = (n32 && n32->narrow_vars.count(s) ? std::string("int32_t") : c_type(s->type)) + " " + local_name(s->name);
        if (s->expr) decl += " = " + ex(s->expr);
        else if (!s->uninit) decl += " = " + zero_value(s->type);  // zero or defaults, unless `---`
        line(decl + ";");
        break;
      }
      case StmtKind::assign: assign(s); break;
      case StmtKind::ret:
        if (!any_defers_from(0)) {
          line(s->expr ? "return " + ex(s->expr) + ";" : "return;");
          break;
        }
        // The value first, then cleanup, then the return.
        if (s->expr) line("coax_ret = " + ex(s->expr) + ";");
        ret_temp = ret_temp || s->expr;
        emit_defers_from(0);
        if (opts.debug_info) out+=debug_line(file,s->loc);
        line(s->expr ? "return coax_ret;" : "return;");
        break;
      case StmtKind::break_:
      case StmtKind::continue_:
        emit_defers_from(loop_scopes.back());
        line(s->kind == StmtKind::break_ ? "break;" : "continue;");
        break;
      case StmtKind::defer: break;  // registered by the enclosing block
      case StmtKind::assert_:  // checked in every build, like bounds and casts
        line("if (!" + condition(s->expr) + ") coax_trap(\"assertion failed\", " + std::to_string(s->loc.line) + ");");
        break;
      case StmtKind::if_:
        line("if " + condition(s->expr));
        stmt(s->then_);
        if (s->else_) {
          line("else");
          stmt(s->else_);
        }
        break;
      case StmtKind::switch_: {
        std::string value=capture(s->expr);
        if(is_sum(s->expr->type))line("if ("+value+".tag >= "+std::to_string(sum_count(s->expr->type))+") coax_trap(\"invalid sum tag\", "+std::to_string(s->loc.line)+");");
        line("{");indent++;
        for(int32_t i=0;i<s->cases.count;i++){
          const SwitchCase *arm=s->cases[i];
          std::string tag=is_sum(s->expr->type)?value+".tag":value;
          std::string alternative=is_sum(s->expr->type) ? "UINT32_C("+std::to_string(arm->tag_value)+")" : int_text(s->expr->type,arm->tag_value);
          line(std::string(i?"else if (":"if (")+tag+" == "+alternative+") {");indent++;
          if(arm->binding)line("const "+c_type(arm->binding->type)+" "+local_name(arm->binding->name)+" = "+value+".payload."+sum_member((int32_t)arm->tag_value)+";");
          stmt(arm->body);indent--;line("}");
        }
        if(s->cases.count)line("else coax_trap(\"invalid switch tag\", "+std::to_string(s->loc.line)+");");
        indent--;line("}");break;
      }
      case StmtKind::while_:
        if(control(s->expr)){
          line("while (1) {");indent++;
          std::string test=ex(s->expr);line("if (!("+test+")) break;");
          loop(s->then_);indent--;line("}");
        }else{line("while " + condition(s->expr));loop(s->then_);}
        break;
      case StmtKind::for_range: {
        if (device() && g_warp.lane_loops.count(s)) {
          // Each lane runs the body once, as its own `lane`.
          if (n32) loop(s->then_, {"const int32_t " + local_name(s->name) + " = (int32_t)coax_lane;"});
          else loop(s->then_, {"const int64_t " + local_name(s->name) + (opts.metal_compute ? " = (int64_t)coax_lane;" : " = (int64_t)(threadIdx.x & 31u);")});
          break;
        }
        if (device() && g_warp.thread_loops.count(s)) {
          // A phase: every thread of the group runs the body as its own
          // `thread`, between two barriers.
          line(group_barrier());
          if (n32) block_body(s->then_, {"const int32_t " + local_name(s->name) + " = (int32_t)coax_lane;"});
          else block_body(s->then_, {"const int64_t " + local_name(s->name) + (opts.metal_compute ? " = (int64_t)coax_lane;" : " = (int64_t)threadIdx.x;")});
          line(group_barrier());
          break;
        }
        std::string t = n32 && n32->narrow_vars.count(s) ? "int32_t" : c_type(s->type), n = std::to_string(temp_count++);
        std::string i = local_name(s->name);
        line("{");
        indent++;
        line(t + " coax_lo" + n + " = " + ex(s->expr) + ";");
        line(t + " coax_hi" + n + " = " + ex(s->expr2) + ";");
        // CUDA: a loop over constant bounds with at most 128 steps is unrolled,
        // so fixed arrays indexed by its counter stay in registers.
        auto literal = [](const Expr *x) -> const Expr * {
          if (x->kind == ExprKind::ident && x->constant && x->constant->expr) x = x->constant->expr;
          return x->kind == ExprKind::int_lit ? x : nullptr;
        };
        const Expr *lo = literal(s->expr), *hi = literal(s->expr2);
        if (device() && lo && hi && (int64_t)hi->int_value - (int64_t)lo->int_value <= 128) line("#pragma unroll");
        std::string head = "for (" + t + " " + i + " = coax_lo" + n + "; " + i + " < coax_hi" + n + "; " + i + "++)";
        if (!versioned_for(s, n, head)) {
          line(head);
          loop(s->then_);
        }
        indent--;
        line("}");
        break;
      }
      case StmtKind::for_each: {
        Type ct = s->expr->type;
        std::string n = std::to_string(temp_count++);
        std::string c = "coax_c" + n, i = "coax_i" + n, count, element;
        line("{");
        indent++;
        if (ct->kind == TypeKind::array) {
          // Iterate in place: writes by the body are seen by later iterations.
          if (is_place(s->expr)) line(c_type(ct) + " *" + c + " = &(" + ex(s->expr) + ");");
          else {
            line(c_type(ct) + " " + c + "_value = " + ex(s->expr) + ";");
            line(c_type(ct) + " *" + c + " = &" + c + "_value;");
          }
          count = std::to_string(ct->length);
          element = c + "->e[" + i + "]";
        } else {
          line(c_type(ct) + " " + c + " = " + ex(s->expr) + ";");
          count = c + ".count";
          element = ct == &T_STRING ? "(uint8_t)" + c + ".data[" + i + "]" : c + ".data[" + i + "]";
        }
        line("for (int64_t " + i + " = 0; " + i + " < " + count + "; " + i + "++)");
        std::vector<std::string> prelude = {c_type(s->type) + " " + local_name(s->name) + " = " + element + ";"};
        if (s->name2.count) prelude.push_back("int64_t " + local_name(s->name2) + " = " + i + ";");
        loop(s->then_, prelude);
        indent--;
        line("}");
        break;
      }
    }
  }

  // ---- loop versioning ----
  // A for loop L, outside any other versioned loop, in an optimized C
  // product (native optimization 1 or more, as --release selects; not a
  // device, Metal or verification build). -O0 output has no versioned loops. Its candidate indexes are v[x]
  // where v is a local array (its length is its type's, wherever it is
  // declared) or a view named by an identifier L never declares or assigns,
  // and x is affine: integer literals and constants, identifiers L
  // never declares or assigns, `.count` of such a view, L's counter, and the
  // counters of for loops inside L (declared once, with affine bounds, used
  // only inside their own loop), combined with + - * and / by a positive
  // integer literal. The guard evaluates
  // every subexpression's interval with exact endpoints (IV_RUNTIME); the
  // fast copy runs only when all of them fit in int64 and every candidate
  // index is inside its view or array.
  struct VScan {
    const Stmt *loop = nullptr;
    std::map<std::string, int> declared;
    std::set<std::string> assigned;
    std::map<std::string, const Stmt *> counters;              // nested for loops, by counter name
    std::map<const Stmt *, std::vector<const Stmt *>> outer;  // a nested for loop: the nested for loops around it
    std::vector<std::pair<const Expr *, std::vector<const Stmt *>>> indexes;  // with the nested for loops around each
    std::vector<const Stmt *> stack;
  };
  static std::string name_of(Str n) { return std::string(n.data, (size_t)n.count); }
  void vscan_expr(const Expr *e, VScan &v) {
    if (!e) return;
    if (e->kind == ExprKind::index) v.indexes.push_back({e, v.stack});
    vscan_expr(e->lhs, v); vscan_expr(e->rhs, v); vscan_expr(e->third, v);
    for (int32_t k = 0; k < e->args.count; k++) vscan_expr(e->args[k], v);
    for (int32_t k = 0; k < e->fields.count; k++) vscan_expr(e->fields[k].value, v);
  }
  void vscan_stmt(const Stmt *s, VScan &v) {
    if (!s) return;
    switch (s->kind) {
      case StmtKind::block: for (int32_t k = 0; k < s->body.count; k++) vscan_stmt(s->body[k], v); break;
      case StmtKind::var: v.declared[name_of(s->name)]++; vscan_expr(s->expr, v); break;
      case StmtKind::assign:
        if (s->target && s->target->kind == ExprKind::ident) v.assigned.insert(name_of(s->target->text));
        vscan_expr(s->target, v); vscan_expr(s->expr, v); break;
      case StmtKind::for_range:
        v.declared[name_of(s->name)]++;
        v.counters[name_of(s->name)] = s;
        v.outer[s] = v.stack;
        vscan_expr(s->expr, v); vscan_expr(s->expr2, v);
        v.stack.push_back(s); vscan_stmt(s->then_, v); v.stack.pop_back();
        break;
      case StmtKind::for_each:
        v.declared[name_of(s->name)]++;
        if (s->name2.count) v.declared[name_of(s->name2)]++;
        vscan_expr(s->expr, v); vscan_stmt(s->then_, v); break;
      case StmtKind::switch_:
        vscan_expr(s->expr, v);
        for (const SwitchCase *arm : s->cases) {
          if (arm->binding) v.declared[name_of(arm->binding->name)]++;
          vscan_stmt(arm->body, v);
        }
        break;
      default:
        vscan_expr(s->expr, v); vscan_expr(s->expr2, v); vscan_expr(s->target, v);
        vscan_stmt(s->then_, v); vscan_stmt(s->else_, v); break;
    }
  }
  bool invariant(const std::string &n, const VScan &v) const {
    return !v.declared.count(n) && !v.assigned.count(n) && n != name_of(v.loop->name);
  }
  // A nested counter usable where the nested for loops `around` enclose the use.
  const Stmt *counter(const std::string &n, const VScan &v, const std::vector<const Stmt *> &around) const {
    auto c = v.counters.find(n);
    if (c == v.counters.end() || v.declared.at(n) != 1 || v.assigned.count(n) || c->second->type != T_INT) return nullptr;
    if (std::find(around.begin(), around.end(), c->second) == around.end()) return nullptr;
    return c->second;
  }
  bool affine(const Expr *e, const VScan &v, const std::vector<const Stmt *> &around, int depth = 0) const {
    if (!e || e->type != T_INT || depth > 64) return false;
    switch (e->kind) {
      case ExprKind::int_lit: return true;
      case ExprKind::ident: {
        if (e->constant) return e->constant->expr && e->constant->expr->kind == ExprKind::int_lit;
        std::string n = name_of(e->text);
        if (n == name_of(v.loop->name)) return v.loop->type == T_INT && !v.declared.count(n) && !v.assigned.count(n);
        if (const Stmt *c = counter(n, v, around)) {
          const std::vector<const Stmt *> &o = v.outer.at(c);
          return affine(c->expr, v, o, depth + 1) && affine(c->expr2, v, o, depth + 1);
        }
        return invariant(n, v);
      }
      case ExprKind::binary:
        if (e->op == Tok::slash)
          return e->rhs->kind == ExprKind::int_lit && (int64_t)e->rhs->int_value > 0 && affine(e->lhs, v, around, depth + 1);
        return (e->op == Tok::plus || e->op == Tok::minus || e->op == Tok::star) && affine(e->lhs, v, around, depth + 1) &&
               affine(e->rhs, v, around, depth + 1);
      case ExprKind::field:
        return e->field_index == -2 && e->lhs->kind == ExprKind::ident && !e->lhs->constant &&
               e->lhs->type->kind == TypeKind::view && invariant(name_of(e->lhs->text), v);
      default: return false;
    }
  }
  // The guard's interval for e, as a coax_iv temporary; ok is the guard flag.
  std::string interval(const Expr *e, const VScan &v, const std::vector<const Stmt *> &around, const std::string &ok,
                       const std::string &lo, const std::string &hi, std::map<const Stmt *, std::string> &done) {
    std::string t = "coax_iv" + std::to_string(temp_count++);
    switch (e->kind) {
      case ExprKind::int_lit: case ExprKind::field: {
        std::string x = ex(e);
        line("coax_iv " + t + " = {" + x + ", " + x + "};");
        return t;
      }
      case ExprKind::ident: {
        std::string n = name_of(e->text);
        if (!e->constant && n == name_of(v.loop->name)) {
          line("coax_iv " + t + " = {" + lo + ", " + lo + "};");
          line(ok + " = " + ok + " && " + lo + " < " + hi + ";");
          line("if (" + ok + ") " + t + ".hi = " + hi + " - 1;");
          return t;
        }
        if (const Stmt *c = e->constant ? nullptr : counter(n, v, around)) {
          auto d = done.find(c);
          if (d != done.end()) return d->second;
          const std::vector<const Stmt *> &o = v.outer.at(c);
          std::string a = interval(c->expr, v, o, ok, lo, hi, done), b = interval(c->expr2, v, o, ok, lo, hi, done);
          line("coax_iv " + t + " = {" + a + ".lo, " + a + ".lo};");
          line(ok + " = " + ok + " && " + a + ".lo < " + b + ".hi;");
          line("if (" + ok + ") " + t + ".hi = " + b + ".hi - 1;");
          done[c] = t;
          return t;
        }
        std::string x = ex(e);
        line("coax_iv " + t + " = {" + x + ", " + x + "};");
        return t;
      }
      default: {
        std::string a = interval(e->lhs, v, around, ok, lo, hi, done), b = interval(e->rhs, v, around, ok, lo, hi, done);
        // Division by a positive literal truncates toward zero, which keeps the order.
        if (e->op == Tok::slash) {
          line("coax_iv " + t + " = {" + a + ".lo / " + b + ".lo, " + a + ".hi / " + b + ".lo};");
          return t;
        }
        const char *f = e->op == Tok::plus ? "coax_iv_add" : e->op == Tok::minus ? "coax_iv_sub" : "coax_iv_mul";
        line("coax_iv " + t + " = {0, 0};");
        line(ok + " = " + ok + " && " + f + "(" + a + ", " + b + ", &" + t + ");");
        return t;
      }
    }
  }
  // An affine index in plain C: the guard has shown no step overflows.
  std::string plain_index(const Expr *e) {
    if (e->kind == ExprKind::binary) {
      std::string a = plain_index(e->lhs);
      std::string b = plain_index(e->rhs);
      return "(" + a + (e->op == Tok::plus ? " + " : e->op == Tok::minus ? " - " : e->op == Tok::slash ? " / " : " * ") + b + ")";
    }
    return "(int64_t)(" + ex(e) + ")";
  }
  bool versioned_for(const Stmt *s, const std::string &n, const std::string &head) {
    if (opts.optimization < 1 || device() || opts.metal || verification || version_depth > 0 || s->type != T_INT) return false;
    VScan v;
    v.loop = s;
    vscan_stmt(s->then_, v);
    if (v.declared.count(name_of(s->name))) return false;  // L's counter shadowed inside L
    std::vector<std::pair<const Expr *, std::vector<const Stmt *>>> picked;
    for (auto &x : v.indexes) {
      const Expr *e = x.first;
      Type lt = e->lhs->type;
      if (lt == &T_STRING || (lt->kind != TypeKind::view && lt->kind != TypeKind::array)) continue;
      if (e->lhs->kind != ExprKind::ident || e->lhs->constant) continue;
      if (lt->kind == TypeKind::view && !invariant(name_of(e->lhs->text), v)) continue;
      if (!affine(e->rhs, v, x.second)) continue;
      picked.push_back(x);
    }
    if (picked.empty()) return false;
    std::string ok = "coax_ok" + n, lo = "coax_lo" + n, hi = "coax_hi" + n;
    line("int " + ok + " = 1;");
    std::map<const Stmt *, std::string> done;
    for (auto &x : picked) {
      const Expr *e = x.first;
      std::string iv = interval(e->rhs, v, x.second, ok, lo, hi, done);
      std::string count = e->lhs->type->kind == TypeKind::view ? "(" + ex(e->lhs) + ").count" : "INT64_C(" + std::to_string(e->lhs->type->length) + ")";
      line(ok + " = " + ok + " && " + iv + ".lo >= 0 && " + iv + ".hi < " + count + ";");
    }
    versioned = true;
    version_depth++;
    line("if (" + ok + ")");
    line("{");
    indent++;
    for (auto &x : picked) unchecked.insert(x.first);
    line(head);
    loop(s->then_);
    unchecked.clear();
    indent--;
    line("}");
    line("else");
    line("{");
    indent++;
    line(head);
    loop(s->then_);
    indent--;
    line("}");
    version_depth--;
    return true;
  }

  void loop(const Stmt *body, const std::vector<std::string> &prelude = {}) {
    loop_scopes.push_back(defers.size());
    block_body(body, prelude);
    loop_scopes.pop_back();
  }

  // ---- declarations ----

  std::string prototype(const ProcDecl *p, bool header = false) {
    std::string s = (opts.cuda ? "static __device__ " : opts.metal_compute ? "static inline " : header || (p->export_c && !verification) ? "" : p->foreign ? "extern " : "static ") + c_type(p->ret) + " " +
                    proc_name(p) + (n32 && n32->proc == p ? "_n32" : "") + "(";
    if (p->params.count == 0 && !opts.metal_compute) s += "void";
    for (int32_t i = 0; i < p->params.count; i++) {
      if (i) s += ", ";
      s += c_type(p->params[i].type);
      if (!header) s += " " + local_name(p->params[i].name);
      else if (!is_c_keyword(p->params[i].name)) s += " " + to_std(p->params[i].name);
    }
    // Metal: every procedure carries the simdgroup lane and the launch's error words.
    if (opts.metal_compute) s += std::string(p->params.count ? ", " : "") + "uint coax_lane, thread uint *coax_err";
    // A group kernel's threadgroup arrays live in its entry, which passes them in.
    if (opts.metal_compute && g_warp.shared_arrays.count(p))
      for (const Stmt *d : g_warp.shared_arrays.at(p)) s += ", threadgroup " + c_type(d->type) + " *coax_tg_" + local_name(d->name);
    return s + ")";
  }

  std::string function(const ProcDecl *p) {
    if (p->foreign) return "";
    current = p;
    mapping_active=true;debug_location=p->loc;
    out.clear();
    temps.clear();
    lowered.clear();
    ret_temp = false;
    indent = 1;
    std::string saved;
    // Emit the body's statements, then wrap them with the temporaries.
    defers.push_back({});
    for (const Stmt *c : p->body->body) {
      if (c->kind == StmtKind::defer) defers.back().push_back(c->then_);
      else stmt(c);
    }
    std::vector<const Stmt *> mine = defers.back();
    defers.pop_back();
    for (size_t i = mine.size(); i-- > 0;) stmt(mine[i]);
    std::string body = out;mapping_active=false;
    std::string s = "\n" + (opts.debug_info ? debug_line(file,p->loc) : "") + prototype(p) + " {\n";
    if (ret_temp) s += "  " + c_type(p->ret) + " coax_ret;\n";
    for (const std::string &t : temps) s += "  " + t + "\n";
    s += body + "}\n";
    if (opts.debug_info) s+="#line 1 \"<coax-generated>\"\n";
    return s;
  }
};

// ---- types: declarations in dependency order ----

// Header composition checks direct C ABI definitions, not logical Coax
// declaration identity. Referenced named types are checked independently by
// TypeWriter::need, so recursive borrowed records require no recursive schema
// expansion. Defaults and checkout paths do not change this C interface.
static std::string header_type_schema(Type t) {
  std::string schema;
  auto part = [&](const std::string &value) {
    schema += std::to_string(value.size()) + ":" + value;
  };
  part(is_sum(t) ? "coax-c-sum-lp64-v1" : "coax-c-type-v1");
  switch (t->kind) {
    case TypeKind::struct_: part("struct"); break;
    case TypeKind::enum_: part("enum"); break;
    case TypeKind::array: part("array"); break;
    case TypeKind::view: part("view"); break;
    case TypeKind::union_: part("union"); break;
    case TypeKind::result: part("result"); break;
    case TypeKind::optional: part("optional"); break;
    default: part("other"); break;
  }
  part(c_type(t));
  part(std::to_string(t->size));
  part(std::to_string(t->align));
  if(is_sum(t)){
    part("u32");part(std::to_string(t->sum_payload_offset));part(std::to_string(sum_count(t)));
    for(int32_t i=0;i<sum_count(t);i++){
      part(std::to_string(i));part(c_type(sum_payload(t,i)));
      if(t->kind==TypeKind::union_)part(to_std(t->union_decl->variants[i].name));
    }
  } else if (t->kind == TypeKind::struct_) {
    part(std::to_string(t->struct_decl->fields.count));
    for (const Field &field : t->struct_decl->fields) {
      part(to_std(field.name));
      part(c_type(field.type));
      part(std::to_string(field.offset));
    }
  } else if (t->kind == TypeKind::enum_) {
    part(c_type(t->elem));
    part(std::to_string(t->enum_decl->members.count));
    for (const EnumMember &member : t->enum_decl->members) {
      part(to_std(member.name));
      part(std::to_string(member.bits));
    }
  } else if (t->kind == TypeKind::array || t->kind == TypeKind::view) {
    part(c_type(t->elem));
    if (t->kind == TypeKind::array) part(std::to_string(t->length));
  }
  return schema;
}

static std::string header_type_definition(Type t, const std::string &definition) {
  static const char hex[] = "0123456789abcdef";
  std::string encoded;
  for (unsigned char byte : header_type_schema(t)) {
    encoded += hex[byte >> 4];
    encoded += hex[byte & 15];
  }
  std::string guard = "COAX_" + c_type(t) + "_DEFINED";
  std::string schema = "COAX_SCHEMA_" + c_type(t) + "_" + encoded;
  return "#ifdef " + guard + "\n#ifndef " + schema +
         "\n#error \"incompatible Coax C type " + c_type(t) + "\"\n#endif\n#else\n#define " +
         guard + "\n#define " + schema + "\n" + definition + "#endif\n";
}

struct TypeWriter {
  std::string out;
  std::vector<Type> done;
  bool header = false;

  bool seen(Type t) {
    for (Type d : done) if (d == t || ((t->kind==TypeKind::array || t->kind==TypeKind::view || is_sum(t)) && d->kind==t->kind && tag(d)==tag(t))) return true;
    return false;
  }

  void need(Type t) {
    if (seen(t)) return;
    if(t->physical) { done.push_back(t); need(t->physical); return; }
    switch (t->kind) {
      case TypeKind::struct_: {
        done.push_back(t);
        const StructDecl *d = t->struct_decl;
        for (const Field &f : d->fields) if (f.type->kind != TypeKind::view) need(f.type);
        for (const Field &f : d->fields) if (f.type->kind == TypeKind::view) need(f.type);
        std::string definition = "struct coax_" + tag(t) + " {";
        for (const Field &f : d->fields) definition += " " + c_type(f.type) + " " + to_std(f.name) + ";";
        if (!d->fields.count) definition += " char coax_empty;";
        definition += " };\n";
        out += header ? header_type_definition(t, definition) : definition;
        break;
      }
      case TypeKind::union_: case TypeKind::result: case TypeKind::optional: {
        done.push_back(t);
        bool payload=false;
        for(int32_t i=0;i<sum_count(t);i++)if(sum_payload(t,i)!=&T_VOID){need(sum_payload(t,i));payload=true;}
        std::string definition="struct "+c_type(t)+" { uint32_t tag;";
        if(payload){
          definition+=" union {";
          for(int32_t i=0;i<sum_count(t);i++)if(sum_payload(t,i)!=&T_VOID)
            definition+=" "+c_type(sum_payload(t,i))+" "+sum_member(i)+";";
          definition+=" } payload;";
        }
        definition+=" };\n";
        out+=header ? header_type_definition(t,definition) : definition;
        break;
      }
      case TypeKind::array: {
        need(t->elem);
        done.push_back(t);
        std::string definition = "typedef struct { " + c_type(t->elem) + " e[" + std::to_string(t->length) + "]; } " + c_type(t) + ";\n";
        out += header ? header_type_definition(t, definition) : definition;
        break;
      }
      case TypeKind::view:
        done.push_back(t);
        if(is_sum(t->elem)){
          // The sum has a forward alias. Publish its pointer descriptor before
          // walking a recursive union's payloads, which may use this view.
          std::string definition="typedef struct { "+c_type(t->elem)+" *data; int64_t count; } "+c_type(t)+";\n";
          out+=header ? header_type_definition(t,definition) : definition;
          need(t->elem);break;
        }
        // C needs only the element's name for a pointer; a header still
        // declares the element so the host can use it.
        if (t->elem->kind != TypeKind::struct_ || header) need(t->elem);
        {
          // A view of a scalar is the same in every library, so headers
          // from two libraries can be included together.
          std::string def = "typedef struct { " + c_type(t->elem) + " *data; int64_t count; } " + c_type(t) + ";\n";
          TypeKind k = t->elem->kind;
          bool shared = k == TypeKind::integer || k == TypeKind::floating || k == TypeKind::bool_;
          if (header) def = header_type_definition(t, def);
          else if (shared) {
            std::string guard = "COAX_" + c_type(t) + "_DEFINED";
            def = "#ifndef " + guard + "\n#define " + guard + "\n" + def + "#endif\n";
          }
          out += def;
        }
        break;
      case TypeKind::enum_: {
        done.push_back(t);
        std::string definition = "typedef " + c_type(t->elem) + " " + c_type(t) + ";\n";
        for (const EnumMember &m : t->enum_decl->members)
          definition += "#define COAX_" + (t->scope ? "q" + std::to_string(t->scope) + "_" : std::string()) + to_std(t->enum_decl->name) + "_" + to_std(m.name) + " " + int_text(t, m.bits) + "\n";
        out += header ? header_type_definition(t, definition) : definition;
        break;
      }
      default: break;
    }
  }

  void forward_structs(const File *file) {
    for(const UnionDecl *d:file->unions)out+="typedef struct "+c_type(d->type)+" "+c_type(d->type)+";\n";
    for(Type t:all_composite_types())if(is_sum(t))out+="typedef struct "+c_type(t)+" "+c_type(t)+";\n";
    for (const StructDecl *d : file->structs) if(!d->type->physical)
      out += "typedef struct coax_" + tag(d->type) + " coax_" + tag(d->type) + ";\n";
  }

  // The C compiler checks that Coax's layout is the C layout.
  void sum_layout_asserts(const char *alignment="_Alignof") {
    for(Type t:done)if(is_sum(t)){
      std::string c=c_type(t);
      out+="COAX_LAYOUT(sizeof("+c+") == "+std::to_string(t->size)+" && "+alignment+"("+c+") == "+std::to_string(t->align)+", \"sum layout of "+c+"\");\n";
      out+="COAX_LAYOUT(offsetof("+c+", tag) == 0, \"sum tag of "+c+"\");\n";
      if(t->sum_payload_offset)out+="COAX_LAYOUT(offsetof("+c+", payload) == "+std::to_string(t->sum_payload_offset)+", \"sum payload of "+c+"\");\n";
    }
  }
  void layout_asserts(const File *file) {
    sum_layout_asserts();
    for (const StructDecl *d : file->structs) {
      if(d->type->physical) continue;
      std::string c = c_type(d->type);
      out += "COAX_LAYOUT(sizeof(" + c + ") == " + std::to_string(d->type->size) + " && _Alignof(" + c + ") == " +
             std::to_string(d->type->align) + ", \"layout of " + to_std(d->name) + "\");\n";
      for (const Field &f : d->fields)
        out += "COAX_LAYOUT(offsetof(" + c + ", " + to_std(f.name) + ") == " + std::to_string(f.offset) +
               ", \"offset of " + to_std(d->name) + "." + to_std(f.name) + "\");\n";
    }
  }
};

void collect_types(const File *file, std::vector<Type> *types) {
  auto add = [&](Type t) {
    if(t->physical) return;
    for (Type x : *types) if (x == t || ((t->kind==TypeKind::array || t->kind==TypeKind::view) && x->kind==t->kind && tag(x)==tag(t))) return;
    types->push_back(t);
  };
  for (const StructDecl *d : file->structs) add(d->type);
  for (const EnumDecl *d : file->enums) add(d->type);
  for(const UnionDecl *d:file->unions)add(d->type);
  for (Type t : all_composite_types()) add(t);
}

// Each type's print and enum-conversion helpers. With `uses` (the C that
// calls them), only the helpers that C reaches are kept, through the helpers
// they call in turn: a type that is never printed or converted to gets none
// (ax-library-check-cache).
std::string show_functions(const File *file, Emitter &em, const std::string *uses = nullptr) {
  std::vector<Type> types;
  collect_types(file, &types);
  struct Item { std::string protos, bodies; std::vector<std::string> names; };
  std::vector<Item> items;
  for (Type t : types) {
    items.emplace_back();
    std::string &protos = items.back().protos, &bodies = items.back().bodies;
    std::string c = c_type(t), tg = tag(t);
    items.back().names = {"coax_show_" + tg, "coax_to_" + tg};
    if (t->kind == TypeKind::enum_) {
      protos += "static void coax_show_" + tg + "(" + c + " v);\n";
      bodies += "static void coax_show_" + tg + "(" + c + " v) {\n  switch (v) {\n";
      for (const EnumMember &m : t->enum_decl->members)
        bodies += "    case " + int_text(t, m.bits) + ": fputs(\"" + to_std(m.name) + "\", stdout); return;\n";
      bodies += "    default: break;\n  }\n  fputs(\"" + to_std(t->enum_decl->name) + "(\", stdout); " +
                (t->elem->is_signed ? "coax_print_int((int64_t)v);" : "coax_print_uint((uint64_t)v);") +
                " fputc(')', stdout);\n}\n";
      // Checked conversion from an integer: it must name a member.
      bodies += "static " + c + " coax_to_" + tg + "(int64_t s, uint64_t u, int is_signed, int32_t l) {\n";
      for (const EnumMember &m : t->enum_decl->members) {
        bool negative = t->elem->is_signed && (int64_t)m.bits < 0;
        if (negative) bodies += "  if (is_signed && s == INT64_C(" + std::to_string((int64_t)m.bits) + ")) return " + int_text(t, m.bits) + ";\n";
        else bodies += "  if (is_signed ? (s >= 0 && (uint64_t)s == UINT64_C(" + std::to_string(m.bits) + ")) : u == UINT64_C(" +
                       std::to_string(m.bits) + ")) return " + int_text(t, m.bits) + ";\n";
      }
      bodies += "  coax_trap(\"value is not a member of enum " + to_std(t->enum_decl->name) + "\", l);\n  return 0;\n}\n";
      protos += "static " + c + " coax_to_" + tg + "(int64_t s, uint64_t u, int is_signed, int32_t l);\n";
      continue;
    }
    protos += "static void coax_show_" + tg + "(const " + c + " *v);\n";
    bodies += "static void coax_show_" + tg + "(const " + c + " *v) {\n";
    if(is_sum(t)){
      bodies+="  switch(v->tag) {\n";
      for(int32_t i=0;i<sum_count(t);i++){
        Type payload=sum_payload(t,i);
        std::string label=t->kind==TypeKind::union_ ? to_std(t->union_decl->variants[i].name) : t->kind==TypeKind::result ? (i==0?"ok":"err") : (i==0?"none":"some");
        bodies+="  case "+std::to_string(i)+": fputs(\""+label+"\", stdout);";
        if(payload!=&T_VOID)bodies+=" fputc('(', stdout); "+em.show_call(payload,"v->payload."+sum_member(i),false)+"; fputc(')', stdout);";
        bodies+=" return;\n";
      }
      bodies+="  default: coax_trap(\"invalid sum tag\",0);\n  }\n";
    } else if (t->kind == TypeKind::struct_) {
      const StructDecl *d = t->struct_decl;
      bodies += "  fputs(\"" + to_std(d->name) + ".{\", stdout);\n";
      for (int32_t i = 0; i < d->fields.count; i++) {
        const Field &f = d->fields[i];
        bodies += "  fputs(\"" + std::string(i ? ", " : "") + to_std(f.name) + " = \", stdout); " +
                  em.show_call(f.type, "v->" + to_std(f.name), false) + ";\n";
      }
      bodies += "  fputc('}', stdout);\n";
    } else {
      std::string n = t->kind == TypeKind::array ? std::to_string(t->length) : "v->count";
      std::string el = t->kind == TypeKind::array ? "v->e[i]" : "v->data[i]";
      bodies += "  fputc('[', stdout);\n  for (int64_t i = 0; i < " + n + "; i++) {\n    if (i) fputs(\", \", stdout);\n    " +
                em.show_call(t->elem, el, false) + ";\n  }\n  fputc(']', stdout);\n";
    }
    bodies += "}\n";
  }
  std::vector<bool> kept(items.size(), !uses);
  if (uses) {
    // A helper's name is used when it appears followed by '(' in kept C.
    auto calls = [](const std::string &text, const std::string &name) {
      for (size_t at = text.find(name); at != std::string::npos; at = text.find(name, at + 1))
        if (at + name.size() < text.size() && text[at + name.size()] == '(' &&
            (at == 0 || !(isalnum((unsigned char)text[at - 1]) || text[at - 1] == '_')))
          return true;
      return false;
    };
    std::vector<const std::string *> pending{uses};
    while (!pending.empty()) {
      const std::string *text = pending.back();
      pending.pop_back();
      for (size_t i = 0; i < items.size(); i++) {
        if (kept[i]) continue;
        for (const std::string &name : items[i].names)
          if (calls(*text, name)) { kept[i] = true; pending.push_back(&items[i].bodies); break; }
      }
    }
  }
  std::string protos, bodies;
  for (size_t i = 0; i < items.size(); i++) if (kept[i]) { protos += items[i].protos; bodies += items[i].bodies; }
  return protos + bodies;
}

std::string view_helpers() {
  std::string s;
  std::set<std::string> emitted;
  for (Type t : all_composite_types()) {
    if (t->kind != TypeKind::view || !emitted.insert(tag(t)).second) continue;
    std::string c = c_type(t), e = c_type(t->elem), tg = tag(t);
    if (t->elem == &T_U8)
      s += "static coax_string coax_string_of_bytes(" + c + " v) { coax_string s = {(const char *)v.data, v.count}; return s; }\n";
    s += "static " + e + " *coax_elem_" + tg + "(" + c + " v, int64_t i, int32_t l) { return &v.data[coax_index(i, v.count, l)]; }\n";
    s += "static " + c + " coax_mkview_" + tg + "(" + e + " *data, int64_t n, int64_t lo, int64_t hi, int32_t l) {\n"
         "  coax_slice_check(lo, hi, n, l);\n  " + c + " r = {data + lo, hi - lo};\n  return r;\n}\n";
    s += "static " + c + " coax_reslice_" + tg + "(" + c + " v, int64_t lo, int64_t hi, int32_t l) {\n"
         "  coax_slice_check(lo, hi, v.count, l);\n  " + c + " r = {v.data + lo, hi - lo};\n  return r;\n}\n";
  }
  return s;
}

std::string init_functions(const File *file, Emitter &em) {
  std::vector<Type> types;
  collect_types(file, &types);
  std::string protos, bodies;
  for (Type t : types) {
    if (!needs_init(t)) continue;
    std::string c = c_type(t), tg = tag(t);
    protos += "static " + c + " coax_init_" + tg + "(void);\n";
    bodies += "static " + c + " coax_init_" + tg + "(void) {\n  " + c + " v;\n  memset(&v, 0, sizeof v);\n";
    if (t->kind == TypeKind::struct_) {
      for (const Field &f : t->struct_decl->fields) {
        if (f.init) bodies += "  v." + to_std(f.name) + " = " + em.ex(f.init) + ";\n";
        else if (needs_init(f.type)) bodies += "  v." + to_std(f.name) + " = coax_init_" + tag(f.type) + "();\n";
      }
    } else {
      bodies += "  for (int64_t i = 0; i < " + std::to_string(t->length) + "; i++) v.e[i] = coax_init_" + tag(t->elem) + "();\n";
    }
    bodies += "  return v;\n}\n";
  }
  return protos + bodies;
}

// The types a --library header declares: those the exported and foreign
// procedures use, and everything they contain.
TypeWriter header_types(const File *file) {
  TypeWriter types;
  types.header = true;
  for (const ProcDecl *p : file->procs) {
    // A #foreign prototype names its view parameters' types too.
    if (!p->export_c && !p->foreign) continue;
    types.need(p->ret);
    for (const Param &prm : p->params) types.need(prm.type);
  }
  return types;
}

// A header type a host constructs: a struct or array with a declared default.
bool host_default(Type t) {
  return (t->kind == TypeKind::struct_ || t->kind == TypeKind::array) && needs_init(t);
}

// State construction for hosts (spec 17.2): each header type with a declared
// default gets coax_default_T(T *p), which writes those defaults in place over
// any bytes, so a host's zeroed or reused state starts as `s: [1] T` does
// natively. In place, because a state can be larger than a host's stack.
// Weak, because two units that share a type both define it, identically.
std::string state_defaults(const File *file, Emitter &em) {
  std::string protos, bodies;
  for (Type t : header_types(file).done) {
    if (!host_default(t)) continue;
    std::string c = c_type(t), tg = tag(t);
    protos += "void coax_default_" + tg + "(" + c + " *p);\n";
    bodies += "__attribute__((weak)) void coax_default_" + tg + "(" + c + " *p) {\n  memset(p, 0, sizeof *p);\n";
    if (t->kind == TypeKind::struct_) {
      for (const Field &f : t->struct_decl->fields) {
        if (f.init) bodies += "  p->" + to_std(f.name) + " = " + em.ex(f.init) + ";\n";
        else if (needs_init(f.type)) bodies += "  coax_default_" + tag(f.type) + "(&p->" + to_std(f.name) + ");\n";
      }
    } else {
      bodies += "  for (int64_t i = 0; i < " + std::to_string(t->length) + "; i++) coax_default_" + tag(t->elem) + "(&p->e[i]);\n";
    }
    bodies += "}\n";
  }
  if (bodies.empty()) return "";
  return "\n/* Struct defaults for hosts: coax_default_T writes T's declared defaults in place. */\n" + protos + bodies;
}

std::string escape_path(const std::string &path) {
  std::string s;
  for (unsigned char c : path) {
    if (c < 0x20 || c >= 0x7f) {
      char octal[5];snprintf(octal,sizeof octal,"\\%03o",c);s+=octal;
    } else {
      if (c == '"' || c == '\\') s += '\\';
      s += (char)c;
    }
  }
  return s;
}

}  // namespace

// Source-unit provenance is emitted only for composed programs, preserving
// standalone seed bytes. Runtime helpers receive joined line numbers.
static bool sum_runtime_profile(const File *file) {
  if(file->unions.count)return true;
  for(Type t:all_composite_types())if(is_sum(t))return true;
  std::function<bool(const Stmt *)> switched=[&](const Stmt *stmt){
    if(!stmt)return false;
    if(stmt->kind==StmtKind::switch_)return true;
    for(const Stmt *child:stmt->body)if(switched(child))return true;
    return switched(stmt->then_) || switched(stmt->else_);
  };
  for(const ProcDecl *proc:file->procs)if(switched(proc->body))return true;
  for(const CheckDecl *check:file->checks)if(switched(check->proc->body))return true;
  return false;
}

static std::string source_runtime(const File *file, bool verification = false) {
  auto declared_runtime=[&](std::string runtime){
    if(sum_runtime_profile(file)){
      const std::string declaration="static void coax_trap(";
      runtime.replace(runtime.find(declaration),declaration.size(),"static _Noreturn void coax_trap(");
    }
    return runtime;
  };
  if (file->src->units.size()<2 && !verification) return declared_runtime(RUNTIME);
  std::string out="struct coax_source_range { int first, last, base, fixed; const char *path; };\n";
  if (verification) {
    const std::string &path = file->src->units.empty() ? file->src->path : file->src->units.front()->canonical;
    out += "static const char *coax_verification_source_path = \"" + escape_path(path) + "\";\n";
  }
  out+="static const struct coax_source_range coax_source_ranges[] = {\n";
  auto range=[&](int first,int last,int base,bool fixed,const std::string &path) {
    out+="  {"+std::to_string(first)+","+std::to_string(last)+","+std::to_string(base)+","+(fixed?"1":"0")+",\""+escape_path(path)+"\"},\n";
  };
  for (const auto &r:file->src->generated) {
    int first=1+(int)std::count(file->src->text.begin(),file->src->text.begin()+r.start,'\n');
    int last=1+(int)std::count(file->src->text.begin(),file->src->text.begin()+r.end,'\n');
    auto point=source_point(file->src,r.directive);
    const SourceUnit *unit = verification ? source_unit_at(file->src, r.directive) : nullptr;
    range(first,last,point.loc.line,true,unit ? unit->canonical : point.path);
  }
  for (const auto &unit:file->src->units) {
    int count=(int)std::count(file->src->text.begin()+unit->begin,file->src->text.begin()+unit->end,'\n');
    range(unit->first_line,unit->first_line+std::max(1,count)-1,1,false,verification ? unit->canonical : unit->path);
  }
  out+="};\nstatic const struct coax_source_range *coax_find_source(int line) {\n";
  out+="  for (unsigned i=0;i<sizeof(coax_source_ranges)/sizeof(coax_source_ranges[0]);i++) if (line>=coax_source_ranges[i].first && line<=coax_source_ranges[i].last) return &coax_source_ranges[i];\n  return 0;\n}\n";
  out+="static const char *coax_path_for(int line) { const struct coax_source_range *r=coax_find_source(line); return r?r->path:"+
       std::string(verification ? "coax_verification_source_path" : "coax_source_path")+"; }\n";
  out+="static int coax_line_for(int line) { const struct coax_source_range *r=coax_find_source(line); return r?(r->fixed?r->base:r->base+line-r->first):line; }\n";
  std::string runtime=RUNTIME;std::string needle="coax_source_path, line, what";
  runtime.replace(runtime.find(needle),needle.size(),"coax_path_for(line), coax_line_for(line), what");
  if (verification) {
    const std::string trap = "static void coax_trap(const char *what, int32_t line) {";
    const std::string handler =
        "typedef void (*Coax_VerificationTrapHandler_v1)(const char *, int64_t, const char *, int64_t, int64_t);\n"
        "static Coax_VerificationTrapHandler_v1 coax_verification_trap_handler_v1;\n"
        "void coax_verification_set_trap_v1(Coax_VerificationTrapHandler_v1 handler) { coax_verification_trap_handler_v1 = handler; }\n\n";
    size_t at = runtime.find(trap);
    runtime.insert(at, handler);
    const std::string flush = "  fflush(stdout);\n";
    at = runtime.find(flush, at + handler.size()) + flush.size();
    runtime.insert(at,
        "  if (coax_verification_trap_handler_v1) {\n"
        "    const char *path = coax_path_for(line);\n"
        "    coax_verification_trap_handler_v1(what, (int64_t)strlen(what), path, (int64_t)strlen(path), coax_line_for(line));\n"
        "  }\n");
  }
  return out+declared_runtime(std::move(runtime));
}

// Procedures a CUDA module contains: the kernels (#export_c) and what they
// call, in declaration order. Checks and their helpers stay on the CPU.
std::vector<const ProcDecl *> cuda_procs(const File *file) {
  std::vector<const ProcDecl *> seen;
  std::function<void(const ProcDecl *)> visit_proc;
  std::function<void(const Expr *)> visit_expr = [&](const Expr *e) {
    if (!e) return;
    if (e->kind == ExprKind::call && e->proc && !is_device_primitive(e->proc)) visit_proc(e->proc);
    visit_expr(e->lhs); visit_expr(e->rhs); visit_expr(e->third);
    for (const Expr *a : e->args) visit_expr(a);
    for (const FieldInit &f : e->fields) visit_expr(f.value);
  };
  std::function<void(const Stmt *)> visit_stmt = [&](const Stmt *st) {
    if (!st) return;
    visit_expr(st->expr); visit_expr(st->expr2); visit_expr(st->target);
    for (const Stmt *c : st->body) visit_stmt(c);
    visit_stmt(st->then_); visit_stmt(st->else_);
    for(const SwitchCase *arm:st->cases)visit_stmt(arm->body);
  };
  visit_proc = [&](const ProcDecl *p) {
    for (const ProcDecl *q : seen) if (q == p) return;
    seen.push_back(p);
    visit_stmt(p->body);
  };
  for (const ProcDecl *p : file->procs) if (p->export_c && !p->foreign) visit_proc(p);
  std::vector<const ProcDecl *> ordered;
  for (const ProcDecl *p : file->procs)
    for (const ProcDecl *q : seen) if (q == p) { ordered.push_back(p); break; }
  return ordered;
}

// Apple matrix primitives (lib/compute/apple.coax) for `coax metal-compute`.
// The simdgroup tile product: 4 simdgroups of a 128-thread group; simdgroup
// g owns rows 32*(g%2) .. +31 and columns 16*(g/2) .. +15 of the 64x32
// accumulator, as eight 8x8 matrices (rows 8i, columns 8j at 2i+j). a holds
// 64 rows of 32 k, b 32 columns of 32 k; the hardware adds in its own order.
static const char *METAL_SIMDGROUP_RUNTIME = R"COAXRT(
COAX_DEV void coax_am_sg_mma(thread simdgroup_float8x8 *acc, threadgroup const float *a, threadgroup const float *b, uint tid) {
  uint g = tid / 32u; int sr = (int)(g & 1u) * 32, sc = (int)(g >> 1) * 16;
  for (int kk = 0; kk < 32; kk += 8) {
    simdgroup_float8x8 A[4], B[2];
    for (int i = 0; i < 4; i++) simdgroup_load(A[i], a + (sr + 8 * i) * 32 + kk, 32);
    for (int j = 0; j < 2; j++) simdgroup_load(B[j], b + (sc + 8 * j) * 32 + kk, 32, ulong2(0, 0), true);
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 2; j++) simdgroup_multiply_accumulate(acc[2 * i + j], A[i], B[j], acc[2 * i + j]);
  }
}
COAX_DEV void coax_am_sg_spill(thread simdgroup_float8x8 *acc, threadgroup float *dst, uint tid) {
  uint g = tid / 32u; int sr = (int)(g & 1u) * 32, sc = (int)(g >> 1) * 16;
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 2; j++) simdgroup_store(acc[2 * i + j], dst + (sr + 8 * i) * 32 + sc + 8 * j, 32);
}
)COAXRT";
// The Metal 4 tensor-op tile (MetalPerformancePrimitives matmul2d, BF16
// weights times f32 activations into f32, relaxed precision off): out[t][r]
// for TM tokens from t0 and TN rows from r0, clipped to tokens and rows. The
// whole group calls it with the same values; a failed check voids the launch.
static const char *METAL_TENSOR_RUNTIME = R"COAXRT(
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
template <int TM, int TN, int SG>
COAX_DEV void coax_am_matmul(int64_t rows, int64_t cols, int64_t tokens, int64_t r0, int64_t t0, coax_v_u32 w, coax_v_f32 x, coax_v_f32 out, int32_t line, COAX_ERR) {
  using namespace mpp::tensor_ops;
  if (rows < 1 || cols < 2 || cols % 2 != 0 || tokens < 1 || r0 < 0 || r0 >= rows || t0 < 0 || t0 >= tokens || rows > 2147483647 / cols ||
      tokens > 2147483647 / cols || tokens > 2147483647 / rows || w.count < rows * (cols / 2) || x.count < tokens * cols || out.count < tokens * rows) {
    coax_trap_(line, coax_err);
    return;
  }
  int c = (int)cols, nt = (int)min((int64_t)TM, tokens - t0), nr = (int)min((int64_t)TN, rows - r0);
  auto X = tensor<device float, dextents<int32_t, 2>, tensor_inline>(x.data + t0 * cols, dextents<int32_t, 2>(c, nt), array<int32_t, 2>({1, c}));
  auto W = tensor<device bfloat, dextents<int32_t, 2>, tensor_inline>((device bfloat *)w.data + r0 * cols, dextents<int32_t, 2>(c, nr), array<int32_t, 2>({1, c}));
  auto C = tensor<device float, dextents<int32_t, 2>, tensor_inline>(out.data + t0 * rows + r0, dextents<int32_t, 2>(nr, nt), array<int32_t, 2>({1, (int)rows}));
  constexpr auto d = matmul2d_descriptor(TM, TN, static_cast<int>(dynamic_extent), false, true, false);
  matmul2d<d, execution_simdgroups<SG>> op;
  op.run(X, W, C);
}
)COAXRT";

static std::string emit_cuda(const File *file, const EmitOptions &opts) {
  Emitter em{file, opts};
  std::vector<const ProcDecl *> procs = cuda_procs(file);
  std::string functions;
  for (const ProcDecl *p : procs) functions += em.function(p);
  // The array and view types those procedures use, in dependency order.
  std::vector<Type> used;
  auto add = [&](Type t) {
    if (t->kind != TypeKind::array && t->kind != TypeKind::view) return;
    for (Type u : used) if (u == t) return;
    used.push_back(t);
  };
  std::function<void(const Expr *)> types_expr = [&](const Expr *e) {
    if (!e) return;
    add(e->type);
    types_expr(e->lhs); types_expr(e->rhs); types_expr(e->third);
    for (const Expr *a : e->args) types_expr(a);
  };
  std::function<void(const Stmt *)> types_stmt = [&](const Stmt *st) {
    if (!st) return;
    add(st->type);
    types_expr(st->expr); types_expr(st->expr2); types_expr(st->target);
    if (st->expr) add(st->expr->type);
    for (const Stmt *c : st->body) types_stmt(c);
    types_stmt(st->then_); types_stmt(st->else_);
    for(const SwitchCase *arm:st->cases)types_stmt(arm->body);
  };
  for (const ProcDecl *p : procs) {
    add(p->ret);
    for (const Param &prm : p->params) add(prm.type);
    types_stmt(p->body);
  }
  TypeWriter types;
  for (Type t : all_composite_types())
    for (Type u : used) if (u == t) { types.need(t); break; }
  std::string helpers;
  for (Type t : types.done) {
    if (t->kind != TypeKind::view) continue;
    std::string c = c_type(t), e = c_type(t->elem), tg = tag(t);
    helpers += "COAX_DEV " + e + " *coax_elem_" + tg + "(" + c + " v, int64_t i, int32_t l) { return &v.data[coax_index(i, v.count, l)]; }\n";
    helpers += "COAX_DEV " + c + " coax_mkview_" + tg + "(" + e + " *data, int64_t n, int64_t lo, int64_t hi, int32_t l) {\n"
               "  coax_slice_check(lo, hi, n, l);\n  " + c + " r = {data + lo, hi - lo};\n  return r;\n}\n";
    helpers += "COAX_DEV " + c + " coax_reslice_" + tg + "(" + c + " v, int64_t lo, int64_t hi, int32_t l) {\n"
               "  coax_slice_check(lo, hi, v.count, l);\n  " + c + " r = {v.data + lo, hi - lo};\n  return r;\n}\n";
  }
  std::string s = "/* Generated by coax0 from " + file->src->path + " (coax cuda). Do not edit: change the .coax file. */\n";
  s += CUDA_RUNTIME;
  s += "\n/* Types */\n" + types.out + helpers + "\n";
  for (const ProcDecl *p : procs) s += em.prototype(p) + ";\n";
  s += functions;
  // One entry per kernel: work item i of n runs the procedure once.
  s += "\n/* Kernels: launch with n items; item i calls the procedure with i. */\n";
  for (const ProcDecl *p : procs) {
    if (!p->export_c) continue;
    std::string w = "extern \"C\" __global__ void " + to_std(p->name) + "(int64_t coax_items";
    std::string call = em.proc_name(p) + "(coax_item";
    for (int32_t i = 1; i < p->params.count; i++) {
      w += ", " + c_type(p->params[i].type) + " " + em.local_name(p->params[i].name);
      call += ", " + em.local_name(p->params[i].name);
    }
    if (g_warp.group_kernels.count(p)) {  // one block of T threads per work item; launch with block = T
      std::string T = std::to_string(g_warp.group_kernels.at(p));
      s += w + ") {\n  if (blockDim.x != " + T + "u) __trap();\n  int64_t coax_item = (int64_t)blockIdx.x;\n"
           "  if (coax_item >= coax_items) return;\n  " + call + ");\n}\n";
    } else if (g_warp.warp_kernels.count(p))  // one warp per work item; launch 32 threads per item
      s += w + ") {\n  int64_t coax_item = ((int64_t)blockIdx.x * (int64_t)blockDim.x + (int64_t)threadIdx.x) >> 5;\n"
           "  if (coax_item >= coax_items) return;\n  " + call + ");\n}\n";
    else
      s += w + ") {\n  int64_t coax_item = (int64_t)blockIdx.x * (int64_t)blockDim.x + (int64_t)threadIdx.x;\n"
           "  if (coax_item >= coax_items) return;\n  " + call + ");\n}\n";
  }
  for (size_t at = 0; (at = s.find("_Bool", at)) != std::string::npos;) s.replace(at, 5, "bool");
  return s;
}

// The device runtime of `coax metal-compute`: the checks of RUNTIME spelled
// for Metal Shading Language, the float-float f64 profile (APPLE-FF-v1) and
// the simdgroup MMA. Metal has no trap, so a failed check counts itself in
// the launch's error words (coax_err[0] failures, coax_err[1] the largest
// failing line), takes a harmless value and lets the launch finish; the host
// reads the words at completion and discards the launch's results. Each
// trapping helper takes the error words as a hidden last argument through a
// macro of the same name as its C counterpart.
static const char *METAL_RUNTIME = R"COAXRT(/* Compile with fast math off (MTLMathModeSafe, precise functions): +, -, *, /
   round once each and are never contracted or reassociated, so the
   float-float sums below stay compensated. */
#include <metal_stdlib>
using namespace metal;
#pragma METAL fp math_mode(safe)
#pragma METAL fp contract(off)
#pragma clang diagnostic ignored "-Wunused-function"
/* metal_stdlib defines int8_t .. uint64_t (64-bit long and ulong). */
#define INT64_C(x) x##L
#define UINT64_C(x) x##UL
#define INT64_MIN (-9223372036854775807L - 1)
#define INT64_MAX 9223372036854775807L
#define UINT64_MAX 18446744073709551615UL
#define COAX_DEV static inline
/* The thread's own error words live in registers; the kernel entry adds them
   to the launch's words once, at the end (a device atomic inside a check
   would serialize every simdgroup shuffle after it). */
#define COAX_ERR thread uint *coax_err
COAX_DEV void coax_trap_(int32_t line, COAX_ERR) {
  coax_err[0] += 1u;
  coax_err[1] = max(coax_err[1], (uint)line);
}
/* Narrow integers are computed in 64 bits and range checked. */
#define COAX_NARROW_OPS(T, N, LO, HI)                                                                     \
  COAX_DEV T coax_add_##N##_(T a, T b, int32_t l, COAX_ERR) { int64_t r = (int64_t)a + (int64_t)b; if (r < LO || r > HI) coax_trap_(l, coax_err); return (T)r; } \
  COAX_DEV T coax_sub_##N##_(T a, T b, int32_t l, COAX_ERR) { int64_t r = (int64_t)a - (int64_t)b; if (r < LO || r > HI) coax_trap_(l, coax_err); return (T)r; } \
  COAX_DEV T coax_mul_##N##_(T a, T b, int32_t l, COAX_ERR) { int64_t r = (int64_t)a * (int64_t)b; if (r < LO || r > HI) coax_trap_(l, coax_err); return (T)r; } \
  COAX_DEV T coax_neg_##N##_(T a, int32_t l, COAX_ERR) { int64_t r = -(int64_t)a; if (r < LO || r > HI) coax_trap_(l, coax_err); return (T)r; } \
  COAX_DEV T coax_wadd_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a + (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wsub_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a - (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wmul_##N(T a, T b) { return (T)(uint64_t)((uint64_t)(int64_t)a * (uint64_t)(int64_t)b); }                        \
  COAX_DEV T coax_wneg_##N(T a) { return (T)(uint64_t)(0UL - (uint64_t)(int64_t)a); }
#define COAX_SHIFT_DIV_OPS(T, N, SIGNED, MIN)                                                             \
  COAX_DEV T coax_div_##N##_(T a, T b, int32_t l, COAX_ERR) {                                             \
    if (b == 0) { coax_trap_(l, coax_err); return 0; }                                                  \
    if (SIGNED && a == MIN && b == (T)-1) { coax_trap_(l, coax_err); return a; }                        \
    return (T)(a / b);                                                                                  \
  }                                                                                                     \
  COAX_DEV T coax_mod_##N##_(T a, T b, int32_t l, COAX_ERR) {                                             \
    if (b == 0) { coax_trap_(l, coax_err); return 0; }                                                  \
    if (SIGNED && b == (T)-1) return 0;                                                                 \
    return (T)(a % b);                                                                                  \
  }                                                                                                     \
  COAX_DEV T coax_shl_##N##_(T a, int64_t b, int32_t l, COAX_ERR) {                                       \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) { coax_trap_(l, coax_err); return 0; }                  \
    return (T)((uint64_t)a << b);                                                                       \
  }                                                                                                     \
  COAX_DEV T coax_shr_##N##_(T a, int64_t b, int32_t l, COAX_ERR) {                                       \
    if (b < 0 || b >= (int64_t)(8 * sizeof(T))) { coax_trap_(l, coax_err); return 0; }                  \
    return (T)(a >> b);                                                                                 \
  }
COAX_NARROW_OPS(int8_t, s8, -128L, 127L)
COAX_NARROW_OPS(int16_t, s16, -32768L, 32767L)
COAX_NARROW_OPS(int32_t, s32, -2147483648L, 2147483647L)
COAX_NARROW_OPS(uint8_t, u8, 0L, 255L)
COAX_NARROW_OPS(uint16_t, u16, 0L, 65535L)
COAX_NARROW_OPS(uint32_t, u32, 0L, 4294967295L)
COAX_DEV int64_t coax_add_s64_(int64_t a, int64_t b, int32_t l, COAX_ERR) { int64_t r = (int64_t)((uint64_t)a + (uint64_t)b); if (((a ^ r) & (b ^ r)) < 0) coax_trap_(l, coax_err); return r; }
COAX_DEV int64_t coax_sub_s64_(int64_t a, int64_t b, int32_t l, COAX_ERR) { int64_t r = (int64_t)((uint64_t)a - (uint64_t)b); if (((a ^ b) & (a ^ r)) < 0) coax_trap_(l, coax_err); return r; }
COAX_DEV int64_t coax_mul_s64_(int64_t a, int64_t b, int32_t l, COAX_ERR) {
  int64_t r = (int64_t)((uint64_t)a * (uint64_t)b);
  if ((a == -1 && b == INT64_MIN) || (b == -1 && a == INT64_MIN) || (a != 0 && (r / a != b))) coax_trap_(l, coax_err);
  return r;
}
COAX_DEV int64_t coax_neg_s64_(int64_t a, int32_t l, COAX_ERR) { if (a == INT64_MIN) coax_trap_(l, coax_err); return (int64_t)(0UL - (uint64_t)a); }
COAX_DEV int64_t coax_wadd_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a + (uint64_t)b); }
COAX_DEV int64_t coax_wsub_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a - (uint64_t)b); }
COAX_DEV int64_t coax_wmul_s64(int64_t a, int64_t b) { return (int64_t)((uint64_t)a * (uint64_t)b); }
COAX_DEV int64_t coax_wneg_s64(int64_t a) { return (int64_t)(0UL - (uint64_t)a); }
COAX_DEV uint64_t coax_add_u64_(uint64_t a, uint64_t b, int32_t l, COAX_ERR) { uint64_t r = a + b; if (r < a) coax_trap_(l, coax_err); return r; }
COAX_DEV uint64_t coax_sub_u64_(uint64_t a, uint64_t b, int32_t l, COAX_ERR) { if (b > a) coax_trap_(l, coax_err); return a - b; }
COAX_DEV uint64_t coax_mul_u64_(uint64_t a, uint64_t b, int32_t l, COAX_ERR) { uint64_t r = a * b; if (a != 0 && r / a != b) coax_trap_(l, coax_err); return r; }
COAX_DEV uint64_t coax_neg_u64_(uint64_t a, int32_t l, COAX_ERR) { if (a != 0) coax_trap_(l, coax_err); return 0; }
COAX_DEV uint64_t coax_wadd_u64(uint64_t a, uint64_t b) { return a + b; }
COAX_DEV uint64_t coax_wsub_u64(uint64_t a, uint64_t b) { return a - b; }
COAX_DEV uint64_t coax_wmul_u64(uint64_t a, uint64_t b) { return a * b; }
COAX_DEV uint64_t coax_wneg_u64(uint64_t a) { return 0UL - a; }
COAX_SHIFT_DIV_OPS(int8_t, s8, 1, (int8_t)-128)
COAX_SHIFT_DIV_OPS(int16_t, s16, 1, (int16_t)-32768)
COAX_SHIFT_DIV_OPS(int32_t, s32, 1, (int32_t)(-2147483647 - 1))
COAX_SHIFT_DIV_OPS(int64_t, s64, 1, INT64_MIN)
COAX_SHIFT_DIV_OPS(uint8_t, u8, 0, 0)
COAX_SHIFT_DIV_OPS(uint16_t, u16, 0, 0)
COAX_SHIFT_DIV_OPS(uint32_t, u32, 0, 0)
COAX_SHIFT_DIV_OPS(uint64_t, u64, 0, 0)
#define coax_add_s8(a, b, l) coax_add_s8_(a, b, l, coax_err)
#define coax_add_s16(a, b, l) coax_add_s16_(a, b, l, coax_err)
#define coax_add_s32(a, b, l) coax_add_s32_(a, b, l, coax_err)
#define coax_add_s64(a, b, l) coax_add_s64_(a, b, l, coax_err)
#define coax_add_u8(a, b, l) coax_add_u8_(a, b, l, coax_err)
#define coax_add_u16(a, b, l) coax_add_u16_(a, b, l, coax_err)
#define coax_add_u32(a, b, l) coax_add_u32_(a, b, l, coax_err)
#define coax_add_u64(a, b, l) coax_add_u64_(a, b, l, coax_err)
#define coax_sub_s8(a, b, l) coax_sub_s8_(a, b, l, coax_err)
#define coax_sub_s16(a, b, l) coax_sub_s16_(a, b, l, coax_err)
#define coax_sub_s32(a, b, l) coax_sub_s32_(a, b, l, coax_err)
#define coax_sub_s64(a, b, l) coax_sub_s64_(a, b, l, coax_err)
#define coax_sub_u8(a, b, l) coax_sub_u8_(a, b, l, coax_err)
#define coax_sub_u16(a, b, l) coax_sub_u16_(a, b, l, coax_err)
#define coax_sub_u32(a, b, l) coax_sub_u32_(a, b, l, coax_err)
#define coax_sub_u64(a, b, l) coax_sub_u64_(a, b, l, coax_err)
#define coax_mul_s8(a, b, l) coax_mul_s8_(a, b, l, coax_err)
#define coax_mul_s16(a, b, l) coax_mul_s16_(a, b, l, coax_err)
#define coax_mul_s32(a, b, l) coax_mul_s32_(a, b, l, coax_err)
#define coax_mul_s64(a, b, l) coax_mul_s64_(a, b, l, coax_err)
#define coax_mul_u8(a, b, l) coax_mul_u8_(a, b, l, coax_err)
#define coax_mul_u16(a, b, l) coax_mul_u16_(a, b, l, coax_err)
#define coax_mul_u32(a, b, l) coax_mul_u32_(a, b, l, coax_err)
#define coax_mul_u64(a, b, l) coax_mul_u64_(a, b, l, coax_err)
#define coax_neg_s8(a, l) coax_neg_s8_(a, l, coax_err)
#define coax_neg_s16(a, l) coax_neg_s16_(a, l, coax_err)
#define coax_neg_s32(a, l) coax_neg_s32_(a, l, coax_err)
#define coax_neg_s64(a, l) coax_neg_s64_(a, l, coax_err)
#define coax_neg_u8(a, l) coax_neg_u8_(a, l, coax_err)
#define coax_neg_u16(a, l) coax_neg_u16_(a, l, coax_err)
#define coax_neg_u32(a, l) coax_neg_u32_(a, l, coax_err)
#define coax_neg_u64(a, l) coax_neg_u64_(a, l, coax_err)
#define coax_div_s8(a, b, l) coax_div_s8_(a, b, l, coax_err)
#define coax_div_s16(a, b, l) coax_div_s16_(a, b, l, coax_err)
#define coax_div_s32(a, b, l) coax_div_s32_(a, b, l, coax_err)
#define coax_div_s64(a, b, l) coax_div_s64_(a, b, l, coax_err)
#define coax_div_u8(a, b, l) coax_div_u8_(a, b, l, coax_err)
#define coax_div_u16(a, b, l) coax_div_u16_(a, b, l, coax_err)
#define coax_div_u32(a, b, l) coax_div_u32_(a, b, l, coax_err)
#define coax_div_u64(a, b, l) coax_div_u64_(a, b, l, coax_err)
#define coax_mod_s8(a, b, l) coax_mod_s8_(a, b, l, coax_err)
#define coax_mod_s16(a, b, l) coax_mod_s16_(a, b, l, coax_err)
#define coax_mod_s32(a, b, l) coax_mod_s32_(a, b, l, coax_err)
#define coax_mod_s64(a, b, l) coax_mod_s64_(a, b, l, coax_err)
#define coax_mod_u8(a, b, l) coax_mod_u8_(a, b, l, coax_err)
#define coax_mod_u16(a, b, l) coax_mod_u16_(a, b, l, coax_err)
#define coax_mod_u32(a, b, l) coax_mod_u32_(a, b, l, coax_err)
#define coax_mod_u64(a, b, l) coax_mod_u64_(a, b, l, coax_err)
#define coax_shl_s8(a, b, l) coax_shl_s8_(a, b, l, coax_err)
#define coax_shl_s16(a, b, l) coax_shl_s16_(a, b, l, coax_err)
#define coax_shl_s32(a, b, l) coax_shl_s32_(a, b, l, coax_err)
#define coax_shl_s64(a, b, l) coax_shl_s64_(a, b, l, coax_err)
#define coax_shl_u8(a, b, l) coax_shl_u8_(a, b, l, coax_err)
#define coax_shl_u16(a, b, l) coax_shl_u16_(a, b, l, coax_err)
#define coax_shl_u32(a, b, l) coax_shl_u32_(a, b, l, coax_err)
#define coax_shl_u64(a, b, l) coax_shl_u64_(a, b, l, coax_err)
#define coax_shr_s8(a, b, l) coax_shr_s8_(a, b, l, coax_err)
#define coax_shr_s16(a, b, l) coax_shr_s16_(a, b, l, coax_err)
#define coax_shr_s32(a, b, l) coax_shr_s32_(a, b, l, coax_err)
#define coax_shr_s64(a, b, l) coax_shr_s64_(a, b, l, coax_err)
#define coax_shr_u8(a, b, l) coax_shr_u8_(a, b, l, coax_err)
#define coax_shr_u16(a, b, l) coax_shr_u16_(a, b, l, coax_err)
#define coax_shr_u32(a, b, l) coax_shr_u32_(a, b, l, coax_err)
#define coax_shr_u64(a, b, l) coax_shr_u64_(a, b, l, coax_err)
/* A failed index or slice check reads element 0 of the same view instead. */
COAX_DEV int64_t coax_index_(int64_t i, int64_t n, int32_t l, COAX_ERR) { if ((uint64_t)i >= (uint64_t)n) { coax_trap_(l, coax_err); return 0; } return i; }
#define coax_index(i, n, l) coax_index_(i, n, l, coax_err)
/* The 32-bit body's check: n is below 2^31 (a fixed length, or a view count the entry checked). */
COAX_DEV int32_t coax_index32_(int32_t i, int32_t n, int32_t l, COAX_ERR) { if ((uint32_t)i >= (uint32_t)n) { coax_trap_(l, coax_err); return 0; } return i; }
#define coax_index32(i, n, l) coax_index32_(i, n, l, coax_err)
/* As coax_div_s64 and coax_mod_s64 where the quotient fits: zero traps and yields 0, and x % -1 is 0. */
COAX_DEV int32_t coax_div32_(int32_t a, int32_t b, int32_t l, COAX_ERR) { if (b == 0) { coax_trap_(l, coax_err); return 0; } return a / b; }
COAX_DEV int32_t coax_mod32_(int32_t a, int32_t b, int32_t l, COAX_ERR) { if (b == 0) { coax_trap_(l, coax_err); return 0; } if (b == -1) return 0; return a % b; }
#define coax_div32(a, b, l) coax_div32_(a, b, l, coax_err)
#define coax_mod32(a, b, l) coax_mod32_(a, b, l, coax_err)
COAX_DEV bool coax_slice_ok_(int64_t lo, int64_t hi, int64_t n, int32_t l, COAX_ERR) { if ((uint64_t)hi > (uint64_t)n || (uint64_t)lo > (uint64_t)hi) { coax_trap_(l, coax_err); return false; } return true; }
COAX_DEV int64_t coax_cast_ss_(int64_t v, int64_t lo, int64_t hi, int32_t l, COAX_ERR) { if (v < lo || v > hi) coax_trap_(l, coax_err); return v; }
COAX_DEV uint64_t coax_cast_su_(int64_t v, uint64_t hi, int32_t l, COAX_ERR) { if (v < 0 || (uint64_t)v > hi) coax_trap_(l, coax_err); return (uint64_t)v; }
COAX_DEV int64_t coax_cast_us_(uint64_t v, int64_t hi, int32_t l, COAX_ERR) { if (v > (uint64_t)hi) coax_trap_(l, coax_err); return (int64_t)v; }
COAX_DEV uint64_t coax_cast_uu_(uint64_t v, uint64_t hi, int32_t l, COAX_ERR) { if (v > hi) coax_trap_(l, coax_err); return v; }
#define coax_cast_ss(v, lo, hi, l) coax_cast_ss_(v, lo, hi, l, coax_err)
#define coax_cast_su(v, hi, l) coax_cast_su_(v, hi, l, coax_err)
#define coax_cast_us(v, hi, l) coax_cast_us_(v, hi, l, coax_err)
#define coax_cast_uu(v, hi, l) coax_cast_uu_(v, hi, l, coax_err)
COAX_DEV int64_t coax_ftoi_s_(float v, int64_t lo, int64_t hi, int32_t l, COAX_ERR) {
  if (!(v >= -9223372036854775808.0f && v < 9223372036854775808.0f)) { coax_trap_(l, coax_err); return 0; }
  int64_t i = (int64_t)v; if (i < lo || i > hi) coax_trap_(l, coax_err); return i;
}
COAX_DEV uint64_t coax_ftoi_u_(float v, uint64_t hi, int32_t l, COAX_ERR) {
  if (!(v > -1.0f && v < 18446744073709551616.0f)) { coax_trap_(l, coax_err); return 0; }
  uint64_t u = (uint64_t)v; if (u > hi) coax_trap_(l, coax_err); return u;
}
#define coax_ftoi_s(v, lo, hi, l) coax_ftoi_s_(v, lo, hi, l, coax_err)
#define coax_ftoi_u(v, hi, l) coax_ftoi_u_(v, hi, l, coax_err)
COAX_DEV float coax_f32_from_bits(uint32_t x) { return as_type<float>(x); }
COAX_DEV uint32_t coax_f32_bits(float f) { return as_type<uint>(f); }
COAX_DEV uint32_t coax_add_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a+b);}
COAX_DEV uint32_t coax_sub_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a-b);}
COAX_DEV uint32_t coax_mul_wrap_u32(uint32_t a,uint32_t b){return (uint32_t)(a*b);}
COAX_DEV uint32_t coax_rotl_u32(uint32_t a,uint32_t b){uint k=(uint)(b&31u);return (uint32_t)((a<<k)|(a>>((32u-k)&31u)));}
COAX_DEV uint32_t coax_rotr_u32(uint32_t a,uint32_t b){uint k=(uint)(b&31u);return (uint32_t)((a>>k)|(a<<((32u-k)&31u)));}
COAX_DEV uint64_t coax_add_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a+b);}
COAX_DEV uint64_t coax_sub_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a-b);}
COAX_DEV uint64_t coax_mul_wrap_u64(uint64_t a,uint64_t b){return (uint64_t)(a*b);}
COAX_DEV uint64_t coax_rotl_u64(uint64_t a,uint64_t b){uint k=(uint)(b&63u);return (uint64_t)((a<<k)|(a>>((64u-k)&63u)));}
COAX_DEV uint64_t coax_rotr_u64(uint64_t a,uint64_t b){uint k=(uint)(b&63u);return (uint64_t)((a>>k)|(a<<((64u-k)&63u)));}

/* APPLE-FF-v1: f64 is a float-float pair, value hi + lo with |lo| <= ulp(hi)/2
   (about 48 significant bits; the f32 exponent range, subnormals flushed).
   Sums use error-free two-sum, products the exact fma residual. */
struct coax_ff { float hi; float lo; };
COAX_DEV coax_ff coax_ff_make(float h, float l) { coax_ff r; r.hi = h; r.lo = l; return r; }
COAX_DEV coax_ff coax_ff_two_sum(float a, float b) { float s = a + b; float bb = s - a; return coax_ff_make(s, (a - (s - bb)) + (b - bb)); }
COAX_DEV coax_ff coax_ff_fast(float a, float b) { float s = a + b; return coax_ff_make(s, b - (s - a)); }
COAX_DEV coax_ff operator+(coax_ff a, coax_ff b) {
  coax_ff s = coax_ff_two_sum(a.hi, b.hi);
  if (!isfinite(s.hi)) return coax_ff_make(s.hi, 0.0f);
  coax_ff t = coax_ff_two_sum(a.lo, b.lo);
  s = coax_ff_fast(s.hi, s.lo + t.hi);
  return coax_ff_fast(s.hi, s.lo + t.lo);
}
COAX_DEV coax_ff operator-(coax_ff a) { return coax_ff_make(-a.hi, -a.lo); }
COAX_DEV coax_ff operator-(coax_ff a, coax_ff b) { return a + (-b); }
COAX_DEV coax_ff operator*(coax_ff a, coax_ff b) {
  float p = a.hi * b.hi;
  if (!isfinite(p) || p == 0.0f) return coax_ff_make(p, 0.0f);
  float e = fma(a.hi, b.hi, -p);
  e = e + (a.hi * b.lo + a.lo * b.hi);
  return coax_ff_fast(p, e);
}
COAX_DEV coax_ff operator/(coax_ff a, coax_ff b) {
  float q1 = a.hi / b.hi;
  if (!isfinite(q1) || q1 == 0.0f) return coax_ff_make(q1, 0.0f);
  coax_ff r = a - b * coax_ff_make(q1, 0.0f);
  float q2 = r.hi / b.hi;
  r = r - b * coax_ff_make(q2, 0.0f);
  float q3 = r.hi / b.hi;
  return coax_ff_fast(q1, q2) + coax_ff_make(q3, 0.0f);
}
COAX_DEV bool operator==(coax_ff a, coax_ff b) { return a.hi == b.hi && a.lo == b.lo; }
COAX_DEV bool operator!=(coax_ff a, coax_ff b) { return !(a == b); }
COAX_DEV bool operator<(coax_ff a, coax_ff b) { return a.hi < b.hi || (a.hi == b.hi && a.lo < b.lo); }
COAX_DEV bool operator>(coax_ff a, coax_ff b) { return b < a; }
COAX_DEV bool operator<=(coax_ff a, coax_ff b) { return a < b || a == b; }
COAX_DEV bool operator>=(coax_ff a, coax_ff b) { return b < a || a == b; }
COAX_DEV coax_ff coax_ff_from_f32(float x) { return coax_ff_make(x, 0.0f); }
COAX_DEV coax_ff coax_ff_from_s64(int64_t v) { float h = (float)v; return coax_ff_fast(h, (float)(v - (int64_t)h)); }
COAX_DEV coax_ff coax_ff_from_u64(uint64_t v) { float h = (float)v; return coax_ff_fast(h, (float)(int64_t)(v - (uint64_t)h)); }
/* Rounds the pair once; a finite pair that rounds past FLT_MAX fails, as the C build's f32(x) does. */
COAX_DEV float coax_ff_to_f32_(coax_ff a, int32_t l, COAX_ERR) { float r = a.hi + a.lo; if (isinf(r) && isfinite(a.hi)) coax_trap_(l, coax_err); return r; }
#define coax_ff_to_f32(a, l) coax_ff_to_f32_(a, l, coax_err)
COAX_DEV coax_ff coax_ff_abs(coax_ff a) { return a.hi < 0.0f ? -a : a; }
COAX_DEV coax_ff coax_ff_floor(coax_ff a) { float f = floor(a.hi); if (f == a.hi) return coax_ff_fast(f, floor(a.lo)); return coax_ff_make(f, 0.0f); }
/* Scales a pair by 2^k exactly (no overflow or flush for |k| in the ranges used). */
COAX_DEV coax_ff coax_ff_scale(coax_ff a, int k) { return coax_ff_make(ldexp(a.hi, k), ldexp(a.lo, k)); }
/* sqrt: scale by an even power of two into [1, 4) so the residual stays
   normal, one Newton correction, then scale back. */
COAX_DEV coax_ff coax_ff_sqrt(coax_ff a) {
  if (!(a.hi > 0.0f) || isinf(a.hi)) return coax_ff_make(precise::sqrt(a.hi), 0.0f);
  int k = ilogb(a.hi) & ~1;
  coax_ff m = coax_ff_scale(a, -k);
  float s = precise::sqrt(m.hi), p = s * s;
  coax_ff r = m - coax_ff_make(p, fma(s, s, -p));
  return coax_ff_scale(coax_ff_fast(s, r.hi / (2.0f * s)), k / 2);
}
/* exp: x = n ln2 + r, r/256 through a degree-8 expm1 series, then eight
   doublings of expm1 (e^2y - 1 = 2(e^y - 1) + (e^y - 1)^2), then 2^n. */
COAX_DEV coax_ff coax_ff_exp(coax_ff a) {
  if (isnan(a.hi)) return a;
  if (a.hi > 88.7228394f) return coax_ff_make(as_type<float>(0x7f800000u), 0.0f); /* above log FLT_MAX */
  if (a.hi < -103.98f) return coax_ff_make(0.0f, 0.0f);
  const coax_ff ln2 = coax_ff_make(0.693147182f, -1.90465421e-09f);
  const coax_ff inv[7] = {coax_ff_make(0.5f, 0.0f), coax_ff_make(0.166666672f, -4.96705388e-09f), coax_ff_make(0.0416666679f, -1.24176347e-09f),
    coax_ff_make(0.00833333377f, -4.34617203e-10f), coax_ff_make(0.00138888892f, -3.36310944e-11f), coax_ff_make(0.000198412701f, -2.72559687e-12f),
    coax_ff_make(2.48015876e-05f, -3.40699609e-13f)};
  float n = rint(a.hi / 0.693147182f);
  coax_ff r = a - ln2 * coax_ff_make(n, 0.0f);
  r = coax_ff_make(r.hi * 0.00390625f, r.lo * 0.00390625f);
  coax_ff s = r, p = r;
  for (int k = 0; k < 7; k++) { p = p * r; s = s + p * inv[k]; }
  for (int k = 0; k < 8; k++) s = coax_ff_make(2.0f * s.hi, 2.0f * s.lo) + s * s;
  s = s + coax_ff_make(1.0f, 0.0f);
  int e = (int)n;
  return coax_ff_make(ldexp(s.hi, e), ldexp(s.lo, e));
}
/* log: x = m 2^k with m in [sqrt(1/2), sqrt(2)); log m = 2 atanh u with
   u = (m - 1) / (m + 1), |u| <= 0.172, summed to u^25 (the next term is
   below 2^-50 of the sum); then k ln2. Near x = 1 the result keeps its
   relative accuracy because m - 1 is exact. */
COAX_DEV coax_ff coax_ff_log(coax_ff a) {
  if (!(a.hi > 0.0f) || isinf(a.hi)) return coax_ff_make(precise::log(a.hi), 0.0f);
  const coax_ff ln2 = coax_ff_make(0.693147182f, -1.90465421e-09f);
  const coax_ff odd[13] = {coax_ff_make(1.0f, 0.0f), coax_ff_make(0.333333343f, -9.93410776e-09f), coax_ff_make(0.200000003f, -2.98023228e-09f),
    coax_ff_make(0.142857149f, -6.386212e-09f), coax_ff_make(0.111111112f, -8.27842295e-10f), coax_ff_make(0.0909090936f, -2.70930212e-09f),
    coax_ff_make(0.0769230798f, -2.86560797e-09f), coax_ff_make(0.0666666701f, -3.47693763e-09f), coax_ff_make(0.0588235296f, -2.19134724e-10f),
    coax_ff_make(0.0526315793f, -3.92135824e-10f), coax_ff_make(0.0476190485f, -8.86973883e-10f), coax_ff_make(0.0434782617f, -8.09845746e-10f),
    coax_ff_make(0.0399999991f, 8.94069652e-10f)};
  int k = ilogb(a.hi);
  coax_ff m = coax_ff_scale(a, -k);
  if (m.hi > 1.41421354f) { m = coax_ff_scale(m, -1); k += 1; }
  const coax_ff one = coax_ff_make(1.0f, 0.0f);
  coax_ff u = (m - one) / (m + one), u2 = u * u, p = odd[12];
  for (int j = 11; j >= 0; j--) p = p * u2 + odd[j];
  coax_ff y = u * p;
  y = coax_ff_make(2.0f * y.hi, 2.0f * y.lo);
  return ln2 * coax_ff_make((float)k, 0.0f) + y;
}

/* cu_mma_bf16_16x8x16 for one simdgroup, in the PTX fragment layout of
   lib/compute/mma.coax: each lane gathers rows g and g+8 of A and columns 2t
   and 2t+1 of B from the lanes that hold them, adds the 16 exact products in
   f32 in k order and adds that sum into C. */
COAX_DEV float coax_bf16_lo(uint w) { return as_type<float>(w << 16); }
COAX_DEV float coax_bf16_hi(uint w) { return as_type<float>(w & 0xffff0000u); }
/* The gathered rows of A (the shuffles below) depend only on the
   simdgroup's A fragments, so a caller that multiplies one A by many B
   (dw_project) keeps them in coax_mc and gathers again only when some lane's
   A changed (simd_all keeps the branch uniform). */
typedef struct { uint a[4]; uint x[16]; bool ok; } coax_mma_cache;
COAX_DEV void coax_mma_bf16_16x8x16(thread uint *a, thread uint *b, thread float *c, uint lane, thread coax_mma_cache &mc) {
  uint g = lane >> 2, t = lane & 3u;
  uint a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], b0 = b[0], b1 = b[1];
  bool same = mc.ok && a0 == mc.a[0] && a1 == mc.a[1] && a2 == mc.a[2] && a3 == mc.a[3];
  if (!simd_all(same)) {
    for (uint j = 0; j < 4; j++) {
      ushort sa = (ushort)(4 * g + j);
      mc.x[2 * j] = simd_shuffle(a0, sa); mc.x[2 * j + 1] = simd_shuffle(a1, sa);
      mc.x[8 + 2 * j] = simd_shuffle(a2, sa); mc.x[9 + 2 * j] = simd_shuffle(a3, sa);
    }
    mc.a[0] = a0; mc.a[1] = a1; mc.a[2] = a2; mc.a[3] = a3; mc.ok = true;
  }
  float s00 = 0.0f, s01 = 0.0f, s10 = 0.0f, s11 = 0.0f;
  /* A product of two bf16 values is exact in f32, so fma(x, y, s) rounds
     exactly as s + x * y. Step J of half H covers k = 8H + 2J and 8H + 2J + 1. */
#define COAX_MMA_STEP(J, H)                                                                        \
  {                                                                                                \
    ushort sb0 = (ushort)(8 * t + J), sb1 = (ushort)(8 * t + 4 + J);                               \
    uint x0 = mc.x[8 * H + 2 * J], x1 = mc.x[8 * H + 2 * J + 1];                                   \
    uint y0 = simd_shuffle(H ? b1 : b0, sb0), y1 = simd_shuffle(H ? b1 : b0, sb1);                 \
    float r0l = coax_bf16_lo(x0), r0h = coax_bf16_hi(x0), r1l = coax_bf16_lo(x1), r1h = coax_bf16_hi(x1); \
    float c0l = coax_bf16_lo(y0), c0h = coax_bf16_hi(y0), c1l = coax_bf16_lo(y1), c1h = coax_bf16_hi(y1); \
    s00 = fma(r0l, c0l, s00); s00 = fma(r0h, c0h, s00); s01 = fma(r0l, c1l, s01); s01 = fma(r0h, c1h, s01); \
    s10 = fma(r1l, c0l, s10); s10 = fma(r1h, c0h, s10); s11 = fma(r1l, c1l, s11); s11 = fma(r1h, c1h, s11); \
  }
  COAX_MMA_STEP(0, 0) COAX_MMA_STEP(1, 0) COAX_MMA_STEP(2, 0) COAX_MMA_STEP(3, 0)
  COAX_MMA_STEP(0, 1) COAX_MMA_STEP(1, 1) COAX_MMA_STEP(2, 1) COAX_MMA_STEP(3, 1)
#undef COAX_MMA_STEP
  c[0] += s00; c[1] += s01; c[2] += s10; c[3] += s11;
}
)COAXRT";

// `coax metal-compute FILE`: the kernels of a file and what they call, as
// Metal Shading Language. Each kernel takes one constant argument block at
// buffer index 0 and the launch's two error words at buffer index 1. The
// argument block is the work-item count (8 bytes) and then each parameter
// after the work item, in order: a view is 16 bytes (the device address of
// element 0, then the element count), an f64 is 8 bytes (hi, then lo, as
// f32), and every other scalar sits in the low bytes of its own 8.
std::string emit_metal_compute(const File *file, const EmitOptions &opts) {
  g_metal_compute = true;
  Emitter em{file, opts};
  std::vector<const ProcDecl *> procs = cuda_procs(file);
  std::string functions, narrow_prototypes;
  g_narrow.clear();
  for (const ProcDecl *p : procs) {
    functions += em.function(p);
    if (!p->export_c || !p->params.count || p->params[0].type != T_INT) continue;
    Narrow &n = g_narrow[p];
    n.analyze(p);
    if (!n.any) { g_narrow.erase(p); continue; }
    em.n32 = &n;
    functions += em.function(p);
    narrow_prototypes += em.prototype(p) + ";\n";
    em.n32 = nullptr;
  }
  std::vector<Type> used;
  auto add = [&](Type t) {
    if (t->kind != TypeKind::array && t->kind != TypeKind::view) return;
    for (Type u : used) if (u == t) return;
    used.push_back(t);
  };
  std::function<void(const Expr *)> types_expr = [&](const Expr *e) {
    if (!e) return;
    add(e->type);
    types_expr(e->lhs); types_expr(e->rhs); types_expr(e->third);
    for (const Expr *a : e->args) types_expr(a);
  };
  std::function<void(const Stmt *)> types_stmt = [&](const Stmt *st) {
    if (!st) return;
    add(st->type);
    types_expr(st->expr); types_expr(st->expr2); types_expr(st->target);
    for (const Stmt *c : st->body) types_stmt(c);
    types_stmt(st->then_); types_stmt(st->else_);
    for(const SwitchCase *arm:st->cases)types_stmt(arm->body);
  };
  for (const ProcDecl *p : procs) {
    add(p->ret);
    for (const Param &prm : p->params) add(prm.type);
    types_stmt(p->body);
  }
  // Arrays and views hold scalars only (admission), so they never depend on each other.
  std::string types, helpers;
  for (Type t : used) {
    std::string c = c_type(t), e = c_type(t->elem), tg = tag(t);
    if (t->kind == TypeKind::array) { types += "typedef struct { " + e + " e[" + std::to_string(t->length) + "]; } " + c + ";\n"; continue; }
    types += "typedef struct { device " + e + " *data; int64_t count; } " + c + ";\n";
    helpers += "COAX_DEV device " + e + " *coax_elem_" + tg + "_(" + c + " v, int64_t i, int32_t l, COAX_ERR) { return &v.data[coax_index(i, v.count, l)]; }\n";
    helpers += "#define coax_elem_" + tg + "(v, i, l) coax_elem_" + tg + "_(v, i, l, coax_err)\n";
    helpers += "COAX_DEV device " + e + " *coax_elem32_" + tg + "_(" + c + " v, int32_t i, int32_t l, COAX_ERR) { return &v.data[coax_index32(i, (int32_t)v.count, l)]; }\n";
    helpers += "#define coax_elem32_" + tg + "(v, i, l) coax_elem32_" + tg + "_(v, i, l, coax_err)\n";
    helpers += "COAX_DEV " + c + " coax_reslice_" + tg + "_(" + c + " v, int64_t lo, int64_t hi, int32_t l, COAX_ERR) {\n"
               "  " + c + " r = {v.data, 0};\n  if (coax_slice_ok_(lo, hi, v.count, l, coax_err)) { r.data = v.data + lo; r.count = hi - lo; }\n  return r;\n}\n";
    helpers += "#define coax_reslice_" + tg + "(v, lo, hi, l) coax_reslice_" + tg + "_(v, lo, hi, l, coax_err)\n";
  }
  std::string s = "/* Generated by coax0 from " + file->src->path + " (coax metal-compute). Do not edit: change the .coax file. */\n";
  s += METAL_RUNTIME;
  s += "\n/* Types */\n" + types + helpers + "\n";
  bool simdgroups = false;
  for (const auto &[call, kind] : g_warp.apple_calls) simdgroups = simdgroups || kind != 3;
  if (simdgroups) s += METAL_SIMDGROUP_RUNTIME;
  if (em.apple_tensor) s += METAL_TENSOR_RUNTIME;
  for (const ProcDecl *p : procs) s += em.prototype(p) + ";\n";
  s += narrow_prototypes;
  s += functions;
  s += "\n/* Kernels: one argument block at buffer(0) (the item count, then each parameter\n"
       "   in an 8-byte slot, views in 16), the error words at buffer(1). */\n";
  for (const ProcDecl *p : procs) {
    if (!p->export_c) continue;
    std::string name = to_std(p->name), block = "struct coax_args_" + name + " {\n  int64_t coax_items;\n";
    std::string call = em.proc_name(p) + "(coax_item";
    for (int32_t i = 1; i < p->params.count; i++) {
      Type t = p->params[i].type;
      std::string field = em.local_name(p->params[i].name);
      block += "  " + c_type(t) + " " + field + ";";
      int64_t size = t->kind == TypeKind::view ? 16 : t == &T_F64 ? 8 : t->kind == TypeKind::bool_ ? 1 : t->bits / 8;
      if (size < 8) block += " uint8_t coax_pad" + std::to_string(i) + "[" + std::to_string(8 - size) + "];";
      block += "\n";
      call += ", coax_a." + field;
    }
    block += "};\n";
    bool warp = g_warp.warp_kernels.count(p), group = g_warp.group_kernels.count(p);
    s += block;
    s += "kernel void " + name + "(constant coax_args_" + name + " &coax_a [[buffer(0)]], device atomic_uint *coax_errors [[buffer(1)]],\n"
         "    uint coax_gid [[thread_position_in_grid]], uint coax_simd_lane [[thread_index_in_simdgroup]]" +
         std::string(group ? ",\n    uint coax_tid [[thread_index_in_threadgroup]], uint coax_tpg [[threads_per_threadgroup]], uint coax_tgid [[threadgroup_position_in_grid]]" : "") + ") {\n";
    std::string shared_args;
    if (group) {  // one threadgroup of T threads per work item; the host launches T threads per group
      std::string T = std::to_string(g_warp.group_kernels.at(p));
      if (g_warp.shared_arrays.count(p))
        for (const Stmt *d : g_warp.shared_arrays.at(p)) {
          s += "  threadgroup " + c_type(d->type) + " coax_tg_" + em.local_name(d->name) + ";\n";
          shared_args += ", &coax_tg_" + em.local_name(d->name);
        }
      s += "  if (coax_tpg != " + T + "u) {  /* launched with the wrong group size: the launch is void */\n"
           "    if (coax_tid == 0) { atomic_fetch_add_explicit(&coax_errors[0], 1u, memory_order_relaxed); atomic_fetch_max_explicit(&coax_errors[1], " +
           std::to_string(p->loc.line) + "u, memory_order_relaxed); }\n    return;\n  }\n";
      s += "  int64_t coax_item = (int64_t)coax_tgid;\n  uint coax_lane = coax_tid;\n";
    } else if (warp)  // one simdgroup of 32 lanes per work item
      s += "  int64_t coax_item = (int64_t)(coax_gid >> 5);\n  uint coax_lane = coax_simd_lane;\n";
    else
      s += "  int64_t coax_item = (int64_t)coax_gid;\n  uint coax_lane = coax_simd_lane;\n";
    s += "  if (coax_item >= coax_a.coax_items) return;\n  uint coax_err[2] = {0, 0};\n";
    std::string args = (p->params.count > 1 ? ", " : ", ") + std::string("coax_lane, coax_err") + shared_args + ");\n";
    auto narrow = g_narrow.find(p);
    if (narrow != g_narrow.end()) {
      // The 32-bit body when the launch meets the bounds its intervals assumed (Narrow).
      uint64_t g = narrow->second.guard;
      std::string b = std::to_string(NARROW_BOUND), cond = "coax_a.coax_items <= " + b;
      for (int32_t i = 1; i < p->params.count && i < 63; i++)
        if (g & ((uint64_t)1 << i)) {
          std::string f = "coax_a." + em.local_name(p->params[i].name);
          cond += " && " + f + " >= 0 && " + f + " <= " + b;
        }
      if (g >> 63)
        for (int32_t i = 1; i < p->params.count; i++)
          if (p->params[i].type->kind == TypeKind::view) cond += " && coax_a." + em.local_name(p->params[i].name) + ".count <= 2147483647";
      std::string ncall = call;
      ncall.replace(0, em.proc_name(p).size(), em.proc_name(p) + "_n32");
      s += "  if (" + cond + ") " + ncall + args + "  else " + call + args;
    } else s += "  " + call + args;
    s += ""
         "  if (coax_err[0]) {\n"
         "    atomic_fetch_add_explicit(&coax_errors[0], coax_err[0], memory_order_relaxed);\n"
         "    atomic_fetch_max_explicit(&coax_errors[1], coax_err[1], memory_order_relaxed);\n  }\n}\n";
  }
  for (size_t at = 0; (at = s.find("_Bool", at)) != std::string::npos;) s.replace(at, 5, "bool");
  g_metal_compute = false;
  return s;
}

// The generic instances the program's own procedures call, directly or
// through other instances. An instance that only a check creates (a library
// check over int, or a test of the root's own) is never called by emitted code,
// so the C leaves it out (ax-library-check-cache).
static std::set<const ProcDecl *> called_instances(const File *file) {
  std::set<const ProcDecl *> reached;
  std::vector<const ProcDecl *> work;
  auto visit = [&](const ProcDecl *p) {
    if (p && p->origin && reached.insert(p).second) work.push_back(p);
  };
  std::function<void(const Expr *)> expr = [&](const Expr *e) {
    if (!e) return;
    visit(e->proc);
    visit(e->mutation_proc);
    expr(e->lhs); expr(e->rhs); expr(e->third);
    for (const Expr *a : e->args) expr(a);
    for (const FieldInit &f : e->fields) expr(f.value);
  };
  std::function<void(const Stmt *)> stmt = [&](const Stmt *st) {
    if (!st) return;
    expr(st->expr); expr(st->expr2); expr(st->target);
    for (const Stmt *c : st->body) stmt(c);
    stmt(st->then_); stmt(st->else_);
    for(const SwitchCase *arm:st->cases)stmt(arm->body);
  };
  for (const ProcDecl *p : file->procs) if (!p->origin) stmt(p->body);
  while (!work.empty()) {
    const ProcDecl *p = work.back();
    work.pop_back();
    stmt(p->body);
  }
  return reached;
}

size_t g_instance_c_bytes = 0;
std::string emit_c(const File *file, const EmitOptions &opts) {
  if (opts.cuda) return emit_cuda(file, opts);
  if (opts.metal_compute) return emit_metal_compute(file, opts);
  Emitter em{file, opts};
  std::string functions;
  g_instance_c_bytes = 0;
  const std::set<const ProcDecl *> called = called_instances(file);
  auto emitted = [&](const ProcDecl *p) { return !p->origin || called.count(p); };
  for (const ProcDecl *p : file->procs) {if (!emitted(p)) continue;std::string f = em.function(p);if (p->origin) g_instance_c_bytes += f.size();functions += f;}
  if (opts.metal) {
    // Scalar f32/bool functions only (the checker enforced it): no runtime.
    std::string s = "/* Generated by coax0 from " + file->src->path + ". Do not edit: change the .coax file. */\n";
    s += "#include <metal_stdlib>\nusing namespace metal;\n\n";
    for (const ProcDecl *p : file->procs) if (emitted(p)) s += em.prototype(p) + ";\n";
    s += functions;
    for (size_t at = 0; (at = s.find("_Bool", at)) != std::string::npos;) s.replace(at, 5, "bool");
    return s;
  }
  std::string inits = init_functions(file, em);
  std::string hosted = opts.library ? state_defaults(file, em) : std::string();
  const std::string uses = inits + functions + hosted;
  std::string shows = show_functions(file, em, &uses);

  TypeWriter types;
  types.forward_structs(file);
  std::vector<Type> all;
  collect_types(file, &all);
  for (Type t : all) types.need(t);
  types.layout_asserts(file);

  std::string s = "/* Generated by coax0 from " + file->src->path + ". Do not edit: change the .coax file. */\n";
  s += "static const char *coax_source_path = \"" + escape_path(file->src->path) + "\";\n";
  s += source_runtime(file);
  if (em.barrier) s += BARRIER_RUNTIME;
  if (em.wrapping) s += WRAP_RUNTIME;
  if (em.versioned) s += IV_RUNTIME;
  s += "#define COAX_LAYOUT(c, m) _Static_assert(c, m)\n";
  s += "\n/* Types */\n" + types.out;
  if (em.wide) s += WIDE_RUNTIME;
  s += view_helpers();
  if (!em.ct_values.empty()) {
    s += "\n/* Values computed at compile time */\n";
    for (size_t i = 0; i < em.ct_values.size(); i++) {
      const Expr *e = em.ct_values[i];
      s += "static const " + c_type(e->type) + " coax_k" + std::to_string(i) + " = " + em.init_list(*e->ct) + ";\n";
    }
  }
  s += "\n" + inits + shows + "\n";
  for (const ProcDecl *p : file->procs) if (emitted(p)) s += em.prototype(p) + ";\n";
  s += functions;
  s += hosted;
  bool has_main = false;
  for (const ProcDecl *p : file->procs) has_main = has_main || str_eq(p->name, "main");
  if (!opts.library && has_main) s += "\nint main(void) {\n  coax_p_main();\n  return 0;\n}\n";
  return s;
}

static std::string native_check_table_v2(const File *file, Emitter &em, const NativeCheckCPlan &plan) {
  std::string s = "\n/* Explicit verification ABI2: immutable binding metadata and admitted word tuples. */\n"
      "typedef struct Coax_VerificationEnumValue_v2 { uint64_t bits; const char *label; int64_t label_count; } Coax_VerificationEnumValue_v2;\n"
      "typedef struct Coax_VerificationBinding_v2 {\n"
      "  const char *name; int64_t name_count; const char *type_name; int64_t type_name_count;\n"
      "  int64_t kind, width, is_signed, first; uint64_t count;\n"
      "  const Coax_VerificationEnumValue_v2 *values; int64_t value_count;\n"
      "} Coax_VerificationBinding_v2;\n"
      "typedef struct Coax_VerificationCheck_v2 {\n"
      "  int64_t declaration_index; const char *name; int64_t name_count;\n"
      "  const char *source; int64_t source_count; int64_t line, column;\n"
      "  int64_t kind; const Coax_VerificationBinding_v2 *bindings; int64_t binding_count;\n"
      "  uint64_t case_count; int64_t (*run_values)(const uint64_t *, int64_t);\n"
      "} Coax_VerificationCheck_v2;\n";
  for (size_t row = 0; row < plan.checks.size(); ++row) {
    const NativeCheckCEntry &entry = plan.checks[row];
    const ProcDecl *proc = entry.check->proc;
    std::string prefix = "coax_verification_v2_" + std::to_string(row);
    for (size_t binding = 0; binding < entry.domains.size(); ++binding) {
      const NativeCheckDomain &domain = entry.domains[binding];
      if (domain.values.empty()) continue;
      s += "static const Coax_VerificationEnumValue_v2 " + prefix + "_values_" + std::to_string(binding) + "[] = {\n";
      for (size_t member = 0; member < domain.values.size(); ++member)
        s += "  {UINT64_C(" + std::to_string(domain.values[member]) + "), " + c_string_text(domain.labels[member]) + ", " +
             std::to_string(domain.labels[member].count) + "},\n";
      s += "};\n";
    }
    if (!entry.domains.empty()) {
      s += "static const Coax_VerificationBinding_v2 " + prefix + "_bindings[] = {\n";
      for (size_t binding = 0; binding < entry.domains.size(); ++binding) {
        const NativeCheckDomain &domain = entry.domains[binding];
        const Param &param = proc->params[(int32_t)binding];
        Type base = domain.type->kind == TypeKind::enum_ ? domain.type->elem : domain.type;
        Str label{domain.type->name.data(), (int32_t)domain.type->name.size()};
        s += "  {" + c_string_text(param.name) + ", " + std::to_string(param.name.count) + ", " + c_string_text(label) + ", " +
             std::to_string(label.count) + ", " + std::to_string(domain.kind) + ", " +
             std::to_string(base->bits) + ", " + (base->is_signed ? "1" : "0") + ", " +
             int_text(&T_S64, (uint64_t)domain.first) + ", UINT64_C(" + std::to_string(domain.count) + "), " +
             (domain.values.empty() ? "NULL" : prefix + "_values_" + std::to_string(binding)) + ", " +
             std::to_string(domain.values.size()) + "},\n";
      }
      s += "};\n";
    }
    s += "static int64_t " + prefix + "_run(const uint64_t *values, int64_t count) {\n"
         "  if (count != " + std::to_string(proc->params.count) +
         (proc->params.count ? " || !values" : "") + ") return -1;\n";
    if (!proc->params.count) s += "  (void)values;\n";
    std::vector<std::string> arguments;
    for (int32_t i = 0; i < proc->params.count; ++i) {
      Type type = proc->params[i].type;
      Type base = type->kind == TypeKind::enum_ ? type->elem : type;
      std::string word = "values[" + std::to_string(i) + "]";
      if (base->is_signed) {
        std::string signed_word = "coax_signed_" + std::to_string(i);
        s += "  int64_t " + signed_word + "; memcpy(&" + signed_word + ", &" + word + ", sizeof(" + signed_word + "));\n";
        word = signed_word;
      }
      arguments.push_back("(" + c_type(type) + ")" + word);
    }
    s += "  " + em.proc_name(proc) + "(";
    for (size_t i = 0; i < arguments.size(); ++i) s += (i ? ", " : "") + arguments[i];
    s += ");\n  return 0;\n}\n";
  }
  s += "static const Coax_VerificationCheck_v2 coax_verification_table_v2[] = {\n";
  for (size_t row = 0; row < plan.checks.size(); ++row) {
    const NativeCheckCEntry &entry = plan.checks[row];
    const CheckDecl *check = entry.check;
    auto point = source_point(file->src, check->loc);
    Str path{point.path.data(), (int32_t)point.path.size()};
    s += "  {" + std::to_string(entry.declaration_index) + ", " + c_string_text(check->name) + ", " +
         std::to_string(check->name.count) + ", " + c_string_text(path) + ", " + std::to_string(path.count) + ", " +
         std::to_string(point.loc.line) + ", " + std::to_string(point.loc.col) + ", " + (check->forall ? "2" : "1") + ", " +
         (entry.domains.empty() ? "NULL" : "coax_verification_v2_" + std::to_string(row) + "_bindings") + ", " +
         std::to_string(entry.domains.size()) + ", UINT64_C(" + std::to_string(entry.case_count) + "), coax_verification_v2_" +
         std::to_string(row) + "_run},\n";
  }
  s += "};\nconst Coax_VerificationCheck_v2 *coax_verification_checks_v2(int64_t *count) {\n"
       "  if (count) *count = " + std::to_string(plan.checks.size()) + ";\n  return coax_verification_table_v2;\n}\n";
  return s;
}

std::string emit_native_checks_c_plan(const File *file, const EmitOptions &opts, const NativeCheckCPlan &plan) {
  Emitter em{file, opts};
  em.verification = true;
  // Every definition in this verification unit has a generated private name.
  // Authored export names and arbitrary check display names cannot collide
  // with the table ABI or inject identifiers into emitted C.
  for (size_t i = 0; i < plan.procedures.size(); ++i)
    em.verification_names.emplace(plan.procedures[i], "coax_verification_body_" + std::to_string(i));
  std::string functions;
  g_instance_c_bytes = 0;
  for (const ProcDecl *p : plan.procedures) {
    std::string function = em.function(p);
    if (p->origin) g_instance_c_bytes += function.size();
    functions += function;
  }
  std::string inits = init_functions(file, em);
  std::string shows = show_functions(file, em);
  TypeWriter types;
  types.forward_structs(file);
  std::vector<Type> all;
  collect_types(file, &all);
  for (Type type : all) types.need(type);
  types.layout_asserts(file);

  std::string s = "/* Checked-AST verification bodies. Not product emission. */\n";
  s += "static const char *coax_source_path = \"" + escape_path(file->src->path) + "\";\n";
  s += source_runtime(file, true);
  if (em.barrier) s += BARRIER_RUNTIME;
  if (em.wrapping) s += WRAP_RUNTIME;
  s += "#define COAX_LAYOUT(c, m) _Static_assert(c, m)\n";
  s += "\n/* Types */\n" + types.out;
  if (em.wide) s += WIDE_RUNTIME;
  s += view_helpers();
  if (!em.ct_values.empty()) {
    s += "\n/* Values computed at compile time */\n";
    for (size_t i = 0; i < em.ct_values.size(); ++i) {
      const Expr *e = em.ct_values[i];
      s += "static const " + c_type(e->type) + " coax_k" + std::to_string(i) + " = " + em.init_list(*e->ct) + ";\n";
    }
  }
  s += "\n" + inits + shows + "\n";
  for (const ProcDecl *p : plan.procedures) s += em.prototype(p) + ";\n";
  s += functions;
  if (plan.verification_abi == 2) return s + native_check_table_v2(file, em, plan);
  s += "\n/* Verification-only ABI v1: display strings are byte spans, not C identifiers. */\n"
       "typedef struct Coax_VerificationCheck_v1 {\n"
       "  int64_t declaration_index;\n"
       "  const char *name; int64_t name_count;\n"
       "  const char *source; int64_t source_count;\n"
       "  int64_t line, column;\n"
       "  void (*run)(void);\n"
       "} Coax_VerificationCheck_v1;\n"
       "static const Coax_VerificationCheck_v1 coax_verification_table_v1[] = {\n";
  for (const NativeCheckCEntry &entry : plan.checks) {
    const CheckDecl *check = entry.check;
    auto point = source_point(file->src, check->loc);
    // Admitted filesystem paths fit Str's bounded count; the ABI fields are int64_t.
    Str path{point.path.data(), (int32_t)point.path.size()};
    s += "  {" + std::to_string(entry.declaration_index) + ", " + c_string_text(check->name) + ", " +
         std::to_string(check->name.count) + ", " + c_string_text(path) + ", " + std::to_string(path.count) + ", " +
         std::to_string(point.loc.line) + ", " + std::to_string(point.loc.col) + ", " + em.proc_name(check->proc) + "},\n";
  }
  s += "};\nconst Coax_VerificationCheck_v1 *coax_verification_checks_v1(int64_t *count) {\n"
       "  if (count) *count = " + std::to_string(plan.checks.size()) + ";\n"
       "  return coax_verification_table_v1;\n}\n";
  return s;
}

std::string emit_header(const File *file) {
  // The types the exported procedures use, and everything they contain.
  TypeWriter types;
  types.header = true;
  for(const UnionDecl *d:file->unions)types.out+="typedef struct "+c_type(d->type)+" "+c_type(d->type)+";\n";
  for(Type t:all_composite_types())if(is_sum(t))types.out+="typedef struct "+c_type(t)+" "+c_type(t)+";\n";
  for (const StructDecl *d : file->structs) {
    bool used = false;
    std::vector<Type> visiting;
    std::function<bool(Type)> uses = [&](Type t) -> bool {
      if (t == d->type) return true;
      for (Type v : visiting) if (v == t) return false;
      visiting.push_back(t);
      bool found = false;
      if(is_sum(t))for(int32_t i=0;i<sum_count(t);i++)found=found || uses(sum_payload(t,i));
      if (t->kind == TypeKind::array || t->kind == TypeKind::view) found = uses(t->elem);
      if (t->kind == TypeKind::struct_)
        for (const Field &f : t->struct_decl->fields) found = found || uses(f.type);
      visiting.pop_back();
      return found;
    };
    for (const ProcDecl *p : file->procs) {
      if (!p->export_c && !p->foreign) continue;
      used = used || uses(p->ret);
      for (const Param &prm : p->params) used = used || uses(prm.type);
    }
    if (used && !d->type->physical) types.out += "typedef struct coax_" + tag(d->type) + " coax_" + tag(d->type) + ";\n";
  }
  {
    TypeWriter used = header_types(file);
    types.out += used.out;
    types.done = used.done;
  }
  size_t definitions_end=types.out.size();types.sum_layout_asserts("COAX_ALIGNOF");
  std::string asserts=types.out.substr(definitions_end);types.out.resize(definitions_end);
  for (const StructDecl *d : file->structs) {
    if (d->type->physical || !types.seen(d->type)) continue;
    std::string c = c_type(d->type);
    asserts += "COAX_LAYOUT(sizeof(" + c + ") == " + std::to_string(d->type->size) + " && COAX_ALIGNOF(" + c +
               ") == " + std::to_string(d->type->align) + ", \"layout of " + to_std(d->name) + "\");\n";
    for (const Field &f : d->fields)
      asserts += "COAX_LAYOUT(offsetof(" + c + ", " + to_std(f.name) + ") == " + std::to_string(f.offset) +
                 ", \"offset of " + to_std(d->name) + "." + to_std(f.name) + "\");\n";
  }

  Emitter em{file, {}};
  std::string s = "/* Generated by coax0 from " + file->src->path + ". Do not edit: change the .coax file.\n"
                  "   Coax int is int64_t; a Coax string or view is a pointer and a count, not\n"
                  "   NUL-terminated; a failed check inside a call aborts the process. */\n";
  // Per-type guards permit repeated inclusion without hiding another entry
  // unit that happens to have the same basename. Compatible C prototypes and
  // forward typedefs may be repeated in C11 and C++.
  s += "#include <stddef.h>\n#include <stdint.h>\n\n";
  s += "#ifdef __cplusplus\n#define _Bool bool\n#define COAX_LAYOUT(c, m) static_assert(c, m)\n#define COAX_ALIGNOF alignof\nextern \"C\" {\n#else\n"
       "#define COAX_LAYOUT(c, m) _Static_assert(c, m)\n#define COAX_ALIGNOF _Alignof\n#endif\n\n";
  s += "#ifndef COAX_STRING_DEFINED\n#define COAX_STRING_DEFINED\ntypedef struct { const char *data; int64_t count; } coax_string;\n#endif\n\n";
  s += types.out + asserts + "\n";
  for (const ProcDecl *p : file->procs)
    if (p->export_c) s += em.prototype(p, true) + ";\n";
  for (Type t : types.done)
    if (host_default(t)) s += "void coax_default_" + tag(t) + "(" + c_type(t) + " *p);\n";
  bool any_foreign = false;
  for (const ProcDecl *p : file->procs) any_foreign = any_foreign || p->foreign;
  if (any_foreign) {
    s += "\n/* Provided by the host (#foreign). */\n";
    for (const ProcDecl *p : file->procs)
      if (p->foreign) s += em.prototype(p, true) + ";\n";
  }
  s += "\n#ifdef __cplusplus\n}\n#undef _Bool\n#endif\n#undef COAX_LAYOUT\n#undef COAX_ALIGNOF\n";
  return s;
}

std::string layout_report(const File *file) {
  std::vector<Type> types;collect_types(file,&types);
  bool sums=false;for(Type t:types)sums=sums || is_sum(t);
  std::string s=sums ? "coax-layout-sums-lp64.v1\n" : "";
  if(sums)for(Type t:types)if(is_sum(t)){
    s+=std::string(type_name(t))+"  sum size "+std::to_string(t->size)+"  align "+std::to_string(t->align)+"  tag u32@0  payload@"+std::to_string(t->sum_payload_offset)+"\n";
    for(int32_t i=0;i<sum_count(t);i++)s+="  "+std::to_string(i)+": "+type_name(sum_payload(t,i))+"\n";
  }
  char buf[256];
  for (const StructDecl *d : file->structs) {
    // an instance is listed by its type: Pair(int)
    snprintf(buf, sizeof buf, "%s  size %d  align %d\n", d->origin ? type_name(d->type) : to_std(d->name).c_str(), d->type->size, d->type->align);
    s += buf;
    int32_t end = 0;
    for (const Field &f : d->fields) {
      if (f.offset > end) {
        snprintf(buf, sizeof buf, "  %6d  %4d  (padding)\n", end, f.offset - end);
        s += buf;
      }
      snprintf(buf, sizeof buf, "  %6d  %4d  %s: %s\n", f.offset, f.type->size, to_std(f.name).c_str(), type_name(f.type));
      s += buf;
      end = f.offset + f.type->size;
    }
    if (d->type->size > end && d->fields.count) {
      snprintf(buf, sizeof buf, "  %6d  %4d  (padding)\n", end, d->type->size - end);
      s += buf;
    }
  }
  for (const EnumDecl *d : file->enums) {
    snprintf(buf, sizeof buf, "%s  enum %s  size %d\n", to_std(d->name).c_str(), type_name(d->type->elem), d->type->size);
    s += buf;
    for (const EnumMember &m : d->members) {
      std::string v = d->type->elem->is_signed ? std::to_string((int64_t)m.bits) : std::to_string(m.bits);
      snprintf(buf, sizeof buf, "  %s = %s\n", to_std(m.name).c_str(), v.c_str());
      s += buf;
    }
  }
  if (s.empty()) s = "no structs or enums\n";
  return s;
}

}  // namespace coax

namespace coax {
static std::string debug_source_hash(const std::string &text) {
#ifndef COAX_BOOTSTRAP_IMPORTER
  uint8_t out[64];auto digest=S_hash({text.data(),(int64_t)text.size()});
  if(S_hex(digest,{out,64}))return std::string((char*)out,64);
#endif
  return ""; // build-only stage0 refuses --source-map; no native hash fallback
}
std::string emit_debug_map(const File *file) {
  Emitter em{file,{}};
  std::string out="{\"schema_version\":1,\"sources\":[";
  bool first=true;
  for (const auto &unit:file->src->units) {out+=(first?"":",")+json_string(unit->canonical);first=false;}
  out+="],\"source_hashes\":{";first=true;
  for(const auto &unit:file->src->units) {out+=(first?"":",")+json_string(unit->canonical)+":"+json_string(debug_source_hash(unit->text));first=false;}
  out+="},\"functions\":[";first=true;
  for (const auto *p:file->procs) {
    if(p->foreign) continue;
    auto point=source_point(file->src,p->loc);
    out+=(first?"":",")+std::string("{\"name\":")+json_string(to_std(p->name))+",\"c_name\":"+json_string(em.proc_name(p))+",\"file\":"+json_string(debug_path(file->src,p->loc))+",\"line\":"+std::to_string(point.loc.line)+",\"variables\":[";first=false;
    bool variable_first=true;
    auto variable=[&](Str name,Type type,Loc loc,const char *role) {
      auto at=source_point(file->src,loc);
      out+=(variable_first?"":",")+std::string("{\"name\":")+json_string(to_std(name))+",\"c_name\":"+json_string(em.local_name(name))+",\"type\":"+json_string(type->name)+",\"role\":"+json_string(role)+",\"line\":"+std::to_string(at.loc.line)+"}";variable_first=false;
    };
    for(const auto &arg:p->params) variable(arg.name,arg.type,arg.loc,"parameter");
    std::function<void(const Stmt*)> walk=[&](const Stmt *s) {
      if(!s) return;
      if(s->kind==StmtKind::var) variable(s->name,s->type,s->loc,"local");
      if(s->kind==StmtKind::for_range || s->kind==StmtKind::for_each) {
        variable(s->name,s->type,s->loc,"loop");
        if(s->name2.count) variable(s->name2,T_INT,s->name2_loc,"loop");
      }
      for(const auto *child:s->body) walk(child);
      walk(s->then_);walk(s->else_);
      for(const SwitchCase *arm:s->cases){if(arm->binding)variable(arm->binding->name,arm->binding->type,arm->binding->loc,"case");walk(arm->body);}
    };
    walk(p->body);out+="]}";
  }
  return out+"]}\n";
}
} // namespace coax
