# B1 architecture proposal (read-only, before claim/implementation cue)

B checkout base f4d728fb60508049b0a77ef6eb3cd341fe2c3c62. No source edits, compiler/gates or R checkout effects. B0 source/policy and its actual independent/native evidence remain historical. B0 docs are scope/fact accurate.

## Placement and entry

Move policy to `coax/lib/compiler/retain-policy.coax` before loading it; change its BS load to `borrow-summary.coax` and load it from checker.coax. Update standalone tooling/doc path references, snapshot the old source/path, and keep actual fingerprint/bootstrap inventory inclusion. Root owns seed/header/provenance/fixedpoint/normal changes. No loaded semantic input outside the fingerprint.

After CK_instantiate and A1 return diagnostics succeed, extend the same live CB invocation with retained-store analysis, before authority coverage/Metal. Preserve earlier E0366/type/lvalue precedence and A1 return behavior. Share CB_State.work (1,048,576 total), query/origin memo and existing depth/path/set bounds. Do not reset/inflate fuel.

Visit all nongeneric/nonforeign concrete root procedures, hidden check procedures and concrete instance chain, including void/uncalled bodies. Existing typed proc.borrow_writes and borrow_calls indexes provide sites; validate owner/node/tag/linked indices while visiting. No second name/type/module resolver.

## Address versus descriptor contents

Descriptor-leaf RHS origin: CB_expr(rhs, selectedLeafPath, false), retaining known origins plus incomplete. Expand whole-record/owned-array assignments into at most64 borrowed leaves with existing CB_type/fields/path vocabulary; source/type key is CB_descriptor_key(leafType).

Address lowering uses checked target expression and typed projection, not CB_expr(storage=true) of the final descriptor leaf. Before each view dereference, read only that descriptor prefix's VALUE/backing origins. Convert the backing into addressed element storage: LOCAL/STATIC owned backing appends ELEMENT(wildcard), parameter descriptor appends DEREFERENCE; then process following FIELD/owned ELEMENT projections. A subsequent contained-view crossing resolves its own descriptor prefix again. Do not append DEREFERENCE blindly to a LOCAL origin (BS disallows that) or mistake the previous destination descriptor value for address ownership.

No-dereference parameter/owned-array/inline-record storage belongs to the current callee copy (PARAMETER+INLINE or resolved LOCAL). Crossing a Context's contained view is independently external PARAMETER+DESCRIPTOR storage. View elements remain wildcard DEREFERENCE; fixed-array literals may retain exact ELEMENT, dynamic owned index uses wildcard. Multiple known address alternatives survive unknown; malformed typed facts are E0381, unsupported expression/address relations are sticky incomplete.

Call RP_check with current proc frame, selected leaf key, known source and address alternatives, and separate completeness flags. Keep pending/manual/known-bad/fact flags independent. Definition-local violations diagnose original RHS/store expression E0383 immediately, even if an eventual actual holder is local. Same-frame local/local relation remains manual. Complete default-empty source remains complete; ordinary zero-length owned views retain their owner. Never replace/kill old may-effects with a later safe store.

## Sparse external effects and caller application

Proposed internal `CK_RetainEffect {source:BS_Origin; destination:BS_Origin; value_type:int; witness:int; next:int;}`. Frame is implicit in its owning concrete proc; static uses0 and nonstatic/current proc on each RP application. Pending source/destination origins retain exact formal ordinals/projections. No name-based matching. Keep at most64 distinct pending pairs perproc, with first retained source/call witness; canonical dedup excludes only witness, never drops unknown.

Two logical phases: seed/check each body's own descriptor stores first (therefore uncalled definition-local escapes cannot be hidden by demand); then memoize/transitively apply resolved-call effects. Perproc cache states unseen/active/done; an active recursive edge returns its known lower bound plus incomplete, never complete-empty. Known direct pairs remain present even around cycles. No general recursive fixedpoint claim.

At an actual call, substitute only each referenced source AND destination formal/path once into caller namespace. Sources use existing CB_expr and BS per-binding substitution on their known-term lower bound. Destinations use the same typed address lowering on the actual expression plus the callee's checked destination projection. Pass completeness independently; do not union unused scratch/other arguments. RP reclassifies actual caller facts. E0383 from an applied obligation uses the original call location (loaded/generic callee provenance still names the actual definition for definition-local faults).

Caller parameter -> caller local holder discharges the applied relation; caller local -> same-frame local holder remains manual; caller local -> caller external/static is rejected at the call. Parameter -> external remains latent even with identical formal ordinals. Persist only external pending pairs as outward summary; local carrier read-after-write return precision is B2, and A1 opacity/manual floors stay unchanged in B1.

## Proposed workspace/report ABI (needs Root approval before freeze)

Append optional CK_Context views `retain_effects:[]CK_RetainEffect` and `retain_reports:[]CK_RetainObservation`. New Coax cap export `CK_retain_caps(nodes)->{effects:int,reports:int,work:int}` returns invalid zeros for invalid node count, proportional counts clamped128..16384, with work=existing1M (not additive fuel). C++ only allocates/transports those views. Existing literal contexts with no effects view use a fixed128-effect fallback; absent report view disables observation publication only, never semantic checking. This is an additive bounded workspace, not an increased existing budget. Exact multiplier/cap to be accepted after static size review.

Perproc node fields head/count/mark/incomplete/relation support sparse lookup; root traversal clears only eligible proc/check owners after concrete cloning. No global cache scan for each query. Effect insertion/pool charge/owner identity is bounded and checked; capacity/work/invalid facts produce original-located E0381. No unknown/safe-empty fallback on resource refusal.

Versioned report shape: `CK_RetainObservation {kind:u8;owner:int;site:int;facts_complete:bool;relation_complete:bool;forbidden:bool;pending:int;}`; kind1=concrete proc, kind2=applied call. owner is concrete proc node; site is proc or original call node, bounds/type checked. Separate committed `CK_State.retain_report_count` and report status identify the admitted used prefix. Private staging counts are not public; do not scan capacity, stale cache tails or Node.borrow_status.

Successful complete analysis atomically commits requested proc/call observations, including manual/pending rows; any source/graph/resource failure leaves admitted report_count0. Every report describes supplied effect/lifetime relation facts only. Exported host entry obligations are not discharged by a complete summary. Real loaded/generic physical paths are CLI fixtures; the existing one-file Python parser/CK bridge does not gain an invented module resolver.

## Check-first / qualification cutline

Check-first source RED on old5c: direct uncalled void local->external accepted today, expected E0383 at RHS/store. Also loaded uncalled definition, generic/concrete and forward helper; helper parameter obligation called with local input and external state expects call-located E0383. Positive caller views/static/default empty; local holder+caller input; by-value inline copy versus contained-view crossing; exact unrelated field/scratch exclusion. Keep old recursive-only/manual paths explicit, known-local+unknown sharp, later good/default store cannot erase old bad. B2 SoPost/read-after-write cases stay excluded.

New Coax graph #test/#forall precede algorithm implementation: exact typed address/storage cases, whole-leaf expansion, malformed indices/work/output limits, sparse effect dedup and recursion lower bounds, procedure/check/instance discovery and independent source/call report statuses. Root owns changed authority/full-scope mutation, seeds/normal and native layout qualification; no private extracted helper proof is mislabeled full compiler mutation. PS owns original-source and actual one-file graph/native observation fixtures.

If full B1 cannot qualify within2h: split only a complete bounded first behavior (all concrete direct stores and explicit facts), keep original B1 caller-substitution acceptance/issue open, then immediately complete linked call-instantiation slice. No claim B1 complete until every original B1 row passes.
