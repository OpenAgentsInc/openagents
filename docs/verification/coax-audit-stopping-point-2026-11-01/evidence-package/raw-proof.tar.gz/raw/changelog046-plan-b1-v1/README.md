# B1 local 0.46 changelog: prepared only

No module emission, native build, Wasm, browser, server, comparison, approval,
repository, authentication or publication action has run from this plan.
The failed/partial B1 normal epochs and all old v13 captures remain historical.
Final producer/hash/fingerprint/source revision are deliberately unfilled.

The workflow is a narrow clone of the reviewed v13 local workflow. It requires
an actual completed matching normal proof, current installed package, current
source HEAD, explicit introduction and every current input hash. It does not
use old5c/common171afc, the old7c fingerprint or four-file drift admission.
One fresh entropy C/header/profile emission is shared between the two local
native generators; no old passing producer observation is renamed.

`capture.ts`, `serve.ts`, `approve.py`, `producer_binding.py`, the Wasm linker
alias invocation and every capture/compare guard are unchanged. Current Mac
Chrome remains headless and muted. The two views are exactly 1280x800 and
390x844, DPR1, mobilefalse. This is not iPhone hardware or full-site deployment.

Later execution order, ONLY after Root supplies a qualified producer and cues it:

1. `workflow.py prepare` with B checkout/image/new directory and all explicit
   normal/image/fingerprint/revision/introduction parameters in prepared.json.
2. `workflow.py wasm DIRECTORY` stages only the local changelog.
3. `workflow.py capture DIRECTORY` runs the actual official two-page comparison
   against current goldens and retains the raw review PNGs and all mismatches.
   Startup, draw, runtime or unavailable-browser failures are not golden deltas.
4. Root must VIEW BOTH raw PNGs and bind their hashes in an explicit review note.
   Capturing/comparing does not approve or update anything.
5. Only after that review and a separate cue, `approve.py DIRECTORY REVIEW.json`
   copies exactly those two reviewed PNGs. It cannot recapture or commit.
6. If goldens change, run a new actual official comparison of the same staged
   site against the approved baselines with a separately bounded owned local
   server. The exact argv is prepared.json; never relabel the old mismatch.

Each phase uses the existing shared840s deadline, per-command300s cap, ten
transport flags, raw outputs, immutable source/tool/environment/package guards
and owned cleanup. Root must run the final optional postapproval comparison
through a bounded owned-server controller; a bare indefinite server is not an
admitted gate. No old postapproval killpg0/EPERM result is reused as a new pass.

Four critical inputs differ from v13: release metadata and the three golden
files that removed the unrelated galaxy/realm journey. Their changelog-page
entries/dimensions and selected by-address comparison are unchanged. Current
hashes are pinned in source-epoch.json; further drift requires review. Compiler
source/model changes are admitted only by the NEW completed normal proof and
actual current fingerprint, never by refreshing an old proof.
