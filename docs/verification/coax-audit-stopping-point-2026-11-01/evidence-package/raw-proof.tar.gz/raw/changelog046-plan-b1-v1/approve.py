#!/usr/bin/env python3
"""Install precisely two author-reviewed raw renders; never captures or commits."""
import argparse,hashlib,json,os,pathlib,time
from workflow import verify,sha,write
p=argparse.ArgumentParser();p.add_argument('directory');p.add_argument('review_note');a=p.parse_args();d=pathlib.Path(a.directory).resolve();c=json.loads((d/'config.json').read_text());r=json.loads((d/'capture.json').read_text());note_path=pathlib.Path(a.review_note).resolve();note=json.loads(note_path.read_text());assert r['outcome']=='captured-for-author-review';assert note.get('reviewed')is True and type(note.get('reason'))is str and note['reason'].strip(),'explicit author review note required';assert not(d/'approval.json').exists(),'approval already retained'
verify(c,d,'approval-provenance-before',time.monotonic()+120)
root=pathlib.Path(c['repo']);gold=root/'coax/web/goldens';names={'coax-changelog','coax-changelog-phone'};rows=r['actual_captures']['artifacts'];assert {x['name']for x in rows}==names
before={str(x):sha(x)for x in gold.rglob('*.png')}
for row in rows:
 source=pathlib.Path(row['path']);target=gold/(row['name']+'.png');assert source.is_file() and not source.is_symlink() and sha(source)==row['sha256'];assert note.get(row['name']+'_sha256')==row['sha256'],'review note does not bind this exact capture';assert before[str(target)]==r['old_goldens_sha256'][str(target)],'peer golden changed; review rather than overwrite'
for row in rows:
 target=gold/(row['name']+'.png');temporary=target.with_suffix('.a1-review.tmp');assert not temporary.exists();temporary.write_bytes(pathlib.Path(row['path']).read_bytes());os.replace(temporary,target)
after={str(x):sha(x)for x in gold.rglob('*.png')};changed={path for path in before if before[path]!=after[path]};assert changed<={str(gold/(n+'.png'))for n in names} and before.keys()==after.keys()
write(d/'approval.json',{'scope':'Copied exactly the two raw author-reviewed captures. No pixel editing, rerender, unrelated golden update, Git or deployment. A later comparison uses these changed golden inputs.','review_note':str(note_path),'review_note_sha256':sha(note_path),'changed':sorted(changed),'goldens_sha256':{str(gold/(n+'.png')):after[str(gold/(n+'.png'))]for n in sorted(names)}})
print('Exactly two reviewed golden paths are prepared for the author’s own commit; inspect git diff and retain approval.json.')
