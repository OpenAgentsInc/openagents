// Artifact capture only. The existing goldens.ts performs start/draw/error checks.
import {writeFileSync,rmSync} from 'node:fs';
const [repo,base,out]=process.argv.slice(2);
const {startChrome}=await import(repo+'/coax/web/chrome.ts');
const c=await startChrome('coax-046-review-',['--window-size=1280,800']);
let ws:WebSocket|undefined;
try{
 const pages=await(await fetch(`http://127.0.0.1:${c.port}/json/list`)).json();
 ws=new WebSocket(pages.find((x:any)=>x.type==='page').webSocketDebuggerUrl);
 await new Promise<void>(r=>ws!.addEventListener('open',()=>r(),{once:true}));
 let id=0;const pending=new Map<number,(x:any)=>void>();
 ws.addEventListener('message',e=>{const x=JSON.parse(String(e.data));if(x.id){pending.get(x.id)?.(x);pending.delete(x.id);}});
 const send=(method:string,params:any={})=>new Promise<any>((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>{pending.delete(n);reject(Error('CDP timeout '+method));},20000);pending.set(n,x=>{clearTimeout(timer);x.error?reject(Error(JSON.stringify(x.error))):resolve(x.result)});ws!.send(JSON.stringify({id:n,method,params}));});
 const evaluate=async(expression:string)=>(await send('Runtime.evaluate',{expression,returnByValue:true})).result?.value;
 await send('Page.enable');await send('Runtime.enable');
 await send('Page.addScriptToEvaluateOnNewDocument',{source:'globalThis.coaxialGolden=true;Object.defineProperty(Navigator.prototype,"sendBeacon",{value:()=>false});'});
 const artifacts=[];
 for(const[name,width,height]of[['coax-changelog',1280,800],['coax-changelog-phone',390,844]]as const){
  await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:base+'/coax/changelog'});
  const deadline=Date.now()+30000;let ready=false;
  while(Date.now()<deadline){if(await evaluate('location.pathname==="/coax/changelog"&&globalThis.coaxial?.ready===true&&document.querySelector("canvas")?.width>0')){ready=true;break;}await Bun.sleep(100);}
  if(!ready)throw Error('capture engine readiness '+name);
  await Bun.sleep(1200);
  const r=await send('Page.captureScreenshot',{format:'png'});const bytes=Buffer.from(r.data,'base64');const path=out+'/'+name+'.png';writeFileSync(path,bytes);artifacts.push({name,path,width,height,dpr:1,mobile:false,bytes:bytes.length,sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')});
 }
 writeFileSync(out+'/captures.json',JSON.stringify({scope:'Raw desktop/phone review captures, no golden approval or comparison verdict.',artifacts},null,2)+'\n');
}finally{
 try{ws?.close();}catch{}
 try{
  if(c.proc.exitCode===null)c.proc.kill();
  await Promise.race([c.proc.exited,Bun.sleep(5000)]);
  if(c.proc.exitCode===null){process.kill(c.proc.pid,'SIGKILL');await c.proc.exited;}
 }finally{rmSync(c.profile,{recursive:true,force:true});}
}
