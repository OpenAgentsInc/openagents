#!/usr/bin/env python3
"""Prepared bounded comparison of exactly two approved local Mac baselines."""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import subprocess
import time
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
NAMES = {'coax-changelog', 'coax-changelog-phone'}
FLAGS = ['timeout', 'deadline_exhausted', 'stdout_limit', 'stderr_limit',
         'output_limit', 'group_killed', 'kill_errno', 'launch_errno',
         'launch_error', 'read_errno']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def clean(observation):
    return (observation['started'] and observation['returncode'] == 0
            and observation['stdout_eof'] and observation['stderr_eof']
            and not any(observation.get(key) for key in FLAGS))


def pin(path, expected):
    assert path.is_file() and not path.is_symlink() and sha(path) == expected, str(path)


def inner(args):
    directory = Path(args.directory).resolve()
    output = Path(args.output).resolve()
    expected = {'config.json': args.config_sha256, 'staged.json': args.staged_sha256,
                'capture.json': args.capture_sha256, 'approval.json': args.approval_sha256}
    for name, digest in expected.items():
        pin(directory/name, digest)
    config = json.loads((directory/'config.json').read_bytes())
    root = Path(config['repo']).resolve()
    workflow = runpy.run_path(str(HERE/'workflow.py'))
    command = workflow['command']
    bounded = workflow['start_session'](root)
    pin(Path('/bin/ps'), args.ps_sha256)
    pin(Path(__file__).resolve(), config['inputs'][str(Path(__file__).resolve())])
    started = time.monotonic()
    deadline = started + 840
    approval = json.loads((directory/'approval.json').read_bytes())
    capture = json.loads((directory/'capture.json').read_bytes())
    note_path = Path(approval['review_note']).resolve()
    pin(note_path, approval['review_note_sha256'])
    note = json.loads(note_path.read_bytes())
    assert note['reviewed'] is True and isinstance(note['reason'], str) and note['reason'].strip()
    assert capture['outcome'] == 'captured-for-author-review'
    rows = capture['actual_captures']['artifacts']
    assert len(rows) == 2 and {row['name'] for row in rows} == NAMES
    gold = root/'coax/web/goldens'
    assert set(approval['goldens_sha256']) == {str(gold/(name+'.png')) for name in NAMES}
    for row in rows:
        name = row['name']
        original = Path(row['path']).resolve()
        assert original == (directory/'review'/(name+'.png')).resolve()
        pin(original, row['sha256'])
        assert sha(gold/(name+'.png')) == row['sha256'] == note[name+'_sha256']
        assert approval['goldens_sha256'][str(gold/(name+'.png'))] == row['sha256']
    staged = json.loads((directory/'staged.json').read_bytes())
    for relative, digest in staged['files_sha256'].items():
        target = (directory/'site'/relative).resolve()
        assert target.is_relative_to((directory/'site').resolve())
        pin(target, digest)
    before = {str(path): sha(path) for path in gold.rglob('*.png')}
    workflow['verify'](config, output, 'post-approval-provenance-before', deadline)
    command(root, output, 'golden-diff-before', ['git', 'diff', '--name-only'], root, deadline)
    changed = {str(Path(name).resolve().relative_to(root)) for name in approval['changed']}
    assert set((output/'golden-diff-before.stdout').read_text().splitlines()) == changed
    assert changed <= {str(Path('coax/web/goldens')/(name+'.png')) for name in NAMES}, 'only approved two golden inputs may be dirty'
    ownership = []
    cleanup_observations = []
    server = None
    report = None

    def inventory(label, until):
        observation = bounded.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,uid=,stat='],
                                  cwd=str(root), env=None, timeout_s=min(5, max(0, until-time.monotonic())),
                                  max_output_bytes=1048576, deadline=until, quiet_faults=False)
        stdout, stderr = observation.pop('stdout'), observation.pop('stderr')
        (output/(label+'.stdout')).write_bytes(stdout)
        (output/(label+'.stderr')).write_bytes(stderr)
        value = {'process': observation, 'stdout_sha256': sha(output/(label+'.stdout')),
                 'stderr_sha256': sha(output/(label+'.stderr')), 'matching': [], 'uncertain': []}
        write(output/(label+'.json'), value)
        assert clean(observation) and not stderr, 'numeric process inventory unavailable'
        identifiers = {row['sid'] for row in ownership}
        for line in stdout.decode().splitlines():
            fields = line.split()
            assert len(fields) == 5
            pid, ppid, pgid, uid = map(int, fields[:4])
            sid = None
            if uid == os.getuid():
                try:
                    sid = os.getsid(pid)
                except ProcessLookupError:
                    continue
                except OSError as error:
                    value['uncertain'].append({'pid': pid, 'errno': error.errno})
            if pgid in identifiers or sid in identifiers:
                value['matching'].append({'pid': pid, 'ppid': ppid, 'pgid': pgid,
                                          'sid': sid, 'uid': uid, 'state': fields[4]})
        write(output/(label+'.json'), value)
        pin(Path('/bin/ps'), args.ps_sha256)
        cleanup_observations.append({'path': str(output/(label+'.json')), 'sha256': sha(output/(label+'.json'))})
        return value

    def signal_original_group(owned, sig, facts):
        rows = [row for row in facts['matching'] if row['pgid'] == owned['pgid']]
        if not rows:
            return {'pgid': owned['pgid'], 'signal': None, 'reason': 'no matching numeric group members'}
        # An exited/reaped comparison leader cannot later reappear as our child.
        # Do not mistake a reused leader PID for ownership of a new session.
        if owned['reaped'] and any(row['pid'] == owned['pid'] for row in rows):
            return {'pgid': owned['pgid'], 'signal': None, 'ownership_uncertain': 'reused/uncertain session leader'}
        if not all(row['uid'] == os.getuid() and row['sid'] == owned['sid'] for row in rows):
            return {'pgid': owned['pgid'], 'signal': None, 'ownership_uncertain': 'numeric UID/SID/group mismatch'}
        live = 0
        for row in rows:
            try:
                if os.getpgid(row['pid']) != owned['pgid'] or os.getsid(row['pid']) != owned['sid']:
                    return {'pgid': owned['pgid'], 'signal': None, 'ownership_uncertain': 'ownership changed during reobservation'}
                live += 1
            except ProcessLookupError:
                continue
            except OSError as error:
                return {'pgid': owned['pgid'], 'signal': None, 'uncertain_errno': error.errno}
        if not live:
            return {'pgid': owned['pgid'], 'signal': None, 'reason': 'members disappeared; later inventory required'}
        try:
            os.killpg(owned['pgid'], sig)
            return {'pgid': owned['pgid'], 'signal': int(sig), 'sent': True}
        except ProcessLookupError:
            return {'pgid': owned['pgid'], 'signal': int(sig), 'sent': False, 'reason': 'lookup raced; later inventory required'}
        except OSError as error:
            return {'pgid': owned['pgid'], 'signal': int(sig), 'sent': False, 'uncertain_errno': error.errno}

    try:
        ready = output/'server-ready.json'
        with (output/'server.log').open('xb') as log:
            server = subprocess.Popen(['bun', str(HERE/'serve.ts'), str(directory/'site'), str(ready)],
                                      cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        ownership.append({'kind': 'server', 'pid': server.pid, 'pgid': server.pid,
                          'sid': server.pid, 'uid': os.getuid(), 'reaped': False})
        assert os.getpgid(server.pid) == server.pid and os.getsid(server.pid) == server.pid
        write(output/'ownership.json', ownership)
        until = min(deadline, time.monotonic()+15)
        while not ready.exists():
            assert time.monotonic() < until, 'owned local server readiness deadline'
            time.sleep(.05)
        ready_value = json.loads(ready.read_bytes())
        url = urlsplit(ready_value['base'])
        assert ready_value['pid'] == server.pid and url.scheme == 'http'
        assert url.hostname == 'golden.localhost' and url.port == ready_value['port']
        command(root, output, 'approved-baseline-comparison',
                ['bun', root/'coax/web/goldens.ts', ready_value['base'], '--full', '--only',
                 ','.join(sorted(NAMES)), '--report', output/'comparison-report.json'],
                root, deadline, env=workflow['browser_environment']())
        report = json.loads((output/'comparison-report.json').read_bytes())
        assert report['failed'] == report['golden'] == report['other'] == []
        lines = (output/'approved-baseline-comparison.stdout').read_text()
        lanes = re.findall(r'^lane ([^ ]+) \(', lines, re.M)
        assert len(lanes) == 2 and set(lanes) == NAMES, 'exact two actual comparison lanes required'
        assert before == {str(path): sha(path) for path in gold.rglob('*.png')}, 'comparison changed a golden'
        for name, digest in expected.items():
            pin(directory/name, digest)
        workflow['verify'](config, output, 'post-approval-provenance-after', deadline)
    finally:
        comparison = output/'approved-baseline-comparison.json'
        if comparison.is_file():
            pid = json.loads(comparison.read_bytes())['observation'].get('pid')
            if pid is not None:
                ownership.append({'kind': 'comparison', 'pid': pid, 'pgid': pid,
                                  'sid': pid, 'uid': os.getuid(), 'reaped': True})
        write(output/'ownership.json', ownership)
        cleanup_deadline = time.monotonic()+20
        facts = inventory('cleanup-before', cleanup_deadline)
        signals = [signal_original_group(row, signal.SIGTERM, facts) for row in ownership]
        write(output/'cleanup-signals.json', signals)
        wait_until = min(cleanup_deadline, time.monotonic()+5)
        while time.monotonic() < wait_until:
            if server is not None and server.returncode is None:
                try:
                    server.wait(timeout=.1)
                    ownership[0]['reaped'] = True
                except subprocess.TimeoutExpired:
                    pass
            facts = inventory('cleanup-wait-'+str(len(cleanup_observations)), cleanup_deadline)
            if not facts['matching'] and not facts['uncertain']:
                break
            time.sleep(.1)
        if facts['matching'] and not facts['uncertain']:
            signals += [signal_original_group(row, signal.SIGKILL, facts) for row in ownership]
            write(output/'cleanup-signals.json', signals)
        if server is not None and server.returncode is None:
            server.wait(timeout=min(5, max(0, cleanup_deadline-time.monotonic())))
            ownership[0]['reaped'] = True
        final = inventory('cleanup-after', cleanup_deadline)
        write(output/'cleanup.json', {'ownership': ownership, 'signals': signals,
                                     'observations': cleanup_observations,
                                     'remaining': final['matching'], 'uncertain': final['uncertain'],
                                     'scope': 'Only exact process groups created above, with same-UID actual SID/group revalidation. No killpg0 or command-line matching.'})
        assert not final['matching'] and not final['uncertain'], 'owned cleanup absent proof is incomplete'
        assert not any(row.get('uncertain_errno') is not None or row.get('ownership_uncertain') for row in signals), 'signal/ownership remains uncertain'
    assert time.monotonic()-started < 870
    write(output/'qualification.json', {
        'schema': 'coax.changelog046.approved-baseline-comparison.v1', 'outcome': 'passed',
        'count': 2, 'names': sorted(NAMES), 'producer': config['compiler_sha256'],
        'fingerprint': config['fingerprint'], 'normal': config['qualification'],
        'head': config['source_revision'], 'approval_sha256': args.approval_sha256,
        'capture_sha256': args.capture_sha256, 'staged_site_sha256': args.staged_sha256,
        'report': report, 'cleanup': {'path': str(output/'cleanup.json'), 'sha256': sha(output/'cleanup.json')},
        'inputs': expected, 'artifacts': {str(path): sha(path) for path in output.rglob('*') if path.is_file()},
        'scope': 'Fresh exactly-two-view approved-baseline comparison and owned-session cleanup. Original mismatch/capture/Root review remain separate. No recapture, update, commit, deployment or broader site claim.'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory')
    parser.add_argument('--output', required=True)
    for name in ('config', 'staged', 'capture', 'approval'):
        parser.add_argument('--'+name+'-sha256', required=True)
    parser.add_argument('--ps-sha256', required=True)
    parser.add_argument('--inner', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.inner:
        inner(args)
        return
    directory = Path(args.directory).resolve()
    output = Path(args.output).resolve()
    assert not output.exists() and output.is_relative_to(directory), 'fresh output under local capture only'
    output.mkdir(parents=True)
    config = json.loads((directory/'config.json').read_bytes())
    pin(directory/'config.json', args.config_sha256)
    root = Path(config['repo']).resolve()
    sys.path.insert(0, str(root/'coax/tools'))
    import bounded_process
    start = time.monotonic()
    observation = bounded_process.run([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:], '--inner'],
                                      cwd=str(root), env=None, timeout_s=870, max_output_bytes=8388608,
                                      deadline=start+870, quiet_faults=True)
    for name in ('stdout', 'stderr'):
        raw = observation.pop(name)
        path = output/('outer.'+name)
        path.write_bytes(raw)
        observation[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(path)}
    passed = clean(observation)
    write(output/'outer.json', {'schema': 'coax.changelog046.post-approval-transport.v1',
                               'observation': observation, 'transport_ok': passed,
                               'runner_sha256': sha(__file__)})
    print(json.dumps({'transport_ok': passed, 'qualification': str(output/'qualification.json'),
                      'transport': str(output/'outer.json')}))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
