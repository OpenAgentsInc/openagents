"""Read-only final-producer proof binding; no effects on import.
Exact qualification_binding body copied from reviewed private publisher v2.
Capture accepts only kind=normal; historical image/composition is not a final
producer for this new capture epoch.
"""
import hashlib,json,pathlib,re
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def qualification_binding(c):
 """Bind a reviewed qualification to the exact compiler/support package.

This reads retained records; it never executes a build or rewrites a proof.
A matching image alone cannot qualify a different source fingerprint.
"""
 proof=c['qualification'];assert sha(proof['path'])==proof['sha256'];q=json.loads(pathlib.Path(proof['path']).read_bytes());assert q['outcome']=='passed';expected=c['qualified_files'];assert all(re.fullmatch('[0-9a-f]{64}',h)for h in expected.values());assert expected['mutation-survivors']==hashlib.sha256(b'').hexdigest()
 def pinned(fact):
  p=pathlib.Path(fact['path']);assert p.is_file()and not p.is_symlink()and sha(p)==fact['sha256'],'proof dependency drift';return json.loads(p.read_bytes())
 if proof['kind']=='normal':
  assert q['schema']=='coax.bootstrap.bounded-composition.v1';b=pinned({'path':q['binding'],'sha256':q['binding_sha256']});plan=pinned({'path':q['plan'],'sha256':q['plan_sha256']});assert b['schema']=='coax.bootstrap.bounded-binding.v1'and b['expected_fingerprint']==c['fingerprint'],'normal fingerprint differs';ids=[s['id']for s in plan['steps']];assert ids and len(set(ids))==len(ids)and q['required_steps']==ids and q['passed_steps']==ids and set(q['receipts'])==set(ids),'normal is incomplete'
  last=None
  for ident,planned in zip(ids,plan['steps']):
   row=pinned(q['receipts'][ident]);assert row['schema']=='coax.bootstrap.bounded-statement.v1'and row['step']==planned and row['outcome']=='passed'and row['binding_sha256']==q['binding_sha256']and row['expected_fingerprint']==c['fingerprint']and row['source_revision']==b['source_revision'],'normal receipt identity differs';assert row['strict_mutation_execution']is True and row['fresh_gate_execution']is True and row['gate_cache_reuse']is False and row['changed_line_survivor_tolerance']is False;last=row
  paths={str(pathlib.Path(p).resolve()):h for p,h in last['artifacts_after'].items()};base=pathlib.Path(b['snapshot'])/'coax/bin'
  for name,h in expected.items():assert paths.get(str((base/name).resolve()))==h,'normal final artifact differs '+name
  return {'kind':'normal','fingerprint':b['expected_fingerprint'],'image_sha256':expected['coax'],'binding_sha256':q['binding_sha256'],'final_receipt_sha256':q['receipts'][ids[-1]]['sha256'],'source_revision':b['source_revision']}
 if proof['kind']=='accepted-composition':
  assert q['schema']=='coax.bootstrap.current-policy-composition.v1'and q['qualification_kind']=='explicitly-accepted-qualified-reuse';assert q['current_fingerprint']==c['fingerprint']and q['image_sha256']==expected['coax'],'composition identity differs';assert q['actual_regular_empty_survivor_artifact']is True and q['new_private_record_sha256']==expected['provenance.record'];group=proof['artifact_group'];assert group in ['candidate','target','cache'];assert q['artifacts'][group]['files']==expected,'composition artifact identities differ';accept=pinned(q['acceptance']);draft=pinned(q['accepted_draft']);assert accept['root_accepted']is True and accept['draft_sha256']==q['accepted_draft']['sha256']and accept['current_fingerprint']==c['fingerprint']and accept['image_sha256']==expected['coax']and accept['source_revision']==q['source_revision'];assert draft['current_fingerprint']==c['fingerprint']and draft['image_sha256']==expected['coax']
  return {'kind':'accepted-composition','fingerprint':q['current_fingerprint'],'image_sha256':q['image_sha256'],'acceptance_sha256':q['acceptance']['sha256'],'source_revision':q['source_revision']}
 raise ValueError('unsupported qualification proof kind')
