// Private offline fixture server: no production/staging proxy and no writes.
import { join, normalize } from 'node:path';
import { statSync } from 'node:fs';
const [site, ready] = process.argv.slice(2);
const types:Record<string,string>={html:'text/html; charset=utf-8',md:'text/markdown; charset=utf-8',js:'text/javascript; charset=utf-8',wgsl:'text/plain; charset=utf-8',wasm:'application/wasm',svg:'image/svg+xml'};
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(req){
 const u=new URL(req.url);
 if(u.pathname.startsWith('/api/'))return req.method==='GET'?Response.json(null):new Response(null,{status:204});
 if(req.method!=='GET'&&req.method!=='HEAD')return new Response(null,{status:405});
 let rel=normalize(decodeURIComponent(u.pathname)).replace(/^\/+|\/+$/g,'');
 if(rel.startsWith('..'))return new Response(null,{status:400});
 let path=join(site,rel);
 try{if(statSync(path).isDirectory())path=join(path,'index.html');if(!statSync(path).isFile())throw Error();}
 catch{return new Response('not found',{status:404});}
 return new Response(Bun.file(path),{headers:{'content-type':types[path.split('.').pop()!]||'application/octet-stream','cache-control':'no-store'}});
}});
await Bun.write(ready,JSON.stringify({pid:process.pid,port:server.port,base:`http://golden.localhost:${server.port}`})+'\n');
