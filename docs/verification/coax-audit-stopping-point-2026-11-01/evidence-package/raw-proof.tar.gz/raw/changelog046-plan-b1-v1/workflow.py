#!/usr/bin/env python3
"""Prepared-only B1 local 0.46 changelog workflow. No effects on import."""
import argparse,hashlib,json,os,pathlib,re,shlex,shutil,signal,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
SUPPORT=['check-domains.c','check-domains.h','lexer.c','lexer.h','parser.c','parser.h','checker.c','checker.h','sources.c','sources.h','proto_runtime.inc','proto_importer.c','proto_importer.h','mutation-survivors']
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def start_session(root):
 sys.path.insert(0,str(root/'coax/tools'));import bounded_process
 return bounded_process
def command(root,d,label,argv,cwd,deadline,env=None,output=None,allowed=(0,)):
 log=d/(label+'.json');assert not log.exists(),'never repeat a retained step'
 b=start_session(root);r=b.run(list(map(str,argv)),str(cwd),env,min(300,max(1,deadline-time.monotonic())),8388608,deadline,quiet_faults=True)
 out=r.pop('stdout');err=r.pop('stderr');op=d/(label+'.stdout');ep=d/(label+'.stderr');op.write_bytes(out);ep.write_bytes(err)
 if output is not None:output.write_bytes(out)
 good=r['started'] and r['returncode'] in allowed and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k)for k in ['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'])
 write(log,{'argv':list(map(str,argv)),'cwd':str(cwd),'observation':r,'stdout':str(op),'stdout_sha256':sha(op),'stderr':str(ep),'stderr_sha256':sha(ep),'transport_ok':good})
 assert good,'step failed: '+label;return r

def verify(c,d,label,deadline):
 root=pathlib.Path(c['repo']);compiler=pathlib.Path(c['compiler'])
 assert sha(compiler)==c['compiler_sha256'],'compiler changed'
 from producer_binding import qualification_binding
 assert c['qualification']['kind']=='normal'and sha(c['qualification']['path'])==c['qualification']['sha256'];binding=qualification_binding(c);assert binding['source_revision']==c['source_revision'],'qualified source revision differs'
 for name,h in c['qualified_files'].items():
  q=compiler.parent/name;assert q.is_file()and not q.is_symlink()and sha(q)==h,'final compiler package changed '+name
 if (d/'wasm-toolchain.json').is_file():
  facts=json.loads((d/'wasm-toolchain.json').read_bytes())
  for name,h in facts['files_sha256'].items():assert sha(name)==h,'Wasm toolchain subset changed '+name
 for p,h in c['inputs'].items():assert pathlib.Path(p).is_file() and sha(p)==h,'source/tool input changed: '+p
 for tool in c['tools'].values():
  current=shutil.which(tool['logical']);assert current and str(pathlib.Path(current).resolve())==tool['resolved'],'tool resolution changed: '+tool['logical']
  assert sha(current)==tool['sha256'],'tool bytes changed: '+tool['logical']
 assert {key:os.environ.get(key)for key in c['environment']}==c['environment'],'capture build environment changed'
 command(root,d,label+'-source-head',['git','rev-parse','HEAD'],root,deadline)
 assert(d/(label+'-source-head.stdout')).read_text().strip()==c['source_revision'],'capture source HEAD changed'
 command(root,d,label,[root/'coax/provenance.sh','verify',root,compiler,c['helper'],c['provenance']],root,deadline)

def native_tool(c,d,source,name,deadline):
 root=pathlib.Path(c['repo']);p=root/'coax/platform';work=d/'native';work.mkdir(exist_ok=True);compiler=pathlib.Path(c['compiler'])
 assert (work/'entropy.c').is_file() and (work/'entropy-policy.h').is_file(),'fresh same-producer shared entropy artifacts are required'
 command(root,d,name+'-c',[compiler,'c',source,'--library'],root,deadline,output=work/(name+'.c'))
 cc=['/usr/bin/clang','-D_DARWIN_C_SOURCE']if sys.platform=='darwin'else[os.environ.get('CC','gcc'),'-D_DEFAULT_SOURCE'];libs=['-framework','Security']if sys.platform=='darwin'else['-lpthread']
 command(root,d,name+'-link',[*cc,'-std=c11','-O2','-I'+str(work),'-I'+str(p),'-o',work/name,work/(name+'.c'),p/'tool-native.c',p/'process-native.c',p/'store-file-native.c',p/'socket-native.c',p/'entropy-native.c',p/'entropy-foreign.c',work/'entropy.c',*libs,'-lm'],root,deadline)
 return work/name

def fresh_entropy(c,d,deadline):
 # A new semantic compiler producer cannot inherit the old5c common verdict.
 # Emit once for this epoch, then share the exact C/header between both tools.
 root=pathlib.Path(c['repo']);work=d/'native';compiler=pathlib.Path(c['compiler']);profile=work/'entropy-profile.json'
 command(root,d,'entropy-module-c',[compiler,'c',root/'coax/lib/crypto/entropy.coax','--library','--arithmetic','checked','--header',work/'entropy-policy.h','--profile-report',profile],root,deadline,output=work/'entropy.c')
 m=json.loads(profile.read_bytes());assert m['schema_version']==1 and m['command']=='c'and m['backend']=='c11'and m['success']is True and m['exit_status']==0 and m['runtime_arithmetic']=='checked'and m['interpreter_arithmetic']=='checked'
 assert m['emitted_sha256']==m['artifact_sha256']==sha(work/'entropy.c') and type(m['sources'])is list and m['sources']and m['descriptors']==[]
 for fact in m['sources']:
  path=pathlib.Path(fact['path']);path=path if path.is_absolute()else root/path;assert path.is_file()and sha(path)==fact['sha256'],'entropy consumed source drift';c['inputs'][str(path.resolve())]=fact['sha256']
 for path in [work/'entropy.c',work/'entropy-policy.h',profile]:c['inputs'][str(path)]=sha(path)
 c['fresh_entropy']={'compiler_sha256':c['compiler_sha256'],'fingerprint':c['fingerprint'],'profile':str(profile),'profile_sha256':sha(profile),'c_sha256':sha(work/'entropy.c'),'header_sha256':sha(work/'entropy-policy.h'),'scope':'One actual fresh same-producer entropy emission, reused within this capture epoch only; no historical common scope is relabeled.'}
 write(d/'config.json',c)

def prepare(a):
 root=pathlib.Path(a.repo).resolve();compiler=pathlib.Path(a.compiler).resolve();d=pathlib.Path(a.directory).resolve();assert compiler.name=='coax','use the final normally qualified coax, never stage0';assert sha(compiler)==a.compiler_sha256;epoch=json.loads((HERE/'source-epoch.json').read_bytes())
 for rel,h in epoch['critical_files'].items():assert sha(root/rel)==h,'review current rendering/build source drift before capture: '+rel
 text=(root/'coax/CHANGELOG.md').read_text();first=re.search(r'^## (.+)\n(?:.|\n)*?^Commit: \[`([0-9a-f]{40})`\]',text,re.M);assert first and first[1].startswith('0.46.0 — Returned Borrow Summaries —')and first[2]==a.introduction,'actual final0.46 introduction must be explicitly supplied after rebase/metadata';assert sys.platform=='darwin','this fixture qualifies the two Mac goldens only';assert not d.exists() and not d.is_relative_to(root),'fresh directory outside checkout required';d.mkdir(parents=True);deadline=time.monotonic()+840
 specific=['coax/tools/bounded_process.py','coax/tests/quiet_crash.py','coax/CHANGELOG.md','coax/release.coax','coax/provenance.sh','coax/web/wasm.sh','coax/web/toolchain.sh','coax/web/goldens.ts','coax/web/golden-pages.ts','coax/web/golden-policy.ts','coax/web/chrome.ts','coax/web/analytics-contract.json','apps/openagents-web/realms.json','apps/openagents-web/changelog.coax','apps/openagents-web/font.coax','apps/openagents-web/analytics.coax','apps/openagents-web/changelog-face.c','apps/openagents-web/analytics-face.h','apps/openagents-web/gpu/changelog.coax','apps/openagents-web/gpu/changelog.module','apps/openagents-web/gpu/changelog.bindings','apps/openagents-web/favicon.svg']
 inputs={root/p for p in specific if(root/p).is_file()};inputs.update((root/'coax').glob('*.coax'));inputs.update((root/'coax/lib').rglob('*.coax'));inputs.update((root/'coax/platform').glob('*.[ch]'));inputs.update((root/'coax/web').glob('*.coax'));inputs.update((root/'coax/web').glob('*.json'));inputs.update((root/'coax/web').glob('*.js'));inputs.update((root/'coax/web').glob('*.ts'));inputs.update((root/'verse/gpu').rglob('*.coax'));inputs.update(HERE.glob('*'))
 tools={}
 for name,logical in [('bun','bun'),('native-cc','/usr/bin/clang'),('python3','python3'),('chrome',os.environ.get('CHROME','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'))]:
  found=shutil.which(logical);assert found,'required tool missing: '+name;tools[name]={'logical':logical,'resolved':str(pathlib.Path(found).resolve()),'sha256':sha(found)}
 environment={key:os.environ.get(key)for key in ['PATH','CHROME','CHROME_START_WAIT_MS','CC','COAX_CC','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET','COAXIAL_CLANG','COAXIAL_SYSROOT','COAXIAL_RESOURCES','COAXIAL_TOOLCHAIN','GOLDENS_POOL','GOLDENS_CHROMES','GOLDENS_FULL','GOLDENS_PENDING','BLOCK','SHADE','GOLDEN_PAGES_ROOT','GOLDENS_PLATFORM','PERF_CONTROL']}
 proof=pathlib.Path(a.qualification).resolve();assert sha(proof)==a.qualification_sha256;package={name:sha(compiler.parent/name)for name in ['coax','provenance-check','provenance.record',*SUPPORT]};record=compiler.with_name('provenance.record').read_text().splitlines();assert len(record)==4 and record[1]==a.fingerprint and record[2]==a.compiler_sha256;inputs.update([proof,compiler.with_name('provenance-check'),compiler.with_name('provenance.record')])
 work=d/'native';work.mkdir()
 c={'fingerprint':a.fingerprint,'qualified_files':package,'qualification':{'kind':'normal','path':str(proof),'sha256':a.qualification_sha256},'source_revision':a.source_revision,'expected_introduction':a.introduction,'prepared_source_epoch':epoch,'repo':str(root),'compiler':str(compiler),'compiler_sha256':sha(compiler),'helper':str(compiler.with_name('provenance-check')),'provenance':str(compiler.with_name('provenance.record')),'inputs':{str(p):sha(p)for p in sorted(inputs)if p.is_file()},'tools':tools,'environment':environment,'scope':'Fresh B1 qualified-producer private local changelog preparation. No historical common reuse, repo edits or deployment.'};write(d/'config.json',c);verify(c,d,'prepare-provenance-before',deadline)
 r=command(root,d,'version',[compiler,'version'],root,deadline);assert(d/'version.stdout').read_text().strip()=='coax0 0.46.0','matched0.46 compiler required'
 fresh_entropy(c,d,deadline)
 snap=d/'snapshot';(snap/'coax/bin').mkdir(parents=True);(snap/'apps/openagents-web/coax/changelog').mkdir(parents=True);shutil.copy2(compiler,snap/'coax/bin/coax');assert sha(snap/'coax/bin/coax')==c['compiler_sha256']
 for p in specific:
  if(root/p).is_file():q=snap/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,q)
 shutil.copytree(root/'coax/lib',snap/'coax/lib');shutil.copytree(root/'verse/gpu',snap/'verse/gpu')
 gen=native_tool(c,d,'coax/web/changelog-page.coax','changelog-page',deadline);command(root,d,'generate',[gen,'--write'],snap,deadline);command(root,d,'generated-check',[gen,'--check'],snap,deadline)
 wgsl=native_tool(c,d,'coax/web/wgsl-module.coax','wgsl-module',deadline);command(root,d,'wgsl',[wgsl,'apps/openagents-web/gpu/changelog.coax','apps/openagents-web/changelog.wgsl','apps/openagents-web/gpu/changelog.module'],snap,deadline)
 verify(c,d,'prepare-provenance-after',deadline);write(d/'prepared.json',{'outcome':'passed','compiler_sha256':c['compiler_sha256'],'snapshot':str(snap),'snapshot_sha256':{str(p.relative_to(snap)):sha(p)for p in sorted(snap.rglob('*'))if p.is_file()}})
 print('Prepared fresh private generator/product sources from the explicit final qualified producer. Next: workflow.py wasm DIRECTORY')

def browser_environment():
 env=dict(os.environ)
 for name in ['BLOCK','SHADE','GOLDEN_PAGES_ROOT','GOLDENS_PLATFORM','PERF_CONTROL','GOLDENS_POOL','GOLDENS_CHROMES']:env.pop(name,None)
 return env

def observe_wasm_toolchain(c,d,deadline):
 # Actual observations occur only during the later explicitly cued Wasm phase.
 # Static archives/CRT subset is not a whole-SDK/backend manifest.
 root=pathlib.Path(c['repo']);script='source "$1"; python3 -c \'import json,os;print(json.dumps({k:os.environ[k] for k in ["COAXIAL_CLANG","COAXIAL_SYSROOT","COAXIAL_RESOURCES","PATH"]}))\''
 command(root,d,'wasm-toolchain-environment',['bash','-c',script,'capture-toolchain',root/'coax/web/toolchain.sh'],root,deadline)
 envfacts=json.loads((d/'wasm-toolchain-environment.stdout').read_bytes());env={**os.environ,**envfacts};clang=pathlib.Path(envfacts['COAXIAL_CLANG']).resolve();assert clang.is_file();command(root,d,'wasm-clang-version',[clang,'--version'],root,deadline,env=env)
 command(root,d,'wasm-linker-resolution',[clang,'--target=wasm32-wasip1','-print-prog-name=wasm-ld'],root,deadline,env=env);name=(d/'wasm-linker-resolution.stdout').read_text().strip();resolved=shutil.which(name,path=envfacts['PATH']);assert resolved,'actual clang-selected Wasm linker is unavailable';linker_alias=pathlib.Path(resolved);linker=linker_alias.resolve();command(root,d,'wasm-linker-version',[linker_alias,'--version'],root,deadline,env=env)
 files={str(clang):sha(clang),str(linker):sha(linker),str(linker_alias):sha(linker_alias)}
 for key in ['COAXIAL_SYSROOT','COAXIAL_RESOURCES']:
  base=pathlib.Path(envfacts[key]).resolve();assert base.is_dir()
  for pattern in ['*.a','*.o']:
   for p in (base/'lib').rglob(pattern):
    assert len(files)<4096,'Wasm subset inventory bound';files[str(p.resolve())]=sha(p)
 write(d/'wasm-toolchain.json',{'scope':'Actual effective cross-Clang/linker versions/paths and bounded static-archive/CRT hashes only. Not a complete SDK/device/target manifest.','effective_environment':envfacts,'linker_identity':{'selected_alias':str(linker_alias),'physical_program':str(linker),'physical_sha256':sha(linker),'version_argv':[str(linker_alias),'--version']},'files_sha256':files})

def wasm(a):
 d=pathlib.Path(a.directory).resolve();c=json.loads((d/'config.json').read_text());root=pathlib.Path(c['repo']);deadline=time.monotonic()+840;snap=d/'snapshot';assert(d/'prepared.json').is_file();assert not(d/'staged.json').exists();verify(c,d,'wasm-provenance-before',deadline)
 for p,h in json.loads((d/'prepared.json').read_text())['snapshot_sha256'].items():assert sha(snap/p)==h,'private source changed: '+p
 observe_wasm_toolchain(c,d,deadline)
 target=snap/'apps/openagents-web/build/changelog.wasm';assert not target.exists(),'fresh wasm required';env={**os.environ,'COAX':str(snap/'coax/bin/coax'),'COAXIAL_MODE':'release'};env.pop('COAXIAL_RUN_STEPS',None)
 command(root,d,'wasm',['bash',snap/'coax/web/wasm.sh','apps/openagents-web/changelog.coax','apps/openagents-web/changelog-face.c',target],snap,deadline,env=env)
 site=d/'site';(site/'coaxial').mkdir(parents=True);command(root,d,'host-bundle',['bun','build',root/'coax/web/host.js','--target','browser','--format','esm','--outfile',site/'coaxial/host.js'],root,deadline)
 def asset(p,rel):
  p=pathlib.Path(p);stem,ext=os.path.splitext(rel);named=stem+'.'+sha(p)[:12]+ext;q=site/named;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);return'/'+named
 host=asset(site/'coaxial/host.js','coaxial/host.js');w=asset(target,'build/changelog.wasm');g=asset(snap/'apps/openagents-web/changelog.wgsl','build/changelog.wgsl')
 html=(snap/'apps/openagents-web/coax/changelog/index.html').read_text();old='<script type="module" src="/coaxial/host.js" data-app="changelog">';new=f'<link rel="preload" href="{w}" as="fetch" crossorigin><script type="module" src="{host}" data-app="changelog" data-wasm="{w}" data-wgsl="{g}">';assert html.count(old)==1;html=html.replace(old,new)
 q=site/'coax/changelog';q.mkdir(parents=True);(q/'index.html').write_text(html);shutil.copy2(snap/'apps/openagents-web/coax/changelog/index.md',q/'index.md');assert(q/'index.md').read_bytes()==(root/'coax/CHANGELOG.md').read_bytes()
 if(snap/'apps/openagents-web/favicon.svg').is_file():shutil.copy2(snap/'apps/openagents-web/favicon.svg',site/'favicon.svg')
 verify(c,d,'wasm-provenance-after',deadline);write(d/'staged.json',{'outcome':'passed','scope':'Changelog-only local fixture; not full deploy.sh/site qualification. Host bundle/content naming follows deploy.sh; server has no live API proxy.','files_sha256':{str(p.relative_to(site)):sha(p)for p in sorted(site.rglob('*'))if p.is_file()},'wasm':str(target),'wasm_sha256':sha(target)});print('Fresh Wasm/host/shader/page staged. Next: workflow.py capture DIRECTORY')

def capture(a):
 d=pathlib.Path(a.directory).resolve();c=json.loads((d/'config.json').read_text());root=pathlib.Path(c['repo']);deadline=time.monotonic()+840;assert(d/'staged.json').is_file();assert not(d/'capture.json').exists();verify(c,d,'capture-provenance-before',deadline)
 for p,h in json.loads((d/'staged.json').read_text())['files_sha256'].items():assert sha(d/'site'/p)==h,'staged artifact changed'
 review=d/'review';review.mkdir();names=['coax-changelog','coax-changelog-phone'];gold=root/'coax/web/goldens';before={str(p):sha(p)for p in gold.rglob('*.png')}
 for name in names:shutil.copy2(gold/(name+'.png'),review/(name+'-old.png'))
 ready=d/'server-ready.json';log=(d/'server.log').open('wb');server=subprocess.Popen(['bun',str(HERE/'serve.ts'),str(d/'site'),str(ready)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  until=time.monotonic()+15
  while not ready.exists():
   assert server.poll()is None and time.monotonic()<until,'local server failed';time.sleep(.05)
  base=json.loads(ready.read_text())['base'];r=command(root,d,'old-golden-comparison',['bun',root/'coax/web/goldens.ts',base,'--full','--only',','.join(names),'--report',d/'old-goldens.json'],root,deadline,env=browser_environment(),allowed=(0,1));report=json.loads((d/'old-goldens.json').read_text());assert not report['other'],'startup/draw/error failure, not an intentional golden delta';assert all(x['name']in names for x in report['golden'])
  for line in report['failed']:
   m=re.search(r'^(coax-changelog(?:-phone)?):.*; this shot: ([^)]+)\)',line)
   if m:shutil.copy2(m[2],review/(m[1]+'-comparison.png'))
  command(root,d,'raw-review-captures',['bun',HERE/'capture.ts',root,base,review],root,deadline,env=browser_environment())
  assert before=={str(p):sha(p)for p in gold.rglob('*.png')},'capture changed a golden'
  verify(c,d,'capture-provenance-after',deadline);write(d/'capture.json',{'outcome':'captured-for-author-review','comparison_exit_status':r['returncode'],'comparison_report':str(d/'old-goldens.json'),'actual_captures':json.loads((review/'captures.json').read_text()),'old_goldens_sha256':{p:h for p,h in before.items()if pathlib.Path(p).stem in names},'all_repo_goldens_unchanged':True,'scope':'Intentional old-golden mismatch retained, not relabeled passed. No approval, update, Git or deployment effect.'});print('Review the two PNGs under '+str(review)+' before any golden update.')
 finally:
  try:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=5)
  except ProcessLookupError:pass
  except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
  log.close()

def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='action',required=True);b=s.add_parser('prepare');b.add_argument('repo');b.add_argument('compiler');b.add_argument('directory');b.add_argument('--qualification',required=True);b.add_argument('--qualification-sha256',required=True);b.add_argument('--compiler-sha256',required=True);b.add_argument('--fingerprint',required=True);b.add_argument('--introduction',required=True);b.add_argument('--source-revision',required=True)
 for name in ['wasm','capture']:s.add_parser(name).add_argument('directory')
 a=p.parse_args();globals()[a.action](a)
if __name__=='__main__':main()
