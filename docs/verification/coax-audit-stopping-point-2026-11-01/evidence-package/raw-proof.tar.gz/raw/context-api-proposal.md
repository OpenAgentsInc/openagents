# B1 exact context/report proposal, awaiting Root approval

No source implementation yet; PS source manifest and old-producer RED must freeze first.

```jai
CK_RetainEffect :: struct {
 source:BS_Origin; destination:BS_Origin; value_type:int;
 witness:int; next:int;
}
CK_RetainObservation :: struct {
 kind:u8; owner:int; site:int;
 facts_complete:bool; relation_complete:bool; forbidden:bool; pending:int;
}
CK_RetainCaps :: struct {effects:int; reports:int; work:int;}
CK_retain_caps :: (nodes:int)->CK_RetainCaps #export_c;
```

Append optional CK_Context views `retain_effects:[]CK_RetainEffect` and `retain_reports:[]CK_RetainObservation`; append CK_State `retain_report_count:int`. Return0 count until completed successful pass; failure/rejection leaves0. No separate ambiguous status: CK_run bool/error/fatal identify rejection; report view.count0 identifies disabled observation. A successful incomplete/manual semantic analysis is accepted and publishes explicit false facts/relation rows, not safe-empty. Public reports do not describe private effect-cache layout.

Observation schema1 (native test record identity, not a wire protocol): kind1=concrete procedure, site=owner; kind2=applied call, owner=the concrete containing procedure, site=original call node. Every reported owner/site is index/tag checked before use. Facts describe all known/incomplete store effects, relation includes unresolved local ordering and external pending obligations; identical formal origins stay pending. `pending` is the canonical count of external outlives pairs at that proc/call.

`retain_reports` is staged scratch until committed used count is set once at the end. A consumer reads ONLY that used prefix, never capacity/stale tails/Node.borrow_status. Disabled reports perform no report allocation/copy/fuel work and change no semantic admission budget. A requested short report buffer is explicit E0381 with committed count0; it never suppresses checking. No admitted partial prefix on an E0383/graph/resource failure.

Proposed caps: invalid node count outside1..2147483646 gives allzeros; effects=clamp(nodes*2,128,16384), reports=clamp(nodes,128,16384), work=1048576. Max native effect storage is about6MiB; this is an explicitly bounded additive workspace, not raising A1 query/origin/work limits. Existing literal CK_Context with absent effects uses fixed128-effect fallback; production C++ allocates the Coax cap and passes report view empty unless explicitly requesting observations. Existing64origins/64effects-per-proc/8path/32query-depth/128store-pair limits stay. Large capacity boundaries use scalar Coax admission and native heap; no giant compile-time fixture. Exact cap/multiplier requires Root approval before code.

Append private proc-node cache metadata `retain_head:int`, `retain_count:int`, `retain_mark:u8`, `retain_incomplete:bool`, `retain_relation:bool`. Mark0 unseen/1 active/2 finalized, with separate completeness/relation flags. Concrete nodes clear these with invocation memo-head initialization after cloning; no unrelated-proc global scan per lookup. Private CR_State holds effect/report staging counts/depth; only retain_report_count is committed public. No independent1M fuel allowance: CR helpers tick the same live CB_State. Actual A1 has no production per-declaration fuel reset; declaration-local memo chains prevent the1000-proc regression.

Effect source/destination rows are BS origins in the owning proc namespace. Their value key/frame/type role is checked on every RP conversion; frame is static0 or the owning concrete proc. Pending rows carry source PARAMETER/DESCRIPTOR and destination external PARAMETER/DESCRIPTOR/static. Direct local violations reject before being exported as summary. Repeated pairs dedup without deleting earlier witnesses; every unknown/manual flag is sticky. Recursive active dependency preserves known lower-bound rows plus incomplete; no general recursive fixedpoint.

Address projection has two meanings that MUST stay separate:
- Parameter effect path preserves typed FIELD/owned ELEMENT/wildcard DEREFERENCE for actual caller projection. It is not replaced by descriptor old contents.
- Resolved LOCAL/STATIC backing after a runtime view crossing uses ELEMENT sentinel2147483647, NEVER exact0. This normalized owner path serves ONLY frame-relative lifetime classification; it is not an exact alias or element identity and cannot justify B2 strong updates. Later contained-view crossings query that descriptor prefix again.

Any origin that cannot be represented soundly in existing BS shapes stays incomplete while preserving representable known alternatives. Do not forge precision or append a forbidden LOCAL DEREFERENCE. Source Rhs uses selected descriptor-leaf CB_expr; address uses a distinct typed target/place projection. Definition violation site is original RHS (whole aggregate RHS literal if appropriate); applied violation site is the original call expression. E0366/type/lvalue precedence remains earlier.

Integration proposal: CK_borrow_returns/CB_run after instantiate should retain the same live b and call CR_run only after A1 success; all root procs, hidden check procs and concrete instance chain are inspected even void/uncalled. B2 CB_opaque/local helper-write return-query floors stay unchanged. Only source retention/latent caller obligations belong to B1. Root owns C++ mechanical allocation/transport, seed/header/fixedpoint/normal; PS owns source and report-observer fixtures; author owns Coax algorithms/checks and moves policy into fingerprint inventory.
