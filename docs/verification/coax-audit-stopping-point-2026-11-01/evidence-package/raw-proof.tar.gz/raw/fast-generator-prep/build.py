#!/usr/bin/env python3
"""Unqualified seed-generator relink: one fresh checker object, seven pinned objects."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sys,time
P=Path('/tmp/coax-retained-borrows-B1/preseed-c0f-prefix').resolve()
S=P/'snapshot/coax';W=S/'bin/.bootstrap-bounded-normal'
BASE=Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha')
sys.path[:0]=[str(BASE/'infrastructure/coax/tools'),str(BASE/'infrastructure/coax/tests')]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
def main():
 a=argparse.ArgumentParser();a.add_argument('--checker-c',required=True);a.add_argument('--checker-h',required=True);a.add_argument('--c-sha256',required=True);a.add_argument('--h-sha256',required=True);a.add_argument('--kernel-source-sha256',required=True);a.add_argument('--emission-record',required=True);a.add_argument('--directory',required=True);args=a.parse_args()
 d=Path(args.directory).resolve();assert not d.exists(),'fresh independent output directory required'
 c=Path(args.checker_c).resolve();h=Path(args.checker_h).resolve();e=Path(args.emission_record).resolve()
 assert sha(c)==args.c_sha256 and sha(h)==args.h_sha256
 assert h.read_bytes()==(S/'bootstrap/checker.h').read_bytes(),'changed API header requires Root review'
 binding=json.loads((P/'binding.json').read_text());state=json.loads((P/'state.json').read_text())
 assert len(state['passed'])==13 and state['passed'][-1]=='line-049' and not (P/'active.lock').exists()
 emission=json.loads(e.read_text());assert emission['outcome']=='passed' and emission['source_before']==emission['source_after']
 assert emission['source_before']['/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents/coax/lib/compiler/checker.coax']==args.kernel_source_sha256
 row=next(v for v in emission['rows'] if v['label']=='checker');assert row['stdout_sha256']==sha(c) and clean(row['observation'])
 assert {k:os.environ.get(k) for k in binding['environment']}==binding['environment'],'prefix toolchain environment changed'
 for fact in binding['tool_resolutions'].values():assert str(Path(shutil.which(fact['logical']) or '/missing').resolve())==fact['resolved']
 names=['check-domains','mutation-schedule','budget','profiles','lexer','parser','sources']
 objects={n:W/('seed-'+n+'.o') for n in names}
 for p in objects.values():assert state['artifact_state'][str(p)]==sha(p)
 inputs=[Path(__file__).resolve(),c,h,e,P/'binding.json',P/'state.json',*[S/'bootstrap'/n for n in ['checker.h','parser.h','sources.h','profiles.h','budget.h','check-domains.h','mutation-schedule.h']],*objects.values(),W/'proto_runtime.inc',*[p for p in (S/'src').rglob('*') if p.is_file()],Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[Path(v['resolved']) for v in binding['tool_resolutions'].values()]]
 before={str(p):sha(p) for p in inputs}
 d.mkdir();shutil.copy2(c,d/'checker.c');shutil.copy2(h,d/'checker.h');shutil.copy2(W/'proto_runtime.inc',d/'proto_runtime.inc')
 artifacts={str(d/n):sha(d/n) for n in ['checker.c','checker.h','proto_runtime.inc']}
 r={'schema':'coax.B1.fast-seed-generator.v1','scope':'Unqualified build-only generator, not a normal build or install. Reuses seven exact compiled seed objects/frozen CPP at449; fresh checker kernel from separately pinned old5c emission. No profile support or semantic fallback. Final full165 normal must be all-fresh.','native_cpp_revision':binding['source_revision'],'native_prefix_fingerprint':binding['expected_fingerprint'],'fresh_kernel_source_sha256':args.kernel_source_sha256,'emission_record':str(e),'emission_record_sha256':sha(e),'unchanged_objects':{n:{'path':str(p),'sha256':sha(p)} for n,p in objects.items()},'source_before':before,'artifacts':artifacts,'rows':[],'outcome':'not-checked'}
 started=time.monotonic();deadline=started+840
 def save():
  r['source_after']={str(p):sha(p) for p in inputs};r['inputs_unchanged']=r['source_after']==before;r['artifacts_unchanged']=all(sha(p)==v for p,v in artifacts.items());r['elapsed_s']=time.monotonic()-started;(d/'record.json').write_text(json.dumps(r,indent=2)+'\n')
 cflags=['-std=c11','-O1','-g'];cppflags=['-std=c++20','-O1','-g','-Wall','-Wextra','-Wno-missing-field-initializers']
 if os.environ.get('COAX_HOST_TARGET'):
  cflags+=['-target',os.environ['COAX_HOST_TARGET']];cppflags+=['-target',os.environ['COAX_HOST_TARGET']]
 commands=[('compile-checker',[os.environ.get('CC','cc'),*cflags,'-c',str(d/'checker.c'),'-o',str(d/'seed-checker.o')],d/'seed-checker.o'),('link-generator',[os.environ.get('CXX','c++'),*cppflags,'-DCOAX_BOOTSTRAP_IMPORTER','-I','bootstrap','-I',str(d),'-o',str(d/'stage0'),'src/main.cpp',*[str(objects[n]) for n in names[:-1]],str(d/'seed-checker.o'),str(objects['sources'])],d/'stage0')]
 try:
  for name,argv,output in commands:
   save();assert r['inputs_unchanged'] and r['artifacts_unchanged']
   o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=8388608,deadline=deadline,quiet_faults=True)
   row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
   for stream in ['stdout','stderr']:
    data=row['observation'].pop(stream);p=d/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
   row['transport_clean']=clean(o);r['rows'].append(row);save();assert row['transport_clean'] and r['inputs_unchanged'] and r['artifacts_unchanged'],'native generator build failed'
   assert output.is_file();artifacts[str(output)]=sha(output);save();print(json.dumps({'step':name,'passed':True,'seconds':o['elapsed_s'],'output':str(output),'sha256':sha(output)}),flush=True)
  r['outcome']='passed';r['image']=str(d/'stage0');r['image_sha256']=sha(d/'stage0')
 except BaseException as error:r['outcome']='failed';r['error']=repr(error);raise
 finally:save()
 print(json.dumps({'record':str(d/'record.json'),'record_sha256':sha(d/'record.json'),'unqualified_image':str(d/'stage0'),'image_sha256':sha(d/'stage0')}),flush=True)
if __name__=='__main__':main()
