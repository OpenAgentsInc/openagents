#!/usr/bin/env python3
"""Unqualified final-style producer from exact emitted aggregate/frozen native source."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sys,time
P=Path('/tmp/coax-retained-borrows-B1/preseed-c0f-prefix').resolve();S=P/'snapshot/coax';W=S/'bin/.bootstrap-bounded-normal'
BASE=Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha')
sys.path[:0]=[str(BASE/'infrastructure/coax/tools'),str(BASE/'infrastructure/coax/tests')]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
def main():
 a=argparse.ArgumentParser();a.add_argument('--emission-directory',required=True);a.add_argument('--emission-record-sha256',required=True);a.add_argument('--directory',required=True);args=a.parse_args()
 e=Path(args.emission_directory).resolve();d=Path(args.directory).resolve();assert not d.exists()
 assert sha(e/'record.json')==args.emission_record_sha256
 emission=json.loads((e/'record.json').read_text());assert emission['outcome']=='passed' and emission['inputs_unchanged']
 for p,v in emission['artifacts'].items():assert sha(p)==v
 binding=json.loads((P/'binding.json').read_text());state=json.loads((P/'state.json').read_text());assert len(state['passed'])==13
 assert {k:os.environ.get(k) for k in binding['environment']}==binding['environment']
 for fact in binding['tool_resolutions'].values():assert str(Path(shutil.which(fact['logical']) or '/missing').resolve())==fact['resolved']
 inputs=[Path(__file__).resolve(),e/'record.json',e/'proto_importer.c',e/'proto_importer.h',W/'proto_runtime.inc',*[p for p in (S/'src').rglob('*') if p.is_file()],Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[Path(v['resolved']) for v in binding['tool_resolutions'].values()]]
 before={str(p):sha(p) for p in inputs};d.mkdir()
 for p in [e/'proto_importer.c',e/'proto_importer.h',W/'proto_runtime.inc']:shutil.copy2(p,d/p.name)
 artifacts={str(d/n):sha(d/n) for n in ['proto_importer.c','proto_importer.h','proto_runtime.inc']}
 r={'schema':'coax.B1.unqualified-finalstyle-producer.v1','scope':'Development final-style actual producer with profile support (COAX_BOOTSTRAP_IMPORTER is absent), not a renamed build-only stage0. Exact frozen native449+actual new-emitter aggregate; no normal/provenance/SDK lock/qualification/install claim. Early native observations must retain this actual producer attribution.','native_cpp_revision':binding['source_revision'],'reused_native_prefix_fingerprint':binding['expected_fingerprint'],'emission':str(e/'record.json'),'emission_sha256':sha(e/'record.json'),'source_before':before,'artifacts':artifacts,'rows':[],'outcome':'not-checked'}
 started=time.monotonic();deadline=started+840
 def save():
  r['source_after']={str(p):sha(p) for p in inputs};r['inputs_unchanged']=r['source_after']==before;r['artifacts_unchanged']=all(sha(p)==v for p,v in artifacts.items());r['elapsed_s']=time.monotonic()-started;(d/'record.json').write_text(json.dumps(r,indent=2)+'\n')
 cflags=['-std=c11','-O1','-g'];cppflags=['-std=c++20','-O1','-g','-Wall','-Wextra','-Wno-missing-field-initializers']
 if os.environ.get('COAX_HOST_TARGET'):
  cflags+=['-target',os.environ['COAX_HOST_TARGET']];cppflags+=['-target',os.environ['COAX_HOST_TARGET']]
 commands=[('compile-aggregate',[os.environ.get('CC','cc'),*cflags,'-c',str(d/'proto_importer.c'),'-o',str(d/'proto_importer.o')],d/'proto_importer.o'),('link-finalstyle',[os.environ.get('CXX','c++'),*cppflags,'-I',str(d),'-o',str(d/'coax'),'src/main.cpp',str(d/'proto_importer.o')],d/'coax')]
 try:
  for name,argv,output in commands:
   save();assert r['inputs_unchanged'] and r['artifacts_unchanged']
   o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=8388608,deadline=deadline,quiet_faults=True)
   row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
   for stream in ['stdout','stderr']:
    data=row['observation'].pop(stream);p=d/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
   row['transport_clean']=clean(o);r['rows'].append(row);save();assert row['transport_clean'] and r['inputs_unchanged'] and r['artifacts_unchanged'],'candidate build failed'
   assert output.is_file();artifacts[str(output)]=sha(output);save();print(json.dumps({'step':name,'passed':True,'seconds':o['elapsed_s'],'output':str(output),'sha256':sha(output)}),flush=True)
  r['outcome']='passed';r['image']=str(d/'coax');r['image_sha256']=sha(d/'coax')
 except BaseException as error:r['outcome']='failed';r['error']=repr(error);raise
 finally:save()
 print(json.dumps({'record':str(d/'record.json'),'record_sha256':sha(d/'record.json'),'unqualified_image':str(d/'coax'),'image_sha256':sha(d/'coax')}),flush=True)
if __name__=='__main__':main()
