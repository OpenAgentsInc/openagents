#!/usr/bin/env python3
"""Fresh final C/header production + retained native artifacts; no CC/native run."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import time
sys.dont_write_bytecode = True

ENVIRONMENT = ('PATH', 'CC', 'SDKROOT', 'DEVELOPER_DIR',
               'MACOSX_DEPLOYMENT_TARGET', 'COAX_HOST_TARGET')
SUPPORT = ['coax', 'provenance-check', 'provenance.record',
           'check-domains.c', 'check-domains.h', 'lexer.c', 'lexer.h',
           'parser.c', 'parser.h', 'checker.c', 'checker.h',
           'sources.c', 'sources.h', 'proto_runtime.inc',
           'proto_importer.c', 'proto_importer.h', 'mutation-survivors']
FLAGS = ('timeout', 'deadline_exhausted', 'stdout_limit', 'stderr_limit',
         'output_limit', 'group_killed', 'kill_errno', 'launch_errno',
         'launch_error', 'read_errno')
HELPER_SHA = 'e6aefccd3d5815e75dd74c17c7538dc54b79ece9554751842db12646fce9b0c9'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def regular(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    return path


def read_pinned(path, expected):
    path = regular(path)
    assert sha(path) == expected, str(path)
    return json.loads(path.read_bytes())


def clean(observation):
    return (observation['started'] and observation['returncode'] == 0
            and observation['stdout_eof'] and observation['stderr_eof']
            and not any(observation.get(key) for key in FLAGS))


def compiler_alias(program, cwd, environment):
    if os.path.dirname(program):
        value = Path(program)
        value = value if value.is_absolute() else cwd/value
    else:
        search = [str(Path(part) if Path(part).is_absolute() else cwd/part)
                  for part in os.get_exec_path(environment)]
        value = shutil.which(program, path=os.pathsep.join(search))
        assert value, 'retained native CC is unavailable'
    return Path(os.path.abspath(value))


def validate_cases(observed, oracle, root):
    assert {key: observed[key] for key in (
        'cases', 'source_cases', 'negative_cases', 'matched_reports',
        'disabled_controls', 'short_controls')} == {
            'cases': 21, 'source_cases': 19, 'negative_cases': 7,
            'matched_reports': 16, 'disabled_controls': 1, 'short_controls': 1}
    rows = observed['observations']
    cases = {row['id']: row for row in oracle['cases']}
    expected = {(name, 0) for name in cases}
    expected |= {(oracle['cases'][1]['id'], 1), (oracle['cases'][1]['id'], 2)}
    assert len(rows) == 21 and {(r['fixture_id'], r['mode']) for r in rows} == expected
    for row in rows:
        case = cases[row['fixture_id']]
        assert Path(row['input_source']).resolve() == (root/'coax/tests/retained-borrows'/case['source']).resolve()
        if row['mode'] == 2:
            assert not row['ck_ok'] and row['committed_report_count'] == 0
            assert row['error_count'] == 1 and row['errors'][0]['code'] == 'E0381'
            assert not row['report_prefix_admitted'] and row['reports'] == []
            continue
        if not case['expected_success']:
            assert not row['ck_ok'] and row['committed_report_count'] == 0
            assert not row['report_prefix_admitted'] and row['reports'] == []
            want = case['diagnostics'][0]
            assert row['error_count'] == 1 and len(row['errors']) == 1
            got = row['errors'][0]
            assert (got['code'], got['line'], got['column']) == (want['code'], want['line'], want['col'])
            continue
        assert row['ck_ok'] and not row['fatal'] and row['error_count'] == 0 and row['errors'] == []
        if row['mode'] == 1:
            assert row['committed_report_count'] == 0 and not row['report_prefix_admitted'] and row['reports'] == []
            continue
        assert row['report_prefix_admitted'] and row['committed_report_count'] == len(row['reports'])
        for report in row['reports']:
            assert report['owner_tag'] == 64 and report['owner'] >= 2 and report['site'] >= 2
            assert type(report['pending']) is int and 0 <= report['pending'] <= 64
            assert report['kind'] in (1, 2)
            assert report['site_tag'] == (64 if report['kind'] == 1 else 21)
            if report['kind'] == 1:
                assert report['site'] == report['owner']
            assert all(type(report[name]) is bool for name in ('facts_complete', 'relation_complete', 'forbidden'))
        for want in case['reports']:
            matches = [r for r in row['reports'] if r['kind'] == want['kind']
                       and r['owner_name'] == want['owner_name']
                       and r['site_loc']['line'] == want['site_line']
                       and r['site_loc']['column'] == want['site_col']]
            assert len(matches) == 1
            for key in ('facts_complete', 'relation_complete', 'forbidden', 'pending'):
                assert matches[0][key] == want[key]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'compiler', 'compiler-sha256', 'fingerprint', 'source-revision',
                 'normal-receipt', 'normal-sha256', 'early-receipt', 'early-sha256',
                 'early-environment', 'early-environment-sha256', 'binding-helper', 'output'):
        parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    root = Path(args.repo).resolve()
    compiler = Path(args.compiler).resolve()
    output = Path(args.output).resolve()
    assert compiler == root/'coax/bin/coax' and not output.exists() and not output.is_relative_to(root)
    early_path = Path(args.early_receipt).resolve()
    early = read_pinned(early_path, args.early_sha256)
    assert early['schema'] == 'coax.retained-borrows.native-qualification.v1' and early['outcome'] == 'passed'
    assert early['inputs_unchanged'] and early['artifacts_unchanged']
    assert early['source_before'] == early['source_after']
    assert early['compiler_sha256'] == early['compiler_sha256_after'] == sha(early['compiler'])
    assert Path(early['compiler']).resolve() != compiler, 'retain the distinct actual early producer'
    envelope_path = Path(args.early_environment).resolve()
    envelope = read_pinned(envelope_path, args.early_environment_sha256)
    assert envelope['schema'] == 'coax.retained-borrows.early-native-environment.v1'
    assert envelope['native_receipt_sha256'] == args.early_sha256
    assert envelope['compiler_sha256'] == early['compiler_sha256']
    assert set(envelope['environment_before']) == set(ENVIRONMENT)
    assert envelope['environment_before'] == envelope['environment_after']
    assert envelope['environment_before'] == {name: os.environ.get(name) for name in ENVIRONMENT}
    settings = envelope['sdk_settings_files_before']
    assert isinstance(settings, dict) and settings == envelope['sdk_settings_files_after']
    cc = shlex.split(os.environ.get('CC', 'cc'))
    assert cc == early['cc'] and str(root) == early['cc_resolution_cwd']
    alias = compiler_alias(cc[0], root, os.environ)
    assert str(alias) == early['cc_alias'] and str(alias.resolve()) == early['resolved_cc']
    assert sha(alias) == early['resolved_cc_sha256']
    assert os.environ.get('PATH') == early['cc_resolution_path']
    tracked = {}
    def track(facts):
        for path, value in facts.items():
            assert path not in tracked or tracked[path] == value, 'conflicting old/final input identity: '+path
            tracked[path] = value
    track(early['source_before'])
    track(early['artifacts'])
    track(settings)
    tracked[str(early_path)] = args.early_sha256
    tracked[str(envelope_path)] = args.early_environment_sha256
    tracked[early['compiler']] = early['compiler_sha256']
    tracked[str(alias)] = early['resolved_cc_sha256']
    tracked[str(alias.resolve())] = early['resolved_cc_sha256']
    oracle_path = root/'coax/tests/retained-borrows/native-expectations.json'
    assert early['oracle_sha256'] == sha(oracle_path)
    oracle = json.loads(oracle_path.read_bytes())
    assert len(oracle['cases']) == 19
    for case in oracle['cases']:
        assert sha(root/'coax/tests/retained-borrows'/case['source']) == case['authored_source_sha256']
    assert set(early['profiles']) == {'O0', 'O2', 'sanitized'}
    commands = {row['label']: row for row in early['commands']}
    assert len(commands) == len(early['commands']) == 9
    assert set(commands) == {'emit-lexer', 'emit-parser', 'emit-checker',
                             'O0-compile', 'O0-run', 'O2-compile', 'O2-run',
                             'sanitized-compile', 'sanitized-run'}
    for row in commands.values():
        assert row['passed'] and clean(row['observation'])
        assert row['argv'] == row['observation']['argv']
        for fact in row['raw'].values():
            assert regular(fact['path']).stat().st_size == fact['bytes']
            assert sha(fact['path']) == fact['sha256']
            tracked[fact['path']] = fact['sha256']
    for name, profile in early['profiles'].items():
        assert profile['outcome'] == 'passed' and profile['fresh_generated_header_guards_compiled']
        assert sha(profile['binary']) == profile['binary_sha256']
        run = commands[name+'-run']
        assert run['argv'] == [profile['binary']]
        compile_argv = commands[name+'-compile']['argv']
        assert compile_argv[:len(cc)] == cc and compile_argv[-2:] == ['-o', profile['binary']]
        assert all(flag in compile_argv for flag in ('-std=c11', '-ffp-contract=off', '-fno-fast-math'))
        if name == 'sanitized':
            assert all(flag in compile_argv for flag in ('-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'))
        else:
            assert '-'+name in compile_argv
        assert all(str(early_path.parent/(module+'.c')) in compile_argv for module in ('lexer', 'parser', 'checker'))
        assert str(root/'coax/tests/retained-borrows-native.c') in compile_argv
        actual = json.loads(Path(run['raw']['stdout']['path']).read_bytes())
        assert actual == profile['observed']
        validate_cases(actual, oracle, root)
        tracked[profile['binary']] = profile['binary_sha256']
    normal_path = Path(args.normal_receipt).resolve()
    normal = read_pinned(normal_path, args.normal_sha256)
    helper = regular(args.binding_helper).resolve()
    assert sha(helper) == HELPER_SHA
    spec = importlib.util.spec_from_file_location('retained_borrow_normal_binding', helper)
    binding_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(binding_module)
    package = {name: sha(regular(compiler.parent/name)) for name in SUPPORT}
    assert package['coax'] == args.compiler_sha256
    assert package['mutation-survivors'] == hashlib.sha256(b'').hexdigest()
    lines = (compiler.parent/'provenance.record').read_text().splitlines()
    assert len(lines) == 4 and lines[1:3] == [args.fingerprint, args.compiler_sha256]
    config = {'fingerprint': args.fingerprint, 'qualified_files': package,
              'qualification': {'kind': 'normal', 'path': str(normal_path), 'sha256': args.normal_sha256}}
    bound = binding_module.qualification_binding(config)
    assert bound['source_revision'] == args.source_revision
    binding = read_pinned(normal['binding'], normal['binding_sha256'])
    assert Path(binding['source']).resolve() == root
    track(binding['inputs'])
    track({normal['binding']: normal['binding_sha256'], normal['plan']: normal['plan_sha256']})
    track({fact['path']: fact['sha256'] for fact in normal['receipts'].values()})
    tracked[str(normal_path)] = args.normal_sha256
    tracked[str(helper)] = HELPER_SHA
    tracked[str(Path(__file__).resolve())] = sha(__file__)
    tracked.update({str(compiler.parent/name): value for name, value in package.items()})
    def stable():
        assert {name: os.environ.get(name) for name in ENVIRONMENT} == envelope['environment_before']
        assert compiler_alias(cc[0], root, os.environ) == alias and str(alias.resolve()) == early['resolved_cc']
        for path, expected in tracked.items():
            assert sha(regular(path)) == expected, 'source/artifact/receipt/tool drift: '+path
    stable()
    output.mkdir(parents=True)
    sys.path.insert(0, str(root/'coax/tools'))
    import bounded_process
    before = dict(tracked)
    record = {'schema': 'coax.retained-borrows.native-artifact-rebind.v1', 'outcome': 'not-checked',
              'qualification_kind': 'fresh-final-emission-with-retained-exact-artifact-native-observations',
              'final_producer': {'compiler': str(compiler), 'sha256': args.compiler_sha256,
                                 'fingerprint': args.fingerprint, 'source_revision': args.source_revision,
                                 'normal_receipt': str(normal_path), 'normal_sha256': args.normal_sha256},
              'executed_producer': {'compiler': early['compiler'], 'sha256': early['compiler_sha256'],
                                    'qualification': 'UNQUALIFIED early final-style producer, not the final normal image'},
              'early_receipt': {'path': str(early_path), 'sha256': args.early_sha256},
              'early_environment': {'path': str(envelope_path), 'sha256': args.early_environment_sha256},
              'retained_native_profiles': early['profiles'], 'commands': [], 'emissions': {},
              'retained_compile_argv': {name: commands[name+'-compile']['argv'] for name in early['profiles']},
              'source_before': before, 'native_builds_executed': 0, 'native_binaries_executed': 0,
              'scope': 'New final emitter output plus unchanged actually executed C/header/observer/oracle/CC/native binary artifacts. Raw native execution remains attributed to its early producer. No host lifetime, B2 composition or B3 request-owner claim.'}
    start = time.monotonic()
    deadline = start+840
    early_dir = early_path.parent
    try:
        for name in ('lexer', 'parser', 'checker'):
            stable()
            c, header, profile = (output/(name+suffix) for suffix in ('.c', '.h', '.profile.json'))
            argv = [str(compiler), 'c', str(root/'coax/lib/compiler'/(name+'.coax')),
                    '--library', '--arithmetic', 'checked', '--header', str(header),
                    '--profile-report', str(profile)]
            observation = bounded_process.run(argv, cwd=str(root), env=os.environ.copy(),
                                              timeout_s=min(300, max(0, deadline-time.monotonic())),
                                              max_output_bytes=33554432, deadline=deadline, quiet_faults=True)
            raw = {}
            for stream in ('stdout', 'stderr'):
                path = c if stream == 'stdout' else output/(name+'.stderr')
                path.write_bytes(observation.pop(stream))
                raw[stream] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
            record['commands'].append({'argv': argv, 'observation': observation, 'raw': raw})
            assert clean(observation), 'fresh final producer command did not pass'
            facts = json.loads(profile.read_bytes())
            assert facts['schema_version'] == 1 and facts['command'] == 'c' and facts['backend'] == 'c11'
            assert facts['success'] is True and facts['exit_status'] == 0
            assert facts['runtime_arithmetic'] == facts['interpreter_arithmetic'] == 'checked'
            assert facts['emitted_sha256'] == facts['artifact_sha256'] == sha(c) and facts['descriptors'] == []
            old_facts = json.loads((early_dir/(name+'.profile.json')).read_bytes())
            assert facts['sources'] == old_facts['sources'], 'actual consumed source identity changed'
            for fact in facts['sources']:
                assert sha(fact['path']) == fact['sha256']
            assert c.read_bytes() == (early_dir/(name+'.c')).read_bytes(), 'C byte inequality: stop and qualify affected artifacts'
            assert header.read_bytes() == (early_dir/(name+'.h')).read_bytes(), 'header byte inequality: stop and qualify affected artifacts'
            record['emissions'][name] = {'c_sha256': sha(c), 'header_sha256': sha(header),
                                         'profile_sha256': sha(profile), 'profile': facts,
                                         'comparison': 'exact bytes equal to actually native-executed artifacts'}
            tracked.update({str(path): sha(path) for path in (c, header, profile)})
            stable()
        assert len(record['commands']) == 3 and len(record['emissions']) == 3
        record['outcome'] = 'passed'
    except BaseException as error:
        record['outcome'] = 'failed'
        record['error'] = type(error).__name__+': '+str(error)
        raise
    finally:
        record['elapsed_s'] = time.monotonic()-start
        record['source_after'] = {path: sha(path) if Path(path).is_file() else None for path in tracked}
        record['inputs_unchanged'] = all(record['source_after'].get(path) == value for path, value in tracked.items())
        if not record['inputs_unchanged']:
            record['outcome'] = 'input-artifact-changed'
        (output/'qualification.json').write_text(json.dumps(record, indent=2)+'\n')
    assert record['outcome'] == 'passed', 'final source/artifact guard failed'
    print(json.dumps({'outcome': record['outcome'], 'coax_commands': 3,
                      'native_builds': 0, 'native_runs': 0, 'receipt': str(output/'qualification.json')}))


if __name__ == '__main__':
    main()
