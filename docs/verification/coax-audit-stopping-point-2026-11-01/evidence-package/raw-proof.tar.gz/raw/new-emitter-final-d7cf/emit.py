#!/usr/bin/env python3
"""Actual merged-stage0 seed emission; no profile claim or normal continuation."""
from pathlib import Path
import hashlib,json,os,sys,time
S=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents/coax').resolve()
W=Path('/tmp/coax-retained-borrows-B1/fast-generator-d7cf').resolve()
D=Path(__file__).resolve().parent
sys.path[:0]=[str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools')),str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tests'))]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
paths=[Path(__file__).resolve(),W/'stage0',W/'proto_runtime.inc',Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[p for root in [S/'lib/compiler',S/'lib/proto',S/'lib/crypto'] for p in root.rglob('*') if p.is_file()]]
before={str(p):sha(p) for p in paths}
assert before[str(W/'stage0')]=='abc3c11fdc40375375d8ba660ab37e5050ef9ae3d31151884aa6ae9e33159ba3'
assert before[str(S/'lib/compiler/checker.coax')]=='d7cf7034b61e532f3328a1f9f88583d451fa100e310c5ec808eaab553766d90d'
r={'schema':'coax.B1.new-emitter-preseed-emission.v1','scope':'Actual merged build-only stage0 emits mandatory checked C/header. No --profile-report because this producer explicitly lacks it. Broad frozen compiler/proto/crypto inventory manually guarded, not called an observed profile closure. No final qualification, seal, install or normal continuation.','producer':str(W/'stage0'),'producer_sha256':sha(W/'stage0'),'native_cpp_revision':'449b739ffb176c8efdbf67d71f2812a01fbb6abd','kernel_source_sha256':'d7cf7034b61e532f3328a1f9f88583d451fa100e310c5ec808eaab553766d90d','reused_native_prefix_fingerprint':'246eee72b0e23ac1ef2b2a7d75b3d3468ffb0ddd04851758581383218b5e371f','source_before':before,'rows':[],'artifacts':{},'outcome':'not-checked'}
started=time.monotonic();deadline=started+840
def save():
 r['source_after']={str(p):sha(p) for p in paths};r['inputs_unchanged']=r['source_after']==before;r['elapsed_s']=time.monotonic()-started
 (D/'record.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name in ['checker','proto_importer']:
  save();assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
  module='lib/compiler/'+('checker' if name=='checker' else 'compiler')+'.coax'
  header=D/(name+'.h');assert not header.exists() and not (D/(name+'.c')).exists()
  argv=[str(W/'stage0'),'c',module,'--library','--header',str(header)]
  o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=33554432,deadline=deadline,quiet_faults=True)
  row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
  for stream in ['stdout','stderr']:
   data=row['observation'].pop(stream);p=D/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  (D/(name+'.c')).write_bytes(o['stdout'])
  row['transport_clean']=clean(o);r['rows'].append(row);save()
  assert row['transport_clean'] and r['inputs_unchanged'],'actual emission failed'
  assert header.is_file() and header.stat().st_size>0
  for p in [header,D/(name+'.c')]:r['artifacts'][str(p)]=sha(p)
  save();print(json.dumps({'label':name,'passed':True,'elapsed_s':o['elapsed_s'],'artifacts':{str(p):sha(p) for p in [header,D/(name+'.c')]}}),flush=True)
 assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
 r['outcome']='passed'
except BaseException as e:
 r['outcome']='failed';r['error']=repr(e);raise
finally:save()
print(json.dumps({'record':str(D/'record.json'),'sha256':sha(D/'record.json'),'outcome':r['outcome']}),flush=True)
