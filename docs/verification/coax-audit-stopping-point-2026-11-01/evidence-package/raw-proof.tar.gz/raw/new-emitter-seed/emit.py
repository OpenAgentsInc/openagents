#!/usr/bin/env python3
"""Actual merged-stage0 seed emission; no profile claim or normal continuation."""
from pathlib import Path
import hashlib,json,os,sys,time
S=Path('/tmp/coax-retained-borrows-B1/preseed-c0f-prefix/snapshot/coax').resolve()
W=S/'bin/.bootstrap-bounded-normal'
D=Path(__file__).resolve().parent
sys.path[:0]=[str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools')),str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tests'))]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
paths=[Path(__file__).resolve(),W/'stage0',W/'proto_runtime.inc',Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[p for root in [S/'lib/compiler',S/'lib/proto',S/'lib/crypto'] for p in root.rglob('*') if p.is_file()]]
before={str(p):sha(p) for p in paths}
assert before[str(W/'stage0')]=='cc5d4c53d1d078c21a8b3968942d02db1c2a501a218bc9a30a451ed71ce153a5'
assert before[str(S/'lib/compiler/checker.coax')]=='eff6b4f53ddc2fcd0d5a1bf7685f003390735c090b8d199c5b42b53547fc5e47'
r={'schema':'coax.B1.new-emitter-preseed-emission.v1','scope':'Actual merged build-only stage0 emits mandatory checked C/header. No --profile-report because this producer explicitly lacks it. Broad frozen compiler/proto/crypto inventory manually guarded, not called an observed profile closure. No final qualification, seal, install or normal continuation.','producer':str(W/'stage0'),'producer_sha256':sha(W/'stage0'),'source_revision':'449b739ffb176c8efdbf67d71f2812a01fbb6abd','preseed_fingerprint':'246eee72b0e23ac1ef2b2a7d75b3d3468ffb0ddd04851758581383218b5e371f','source_before':before,'rows':[],'artifacts':{},'outcome':'not-checked'}
started=time.monotonic();deadline=started+840
def save():
 r['source_after']={str(p):sha(p) for p in paths};r['inputs_unchanged']=r['source_after']==before;r['elapsed_s']=time.monotonic()-started
 (D/'record.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name in ['checker','proto_importer']:
  save();assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
  module='lib/compiler/'+('checker' if name=='checker' else 'compiler')+'.coax'
  header=D/(name+'.h');assert not header.exists() and not (D/(name+'.c')).exists()
  argv=[str(W/'stage0'),'c',module,'--library','--header',str(header)]
  o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=33554432,deadline=deadline,quiet_faults=True)
  row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
  for stream in ['stdout','stderr']:
   data=row['observation'].pop(stream);p=D/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  (D/(name+'.c')).write_bytes(o['stdout'])
  row['transport_clean']=clean(o);r['rows'].append(row);save()
  assert row['transport_clean'] and r['inputs_unchanged'],'actual emission failed'
  assert header.is_file() and header.stat().st_size>0
  for p in [header,D/(name+'.c')]:r['artifacts'][str(p)]=sha(p)
  save();print(json.dumps({'label':name,'passed':True,'elapsed_s':o['elapsed_s'],'artifacts':{str(p):sha(p) for p in [header,D/(name+'.c')]}}),flush=True)
 assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
 r['outcome']='passed'
except BaseException as e:
 r['outcome']='failed';r['error']=repr(e);raise
finally:save()
print(json.dumps({'record':str(D/'record.json'),'sha256':sha(D/'record.json'),'outcome':r['outcome']}),flush=True)
