# Appendix A. Keywords, directives, types and current status

<!-- Generated from coax/release.coax; do not edit this snapshot. -->
Current compiler: **coax0 0.46.0**. Status inventory schema: **1**.

`works` means the bounded feature is implemented; `partial` records its limits.
`reserved` is recognized and refused; `designed` is planned syntax. A status claim
is reviewed metadata, not a proof, permission or complete target-support claim.

Introduced is the historical implementation version when recorded; — means
unrecorded or unimplemented. It is independent of this release and inventory
schema. Keep signed protocol/schema identities in their own version domains.

## Keywords

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `if` `else` | Conditional | works | — |
| `while` | Loop | works | — |
| `for` `break` `continue` | `for i: lo..<hi`, `for x, i: collection`; leave or skip an iteration | works | — |
| `return` | Return from a procedure | works | — |
| `true` `false` | `bool` literals | works | — |
| `ifx` `then` | Conditional expression: `ifx c then a else b` | works | — |
| `defer` | Run at scope exit, in reverse order, on every exit | works | — |
| `struct` `enum` | Type declarations: `Name :: struct { ... }`, `Name :: enum u8 { ... }` | works | — |
| `cast` | `cast(T) x` (checked), `cast,trunc(T) x` (keeps the low bits) | works | — |
| `size_of` | `size_of(T)`: the C size in bytes, as an untyped integer | works | — |
| `union` `enum_flags` | Tagged unions; flag sets | reserved | — |
| `switch` `case` | Exhaustive selection | reserved | — |
| `using` | Bring an embedded field's members into scope | reserved | — |
| `try` `or_else` | Propagate or handle an error result | reserved | — |
| `null` | The empty optional pointer | reserved | — |
| `push_context` | Change the implicit context for a block | reserved | — |
| `remove` | Remove the current element during iteration | reserved | — |
| `it` `it_index` | Implicit element and index names inside `for` (Coax names them instead: `for x, i: ...`) | reserved | — |
| `xx` | Integer-width autocast | reserved | — |
| `constraint` | Declare a generic constraint | reserved | — |
| `inline` `no_inline` | Inlining control at a definition or call | reserved | — |
| `type_info` | CPU type layout metadata, schema 1 | works | 0.12.0 |
| `type_of` | First-class type reflection | reserved | — |
| `Type` `Code` | Meta types | reserved | — |
| `job` `pure` | Jobs and effect markers | reserved | — |
| `strict` `deterministic` | Floating-point and determinism markers | reserved | — |
| `shader` | GPU procedure | reserved | — |

## Directives

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `#import "Basic";` | Import a module; `Basic` is the only one | works | — |
| `#run expr` | Evaluate with bounded configurable shared work and aggregate storage | works | 0.18.0 |
| `#assert expr;` | A compile-time `bool` check at the top level; an always-on check as a statement | works | — |
| `#test "name" { }` | A check run by `coax test`, never compiled into the program | works | 0.5.0 |
| `#forall a: T, b: lo..<hi { }` (optionally `#forall "name" ...`) | A check over every combination of its bindings | works | 0.5.0 |
| `#steps N` | Before a check's block: the check's own step budget, replacing the file's (`#test "name" #steps 150000000 { }`) | works | 0.45.0 |
| `#authority;` | Every procedure in the file needs a check; checks run on every build | works | 0.5.0 |
| `#export_c` | After a procedure's signature: give it its own C name and the C calling convention (`coax lib`, `coax header`) | works | — |
| `#foreign` | After a procedure's signature, with no body: import a C function that passes integers, floats, `bool` and borrowed views of them (read/written during the call only, never retained), returning a scalar or nothing | works | — |
| `#import_proto "file.pb" as Prefix;` | Generate types and bounded codecs from a protobuf descriptor set (CPU code only) | works | — |
| `#load "part.coax";` | Add a once-only source unit with relative paths, cycle/budget checks and physical-file authority | works | 0.11.0 |
| `#module "a.b";` | Claim a logical owner for a source unit; its #load members share it; declarations get nominal IDs and a module scope for qualified lookup | works | 0.26.0 |
| `#if` | BUILD_DEBUG field/statement blocks; general conditions and top-level declarations remain planned | partial | 0.17.0 |
| `#insert` `#expand` `#text` `#location` | Typed code and macros | reserved | — |
| `#derive(...)` | Generate operations from fields | reserved | — |
| `#bake_arguments` | Explicit partial specialization | reserved | — |
| `#distinct` | A new type with the same representation | reserved | — |
| `#as` | Declared conversion to an embedded field | reserved | — |
| `#import_c` `#c_call` `#no_context` | C header import and calling conventions | reserved | — |
| `#scope_file` `#scope_module` `#scope_export` | Visibility | reserved | — |

## Intrinsics

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `print(format, ...)` | Print with `%` slots checked at compile time; needs `#import "Basic"` | works | — |
| `type_name(expr)` | The expression's type name as a string; the operand isn't evaluated | works | — |
| `size_of(T)` | The type's size in bytes (bootstrap LP64 CPU layout) | works | — |
| `type_info(T)` | Type name, kind, layout and counts as `CoaxTypeInfo` | works | 0.12.0 |
| `field_info(T, i)` | Struct field name, type and layout as `CoaxFieldInfo` | works | 0.12.0 |
| `enum_info(T, i)` | Enum member name and underlying bits as `CoaxEnumInfo` | works | 0.12.0 |
| `len(x)` | The length of a string, array or view (the same as `.count`) | works | — |
| `byte_at(s, i)` | The byte at index `i` of a string | works | — |
| `sin` `cos` `tan` `exp` `log` `sqrt` `floor` `abs` | One float argument, same type back | works | — |
| `pow(a, b)` | Two floats of one type | works | — |
| `f32_bits(x)` `f64_bits(x)` | A float's bit pattern as `u32` or `u64` | works | — |
| `f32_from_bits(b)` `f64_from_bits(b)` | The reverse | works | — |
| `bytes_overlap(a, b)` | Whether two byte views or strings share memory | works | — |
| `add_wrap(a, b)` `sub_wrap(a, b)` `mul_wrap(a, b)` | Matching u32/u64 arithmetic modulo the word width, including checked and compile-time execution | works | 0.15.0 |
| `rotl(a, count)` `rotr(a, count)` | Matching u32/u64 rotation; count reduced modulo the word width | works | 0.15.0 |
| `mul_wide(a, b)` | Two u64 operands produce CoaxU64Product with hi/lo halves; native128-bit and portable wasm32 lowering | works | 0.16.0 |
| `value_barrier(x)` | u32/u64 identity opaque to native optimization; compiler identity; backend-specific evidence is required for constant-time claims | works | — |

## Conversions

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `cast(T) x` | Convert between numbers, or between an enum and an integer; traps if the value doesn't fit | works | — |
| `cast,trunc(T) x` | Convert between integer types, keeping the low bits | works | — |
| `T(x)` for a number type | The same as `cast(T) x`: `int(x)`, `f64(x)`, `u8(x)` | works | — |
| `cast(string) v` | Borrow a `[] u8` view as a string | works | — |
| `xx x` | Automatic integer-width conversion | reserved | — |

## Literals

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| Integer | `42`, `0xFF`, `0b1010`, `1_000_000` (up to the `u64` maximum) | works | — |
| Float | `1.5`, `2e-3`, `6.02e23`; with a suffix, `1.5f32`, `1.5f64` | works | — |
| Character | `'a'`, `'\n'` (one ASCII byte, an integer literal) | works | — |
| String | `"text\n"`, with the escapes `\n \t \r \0 \\ \"` | works | — |
| Struct | `Vec2.{x = 1, y = 2}` | works | — |
| Array | `[3] int.[1, 2, 3]` | works | — |
| Enum member | `Outcome.completed` | works | — |
| Uninitialized | `buf: [128] u8 = ---;` | works | — |
| Inferred struct literal | `.{x = 1}` without the name | designed | — |

## Types

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `int` (the same type as `s64`), `s8 s16 s32 u8 u16 u32 u64`, `uint` (the same as `u64`) |  | works | — |
| `f32 f64` |  | works | — |
| `bool`, `string` |  | works | — |
| structs and enums |  | works | — |
| `[N] T` fixed arrays, `[] T` views |  | works | — |
| `[..] T` dynamic arrays | (E0301) | reserved | — |
| `fixed32 fixed64` | (E0301) | reserved | — |
| `v2 v3 v4 quat m3 m4` | (E0301) | reserved | — |
| `Any` | (E0301); planned for tools and logging only | reserved | — |
| `*T`, `*T?`, `T?`, `Handle(T)`, lane types |  | designed | — |

## Capabilities

| Name | Meaning | Status | Introduced |
| --- | --- | --- | --- |
| `#load` / `coax deps` | Bounded source composition and input inventory | works | 0.11.0 |
| `coax deps --declarations` | Schema coax.declarations.v1: unit owners, nominal declaration IDs and resolved references from the checked graph | works | 0.26.0 |
| `coax deps --modules` | Schema coax.modules.v1: conservative module-scoped content and dependency revisions, separate from nominal IDs, source hashes and the profile; no per-declaration revisions or cache key | partial | 0.27.0 |
| Declaration spans and the `native-lp64` target record | coax deps reports each declaration's exact authored byte range, lines and content hash, or its generated directive origin, and the typed native-lp64 layout record; coax layout and coax deps refuse any other --target (E0612) | partial | 0.29.0 |
| `#load "FILE.coax" as NAME;` qualified lookup | Path imports bind an alias to a logical module; NAME.Type, NAME.proc() and NAME.CONST resolve in the checked graph with per-module scopes, ambiguity at the use and qualified C spellings; no reexports, module parameters or package search | partial | 0.28.0 |
| `#export NAME, ...;` module visibility | A logical module with an #export list keeps its other declarations private: qualified and unqualified uses from other modules are E0389, member units share the owner, unlisted modules stay fully visible; exports name the module's own declarations (E0390, E0391), reexports fail (E0614); coax deps --modules reports each module's exports | partial | 0.30.0 |
| Effect-ordered native lowering | CK_effects classifies each checked expression (call, trap, checked-overflow trap); native C sequences two trapping operands and a trapping place and value, so the first trap in source order is reported at -O0 and -O2 as in the evaluator; coax deps --lowering (0.32.0) prints the coax.lowering.v1 record of those decisions for the eligible subset | partial | 0.31.0 |
| `coax test/mutate --evidence FILE` | Schema coax.evidence.v1: each check, authority-coverage and mutation claim bound to sources, compiler, evaluator target, profile, selection and budgets, ending passed, counterexample, inconclusive, infrastructure-error or not-checked; the verdict is the worst, so missing execution is never a pass | works | 0.33.0 |
| `coax checks-c FILE` | Verification-only C11 from admitted checked zero-argument #test bodies and their callee closure, with original physical identities; no source rewriting or product main. Default ABI1 refuses selected #forall; opt-in --verification-abi 2 emits bounded finite-property metadata and original parameterized bodies. Unsupported effects/borrow forms refuse; emission alone is not execution evidence | works | 0.39.0 |
| Original-source native execution companion | Optional native_check_execution.py host tooling runs one checked-AST C artifact at checked O0/O2 with a complete original evaluator baseline, Coax-owned EP1 protocol/verdict policy and bounded isolated native processes. execution.v1 records exact selected identities, source/artifact/compiler/SDK observations. Default ABI1 covers ordinary checks; opt-in ABI2 adds finite properties in execution.v2. Broader trap semantics and real-consumer qualification remain separate | works | 0.41.0 |
| Finite authored native properties | Opt-in checks-c verification ABI2 and execution.v2 use shared Coax finite-domain admission/traversal for bool, small integers, sparse enums and int ranges, preserving original identities and last-binding-fastest order. Bounded per-property processes publish Coax-validated case progress and named witnesses; original unfiltered baselines remain mandatory. Native arity is limited to 64; ABI1 and execution.v1 remain unchanged | works | 0.42.0 |
| Native semantic experiments | Optional semantics.v1 tooling qualifies independent value/write/cleanup assertions, recognizes a checked subset of runtime traps through verification-only structured hooks, and detects a retained C-only multiplication seed with bounded signature-preserving tuple replay. Matching an expected failed-original trap is artifact-only and never a passed baseline. Arbitrary source minimization and real-consumer qualification remain separate | works | 0.44.0 |
| `$T` type parameters | A $T binds from procedure parameters or an explicit generic-struct parameter list; unbound/result-only uses and unsupported nesting are refused (E0392-E0395); recursive or C-exported generic procedures are refused (E0396, E0398) | partial | 0.34.0 |
| Generic instantiation | Each call deduces its bindings, typed arguments first and then literals for a bare $T (E0348, E0349, E0397); one checked instance per procedure and binding, at most 256 (E0339), evaluated, emitted as name__bindings and mutated like any procedure; built-in constraints restrict admitted types and operations | partial | 0.35.0 |
| `$N` value parameters | [$N] T binds a fixed array argument's length (E0348 two lengths, E0349 not a fixed array or wrong length, E0368 a name used as type and length); [4] $T and [$N] $T are accepted | partial | 0.36.0 |
| Generic structs | Pair :: struct($T) and Box :: struct($T, $N) instantiate per binding from Pair(int) types, with a length given as a literal or a named integer constant (Box(f64, CAP)), deducing literals and Pair($T) parameters; fixed-storage bindings only (no views or aggregates containing views); each instance is laid out and emitted (E0800-E0804, E0223) | partial | 0.37.0 |
| Borrowed views across `#foreign` | A #foreign parameter may be a [] view of integers, floats or bool, passed as the {data, count} struct; the host reads and writes it during the call only (no retention, transfer or asynchronous use), views may overlap; other views, arrays and view results are E0376; compile-time and check execution refuse host calls (E0404) | partial | 0.38.0 |
| Generic constraints | $T: equatable, ordered, numeric or copyable; bodies check against the constraint and calls outside it are refused with an instantiation trace (E0805-E0808) | partial | 0.40.0 |
| `#import_proto` | Selected proto3 descriptor generation in Coax; domain admission remains separate | works | 0.10.0 |
| Native source debugging | Original-file line maps and optional LLDB names; optimized values and generated-code limits remain | partial | 0.13.0 |
| E0383 local-borrow diagnostics | Rejects direct local fixed-array view/string returns and simple aliases, slices and casts. Helper returns and retained stores have separate bounded profiles; general ownership remains unchecked | works | 0.13.0 |
| Bounded returned-borrow diagnostics | Resolved helper and aggregate return projections retain known caller, static and local origins; a concrete local witness reports E0383 even beside an incomplete arm. Recursion and unmodeled helper writes remain explicit manual status, not a safe empty result. Resource exhaustion is E0381; retained caller-state and general region lifetimes remain separate | partial | 0.46.0 |
| Bounded retained-store diagnostics | Checks concrete bodies including void and uncalled procedures, rejecting known callee-local descriptor backing stored into caller or static storage with E0383. Sparse parameter outlives obligations are projected at actual callers. Unknown, recursive, foreign and same-frame region relations remain explicit manual scope; local-carrier write-to-return composition and request ownership remain separate | partial | 0.46.0 |
| Release/status generation | Canonical Coax catalogue, CLI status and build/publication drift gate | works | 0.14.0 |
| Compiler build identity | Checked source and artifact consistency record for site releases; not authentication | works | 0.22.0 |
| Explicit semantic profile selection | Independent arithmetic, native optimization, build selector and debug information; optional schema-1 profile report; legacy presets retained, no general cross-object or device qualification | partial | 0.25.0 |
| `coax cuda` compute subset | CUDA C for NVRTC: item, warp and bounded group kernels with numeric views and fixed scalar arrays; group kernels admit owned shared-memory writes and barriers; general atomics remain unsupported | partial | 0.23.0 |
| CUDA warp kernels | `for lane: 0..<32` loops, per-lane register arrays and the BF16 tensor-core primitive `cu_mma_bf16_16x8x16`; cooperative shared memory and barriers use the separate group-kernel rules | partial | 0.24.0 |
| Linux x86-64 C11 host | Builds, checks and runs on the tested NixOS x86-64 host with GCC; not a release-qualified target | partial | 0.23.0 |
| Bounded aggregate traversal | Independent finite work accounting for evaluated aggregate traversal | works | 0.21.0 |
| Bounded interpreted string snapshots | Owned cast snapshots with finite live bytes and materialization work | works | 0.20.0 |
| Conservative mutation scheduling | Runs all mutants with isolated check scheduling and full-run fallback | works | 0.19.0 |
| Differential conformance tooling | Optional bounded evaluator/native tests with independent oracle and reduced witnesses | partial | 0.14.0 |
| General ownership | Transfer, destruction and complete region/lifetime rules remain planned | designed | — |
| Apple C11 host | Tested Apple LP64 host; target support requires runtime/ABI/debugging evidence | partial | — |
| Coaxial browser path | Current Wasm/WebGPU consumers; general target layout/runtime/debugging remain incomplete | partial | — |

Annotations such as `@range` and `@unit` are lexed but not accepted yet.
The accepted grammar and focused implementation tests remain separate evidence
for these reviewed status claims.
