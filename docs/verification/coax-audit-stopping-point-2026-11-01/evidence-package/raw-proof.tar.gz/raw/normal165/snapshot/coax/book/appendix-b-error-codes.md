# Appendix B. Error codes

<!-- coax-release:current:start -->
Current compiler: **coax0 0.46.0**. Status inventory schema: **1**.
<!-- coax-release:current:end -->
This appendix lists every error code the current compiler can report. The tables
below are the output of `coax explain --all --markdown`, which prints the
compiler's own table from `coax/src/errors.cpp`; when that table changes,
regenerate this appendix from it rather than editing the rows by hand. In
a terminal, `coax explain CODE` prints one entry:

```shell
$ coax explain E0303
E0303: name already declared; no shadowing
  Every local name in a procedure is unique among the names in scope. Coax has no shadowing, so a name always means one thing.
```

Codes are stable: a code keeps its meaning, and a retired code is never
reused, so the tables include the retired ones too.

The `E0413` description below refers to the default `checks-c` ABI1.
Explicit `checks-c --verification-abi 2` supports admitted finite `#forall`
properties. Unsupported bodies still refuse, and both ABIs retain authority
checks.

The first two digits after the `E` give the stage that reports the error:

| Prefix | Stage | Where to read more |
| --- | --- | --- |
| `E01` | Lexer | Chapter 4 |
| `E02` | Parser | Chapter 4 |
| `E03` | Checker | Chapter 4 |
| `E04` | Compile-time evaluation and checks | Chapters 9 and 11 |
| `E05` | Protobuf descriptor imports | Chapter 18 |
| `E06` | Source-unit composition | Chapter 10 |
| `E07` | Device code (`coax cuda`, `coax metal-compute`, `coax spirv`) | Chapter 17 |

Chapter 4 explains how to read a diagnostic, and Chapter 27 shows which
part of the compiler produces each stage's errors. With `--json`, each
diagnostic is one JSON object per line on stderr, with the fields `file`,
`line`, `col`, `code`, `message` and `fix`.






## E01xx: lexer

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0101` | block comment is never closed | A /* comment has no matching */ before the end of the file. Block comments nest, so every /* inside needs its own */. |
| `E0102` | retired in 0.3.0 | Was: floating-point literals are not supported. Floats arrived in 0.3.0. |
| `E0103` | number has no digits after its base prefix | 0x and 0b must be followed by at least one digit of that base. |
| `E0104` | integer literal does not fit in 64 bits | Integer literals go up to 18446744073709551615 (the u64 maximum). Where the literal is used, it must also fit that type. |
| `E0105` | unknown escape in a string | Strings support \n \t \r \0 \\ and \". Unicode and hex escapes are planned. |
| `E0106` | string is never closed | A string ends with a " on the same line. Strings cannot span lines yet. |
| `E0107` | non-ASCII character outside a string or comment | Identifiers and operators are ASCII. UTF-8 text belongs in strings and comments. |
| `E0108` | unexpected character | The character starts no token in Coax. |
| `E0109` | bad floating-point literal | The literal rounds to infinity (the largest f64 is about 1.8e308, the largest f32 about 3.4e38), or it is followed by something other than an f32 or f64 suffix. |
| `E0110` | invalid character literal | A character literal is one ASCII character or escape in single quotes ('a', '\n', '\''). It is an integer literal holding that byte, so it fits u8. |
| `E0111` | lexer source or storage limit | Source must fit signed 32-bit byte offsets and one-based EOF locations. Native lexer buffers must meet the Coax capacity contract. |

## E02xx: parser

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0201` | expected a token | The parser needed a specific token here, usually ';', ')' or '}'. For a missing ';' the caret points right after the previous token. |
| `E0202` | expected a type | A type is a name (int, f32, Vec2), a fixed array '[N] T', or a view '[] T'. |
| `E0203` | comparisons cannot be chained | a < b < c is rejected rather than given a surprising meaning. Write a < b && b < c. |
| `E0204` | reserved word not supported yet | The word is reserved for a planned feature (union, switch, using, try...). coax0 refuses it rather than guessing what it means. |
| `E0205` | expected an expression | A value was needed here: a literal, a name, a call, or a parenthesized expression. |
| `E0206` | local declarations with :: are not supported | Constants, procedures and types are declared at the top level in coax0. |
| `E0207` | cannot assign to this expression | Only a variable, a struct field or an element (a[i]) can be assigned. |
| `E0208` | expected a name | A parameter, field, member or loop variable name was expected here. |
| `E0209` | expected a module name after #import | Write #import "Basic"; |
| `E0210` | directive not supported here | The directive is unknown or not implemented in this position. Procedures accept #export_c; files accept #import and #assert; expressions accept #run. |
| `E0211` | retired in 0.2.0 | Was: only procedures can be declared at the top level. Top-level constants arrived in 0.2.0. |
| `E0212` | global variables are not supported | Top-level mutable state is not part of coax0. Use constants, or pass state explicitly. |
| `E0213` | expected a top-level declaration | The top level holds #import, #assert and declarations 'name :: ...'. |
| `E0214` | unknown cast modifier | The only modifier is trunc: cast,trunc(u8) x keeps the low bits instead of checking that the value fits. |
| `E0215` | struct literal needs a struct name | Write the struct's name before .{ }: Point.{x = 1, y = 2}. Inferred literals are planned. |
| `E0216` | ranges are half-open | Coax ranges are written lo..<hi and include lo but not hi. '..' alone is not a range. |
| `E0217` | array literal needs a fixed array type | Write the type first: [3] int.[1, 2, 3]. |
| `E0218` | a range loop has one variable | for i: 0..<n { } has a counter only. Index variables belong to loops over arrays, views and strings. |
| `E0219` | enum needs an underlying type | An enum names its integer width: Outcome :: enum u8 { ... }. The width is part of its layout. |
| `E0220` | malformed check | #test takes a name string and a block: #test "refunds never exceed payment" { ... }. #forall takes one or more bindings, each a type or a lo..<hi range, then a block: #forall a: u8, b: 0..<10 { ... }. #steps N before the block gives the check its own budget of N steps, a positive integer literal: #test "the world builds" #steps 150000000 { ... }. |
| `E0221` | parser resource limit | The Coax parser requires an EOF-terminated lexer token stream, caller-owned indexed-tree storage and at most 128 active recursive grammar entries. Reduce syntax nesting or supply the capacities returned by PS_caps. No partial syntax tree is admitted after a failure. |
| `E0223` | malformed struct parameter list | A generic struct lists its parameters as $NAME, each once, separated by ',': Pair :: struct($T) { a: $T; b: $T; } or Box :: struct($T, $N) { items: [$N] $T; }. |
| `E0222` | qualified name reaches through an alias | A qualified name is one module alias and one declaration: hud.Slot, hud.frame(x). Aliases are not reexported, so a.b.Name is refused; load that module with its own alias. |

## E03xx: checker

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0301` | type not supported yet | The type is in the plan (spec 6.2) but coax0 does not implement it, for example dynamic arrays '[..] T' or vectors. |
| `E0302` | unknown type | No built-in type, struct or enum has this name. |
| `E0303` | name already declared; no shadowing | Every local name in a procedure is unique among the names in scope. Coax has no shadowing, so a name always means one thing. |
| `E0304` | name is already a procedure | A local cannot take the name of a procedure. |
| `E0305` | procedures are not values | Procedure values and callbacks are planned. Call the procedure instead. |
| `E0306` | name is not declared | No local, parameter or constant with this name is in scope here. |
| `E0307` | '-' needs a signed integer or a float | Unsigned integers have no negation. Subtract from a value, or use a signed type. |
| `E0308` | '!' needs a bool | There is no truthiness. Compare instead: x == 0. |
| `E0309` | arithmetic needs two numbers of one type | + - * / need two integers or two floats of the same type; % needs integers. There are no implicit conversions: cast one side. |
| `E0310` | ordering needs two numbers of one type | < <= > >= compare two integers or two floats of the same type. |
| `E0311` | cannot compare these values | == and != need two values of one type. Structs, arrays and views are compared field by field or element by element, by you. |
| `E0312` | boolean operator needs two bools | && and \|\| take bools and short-circuit. |
| `E0313` | print needs Basic | print is in module Basic. Add #import "Basic"; at the top of the file. |
| `E0314` | not a procedure | A constant or variable was called like a procedure. |
| `E0315` | procedure is not declared | No procedure has this name. Procedures may be declared after they are used. |
| `E0316` | wrong number of arguments | The call passes a different number of arguments than the procedure declares. |
| `E0317` | argument has the wrong type | Each argument must have its parameter's type exactly. An array is passed as a view with name[..]. |
| `E0318` | print needs a format string | print("text\n"); the format comes first. |
| `E0319` | print's format must be a literal | The format is checked while compiling, so it must be a string literal. |
| `E0320` | format slots and values differ | Each % in the format takes one value. Write %% for a percent sign. |
| `E0321` | cannot print nothing | This call returns no value, so there is nothing to print. |
| `E0322` | value is not used | An expression statement must do something: call a procedure, or assign its value. |
| `E0323` | result is not used | The procedure returns a value that is dropped. Use it, or store it. |
| `E0324` | cannot initialize from nothing | The call returns no value, so it cannot initialize a variable. |
| `E0325` | initializer has the wrong type | The variable's declared type and its initializer differ. There are no implicit conversions. |
| `E0326` | compound assignment needs a number | += -= *= /= need a number target; %= &= \|= ^= <<= >>= need an integer. |
| `E0327` | assigned value has the wrong type | The value's type differs from the target's. |
| `E0328` | missing return value | The procedure declares a result, so return needs a value. |
| `E0329` | procedure returns nothing | A value is returned from a procedure without '-> T'. |
| `E0330` | returned value has the wrong type | The value differs from the declared result type. |
| `E0331` | condition must be bool | if, while and ifx take a bool. Compare explicitly: x != 0. |
| `E0332` | module imported twice | Remove the second #import. |
| `E0333` | unknown module | coax0 has one module, Basic. |
| `E0334` | procedure declared twice | There are no overloads yet; every procedure name is unique. |
| `E0335` | name is a builtin | print (with Basic) and type_name are reserved by the compiler. |
| `E0336` | no main | A program needs main :: () { }. A file whose procedures are #export_c can be built as a library with coax lib instead. |
| `E0337` | main has the wrong signature | main takes no parameters and returns nothing in coax0. |
| `E0338` | missing return | Some path reaches the end of a procedure that must return a value. |
| `E0339` | too many generic instances | A program may make at most 256 generic instances: one per generic procedure or struct and distinct binding of its parameters. A chain of generic uses that binds ever larger types never ends; break it with a concrete type. |
| `E0340` | constant dependency cycle | Constants may refer to each other in any order, but not in a circle. |
| `E0341` | constant has no value | A constant or #run must produce a value; a call returning nothing cannot. |
| `E0342` | name is a constant, type or intrinsic | A local cannot take the name of a constant, struct, enum or intrinsic. |
| `E0343` | type_name needs one value | type_name(x) takes exactly one expression with a value. It is checked but never run. |
| `E0344` | cannot assign a constant or parameter | Constants never change. Parameters are immutable: copy one into a local to update it. |
| `E0345` | duplicate or conflicting constant | The constant's name is already a constant, procedure or intrinsic. |
| `E0346` | #assert needs bool | The asserted expression must be a bool, at the top level and in a statement. |
| `E0347` | constant dependencies too deep | Constant type resolution is bounded at depth 64. |
| `E0348` | type parameter bound twice | The arguments of one call bind each $T once: the first typed argument whose type uses $T binds it, and every other one must have that same type; an untyped literal for a bare $T takes the bound type. Pass the same type, or convert one with cast. |
| `E0349` | argument does not have the parameter's shape | A parameter written [] $T binds $T from a view, so its argument must be a view (pass name[..] for an array); one written [$N] T or [4] T binds or checks a fixed array's length, so its argument must be a fixed array of that length. |
| `E0350` | value does not fit its type | Untyped literals take the type their use needs, if the value fits: x: u8 = 300 does not. A float literal cannot become an integer. Use a wider type, or cast,trunc to keep the low bits. |
| `E0351` | no such field or member | The struct has no field, or the enum no member, with this name. Arrays, views and strings have .count. |
| `E0352` | duplicate field or member | A field or member name appears twice in a declaration or a literal. |
| `E0353` | struct contains itself | A struct cannot hold itself by value; its size would be infinite. Hold it through a view, or by index. |
| `E0354` | a type is not a value | A struct or enum name was used as a value. Make a struct with Name.{ }, or name an enum member with Name.member. |
| `E0355` | cannot index or slice this | Only arrays, views and strings can be indexed and sliced. |
| `E0356` | index must be an integer | Indices and slice bounds are integers of any width. They are checked against the length at run time. |
| `E0357` | array length not known while checking | An array length is a positive integer known while checking: a literal, a constant, size_of, or arithmetic on them. Lengths computed by #run are planned. |
| `E0358` | array literal has the wrong count | [N] T.[...] gives exactly N elements. |
| `E0359` | cannot assign this | The target is a loop variable, a string byte, .count, or a temporary. Strings are immutable; copy the bytes into [N] u8 to change them. |
| `E0360` | break or continue outside a loop | break and continue belong inside while and for. |
| `E0361` | deferred code cannot leave its block | A deferred statement runs while its block exits, so it cannot return, break or continue out of it. |
| `E0362` | invalid cast | cast converts between numbers, and between enums and integers. cast,trunc converts between integer types only. |
| `E0363` | invalid enum value | Enum values are integers known while checking, fit the underlying type, and are distinct. |
| `E0364` | cannot loop over this | for takes a half-open range lo..<hi of one integer type, an array, a view, or a string. |
| `E0365` | ifx branches differ | Both branches of ifx produce a value of the same type. |
| `E0366` | a view needs a variable array | A view borrows an array's storage and may write through it, so the array must be a local variable. Copy a parameter or temporary into a local first. |
| `E0367` | field or element has the wrong type | The value given for a struct field, field default or array element has a different type. |
| `E0368` | type and value parameters share a name | A $NAME is either a type parameter ($T, written as a type) or a value parameter ($N, written as a fixed array length [$N] T) in one procedure, not both. Give the length its own name. |
| `E0369` | invalid export | main cannot be exported, and exported names cannot start with coax_, which the generated runtime uses. |
| `E0370` | bit operation needs integers | & \| ^ need two integers of one type; << >> shift an integer by an integer amount from 0 to its width minus one. |
| `E0371` | field name is reserved in C | Struct fields keep their names in generated C and headers, so they cannot be C or C++ keywords or start with '_'. |
| `E0372` | type name conflicts | A struct or enum name is already used by another type, a procedure, a constant, or a built-in. |
| `E0373` | enum base must be an integer | An enum's underlying type is one of s8..s64 or u8..u64. |
| `E0374` | constant index out of bounds | An index written as a constant must be inside a fixed array's length. Indexes computed at run time are checked when they run. |
| `E0375` | math or string intrinsic misused | sin cos tan exp log sqrt floor abs take one float, pow two floats of one type; len takes a string, array or view; byte_at takes a string and an index. Convert integers first: f64(x). |
| `E0376` | procedure cannot cross the C boundary | A #foreign procedure passes integers, floats, bool and borrowed views of them, returns a scalar or nothing, and its name must be a valid C symbol that is not main and does not start with coax_. |
| `E0377` | outside the Metal scalar profile | coax metal accepts f32 and bool values, if/else, locals and acyclic calls. Loops, strings, integers, f64, print, #assert and #foreign calls stay in the C library. |
| `E0378` | byte intrinsic argument mismatch | bytes_overlap takes byte views or strings. Float bit conversions take their matching f32/u32 or f64/u64 type. |
| `E0379` | #forall domain cannot be enumerated | A #forall binding must be nonempty: bool, a nonempty enum, an integer of at most 16 bits, or an increasing lo..<hi range of int constants. Test a wider type on a small instance: write the code so a smaller type or range exercises the same paths. |
| `E0380` | procedure not exercised by a check | Every procedure except main and #foreign imports must actually execute during an #authority check. Dead branches and pre-folded #run results do not count. Execution coverage is not a proof of the assertions. |
| `E0381` | type checker resource limit | The Coax checker needs its caller-owned graph, type, local, diagnostic and text capacities and at most 256 active semantic entries. Reduce nesting or use CK_caps. Failed checking never admits a partial typed tree. |
| `E0382` | invalid reflection category | field_info takes a struct type and enum_info an enum type. The type must have a field or member to select. Use type_info for scalar, array or view layout. |
| `E0383` | borrow may outlive local backing | A returned descriptor or a checked retained store may expose callee-local backing. Retained-store diagnostics name the original RHS or violating helper call. Keep backing with the caller and satisfy its outlives obligations; unsupported regions and helper-write return composition remain manual. |
| `E0384` | unknown module alias | A qualified name's alias must be bound in this module by #load "FILE.coax" as NAME;. Aliases belong to the logical module that loads them. |
| `E0385` | module has no such declaration | A qualified name sees only the declarations of the alias's module. Check the spelling, or load the module that declares it. |
| `E0386` | ambiguous unqualified name | Two modules declare this name and the use's own module does not. Qualify it with the alias of the module you mean: alias.Name. |
| `E0389` | private to its module | A module with an #export list keeps every other declaration private. Use an exported name, or add the declaration to its module's #export list. |
| `E0390` | export of an undeclared name | An #export list names declarations of its own logical module. Reexports of another module's names are not supported. |
| `E0391` | name exported twice | List each exported name once across a module's #export lists. |
| `E0392` | type parameter appears only in the result | A $T in a procedure's result type must first appear in one of its parameter types, which binds it at each call. Add a parameter whose type uses $T, or return a concrete type. |
| `E0393` | type parameter is not bound here | Only a procedure's parameter types bind a type parameter. A $T first written in a procedure body, or in a constant, check or other declaration outside a procedure signature, has nothing to bind it. |
| `E0394` | nested generic type | A placeholder is accepted as $T, as a view [] $T and as a fixed array [N] $T or [$N] $T. A view or array of a composite that holds a placeholder, such as [] [] $T, [] [$N] T or [4] [] $T, is not supported yet. |
| `E0395` | type parameter in a struct field | A struct field may use only the parameters its struct lists: Pair :: struct($T) { a: $T; b: $T; }. A plain struct lists none, so its fields have concrete types. |
| `E0396` | recursion through a generic procedure | A generic procedure cannot call itself: each instance would need a bounded specialization budget, which is not implemented. Write the recursion in a concrete procedure. |
| `E0397` | argument has no value to bind a type parameter | A call's argument binds $T to its type, and a call that returns nothing has none. Pass a value of the type the procedure should work on. |
| `E0398` | generic procedure cannot be exported | #export_c gives a procedure one C name and signature, which a procedure with type parameters does not have. Export a concrete procedure. |
| `E0399` | query depends on the instance | size_of, type_info, field_info, enum_info and type_name of a type parameter (or a view of one) depend on the type each call binds, and generic instantiation is not supported yet. |
| `E0387` | C cannot spell a module collision | Two modules may each declare a name, and their private C spellings are qualified. An #export_c or #foreign symbol, or a type in a C library header, is one global C name, so a collision there is refused, never merged. Rename one. |
| `E0388` | alias is not reexported | alias.Name cannot name another module's alias. Load the module you mean here with its own alias. |

## E04xx: compile-time evaluation

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0400` | compile-time resource budget exceeded | Compile-time evaluation defaults to 100000 shared steps; --run-steps selects a positive limit up to 250000000. Aggregate storage has an independent fixed cap (1572864 value slots, 131072 arrays and structs; coax test and mutate allow 33554432 and 2097152), and the error names which limit, what was needed and the limit. Each #test and #forall has its own budget, 20000000 steps by default (coax test --steps N). |
| `E0401` | compile-time code cannot capture a runtime value | #run code and constants see only constants and their own locals. |
| `E0402` | compile-time cycle | A constant, or a struct's field defaults, depend on themselves while being evaluated. |
| `E0403` | compile-time depth exceeded | Compile-time calls and dependencies are bounded at depth 64. |
| `E0404` | compile-time code cannot do I/O | print and other host effects are refused while compiling, so builds cannot depend on hidden effects. |
| `E0405` | compile-time read of an uninitialized variable | A variable declared with = --- was read before anything was assigned to it. |
| `E0406` | assertion failed | An #assert condition evaluated to false: at the top level while compiling, or as a statement inside a #test, a #forall or code they call. At run time the same statement traps in debug and release builds. |
| `E0407` | compile-time overflow or division by zero | Compile-time arithmetic is checked in every build mode, so release settings cannot change generated constants. |
| `E0408` | constant call needs #run | A constant that calls a procedure must say so: VALUE :: #run compute(); |
| `E0409` | compile-time result contains a view | A view points at memory that exists only while compiling, so it cannot be baked into the program. Return the array itself. |
| `E0410` | compile-time index out of bounds | An index or slice evaluated while compiling is outside its array, view or string. |
| `E0411` | compile-time cast or shift out of range | A cast evaluated while compiling does not fit its target, a value is not a member of the enum, or a shift amount is out of range. |
| `E0412` | compile-time math has no finite result | A math intrinsic evaluated while compiling gave infinity or NaN, such as sqrt(-1.0) or log(0.0). Compile-time results must be finite. |
| `E0413` | native check emission is not qualified | The verification-only checks-c command supports selected zero-argument #test bodies and their admitted checked callees. Selected #forall bodies, host effects, product main and unsupported representation/lifetime forms refuse at their original source location. This does not change ordinary product emission or waive authority checks. |

## E05xx: proto imports

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0501` | invalid proto import | Use #import_proto "profile.pb" as Prefix; with an exact FileDescriptorSet path relative to the source file. |
| `E0502` | proto descriptor rejected | The descriptor is malformed, outside importer limits or uses an unsupported shape. The importer reports the exact reason; no placeholder types are generated. |
| `E0503` | retired in 0.6.0 | Was: external proto importer unavailable. The compiled Coax descriptor parser, generator and wire runtime are linked into coax0. |
| `E0504` | proto imports are CPU-only | Generated binary codecs are CPU code and cannot be compiled as Metal shaders. |

## E06xx: source units

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0600` | invalid source load | Use #load "part.coax"; at file scope with a nonempty, NUL-free path, or #load "part.coax" as name; to bind its module to an alias. Loads are literal source inputs, never compile-time effects. |
| `E0601` | source unit cannot be read | The resolved source must be a readable regular file. Relative paths are resolved beside the unit containing #load. |
| `E0602` | source load cycle | A source unit loaded a canonical path that is still active. Break the cycle; completed shared dependencies load only once. |
| `E0603` | source graph budget exceeded | One compilation admits at most 128 distinct source units, 32 active units, 16 MiB of source bytes and 512 loads per unit. Source I/O is bounded before allocation and while reading. |
| `E0604` | unbalanced source unit | In a composed program every physical source must balance its own parentheses, brackets and braces within depth 128. Declarations cannot cross a source boundary. |
| `E0605` | invalid logical module | Write #module "engine.hud"; once per source unit, at file scope. An ID is 1 to 128 bytes of lowercase dotted segments; each segment starts with a-z and continues with a-z, 0-9 or _. |
| `E0606` | logical module claimed twice | Two different canonical source units claimed one logical module ID. A module has one authored owner unit; its other files are #load members of it. |
| `E0607` | source unit under two logical modules | A unit without its own #module is a member of the modules whose units load it, and it may belong to only one. Give the shared unit its own #module, or load it under one module. |
| `E0608` | module parameters are not supported | An aliased #load takes the module as written: #load "hud.coax" as hud;. Configured or parameterized modules are not part of coax0. |
| `E0609` | package search is not supported | An aliased #load names a .coax file by its path, relative to the loading unit. Nothing searches packages or installs dependencies. |
| `E0610` | alias target has no logical module | An alias binds to a logical module ID, so the loaded unit must claim one with #module "some.id";. Load a member file without an alias. |
| `E0611` | alias names two modules | Within one logical module an alias names one module. Pick another alias for the second module. |
| `E0612` | unsupported layout target | Layout facts are qualified only for the named native-lp64 target. coax layout and coax deps refuse any other --target instead of reporting LP64 values under its name. |
| `E0613` | malformed export list | #export takes file-scope identifiers separated by ',' and ends with ';': #export hud_slot, HudRect; |
| `E0614` | reexport in an export list | An export list names only its module's own declarations; alias.Name is a reexport, which is not supported. |
| `E0615` | export outside a logical module | #export belongs to a unit under a logical module. Claim one with #module, or load the file from a unit that does. |

## E07xx: device code

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0700` | outside the CUDA compute subset | coax cuda accepts bool, f32, f64 and sized integers, fixed arrays of at most 4096 scalars, views of numbers, if/else, for loops, break, continue and acyclic calls. Strings, structs, enums, while loops, defer, #assert, print and #foreign calls stay in the C library. Every #export_c procedure is a kernel: it returns nothing and its first parameter is its int work item. A kernel with for thread: 0..<T loops (T a multiple of 32 up to 1024) runs T threads per item: a thread loop writes a shared array only at the elements its thread owns, code between thread loops never writes one, and shared arrays fit in 32 KiB. |
| `E0701` | CUDA module has no kernel | coax cuda compiles the #export_c procedures of a file as kernels, with what they call. Mark at least one procedure #export_c. |
| `E0702` | outside the Metal compute subset | coax metal-compute accepts what coax cuda accepts (E0700). Apple GPUs have no binary64, so f64 is a float-float pair: f64_bits, f64_from_bits, sin, cos, tan and pow of an f64 and conversion of an f64 to an integer are refused. A view points into device memory, so a slice of a kernel's fixed array is refused except as a whole argument to a device primitive. The Apple matrix primitives (am_sg_mma_64x32x32, am_sg_spill_64x32, am_matmul_bf16) belong to group kernels of 128 threads (64, 128 or 256 for am_matmul_bf16), called between thread loops. |
| `E0703` | Metal compute module has no kernel | coax metal-compute compiles the #export_c procedures of a file as kernels, with what they call. Mark at least one procedure #export_c. |
| `E0704` | outside the SPIR-V lowering | coax spirv lowers what coax metal accepts (f32 and bool, if/else and acyclic calls) to SPIR-V 1.3 for Vulkan. --kernel NAME wraps one procedure of f32 parameters, returning f32 or bool, in a GLCompute entry point; without it the module is a library. A module has at most 256 procedures, 1024 locals in one procedure, 1024 constants and 32 arguments in one call. |
| `E0705` | shader entry point not found | coax spirv --vertex NAME and --fragment NAME make entry points of procedures declared in the file or the units it loads. Name one of them, spelled as declared. |
| `E0706` | outside the WGSL writer | coax wgsl writes a whole module the way lib/compiler/wgsl.coax does. The construct named in the message is one that writer doesn't accept; rewrite it with what coax spirv lowers, or keep it in the C library. |

## E08xx: generic structs

| Code | Meaning | What to do |
| --- | --- | --- |
| `E0800` | generic struct without arguments | A type that names a generic struct gives an argument for each parameter: Pair(int), Box(f64, 4). A literal Pair.{a = 1, b = 2} deduces them from its fields instead. |
| `E0801` | wrong number of struct arguments | A generic struct takes one argument for each parameter it lists: Box :: struct($T, $N) is written Box(int, 4). |
| `E0802` | generic struct over a borrow | A generic struct holds fixed storage only. Binding a parameter to a view, or to a struct or array that holds one, would carry a borrow past the rule that a view does not outlive its array. Store the array itself, or an index into it. |
| `E0803` | arguments on a type that takes none | Only a generic struct takes arguments. A builtin type, an enum or a struct without parameters is written by its name alone. |
| `E0804` | struct parameter not deduced | A literal of a generic struct deduces each parameter from a field given in it. Give a field that uses the parameter, or declare the variable's type: x: Pair(int) = Pair.{...}. |
| `E0805` | unknown constraint | A type parameter's constraint is one of equatable (== and !=), ordered (also < <= > >=), numeric (also + - * / and integer literals) or copyable (assignment, which every coax0 type allows). A length parameter $N takes no constraint. |
| `E0806` | binding outside a constraint | A call or instance gives a constrained parameter a type that does not meet its constraint. The error is at the use and names the generic declaration and the constraint. Ordered and numeric types are integers and floats; equatable types are scalars, strings and enums. |
| `E0807` | instantiation failed | A generic body checked against its constraints can still fail for one instance, for example a literal too large for u8. The instance's errors come first; this one is at the call that made the instance and lists its bindings. |
| `E0808` | misplaced constraint | A constraint is written once, where the parameter is bound: on its first $T in a procedure's parameters, or in a struct's parameter list. Elsewhere, and a second different constraint on one parameter, are refused. |
