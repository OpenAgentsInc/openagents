# Bounded retained-store checking (B1)

The compiler checks descriptor stores in every concrete procedure body, including void, uncalled, hidden check and instantiated generic bodies. It uses existing resolved declarations, types, calls and fields. The Coax policy is loaded from [retain-policy.coax](lib/compiler/retain-policy.coax), within the compiler fingerprint/bootstrap inventory. [B0](verification-retain-policy.md) records its earlier standalone foundation.

A write addresses storage; it does not address the previous descriptor's pointee. Current-frame inline copies and local descriptor slots remain local. Crossing a contained view resolves that descriptor prefix's backing. Parameter paths retain selected fields and wildcard dereferences. Normalized local/static array owners use the existing wildcard element sentinel for frame-relative classification, without exact element identity or a strong-update claim.

B1 source queries collapse static origins to their lifetime class, preserving descriptor type and role. Local and parameter identities stay exact. Addressed-storage and A1 return queries remain raw; the shared query cache keys the mode separately. This projection proves only the static lifetime relation, without an alias or value-identity claim.

Known callee-local backing retained through caller/static storage reports E0383 at the original RHS, including definitions that are never called. Parameter-to-external stores retain sparse outlives obligations. Actual checked calls project only the referenced source and destination paths once into their caller namespace. A known local violation reports at the original call; unused scratch does not become an origin. Source and destination known alternatives survive unknown arms. Later safe stores do not erase earlier may-effects.

Complete default-empty source descriptors differ from zero-length views of an owner and unknown facts. An unavailable helper return query or unrepresented dereferenced address stays manual; it does not become a complete-empty asserted destination. Value constructors lowered away from calls are not runtime call effects. Unmodeled foreign/intrinsic retention and active recursive dependencies remain explicit incomplete facts. There is no general recursive fixed point.

## Native observations and bounds

Optional observations expose procedure/call owner and site, independent fact/relation completeness, forbidden status and pending count. Consumers read only `CK_State.retain_report_count` after successful `CK_run`. Type, store, authority, Metal and resource rejection leave count zero. Accepted manual/pending rows are explicit. Raw report capacity and private cache tails are not an admitted result.

Existing query/origin/path/depth limits and the single shared 1,048,576 work counter remain. Sets and per-procedure effects are bounded at 64, logical paths at 8, and each supplied store at 128 raw pairs. A direct write visits at most 64 descriptor leaves; borrowed inline arrays are bounded at 64 elements. Coax computes an additional bounded effect workspace, clamped from twice the authored node count to 128..16,384 rows. Native code allocates/transports it. Observations are disabled normally and add no report work then; an explicitly requested short output refuses E0381 with zero committed count.

## Verification record

The [evidence record](../docs/verification/coax-retained-stores-2026-11-01/record.json) binds actual source, producer, raw outcomes and artifact identities. Check-first history retains 16 forbidden programs accepted by the earlier compiler, typed-graph assertion REDs, the original failed 909-check baseline and affected continuations. The corrected Coax program passed all 913 checks on the earlier qualified producer before seed generation; that is a program observation, not qualification of a new compiler image.

Final acceptance requires the fresh strict normal bootstrap, original full authority mutation scopes with zero survivors, deterministic C/header and compiler fixed points, the complete 30-case source inventory, generated-header/layout checks and the 19-case native observation corpus plus disabled/short controls at O0/O2/ASan+UBSan. Existing returned-borrow and relevant native/compiler consumers remain regression gates. Each receipt retains its actual producer; earlier results are not renamed as current observations.

Run the source and native gates with the explicitly selected compiler:

```sh
python3 coax/tests/retained_borrows.py --compiler /absolute/path/to/coax
python3 coax/tests/retained_borrows_native.py --compiler /absolute/path/to/coax
```

These drivers also run in the ordinary compiler test chain. They are maintenance tooling and introduce no runtime dependency.

## Remaining boundary

B2 local-carrier helper writes followed by returned-field reads, including precise actual SoPost composition, remain separate. B3 request defaults, active-owner admission, completion/cancellation, all result uses and backing-buffer reclamation remain separate. Host-entry outlives obligations are not automatically discharged. Foreign retention, ownership transfer, nested-block/loop lifetimes and copied handles have no general proof. This bounded diagnostic is not general ownership safety.
