from pathlib import Path
import hashlib,importlib.util,json,os,time
root=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents');out=Path('/tmp/coax-retained-borrows-B1/parser-origin-probe');out.mkdir(exist_ok=True)
producer=Path('/private/tmp/coax-retained-borrows-B1/normal165/snapshot/coax/bin/.bootstrap-bounded-normal/stage0');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('b1_origin_probe_process',root/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
rows=[]
for label,expr in [('distinct66','"x"'),('shared66','TEXT')]:
 p=out/(label+'.coax');items=','.join('Token.{text='+expr+'}' for _ in range(66))
 p.write_text('Token :: struct {text:string;}\nNode :: struct {name:string;}\nTEXT :: "x";\nstore :: (tokens:[]Token,nodes:[]Node) {nodes[0].name=tokens[0].text;}\n#test "probe" {tokens:=[66]Token.['+items+'];nodes:[1]Node;store(tokens[..],nodes[..]);}\n')
 before=h(p);r=bp.run([str(producer),'test',str(p),'--library','--list'],root,os.environ.copy(),60,1048576,time.monotonic()+65)
 for k in ['stdout','stderr']:(out/(label+'.'+k)).write_bytes(r.pop(k))
 r.update(source_sha256=before,source_unchanged=before==h(p),producer_sha256=h(producer),scope='Actual newstage0 frontend admission only; --list executes no authored checks.')
 (out/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n');rows.append({'case':label,'returncode':r['returncode'],'stderr':(out/(label+'.stderr')).read_text(),'elapsed_s':r['elapsed_s']})
print(json.dumps(rows,indent=2))
