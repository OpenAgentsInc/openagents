# B1 raw proof pack — prepared, not executed

Root must review the script before collection. Run only after the private evidence tree stops changing. This collector makes no compiler/issue verdict, edits no repository source, reads no secret/source outside the exact private B1 root, and runs no compiler, model, host tools or network commands.

Prepared invocation (choose a fresh output path):

    python3 /tmp/coax-retained-borrows-B1/proofpack-prep/proofpack.py \
      --source /tmp/coax-retained-borrows-B1 \
      --outdir /tmp/coax-retained-borrows-B1-proof-FRESH \
      --seconds 220

Use an outer bounded process at230s (owned group cleanup) and retain its raw stdout/stderr/transport separately. No invocation has run yet. Destination must be new and outside the source tree; parent must exist. This guarantees no output-archive recursion and preserves older attempts.

The complete before/after inventory lists SHA256 and size of EVERY regular file, selected or not. MachO/ELF/PE/Wasm/LLVM/object/library images and executable-bytecode suffixes are omitted, with actual identities retained. Executable text controllers remain included. Opaque archives/containers are separately omitted and identified, rather than nesting an uninspected archive that may contain an excluded binary. Compressed text files ending only in .gz remain ordinary selected files; tar.gz/tgz containers are omitted. No symlink or special object is followed or archived; symlinks have their link-text digest/length recorded. All reads use O_NOFOLLOW on every opened path component.

Selected raw JSON/logs/receipts, source snapshots, generated C/H and controllers are copied without byte changes under raw/. The archive also contains its before inventory. Copies are hash-checked while writing, then the entire source inventory is hashed again and must match. A final collection record binds both inventories and the archive SHA/size. Tar ownership/time/mode are normalized; source modes remain in inventory. Partial artifacts and failure records survive any refusal/deadline. The final canonical source/fingerprint/normal/native acceptance record and original-eight assessment remain separate Root-owned documents; collection outcome is merely collected.
