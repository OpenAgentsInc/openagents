#!/usr/bin/env python3
"""Collect B1 raw evidence, not a compiler/issue qualification verdict."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time

ALLOWED = Path('/tmp/coax-retained-borrows-B1').resolve()
BINARY_MAGIC = {
    b'\x7fELF', b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
    b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe',
    b'\xbe\xba\xfe\xca', b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca',
    b'BC\xc0\xde', b'\xde\xc0\x17\x0b', b'\x00asm', b'MTLB',
}
BINARY_SUFFIXES = {'.o', '.obj', '.dylib', '.so', '.dll', '.exe', '.a', '.lib', '.bc', '.metallib', '.pyc', '.pyo'}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def check_time(deadline):
    if time.monotonic() >= deadline:
        raise TimeoutError('proof collection deadline reached')


def open_regular(rootfd, name):
    """Each directory and the file must remain nonsymlink descendants."""
    parts = Path(name).parts
    if not parts or any(p in ('', '.', '..') for p in parts) or Path(name).is_absolute():
        raise ValueError('invalid relative member')
    parent = os.dup(rootfd)
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    finally:
        os.close(parent)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise ValueError('member ceased to be a regular file')
    return os.fdopen(fd, 'rb')


def excluded_image(name, head):
    lower = name.lower()
    if head[:4] in BINARY_MAGIC or head.startswith(b'MZ') or head.startswith(b'!<arch>\n'):
        return 'executable/object/library image magic'
    if Path(lower).suffix in BINARY_SUFFIXES or '.so.' in Path(lower).name:
        return 'object/library/executable bytecode suffix'
    if lower.endswith(('.tar', '.tar.gz', '.tgz', '.tar.bz2', '.tar.xz', '.zip', '.7z', '.zst')) or head.startswith(b'PK\x03\x04'):
        return 'opaque archive/container is not expanded or nested'
    return None


def inventory(source, rootfd, deadline):
    rows = []
    for current, dirs, files in os.walk(source, followlinks=False):
        check_time(deadline)
        # os.walk lists directory symlinks in dirs; record and prune them.
        names = sorted(files + [d for d in dirs if (Path(current) / d).is_symlink()])
        dirs[:] = sorted(d for d in dirs if not (Path(current) / d).is_symlink())
        for name in names:
            check_time(deadline)
            p = Path(current) / name
            relative = p.relative_to(source).as_posix()
            st = p.lstat()
            row = {'path': relative, 'mode': stat.S_IMODE(st.st_mode)}
            if stat.S_ISLNK(st.st_mode):
                text = os.fsencode(os.readlink(p))
                row.update(kind='symlink', selected=False, reason='never followed or archived', link_text_sha256=hashlib.sha256(text).hexdigest(), link_text_bytes=len(text))
            elif stat.S_ISREG(st.st_mode):
                digest = hashlib.sha256()
                head = b''
                size = 0
                with open_regular(rootfd, relative) as f:
                    opened = os.fstat(f.fileno())
                    while True:
                        check_time(deadline)
                        data = f.read(65536)
                        if not data:
                            break
                        if not head:
                            head = data[:512]
                        digest.update(data)
                        size += len(data)
                    final = os.fstat(f.fileno())
                if (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) != (final.st_dev, final.st_ino, final.st_size, final.st_mtime_ns, final.st_ctime_ns) or size != final.st_size:
                    raise RuntimeError('file changed while hashing: ' + relative)
                reason = excluded_image(relative, head)
                row.update(kind='regular', size=size, sha256=digest.hexdigest(), selected=reason is None)
                if reason:
                    row['reason'] = reason
            else:
                row.update(kind='special', selected=False, reason='nonregular filesystem object never opened')
            rows.append(row)
            if len(rows) > 100000:
                raise ValueError('inventory exceeds explicit100000-entry bound')
    return sorted(rows, key=lambda r: r['path'])


class ArchiveReader:
    def __init__(self, file, deadline):
        self.file = file
        self.deadline = deadline
        self.digest = hashlib.sha256()
        self.size = 0

    def read(self, size=-1):
        check_time(self.deadline)
        data = self.file.read(size)
        self.digest.update(data)
        self.size += len(data)
        return data


def add_bytes(tar, name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.mtime = 0
    tar.addfile(info, io.BytesIO(data))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ALLOWED)
    parser.add_argument('--outdir', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=220)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    destination = args.outdir.absolute()
    if source != ALLOWED or not source.is_dir():
        parser.error('source must be exactly the B1 private evidence tree')
    if not 1 <= args.seconds <= 840:
        parser.error('seconds must be1..840')
    # Resolving the existing parent prevents a symlink from putting output inside source.
    destination = destination.parent.resolve(strict=True) / destination.name
    if destination == source or destination.is_relative_to(source):
        parser.error('outdir must be outside source, so no output can recurse into the archive')
    if destination.exists() or destination.is_symlink():
        parser.error('outdir must be a new path; previous evidence is never overwritten')
    destination.mkdir()
    deadline = time.monotonic() + args.seconds
    rootfd = os.open(source, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        before = inventory(source, rootfd, deadline)
        before_bytes = encoded({'schema': 'coax.b1.raw-evidence.inventory.v1', 'source': str(source), 'files': before})
        (destination / 'inventory.before.json').write_bytes(before_bytes)
        partial = destination / 'raw-proof.tar.gz.partial'
        with partial.open('xb') as output:
            with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
                with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                    add_bytes(tar, 'meta/inventory.before.json', before_bytes)
                    for row in before:
                        if not row['selected']:
                            continue
                        check_time(deadline)
                        with open_regular(rootfd, row['path']) as f:
                            reader = ArchiveReader(f, deadline)
                            info = tarfile.TarInfo('raw/' + row['path'])
                            info.size = row['size']
                            info.mode = 0o644
                            info.mtime = 0
                            tar.addfile(info, reader)
                            if reader.size != row['size'] or reader.digest.hexdigest() != row['sha256']:
                                raise RuntimeError('archived bytes differ from before inventory: ' + row['path'])
        after = inventory(source, rootfd, deadline)
        after_bytes = encoded({'schema': 'coax.b1.raw-evidence.inventory.v1', 'source': str(source), 'files': after})
        (destination / 'inventory.after.json').write_bytes(after_bytes)
        if before != after:
            raise RuntimeError('source inventory/content changed during collection')
        final = destination / 'raw-proof.tar.gz'
        partial.rename(final)
        digest = hashlib.sha256()
        with final.open('rb') as file:
            while data := file.read(65536):
                check_time(deadline)
                digest.update(data)
        result = {
            'schema': 'coax.b1.raw-evidence.collection.v1', 'outcome': 'collected',
            'scope': 'Raw evidence collection only; compiler qualification and original-eight assessment are separate Root records.',
            'source': str(source), 'inventory_unchanged': True,
            'inventory_before_sha256': hashlib.sha256(before_bytes).hexdigest(),
            'inventory_after_sha256': hashlib.sha256(after_bytes).hexdigest(),
            'archive': {'path': str(final), 'sha256': digest.hexdigest(), 'size': final.stat().st_size},
            'selected_regular_files': sum(r['selected'] for r in before),
            'excluded_entries': sum(not r['selected'] for r in before),
            'retention': 'Every regular file is hashed, including omitted images/objects/opaque containers. No symlinks or special files are followed/archived; source controllers remain text. Tar members are regular0644 with normalized ownership/time. No old result is relabelled.',
        }
        (destination / 'collection.json').write_bytes(encoded(result))
        print(json.dumps(result, indent=2))
    except BaseException as error:
        (destination / 'failure.json').write_bytes(encoded({'schema': 'coax.b1.raw-evidence.collection-failure.v1', 'outcome': 'incomplete', 'error_type': type(error).__name__, 'error': str(error), 'scope': 'Partial output retained, not qualifying.'}))
        raise
    finally:
        os.close(rootfd)


if __name__ == '__main__':
    main()
