import hashlib, importlib.util, json, os, sys, time
from pathlib import Path
root=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
producer=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax')
label,selection=sys.argv[1:3]
source=Path(sys.argv[3]) if len(sys.argv)>3 else root/'coax/lib/compiler/checker.coax'
out=Path('/tmp/coax-retained-borrows-B1')/label
out.mkdir()
paths=[source,producer,*sorted((root/'coax/lib/compiler').glob('*.coax')),root/'coax/tools/bounded_process.py',root/'coax/tests/quiet_crash.py']
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes()
spec=importlib.util.spec_from_file_location('b1_bounded',root/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
argv=[str(producer),'test',str(source),'--library','--only',selection,'--evidence',str(out/'evidence.json')]
r=bp.run(argv,root,os.environ.copy(),120,1048576,time.monotonic()+125)
for key in ('stdout','stderr'):(out/(key+'.log')).write_bytes(r.pop(key))
after=hashes();r.update(inputs_before=before,inputs_after=after,inputs_unchanged=before==after,scope='Selected B1 Coax graph checks on earlier R5c producer; not authority coverage, native or new compiler qualification.')
(out/'process.json').write_text(json.dumps(r,indent=2)+'\n')
print((out/'stdout.log').read_text());print((out/'stderr.log').read_text());print(json.dumps({k:r[k] for k in ('returncode','elapsed_s','timeout','deadline_exhausted','output_limit','read_errno','stdout_eof','stderr_eof','inputs_unchanged')}));print(out)
