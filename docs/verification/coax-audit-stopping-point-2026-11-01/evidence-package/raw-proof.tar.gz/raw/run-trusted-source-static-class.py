from pathlib import Path
import hashlib,json,time,sys
root=Path.cwd();base=Path('/tmp/coax-retained-borrows-B1');r=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');compiler=r/'coax/bin/coax';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1];assert phase in ['baseline-static-class','emit-trusted-static-class'];d=base/phase;d.mkdir(exist_ok=False)
assert sha(root/'coax/lib/compiler/checker.coax')=='5cd6e5921f65d65cf1cb15ac800dc8382ca810427ac911f48eb9bcbe464a071c';assert sha(compiler)=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
before={str(p):sha(p)for p in [compiler,*sorted((root/'coax/lib/compiler').rglob('*.coax'))]};sys.path.insert(0,str(r/'coax/tools'));import bounded_process
rows=[];start=time.monotonic();deadline=start+840
if phase=='baseline-static-class':commands=[('baseline',[compiler,'test',root/'coax/lib/compiler/checker.coax','--library','--evidence',d/'evidence.json'],None)]
else:commands=[(name,[compiler,'c',root/rel,'--library','--header',d/(name+'.h'),'--profile-report',d/(name+'.profile.json')],d/(name+'.c'))for name,rel in [('checker','coax/lib/compiler/checker.coax'),('proto_importer','coax/lib/compiler/compiler.coax')]]
good=True
for label,argv,output in commands:
 assert all(sha(p)==h for p,h in before.items())
 obs=bounded_process.run(list(map(str,argv)),str(root),None,min(600,deadline-time.monotonic()),33554432,deadline,quiet_faults=True);out=obs.pop('stdout');err=obs.pop('stderr');(d/(label+'.stdout')).write_bytes(out);(d/(label+'.stderr')).write_bytes(err)
 if output is not None:output.write_bytes(out)
 passed=obs['returncode']==0 and obs['started']and obs['stdout_eof']and obs['stderr_eof']and not any(obs.get(k)for k in ['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'])
 row={'label':label,'argv':list(map(str,argv)),'observation':obs,'stdout_sha256':sha(d/(label+'.stdout')),'stderr_sha256':sha(d/(label+'.stderr')),'passed':bool(passed)};rows.append(row)
 (d/(label+'.process.json')).write_text(json.dumps(row,indent=2)+'\n')
 if not passed:good=False;break
after={p:sha(p)for p in before};good=good and before==after
record={'schema':'coax.retained-borrows.trusted-source-phase.v1','phase':phase,'outcome':'passed'if good else'failed','source_before':before,'source_after':after,'rows':rows,'elapsed_seconds':time.monotonic()-start,'scope':'Old qualified5c evaluates/emits NEWfrozenCoaxsource; no newCLI/seed/fixedpoint/normal qualification or install.'};(d/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'phase':phase,'outcome':record['outcome'],'record':str(d/'record.json'),'seconds':record['elapsed_seconds'],'stdout_tail':out[-1000:].decode(errors='replace')if phase=='baseline-static-class'else'emitted source retained, notprinted','stderr_tail':err[-2200:].decode(errors='replace')}));sys.exit(0 if good else 1)
