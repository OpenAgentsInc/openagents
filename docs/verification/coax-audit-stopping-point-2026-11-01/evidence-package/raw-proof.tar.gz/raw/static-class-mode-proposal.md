# Confirmed parser-origin capacity fix (check first)

Actual58bc frontend probes: two66-element Token arrays and the same void store helper. Distinct static literal nodes refuse E0381; shared constant literal passes. This isolates source-origin materialization, not whole-array leaf count. Original normal165 epoch remains71/165 incomplete.

Append `retain_classes:bool` to private CB_Context and to CK_BorrowQuery AFTER `next`. Defaultfalse keeps A1/address queries exact. Cache match includes mode; both modes use the SAME CB_State and query/origin storage/fuel. No counters/caps are reset or enlarged.

Only CB_put with mode=true maps STATIC origins to root0/path{}; kind/type/role remain intact. LOCAL and PARAMETER origins remain exact. This is lifetime-class projection for B1 sources, not alias/value identity. Mode=true is passed only to CB_expr source queries in CR_leaf/CR_apply; CR_address remains raw mode=false. B1 never exports STATIC source obligations, so root identity is irrelevant to its outlives relation. Mixed known LOCAL and unknown remain observable.

Check-first controls:65/66 distinct STATIC origins reduce to one valid BS/RP source; late LOCAL plus unknown remains forbidden; PARAMETER/LOCAL identities stay exact; raw/class query namespace roundtrip produces raw2 versus class1 regardless ordering. Then actual updated-stage0 probe/parser qualification is required. Existing A1 raw query/refusal regressions remain unchanged. No leaf cap or local-destination optimization is included.
