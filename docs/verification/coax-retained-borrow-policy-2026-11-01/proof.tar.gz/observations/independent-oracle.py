"""Data authoring only: independent literal finite expectations, no policy import/run."""
from pathlib import Path
import copy,hashlib,json
D=Path(__file__).resolve().parent
API=D/'proposed-api.md'
EXPECTED_API='c7b16606c4768ae5c33f5d24a9418737f89f55a2dacccfc0673f0e7d716268d5'
assert hashlib.sha256(API.read_bytes()).hexdigest()==EXPECTED_API
P=lambda steps:{'count':len(steps),'steps':[{'kind':k,'index':i}for k,i in steps]+[{'kind':0,'index':0}for _ in range(8-len(steps))]}
def term(kind,root,role=0,path=(),type=7,frame=None):
 return {'frame':(0 if kind==1 else 9)if frame is None else frame,'origin':{'kind':kind,'root':root,'role':role,'type':type,'path':P(path)}}
def address(storage):return {'storage':storage,'value_type':7}
S={'STATIC':term(1,10),'LOCAL':term(2,20),'INLINE':term(3,1,1),'PARAM':term(3,2,2,[(1,1)])}
T={'STATIC':address(term(1,30,type=11)),'LOCAL':address(term(2,40,type=11)),'INLINE':address(term(3,3,1,[(1,0)],type=11)),'EXTERNAL':address(term(3,4,2,[(1,2),(3,0),(1,0)],type=11))}
# Each row is literal (relation_complete, forbidden, obligation_count).
# Columns STATIC,LOCAL,INLINE,EXTERNAL; rows STATIC,LOCAL,INLINE,PARAM.
M=[[(1,0,0),(1,0,0),(1,0,0),(1,0,0)],
   [(1,1,0),(0,0,0),(0,0,0),(1,1,0)],
   [(1,1,0),(0,0,0),(0,0,0),(1,1,0)],
   [(0,0,1),(1,0,0),(1,0,0),(0,0,1)]]
CASES=[]
def case(name,src,dst,sc=True,dc=True,out=64,status=0,relation=True,forbidden=False,witness=(-1,-1),rows=(),frame=9,value_type=7,notes=''):
 result={'status':status,'facts_complete':bool(sc and dc)if status==0 else False,'relation_complete':bool(relation)if status==0 else False,'forbidden':bool(forbidden)if status==0 else False,'obligation_count':len(rows)if status==0 else 0,'bad_source':witness[0]if status==0 else-1,'bad_destination':witness[1]if status==0 else-1}
 CASES.append({'id':name,'call':'RP_check','input':{'frame':frame,'value_type':value_type,'sources':copy.deepcopy(src),'source_complete':sc,'destinations':copy.deepcopy(dst),'destination_complete':dc,'output_count':out},'expected':result,'expected_rows':[{'source':copy.deepcopy(a),'destination':copy.deepcopy(b)}for a,b in rows]if status==0 else[],'output_contract':'all-bytes-unchanged'if status!=0 or not rows else'prefix-fields-only; untouched tail/guards byte-identical','supplied_question_discharged':bool(status==0 and sc and dc and relation and not forbidden and not rows),'notes':notes})
for i,sn in enumerate(['STATIC','LOCAL','INLINE','PARAM']):
 for j,dn in enumerate(['STATIC','LOCAL','INLINE','EXTERNAL']):
  rel,bad,n=M[i][j]
  for sc,dc in [(False,False),(False,True),(True,False),(True,True)]:
   case('matrix-'+sn+'-'+dn+'-'+str(int(sc))+str(int(dc)),[S[sn]],[T[dn]],sc,dc,relation=rel,forbidden=bad,witness=(0,0)if bad else(-1,-1),rows=[(S[sn],T[dn])]if n else[])
# Empty and lower-bound meanings are independent of relation/unknown flags.
case('complete-default-empty-clears-external',[],[T['EXTERNAL']],out=0)
case('unknown-empty-source-not-safe',[],[T['EXTERNAL']],sc=False,out=0)
case('unknown-empty-destination-no-invented-local-escape',[S['LOCAL']],[],dc=False,out=0)
case('both-unknown-no-known-pairs',[],[],sc=False,dc=False,out=0)
case('complete-empty-destination-invalid',[],[],out=0,status=1)
case('complete-empty-destination-invalid-even-source-unknown',[],[],sc=False,out=0,status=1)
case('known-local-ordinary-zero-length-still-origin',[S['LOCAL']],[T['EXTERNAL']],forbidden=True,witness=(0,0),notes='Actual runtime view length is not an input here. Its known local origin must not be rewritten to an empty set.')
case('same-inline-local-frame-is-manual',[S['LOCAL']],[address(copy.deepcopy(S['LOCAL']))],relation=False,out=0)
selfparam=term(3,0,2,[(3,0)])
case('identical-full-parameter-origin-still-latent',[selfparam],[address(copy.deepcopy(selfparam))],relation=False,rows=[(selfparam,address(selfparam))])
case('mixed-known-bad-latent-and-manual-unknown',[S['PARAM'],S['LOCAL'],S['STATIC']],[T['LOCAL'],T['STATIC']],sc=False,dc=False,relation=False,forbidden=True,witness=(1,1),rows=[(S['PARAM'],T['STATIC'])])
case('reversed-address-order-changes-witness-not-output',[S['PARAM'],S['LOCAL'],S['STATIC']],[T['STATIC'],T['LOCAL']],sc=False,dc=False,relation=False,forbidden=True,witness=(1,0),rows=[(S['PARAM'],T['STATIC'])])
case('later-safe-static-does-not-erase-first-bad',[S['LOCAL'],S['STATIC'],S['LOCAL']],[T['EXTERNAL']],forbidden=True,witness=(0,0),sc=False)
# Paths and independent checked owner/type keys.
case('source-descriptor-needs-no-deref',[S['PARAM']],[T['LOCAL']],out=0)
last=address(term(3,7,2,[(1,i)for i in range(7)]+[(3,0)],type=19))
case('address-deref-at-active-slot-eight',[S['PARAM']],[last],relation=False,rows=[(S['PARAM'],last)])
owned=address(term(2,400,path=[(1,2),(2,3)],type=19))
case('field-owned-element-address-is-local',[S['PARAM']],[owned],out=0)
no_d=address(term(3,7,2,[(1,0),(2,0)],type=19))
case('descriptor-address-without-deref-invalid',[S['STATIC']],[no_d],sc=False,dc=False,status=1)
bad=copy.deepcopy(T['EXTERNAL']);bad['storage']['origin']['path']['steps'][1]['index']=1
case('deref-index-must-zero',[S['PARAM']],[bad],status=1)
bad=copy.deepcopy(T['INLINE']);bad['storage']['origin']['path']=P([(3,0)])
case('inline-address-cannot-cross-deref',[S['PARAM']],[bad],status=1)
bad=copy.deepcopy(T['EXTERNAL']);bad['storage']['origin']['path']=P([(1,0)]);bad['storage']['origin']['path']['steps'][7]={'kind':3,'index':0}
case('inactive-deref-cannot-admit-address',[S['PARAM']],[bad],status=1)
bad=copy.deepcopy(T['LOCAL']);bad['storage']['origin']['path']['steps'][7]={'kind':1,'index':0}
case('empty-source-still-validates-unused-address',[],[bad],status=1)
bad=copy.deepcopy(S['PARAM']);bad['origin']['path']['steps'][7]={'kind':0,'index':1}
case('unknown-flags-do-not-hide-invalid-source',[bad],[T['EXTERNAL']],sc=False,dc=False,status=1)
for label,src,dst in [('source-current-frame-mismatch',[term(2,20,frame=8)],[T['EXTERNAL']]),('destination-current-frame-mismatch',[S['STATIC']],[address(term(2,40,type=11,frame=10))]),('static-source-wrong-frame',[term(1,10,frame=9)],[T['LOCAL']]),('static-address-wrong-frame',[S['STATIC']],[address(term(1,30,type=11,frame=9))]),('source-leaf-type-mismatch',[term(3,2,2,type=8)],[T['EXTERNAL']])]:case(label,src,dst,status=1)
bad=copy.deepcopy(T['LOCAL']);bad['value_type']=8
case('destination-value-type-mismatch',[S['STATIC']],[bad],status=1)
for frame in [1,2147483647]:
 src=term(3,0,2,frame=frame);dst=address(term(3,63,2,[(3,0)],type=2147483647,frame=frame))
 case('frame-and-formal-upper-lower-'+str(frame),[src],[dst],frame=frame,relation=False,rows=[(src,dst)])
for frame in [0,-1,2147483648]:case('invalid-invocation-frame-'+str(frame),[S['STATIC']],[T['STATIC']],frame=frame,status=1)
for vt in [0,2147483648]:case('invalid-value-type-'+str(vt),[S['STATIC']],[T['STATIC']],value_type=vt,status=1)
# Literal canonical expected six rows: static destination first; then formal3,4.
p0,p2=term(3,0,2),term(3,2,2)
e3,e4=address(term(3,3,2,[(3,0)],type=11)),address(term(3,4,2,[(3,0)],type=11))
st=T['STATIC'];ordered=[(p0,st),(p2,st),(p0,e3),(p2,e3),(p0,e4),(p2,e4)]
case('canonical-destination-then-source-dedup',[p2,p0,p2],[e4,e3,e4,st],out=7,relation=False,rows=ordered)
case('short-output-late-atomic-refusal',[p2,p0,p2],[e4,e3,e4,st],out=5,status=2)
# Work is raw Cartesian pairs; all duplicate rows avoid capacity masking.
for n,m in [(3,42),(2,64)]:case('duplicate-pair-work-'+str(n*m),[p0]*n,[e3]*m,out=1,relation=False,rows=[(p0,e3)])
case('duplicate-pair-work-129',[p0]*3,[e3]*43,out=64,status=3)
case('work-before-zero-output-capacity',[p0]*3,[e3]*43,out=0,status=3)
bad=copy.deepcopy(e3);bad['storage']['frame']=8
case('late-invalid-before-work-and-unknown',[p0]*3,[e3]*42+[bad],sc=False,dc=False,out=0,status=1)
case('zero-output-no-pending-valid',[S['STATIC']],[e3],out=0)
case('zero-output-pending-capacity',[p0],[e3],out=0,status=2)
ps=[term(3,i,2)for i in range(8)];ds=[address(term(3,i,2,[(3,0)],type=11))for i in range(8)]
case('exact64-distinct-rows',list(reversed(ps)),list(reversed(ds)),out=64,relation=False,rows=[(s,d)for d in ds for s in ps])
case('sixtyfive-distinct-rows-capacity',[term(3,i,2)for i in range(5)],[address(term(3,i,2,[(3,0)],type=11))for i in range(13)],status=2)
case('invalid65-source-count-even-duplicates',[p0]*65,[e3],status=1)
case('invalid65-destination-count-even-empty-source',[],[e3]*65,status=1)
case('invalid65-output-count-even-safe',[S['STATIC']],[T['STATIC']],out=65,status=1)
BOUNDS=[{'counts':x,'expected_status':s}for x,s in [([0,0,0],0),([0,64,0],0),([64,0,0],0),([2,64,64],0),([64,2,0],0),([3,42,0],0),([3,43,64],3),([64,64,64],3),([-1,0,0],1),([0,-1,0],1),([0,0,-1],1),([65,0,0],1),([0,65,0],1),([1,1,65],1),([9223372036854775807,2,0],1),([-9223372036854775808,2,0],1)]]
result={'schema':'coax.B0.independent-literal-native-oracle.v1','state':'UNEXECUTED supplied-fact expectation data only','api_sha256':EXPECTED_API,'interpretation':'Root final rule: relation_complete=false for manual local/inline pairs OR pending obligations; unknown flags affect facts_complete only; zero known pairs relation=true.','status_ids':{'ok':0,'invalid':1,'capacity':2,'work':3},'frame':9,'value_type':7,'matrix_row_sources':['STATIC','LOCAL','INLINE','PARAM'],'matrix_column_destinations':['STATIC','LOCAL','INLINE','EXTERNAL'],'literal_matrix_relation_forbidden_obligation_count':M,'bounds_cases':BOUNDS,'check_cases':CASES,'counts':{'matrix':64,'check_total':len(CASES),'bounds':len(BOUNDS)},'native_adaptation':'Use actual generated header types/exports. Array storage/input spans valid immutable/disjoint. Poison full writable output and surround guards; all failure output bytes and successful tail/guards stay identical. Compare only named/active prefix fields on success, never C padding. These supplied type/path/frame facts are not evidence that a compiler or host pointer satisfies them.','not_claimed':'No compiler integration, native execution, mutation, lifetime soundness, frame ancestry, nested lexical proof, host allocation/cancellation/copy ownership safety, or permission to retain foreign pointers.'}
p=D/'independent-native-oracle.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'counts':result['counts'],'bytes':p.stat().st_size}))
