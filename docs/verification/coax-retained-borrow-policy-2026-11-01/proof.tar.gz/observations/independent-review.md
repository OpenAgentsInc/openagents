# B0 independent review and native oracle

This is supplied-fact policy review only. No Coax checks, compiler, mutation or native program ran. R and B checkouts were not changed. The JSON expectations were authored before reading the implementation, from the final API `c7b16606…716268d5` and Root's explicit relation-bit clarification. The original ambiguity and its superseded interpretation are not carried into this table.

| Known source | Static address | Current local address | By-value inline address | External parameter address |
|---|---|---|---|---|
| Static | clear | clear | clear | clear |
| Current local | forbidden | manual | manual | forbidden |
| By-value parameter inline storage | forbidden | manual | manual | forbidden |
| Parameter descriptor | pending | clear | clear | pending |

`clear`: relation complete, no forbidden witness or pending row. `forbidden`: relation complete, forbidden true, exact first input-order witness. `manual`: relation incomplete, not forbidden, no obligation. `pending`: relation incomplete, not forbidden, one latent obligation. In every cell `facts_complete` is exactly the conjunction of the two supplied flags. Unknown alternatives do not delete known rows or witnesses. With zero known pairs the relation bit is vacuously true, independently of the flags.

Static terms have frame0. Every other term must have the invocation frame; unrelated frame IDs are invalid, not inferred outer/inner relations. Even identical local identities stay manual in this profile. Even identical full parameter origins yield a pending external-store obligation; formal equality is not a lifetime proof.

An addressed storage key is separate from the checked value key. The oracle deliberately uses value_type7 with storage.owner.type11/19/INT32MAX. A descriptor source may have no DEREFERENCE; an externally addressed parameter must have an active DEREFERENCE somewhere in its path, including after FIELD steps or in slot8. An inactive or nonzero-index DEREFERENCE is invalid. Copied inline storage cannot use it.

## Concrete edges to retain beyond the basic matrix

- Combine a pending pair, a known forbidden pair and an unsupported local pair under unknown flags: retain the obligation, false relation bit, true forbidden bit and exact source-major witness together. Sorting output must not reorder witness selection.
- Complete-empty source means default-empty descriptor facts. It still validates every supplied address. Unknown-empty source remains incomplete; unknown-empty destination cannot invent a local escape without a known external address. An ordinary zero-length locally backed view is still a known local origin.
- Validate late malformed metadata before work/capacity or unknown handling. A source3×destination43 workload with the last destination frame wrong is invalid, not work. With all valid duplicates it is work, even when output capacity is zero.
- Work counts raw pairs before deduplication:126 and128 duplicated pairs produce one pending row;129 refuses. Exactly64 unique rows fit;5×13 distinct pending rows give exactly65 and refuse atomically.
- Canonical output is destination-storage origin then source origin. The six-row independent example deliberately reverses both input orders, includes duplicates, and places static destinations before parameter destinations. Short output must not publish its first five rows.
- All invalid/work/capacity results clear flags/count and return witness indices−1; callers must inspect status. That is a hard refusal, never safe empty facts. Failure output and successful unused tail/guards are byte-preserved. Successful prefix comparison uses named/active fields, not padding bytes.

The literal corpus has64 matrix/flag cases,48 additional `RP_check` cases and16 scalar `RP_bounds` cases. It is finite data, not a second implementation or runtime dependency. It makes no claim that a supplied type/path is a real checked graph, a pointer is valid, an allocator outlives a result, a copied active request owns its handle, cancellation revokes a view, or nested lexical regions are proved.

A later read of implementation `760958eb…93c50ed` found its public classification, role/frame/type admission, invalid-before-work ordering and staged atomic publication consistent with these expected cases. No semantic/API mismatch was found by source inspection. This is not a substitute for Root's actual generated-header/native/ASan/UBSan and zero-survivor qualification, and does not qualify compiler integration.
