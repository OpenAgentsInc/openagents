# B0 supplied retained-store policy: frozen proposal

Placement: `coax/policy/retain-policy.coax`, unloaded; `#load "../lib/compiler/borrow-summary.coax"; #authority;`. No compiler integration, resolver, diagnostic, source-acceptance, request ownership or runtime lifetime claim. The current provenance inventory excludes this new directory. B1 must explicitly load/integrate it later and qualify that changed compiler graph.

## Exact carriers and public ABI

```jai
RP_MAX_TERMS :: BS_MAX_SET; RP_MAX_WORK :: BS_MAX_WORK;
RP_Status :: enum u8 {ok; invalid; capacity; work;}
RP_Term :: struct {frame:int; origin:BS_Origin;}
RP_Address :: struct {storage:RP_Term; value_type:int;}
RP_Obligation :: struct {source:RP_Term; destination:RP_Address;}
RP_Result :: struct {
 status:RP_Status; facts_complete:bool; relation_complete:bool;
 forbidden:bool; obligation_count:int;
 bad_source:int = -1; bad_destination:int = -1;
}
RP_bounds :: (source_count:int,destination_count:int,output_count:int)->RP_Status #export_c;
RP_check :: (frame:int,value_type:int,sources:[]RP_Term,source_complete:bool,
 destinations:[]RP_Address,destination_complete:bool,out:[]RP_Obligation)->RP_Result #export_c;
```

`RP_bounds` admits all three counts0..64, then at most128 source×destination pairs. There is no increase to BS limits. `RP_check` reports invalid scalar extents before dereferencing spans, validates every supplied term/address before reporting pair-work/capacity errors, and never multiplies an unadmitted count. Complete destination alternatives cannot be empty for an asserted store; unknown destination with zero known alternatives is permitted but incomplete.

`frame` and `value_type` are1..2147483647. Every nonstatic supplied term uses exactly that current frame; static terms use frame0. Frame IDs bind supplied symbols; there is no frame/region ancestry inference. `BS_origin_valid` owns term/path shape. Every source.origin.type equals value_type; every destination.value_type equals it. Addressed storage.origin.type is a separate checked storage key and may differ. No second resolver validates those supplied checked type IDs.

An address PARAMETER+INLINE has no DEREFERENCE and means callee-owned by-value copy storage. An address PARAMETER+DESCRIPTOR must have an actual DEREFERENCE anywhere in its path; FIELD-before-DEREFERENCE is valid. It denotes externally addressed storage, not the descriptor previously stored there. LOCAL/STATIC backing addresses reuse BS FIELD/owned-ELEMENT paths; known aliases are lowered to their backing owner by the future checker pass. Source PARAMETER+DESCRIPTOR origins need not contain DEREFERENCE. View indexing is wildcard DEREFERENCE, never a fabricated exact ELEMENT.

Input spans are valid/immutable and disjoint from public writable out for the call. Borrowed storage, physical pointer validity and C padding remain host/caller duties. Only named fields/active path fields form semantic identity; inactive logical fields must be BS canonical zeros.

## Independent table and status semantics

- Static source to any known address: no outlives obligation.
- Caller parameter descriptor source to current LOCAL/INLINE-copy destination: no latent external-store obligation.
- LOCAL or PARAMETER+INLINE source to PARAMETER+DESCRIPTOR/static destination: forbidden at definition.
- PARAMETER+DESCRIPTOR source to PARAMETER+DESCRIPTOR/static destination: preserve a latent obligation, even identical formal ordinals. Complete facts do not discharge it; relation_complete=false while this known relation is pending.
- LOCAL/INLINE source to LOCAL/INLINE destination: relation_complete=false; unsupported nested lexical ordering stays manual.

`facts_complete` is exactly both supplied completeness flags. It is independent of relation_complete, forbidden and pending obligations. `relation_complete` is true exactly when every known pair is decided: known forbidden relations count as decided, but same-frame local ordering and parameter-to-external latent obligations keep it false. Empty known-pair sets are vacuously true, regardless of completeness flags. Unknown alternatives never erase known pairs, forbidden witnesses or latent obligations. First forbidden witness is source-major input order, then destination index. No violation means both indices-1. Explicit complete-empty source means the checked descriptor has no backing origin (default empty); it does not mean an ordinary zero-length view has no owner. A source0/complete=false remains incomplete. There is no last-write/strong-update operation here.

On success, all distinct pending obligations are canonically sorted by BS destination-storage-origin, then BS source-origin. The single invocation frame/value_type constraints make frame/value-type comparisons redundant; those fields are still preserved exactly in each returned row. Duplicates consume pair work before deduplication. Output count≤64 and caller capacity; the untouched output tail remains unchanged.

All invalid/work/capacity returns have facts_complete=false, relation_complete=false, forbidden=false, count0 and witness indices-1. Public output remains entirely unchanged. Callers MUST check status; hard refusal is not empty safe facts. On ok, only facts_complete && relation_complete && !forbidden && obligation_count==0 discharges this supplied frame-level store question; it grants no host allocator/reclamation or copied-handle ownership guarantee.

No substitution is implemented in B0. B1 remaps exactly referenced source/address projections once into the caller namespace using existing BS machinery and retains unknown known-witness lower bounds. B2 local helper-write/read-after-write return composition and B3 request lifecycle remain separate.

## Check-first matrix

1. First meaningful RED: known local source -> external view-backed Slot, expected forbidden=true and exact witness; stub cannot reject. Preserve source and producer hashes/raw assertion diagnostic.
2. All4 source classes×4 destination classes×both completeness flags: exact independent forbidden/manual/obligation truth table, deterministic fields, output/tail poison.
3. Complete-empty vs unknown source; complete-empty address invalid; zero-length-owned source still known local. Known forbidden plus unknown and multiple alternatives preserve first witness; later static alternative cannot erase it.
4. FIELD-before-DEREFERENCE, exact FIELD and owned ELEMENT, wildcard DEREFERENCE and all8 active path components; malformed dereference/index/inactive fields. Param INLINE and descriptor destination admission differ.
5. Frame0/static vs same-frame nonstatic, extrema1/INT32MAX and mismatches; source/value_type/address.value_type equality with independent address owner.type.
6. Scalar counts-1/0/64/65; pair126/128/129; work is pre-dedup. Invalid late metadata wins over work/unknown.
7. Canonical destination/source insertion in both orders and duplicate elimination; same formal ordinal remains pending. Exact64 unique obligations vs65, short/empty output and late capacity refusal preserve complete output.
8. Independent Root native generated-header/layout, full-span guards/tails, O0/O2/ASan/UBSan and malformed native extent facts. No invented aggregate-padding equality.

No mutation or broad gate is run by the author until Root coordinates the frozen changed policy. Root owns the final root-only zero-survivor and native qualification.
