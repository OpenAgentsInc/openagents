from pathlib import Path
import sys,time,json,hashlib,os
root=Path.cwd();r=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');d=Path('/tmp/coax-retained-borrows-B0');phase=sys.argv[1];assert phase in ['mutation-v2','native-v1'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=root/'coax/policy/retain-policy.coax';compiler=r/'coax/bin/coax';assert sha(source)=='ddfdfd79d76d633dfa6c97f2c11af15b61b7bea66525a3a9c1d872b8d213e00a';assert sha(compiler)=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
out=d/(phase+'-transport');out.mkdir(exist_ok=False);files=[source,root/'coax/lib/compiler/borrow-summary.coax',compiler];env=None
if phase=='mutation-v2':argv=[str(compiler),'mutate',str(source),'--root-only','--jobs','4']
else:
 files += [root/'coax/tests'/n for n in ['retain-policy-native.c','retain_policy_native.py','retain_policy_vectors.py','retain-policy-oracle.json']]
 env={**os.environ,'COAX_TEST_COMPILER':str(compiler),'COAX_RETAIN_POLICY_RECORD_DIR':str(d/'native-v1')};argv=[sys.executable,str(root/'coax/tests/retain_policy_native.py')]
before={str(p):sha(p)for p in files};sys.path.insert(0,str(r/'coax/tools'));import bounded_process
start=time.monotonic();p=bounded_process.run(argv,str(root),env,840,16777216,start+840,quiet_faults=True);stdout=p.pop('stdout');stderr=p.pop('stderr');(out/'stdout').write_bytes(stdout);(out/'stderr').write_bytes(stderr);after={name:sha(Path(name))for name in before}
good=p['started']and p['returncode']==0 and p['stdout_eof']and p['stderr_eof']and not any(p.get(k)for k in ['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'])and before==after
record={'schema':'coax.retain-policy.qualification-transport.v1','phase':phase,'argv':argv,'observation':p,'source_before':before,'source_after':after,'stdout_sha256':sha(out/'stdout'),'stderr_sha256':sha(out/'stderr'),'transport_ok':bool(good),'elapsed_seconds':time.monotonic()-start,'scope':'New standalone supplied-fact policy only, matched unchanged old qualified5c producer. No accepted-source/compiler integration, new normal seal, request lifecycle or host-lifetime qualification.'};(out/'transport.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'phase':phase,'transport_ok':bool(good),'record':str(out/'transport.json'),'elapsed_seconds':record['elapsed_seconds'],'stdout_tail':stdout[-3000:].decode(errors='replace'),'stderr_tail':stderr[-2500:].decode(errors='replace')}));sys.exit(0 if good else 1)
