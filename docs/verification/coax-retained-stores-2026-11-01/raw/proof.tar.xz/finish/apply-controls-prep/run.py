from pathlib import Path
import hashlib,importlib.util,json,os,shutil,time
root=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents');base=Path('/tmp/coax-retained-borrows-B1-finish/apply-controls-execution');base.mkdir()
producer=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax');assert hashlib.sha256(producer.read_bytes()).hexdigest()=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
spec=importlib.util.spec_from_file_location('bp',root/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
s=(root/'coax/lib/compiler/checker.coax').read_text();a=s.index('CR_apply ::');z=s.index('\n}',a)+2;part=s[a:z]
items=[('full-authored-baseline',None,None,None),('link-resource','{CK_resource(b.c,e.loc);return;}effect:=','{return;}effect:=','retained applied effect links'),('source-classification','source_b.retain_classes=true;','','retained applied source classes'),('first-error','if b.c.state[0].fatal || b.c.state[0].error_count>0','if b.c.state[0].fatal && b.c.state[0].error_count>0','retained applied local violation'),('effect-count','remaining-=1;','remaining-=2;','retained applied two effect chain'),('relation-and','b.c.nodes[owner].retain_relation && callee.retain_relation','b.c.nodes[owner].retain_relation || callee.retain_relation','retained caller preserves a callee manual relation')]
rows=[];bad=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
for name,old,new,only in items:
 out=base/name;out.mkdir();shutil.copytree(root/'coax/lib/compiler',out/'source');source=out/'source/checker.coax';source.write_text(s)
 if old is not None:
  assert part.count(old)==1,(name,part.count(old));source.write_text(s[:a]+part.replace(old,new)+s[z:])
 paths=[producer,Path(__file__),root/'coax/tools/bounded_process.py',root/'coax/tests/quiet_crash.py',*sorted((out/'source').rglob('*.coax'))]
 def hashes():return{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
 before=hashes();argv=[str(producer),'test',str(source),'--library','--evidence',str(out/'evidence.json')]
 if only:argv+=['--only',only]
 r=bp.run(argv,root,os.environ.copy(),90,2097152,time.monotonic()+95,quiet_faults=True)
 for k in('stdout','stderr'):(out/(k+'.log')).write_bytes(r.pop(k))
 r.update(inputs_before=before,inputs_after=hashes(),original_checker_sha256=hashlib.sha256(s.encode()).hexdigest(),mutation={'old':old,'new':new},scope='Coax PROGRAM original authored checks/control only; historical R5c producer, not current compiler qualification.');r['inputs_unchanged']=r['inputs_before']==r['inputs_after'];(out/'process.json').write_text(json.dumps(r,indent=2)+'\n');clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and r['inputs_unchanged'] and not any(r.get(k)for k in bad);stderr=(out/'stderr.log').read_text();row={'name':name,'rc':r['returncode'],'clean_transport':clean,'elapsed_s':r['elapsed_s'],'semantic_red':bool(only) and 'error[E0406]: assertion failed' in stderr,'stderr':stderr,'stdout_tail':(out/'stdout.log').read_text()[-1800:],'record_sha256':hashlib.sha256((out/'process.json').read_bytes()).hexdigest()};rows.append(row);print(json.dumps(row),flush=True)
(base/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
