# Full chapter 30 delivery proposal

Status: private read-only planning, no implementation, issue publication, claim or qualification. Begin only after B1 is actually qualified, pushed and closed. The owner's later instruction selects complete prerequisite language features and full chapter 30, including astronomical time and warp. The earlier `initial-profile-proposal.md` remains unchanged historical planning; its proposed stopping boundary is superseded.

## Scope and project identity

The next planned Coax book chapter is **30, Typed clocks and multirate ticks**, current ROADMAP R13/spec stage 10. Chapter 29 is partly implemented. B2 retained helper composition is a separate R3a child, not chapter 30. Complete B1 first; do not infer B2/B3 completion from its diagnostics or reports.

The retained live project-list observation found no R13/typed-clock/chapter30 task. Its old `r12` milestone means backends after profiling, while the current ROADMAP R12 means units/frames. Root should publish a **new explicitly current-roadmap chapter30 parent**, with the acceptance below and linked prerequisite children. Do not overwrite/reuse the old `r12` identity or close unrelated umbrella milestones.

The goal is executable language semantics plus actual consumer adoption. A status-returning clock library alone does not supply R2 typed-error enforcement or R11 effects. Conversely full chapter30 does not require claiming all R12 transforms, all R15 integrators/event location, full R16 replay, or every Aethyr39/46 design promise. Those remain separately scoped unless a concrete chapter30 dependency requires them.

## Delivery graph

1. **B1 completion barrier**: original full-scope authority mutation zero without equivalence waivers; actual normal bootstrap/fixed points; fresh generated-header layout guards; all seven whole final gates; required docs/render review and a qualified push/closure. Current partial/seeded/private results remain their actual historical scopes.
2. **C30-contract**: freeze normative syntax, result/effect contracts, instant/duration representation, target profiles, schedule/tie rules, conversion provenance and evidence inventory check-first.
3. **C30-R2**: tagged results/optionals, exhaustive switching and typed propagation/cleanup in a real adapter.
4. **C30-R11**: complete transitive effect summaries and enforcement, source-path explanations and real engine/generic consumers. This depends on R2 cleanup/error edges and any procedure-value/callback forms actually required by these consumers.
5. **C30-domains**: typed instants/durations, explicit mappings and actual host-clock effects. Depends on the necessary R12 time quantities, R2 and R11.
6. **C30-schedule**: declared rates/phases, held samples, typed stale errors, deterministic ordering and recorded boundaries.
7. **C30-consumers**: actual simulated-robot physics/control and actual Verse fixed-step call paths use the declarations, preserving their existing safety/order contracts.
8. **C30-astronomy**: distinct TAI/TT/TDB/UTC types, pinned conversion data/series, coverage refusal and independent published numeric oracles.
9. **C30-warp**: event-capped simulation advancement, canonical equal-time handling and identical event order at warp1 and1000000; recorded boundaries available to replay.
10. **C30-final**: chapter examples debug/release, independent native/consumer/target evidence, updated registry/links/claims, final qualification and push. Close the chapter30 parent only when every acceptance row is observed.

These are delivery slices, not permission to stop at the initial profile. Each meaningful finished slice can carry its own honest passing record and push while the parent remains open. Keep commands below15minutes with shards/slices; do not add a whole-task deadline or rerun passing unchanged inputs merely to confirm them.

## C30-contract: decisions before code

Write explicit acceptance cases before choosing syntax or lowering. Preserve existing left-to-right evaluation, destination-before-value assignment, exactly-once destinations and return-before-cleanup semantics.

- **Targets**: state what native LP64 and browser/Wasm32 support is claimed. Observe each actual generated-header/layout contract separately; LP64 evidence cannot be relabelled Wasm32. Device effects/backends are not granted by a clock tag.
- **Time representation**: choose and specify epoch, resolution, count range, overflow, rounding and duration conversion. Aethyr currently uses integer nanoseconds; Quantity currently admits f32/f64 carriers. Either implement an explicit checked integral-duration facility or state and test a deliberate representation/adaptor contract. Do not silently call an integer record an existing integer Quantity, silently widen R12 admission caps, or drive exact scheduling decisions through unspecified float rounding.
- **Static types versus supplied facts**: domains/scales must remain nominal in accepted source types. A caller-supplied epoch/source identifier records the asserted origin; it authenticates no host observation.
- **Syntax**: freeze one implemented task/rate/Hold declaration form. If the book's `task @rate` sketch changes, replace it with runnable implemented declarations and explain the spelling; do not leave an unavailable sketch labelled implemented.
- **Outputs and resources**: define fixed bounds, unknown/refusal states and atomic publication before implementation. Do not enlarge work/container limits to hide an algorithmic failure; measure real compiler self-input as well as unit fixtures.
- **Public contracts**: preserve existing FrameClock and published schemas or version changed contracts. Record real host initializer use when nonzero state defaults matter; zeroed allocation does not invoke generated defaults or initialize descriptor pointees.

## C30-R2: real typed recoverable failures

Implement the ROADMAP's first delivery, not merely `struct {value,error}` conventions:

- Tagged unions/results and optionals, exhaustive switching, typed result/error alternatives and ignored-error diagnostics. Invalid/inactive payload use must be refused by the specified type/control-flow rules.
- `try` and `or_else` preserve original error domain/code and propagate through the checked control-flow representation. Active `defer` actions execute exactly once in reverse order on recoverable exits, including nested scopes and early returns; normal return-value computation remains before deferred mutation.
- Fatal assertion/overflow/bounds traps remain distinct, with no promise of normal cleanup or safe continuation. Do not translate memory traps into recoverable exceptions.
- Support generic result payloads and whichever multiple-result/procedure-value/callback forms the actual adapters need; retain immutable value parameter and evaluation-order guarantees. Owning callback retention still requires its actual lifetime contract.
- Migrate one real native file/resource or protocol-adapter error path. Author malformed-input, each alternative, ignored/missing handling, early release, callback-host-boundary and error-code preservation controls before migration. Preserve existing published async ownership/cancel contracts; if selecting an adapter blocked on B2/B3, either complete that dependency or choose/review a genuinely synchronous concrete adapter without silently changing the issue dependency.

Expected evidence: original-source positive/negative compiler fixtures; independent side-effect/cleanup trace oracle; Coax policy checks and zero-survivor authority mutation; evaluator and emitted C atO0/O2/sanitized; actual adapter integration. Richer R2 adjacent ergonomics/async ownership parents remain open unless their own full acceptance is met.

## C30-R11: transitive effects are enforced facts

The current coarse expression-order effect facts do not implement this contract. Put semantic analysis in Coax, with C++ limited to graph/workspace transport and platform effect boundaries.

- Cover allocation, blocking, hostI/O, clocks, randomness, foreign calls, atomics and region reads/writes through every reachable implementation: concrete/generic instantiations, procedure values/callbacks, cleanup/error paths, formatting/logging, container growth and foreign boundaries.
- Compute summaries to a bounded fixed point with explicit recursion/unknown handling. Unknown foreign/callback effects remain visible unfulfilled obligations. Reject an allegedly pure procedure if any reachable operation/unknown obligation violates purity, including indirect clock reads.
- Region/range overlap uses actual alias/view/pointer facts; distinct field spellings do not prove disjointness. Where proof is absent, retain/refuse the obligation rather than assuming absence. This is an effect-analysis contract, not a blanket general memory-safety claim.
- Reviewed foreign summaries name exact boundary/source identity and effects; unreviewed functions cannot silently default to pure. Future optimization consumes only checked summaries.
- Query/source-map output explains the concrete source path that allocates, blocks or reads a clock. New public query/evidence schemas require versioned contracts where applicable.

Gate one actual engine subsystem and one generic library routine. Literal fixtures hide allocation behind a generic, callback, defer/error branch and foreign call; each must surface with its path. Native instrumented boundary counters compare declared versus observed allocation/blocking, using supplied buffers where needed. Exact effect-source mutations change/refuse the summary. Do not claim an observed limited workload proves all possible host effects.

## C30-domains and mappings

Expose distinct simulation, steady and civil instant types built on admitted time durations. Same-domain subtraction yields a duration; mixed-domain arithmetic/calls and missing mappings fail actual source compilation.

- Simulation pauses, scales and jumps. Its epoch/reset semantics invalidate prior mappings, held values and schedule state as specified.
- Steady time is monotonic within its named source/epoch; reversed samples and overflow are refused. Civil samples can be corrected backward and are not interchangeable with steady deadlines.
- Every cross-clock conversion names a recorded mapping/pinned offset with identity, direction, finite coverage and rounding. Test wrong-source/epoch, changed mappings, exact endpoints and outside coverage. Do not infer a universal simulation↔civil relation.
- Reading any host clock is an R11 effect. A pure caller must be rejected even when the read is hidden behind a generic/helper/callback/defer path. C performs only the actual platform clock read; Coax owns admission, arithmetic, conversion and scheduling decisions.

Use literal boundary oracles and actual compilation negatives before implementation. Native headers/ABI and conversion output guards precede kernel calls. Read/copy/rendering adapters never bypass domain rules by dropping tags inside the accepted Coax call graph.

## C30-schedule and held data

Declare positive rates and legal phases with a defined rational/integral resolution and exact supported horizon. Define deterministic simultaneous-task order by a stable explicit key. Specify overflow and nonrepresentable-rate refusal rather than accumulating floating phase drift.

A held sample records its source domain/epoch/instant and completion boundary. A fast reader sees the last completed slow publication; ties explicitly decide whether same-time publication precedes consumption. Missing/future/wrong-epoch samples and age beyond the declared maximum return distinct typed R2 errors. Age exactly at the maximum and one tick beyond require independent preauthored expectations.

Qualify several real rate/phase combinations over many ticks, including robot1000Hz/500Hz or the existing500Hz/20Hz consumer as selected, and Verse64Hz=15625000ns. Keep both a small literal trace and a separately authored reference scheduler. Include pause/step, epoch reset, large gaps, simultaneous tasks, no-progress, capacity, overflow and refusal atomicity. Record admitted clock boundaries and original identities in a versioned replay-input form; this supplies R16 inputs without claiming full replay/snapshot implementation.

## Actual consumers

**Robot**: use actual Psionic physics/control paths and `step-clock-*`/`panda-clock-adapter` rather than an unused demo. Freeze the chosen rates and prove declared schedule→forward/sample/control/receipt order. Preserve chunk/horizon, watchdog/refusal, stale receipt and failure semantics. Compare the original recorded trace and an independent new schedule oracle. No model-weight CPU rerun is needed merely to exercise scheduling; do not invent a new robot-policy score from a deterministic fixture.

**Verse**: route the real Aethyr/Verse fixed-step entry through the declared schedule. Keep the existing public FrameClock policy (clamp/drop/maxsteps, accepted time, counters and actual order) or version it explicitly. Match actual caller/engine outputs and recorded boundaries. A nominal wrapper around an unused alternative path is not adoption.

Use caller-owned payloads or an actually qualified owner contract for held data. Shallow copied descriptors cannot extend backing-storage lifetime. B1 retained-store analysis alone does not prove async owner/cancel lifetime or B2 read-after-write composition.

## C30-astronomy: full time-scale slice

Implement distinct TAI, TT, TDB and UTC types, conversion APIs and named conversion provenance. Select primary published standards/reference material during implementation; record exact table/series versions, content hashes, coverage and numeric precision before checking outputs.

- `TT = TAI +32.184s` is an exact defined offset under the chosen representable unit; UTC→TAI uses a pinned leap-second table; TT↔TDB uses a named pinned standard series with an explicit approximation/precision profile.
- Refuse out-of-table/series coverage and ambiguous unsupported UTC inputs. Aethyr39's current design explicitly refuses instants inside a leap second rather than guessing: preserve that contract or normatively specify and independently qualify a deliberate richer representation.
- Published UTC–TDB values, leap-boundary endpoints, inverse/round-trip tolerances, table identity changes and coverage refusals must be authored independently of the implementation. A round trip alone cannot validate an offset/series.
- Preserve sufficient precision for the stated epoch span, target and error budget; do not use f32 astronomical timestamps by accident. Pin math/profile and compare CPU/native/browser only at the level actually tested.

Reuse only the time-scale part of Aethyr39's design. Full SPK/Horizons ephemeris readers, light-time/aberration and state/frame transforms are separate unless required by the chosen concrete consumer. Add one actual spacecraft time-conversion call path plus the published-value gate; a constant table demo is insufficient full adoption evidence.

## C30-warp and recorded event boundaries

Warp scales simulation advance relative to steady time, while the earliest scheduled event caps each step. Define canonical equal-time ordering (time, eventkind, stableentity/event identity), simultaneous-event handling and zero-time repeated-event/no-progress refusal before code.

- Compare the same fixed scenario at warp1 and1000000: exact event identities/order and event boundary times, plus independently specified final state where semantics require it. Include burn boundary, signal arrival and contact boundary, ties, newly scheduled same-time events, pause/jump and overflow/refusal cases.
- Use actual known/prelocated event boundaries for the R13 scheduler. R15 adds numerical event location; do not claim arbitrary curved contact detection, dense-output root finding or full Aethyr46 just because scheduled boundaries are respected. If the selected scenario actually needs location, qualify that necessary R15 child explicitly rather than silently skipping crossings.
- Keep one shared simulation-time policy for a shared encounter; reject inconsistent per-participant warp as required by the chosen encounter profile.
- Record clock samples/mappings, warp changes, capped boundaries and event tie keys so replay can consume them. Full R16 rollback/snapshot and observation-level replay remain separate acceptance unless implemented and measured.

## Qualification, teaching and closure

For each changed semantic module: check-first original source/model fixtures, appropriate `#authority`, full inventory mutation zero/no equivalence waivers, resource refusal tests and independent oracles. NativeO0/O2/ASan+UBSan observes real emitted procedures and named fields/guards, not C padding. Measure compiler self-input and actual robot/Verse consumers before freezing seeds; a unit-only pass cannot conceal the shared work-cap exhaustion seen during B1.

Freeze semantic source/ABI before trusted emission and normal bootstrap. Loaded Coax policies live in the compiler fingerprint/snapshot closure. Preserve actual earlier producer labels; compose byte-identical artifacts only with explicit source/tool/package continuity, never retag native observations. Run target-specific evidence where claimed, both required fixed points and provenance. Keep raw outputs, complete selections, budgets and refusal/inconclusive status.

Replace chapter30's planned note only after actual semantics exist. Add runnable examples and exact expected outputs for domains, mappings, pure-read rejection, schedules/Hold/typed stale handling, astronomical coverage and warp. Run changed book examples in debug/release through `check-examples.sh`; update chapter7/28/29 dependency explanations, registry source/qualified_targets/adopted_by, navigation and claim ledger using actual records. Leave chapter32/33 and unrelated parent claims honest.

Final chapter30 acceptance is the conjunction: real typed domains+R2 errors+R11 effect enforcement; declared deterministic multirate schedules; robot and Verse adoption; pinned astronomical conversions with independent published oracles and coverage refusal; event-stopped warp1/1000000; replayable recorded boundaries; runnable debug/release chapter; qualified source/target/producer evidence. No initial-profile-only closure.

## Proposed project issue outline (unpublished)

Parent slug suggestion: `chapter30-typed-clocks-full` (new identity, currentROADMAP R13). Title: Implement Coax chapter30 typed clocks, multirate ticks and astronomical warp. Blocked by actual B1 completion; link current R2/R11/time-duration dependencies rather than old milestone names.

Children, proposed only:

1. `chapter30-contracts-and-oracles`: normative syntax/representations/target contract and complete check-first manifest.
2. `r2-typed-results-cleanup-consumer`: first-delivery language forms and real adapter gate; link actual published R2/R3 dependencies.
3. `r11-transitive-effects-consumers`: all effect categories/paths, unknown obligations, alias/range checks, query explanations and engine/generic native observations.
4. `r13-domains-mappings-clock-effects`: nominal instants/durations, explicit mappings and R11 host clock boundary.
5. `r13-declared-schedules-held-data`: rates/phases, Hold/stale errors, deterministic traces and recorded boundaries.
6. `r13-robot-verse-adoption`: both actual consumers and preserved old contracts.
7. `r13-astronomical-time-scales`: TAI/TT/TDB/UTC, pinned primary data/series, published oracles and coverage refusal.
8. `r13-event-stopped-warp`: exact event order at1/1000000 and recorded boundaries, with any genuinely needed event-location dependency explicit.
9. `chapter30-book-release-qualification`: examples/registry/claims and actual final target/normal/consumer evidence, then parent closure.

Root owns issue publication/claim/dependency edits. These proposed names are not existing task IDs or claims. Re-read live current issues before publishing; the retained queue snapshot is historical, not a guarantee no peer has created a matching issue since.
