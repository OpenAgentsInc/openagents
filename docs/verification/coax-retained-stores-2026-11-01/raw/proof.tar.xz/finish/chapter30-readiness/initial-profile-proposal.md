# Proposed chapter 30 initial implementation profile

**Status: proposal only. Implement only after B1 is qualified and the owner chooses scope.**

The next planned chapter is 30, *Typed clocks and multirate ticks*. The complete chapter/R13 remains larger than the profile below. This proposal delivers executable Coax APIs, runnable teaching examples and two actual consumer integrations, while keeping absent language effects/results and astronomical expansion explicit.

## Profile boundary

Name the first delivery `supplied-clock-schedule-v1` (proposed name). It consumes explicitly supplied clock samples; it reads no host clock, launches no task and owns no thread. Coax owns all arithmetic, schedule admission, sample age and publication decisions. A host may supply raw clock samples as a platform effect; that observation is not authenticated by a clock label.

Use distinct nominal `SimInstant`, `SteadyInstant` and `CivilInstant` records, with integral nanosecond counts and explicit epoch/source identities. A single integral duration type has a named nanosecond unit and range. The existing built-in Quantity family accepts float carriers only, so do not pretend this is an integer Quantity extension or silently erase the clock domain. Explicit adapters can expose R12 `Second/f64` quantities for display/physical consumers, with independently frozen rounding bounds; exact scheduler decisions stay integral.

Each operation has an explicit signature for its domain. Same-domain differences return a duration; mismatched nominal types fail actual compilation. Invalid/foreign epoch or source identities, reversed steady time and overflow/refusal cases return a dedicated status enum and preserve outputs. These are ordinary typed return values under today's Coax, not a claim that R2 optional/try/exhaustiveness or inactive-payload enforcement exists.

Provide explicit, identity-bearing mappings with finite coverage for the initial exact offset/rate-one conversion case. A simulation epoch change invalidates old mappings and held values. There is no implicit simulation/steady/civil conversion, clock calibration, leap-second handling or arbitrary time-scale assumption.

## Initial APIs and observable behavior

The exact spelling is to be frozen check-first; required operations are:

1. Validate/add/difference each instant domain and convert to/from bounded explicit nanosecond duration values. Pause/advance simulation independently while steady time advances. Civil samples may move backward; they cannot be used as monotonic deadlines by accident.
2. Admit a bounded task table with positive integral periods, legal phases and unique task identities. Declare deterministic tie order by table ordinal. Refuse malformed tables before publishing a partial plan.
3. Select the next due task/event up to a supplied simulation boundary, update it exactly once and refuse counter overflow or exhausted output capacity atomically. Exact periods include 1,000Hz (1,000,000ns), 500Hz (2,000,000ns), 20Hz (50,000,000ns) and the existing Verse64Hz (15,625,000ns).
4. Sample-and-hold a bounded owned value with source instant/epoch. A reader gets the last completed sample between updates. Age exactly equal to the declared maximum is accepted; one tick older is stale. Missing, future, wrong-epoch and stale samples are distinct refusals. No asynchronous retention of borrowed payloads.
5. Record admitted clock/tick boundaries in an explicit versioned trace with caller-provided identity. This is a replay input record, not R16 replay implementation or a remote truth claim.

Prefer explicit bounded calls over new `task @rate`/`Hold(...)` syntax in this first profile. The chapter should show the API actually implemented and keep the language sketch clearly planned. Default zero identities should be invalid rather than silently inventing a valid clock; any nonzero host state defaults require actual generated default-helper initialization.

## Actual consumer integration

**Robot:** adapt the existing `psionic/lib/physics/step-clock-*` and `psionic/lib/robotics/panda-clock-adapter.coax` path to consume the declared500Hz/20Hz schedule. Preserve its existing `step-clock-500-20-v1`/ticket/receipt contracts, forward/sample/control/receipt order, fixed chunk horizon and stale/failed receipt behavior. Use explicit adapters between the new instant and existing epoch/step records. Qualify the actual consumer entrypoint and recorded clock/command prefixes; do not rerun model weights or claim a new policy episode score.

**Verse:** drive the actual Aethyr/Verse fixed-step entry through the new schedule, retaining the public FrameClock ABI and all existing clamp/drop/max-step counters, accepted time and output order. `aethyr/loop.coax` is already a working integer-nanosecond consumer: preserve it until the new path agrees. Avoid replacing every realm just to demonstrate a type wrapper. One real selected Verse caller plus unchanged public loop behavior is a concrete initial adoption gate.

An unused wrapper or a second standalone demo does not satisfy either adoption requirement.

## Check-first qualification

- Original-source negative compilation cases for cross-domain calls/arithmetic, plus positive exact signatures. Do not infer negative diagnostics from evaluator values alone.
- Literal integer boundary oracles, mapping coverage/refusal and simulation-pause/steady-advance cases. Expected state/output is authored independently before implementation.
- Independent finite reference task traces for several rate/phase combinations, deterministic ties, empty/malformed/capacity/overflow cases and many-tick schedules. Keep a small frozen literal trace as well as a separately implemented reference generator.
- Sample/hold traces with exact-age boundary, stale, future, missing and epoch reset, preserving the previous published state on refusal. Named fields/buffer guards, no C-padding oracle.
- Coax `#test`/`#forall` before logic. Admission/policy files use `#authority` and full-scope mutation with zero survivors/no equivalence exemptions. Bounded shards preserve full inventory.
- Actual emitted C at O0/O2 and ASan/UBSan, independent values, pointer/extent guards where APIs use buffers, ABI headers observed before native entrypoints.
- Actual robot and Verse adapters compared against their retained original traces and independently expected new clock boundaries. Only changed-input gates rerun; original completed experiments keep their original producer labels.
- Runnable chapter examples with exact outputs under the existing debug/release example gate. Checked behavior must arise from precondition/refusal logic, not accidental debug-only traps.

## What remains open

This profile does **not** complete R13's initial roadmap prerequisite of R11 clock-read effects or full R2 typed-error language support. Having no clock-read operation in a supplied-sample module is useful and testable, but is not compiler enforcement preventing arbitrary client procedures from reading a clock. Do not label it `pure` as an enforced language fact.

Expanded R13 remains planned: TAI/TT/TDB/UTC nominal scales; pinned leap-second/TT–TDB tables/series and published reference values; coverage refusal; event-stopped time acceleration with equal event order at warp1 and1,000,000; broader recorded-clock/replay integration. R15 still supplies event-location mathematics. Full R11, R2 and relevant R12 continuation are separate dependencies, not silently implemented by this chapter library.

The chapter registry should therefore become **partly implemented**, with this exact CPU/native-C profile, real source files, actual qualified targets and named adopter paths. The complete-R13 issue remains open. Root should create a distinct current-roadmap chapter30 task rather than repurpose the old project's `r12` backends milestone or advance B2 accidentally.
