#!/usr/bin/env python3
"""Current-emitter artifact generation with actual profiles; unqualified development producer."""
from pathlib import Path
import hashlib,json,os,sys,time
S=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents/coax').resolve()
W=Path('/tmp/coax-retained-borrows-B1-finish/development-988-current').resolve()
D=Path(__file__).resolve().parent
sys.path[:0]=[str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools')),str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tests'))]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
paths=[Path(__file__).resolve(),W/'coax',W/'proto_runtime.inc',Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[p for root in [S/'lib/compiler',S/'lib/proto',S/'lib/crypto'] for p in root.rglob('*') if p.is_file()]]
before={str(p):sha(p) for p in paths}
assert before[str(W/'coax')]=='f3ac432bc64829e40f839f983e4092d251caa3c3635fe696eb93c73979472932'
assert before[str(S/'lib/compiler/checker.coax')]=='177892429ac07bc7eac88a948e2a0b4be43fb9cb606d41224e669a1dfb5ac895'
r={'schema':'coax.B1.current-emitter-artifact-generation.v1','scope':'Unqualified developmentf3ac432b emits frozen17789242 checker and aggregate C/H using actual profiles. Broad manual inventory is distinguished from actual profile closure. These are current-emitter artifacts for seed generation; no normal qualification, seal or install.','producer':str(W/'coax'),'producer_sha256':sha(W/'coax'),'source_revision':'4c7e53ea3f0bc4e8d429ef099e41a047aea152cb','producer_scope':'Actual current-native4c/frozen-production988Coax development imagef3ac432b. Its unqualified producer attribution is preserved; no normal or installed qualification inferred.','source_before':before,'rows':[],'artifacts':{},'outcome':'not-checked'}
started=time.monotonic();deadline=started+840
def save():
 r['source_after']={str(p):sha(p) for p in paths};r['inputs_unchanged']=r['source_after']==before;r['elapsed_s']=time.monotonic()-started
 (D/'record.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name in ['checker','proto_importer']:
  save();assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
  module='lib/compiler/'+('checker' if name=='checker' else 'compiler')+'.coax'
  header=D/(name+'.h');assert not header.exists() and not (D/(name+'.c')).exists()
  profile=D/(name+'.profile.json')
  argv=[str(W/'coax'),'c',module,'--library','--header',str(header),'--profile-report',str(profile)]
  o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=33554432,deadline=deadline,quiet_faults=True)
  row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
  for stream in ['stdout','stderr']:
   data=row['observation'].pop(stream);p=D/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  (D/(name+'.c')).write_bytes(o['stdout'])
  row['transport_clean']=clean(o);r['rows'].append(row);save()
  assert row['transport_clean'] and r['inputs_unchanged'],'actual emission failed'
  assert header.is_file() and header.stat().st_size>0
  manifest=json.loads(profile.read_text())
  assert manifest['schema_version']==1 and manifest['command']=='c' and manifest['backend']=='c11' and manifest['runtime_arithmetic']=='checked' and manifest['success'] and manifest['exit_status']==0
  assert manifest['emitted_sha256']==sha(D/(name+'.c')) and manifest['artifact_sha256']==sha(D/(name+'.c'))
  for consumed in [*manifest['sources'],*manifest['descriptors']]:assert sha(consumed['path'])==consumed['sha256']
  row['profile']=str(profile);row['profile_sha256']=sha(profile);row['actual_consumed_sources']=manifest['sources'];row['actual_consumed_descriptors']=manifest['descriptors']
  for p in [header,D/(name+'.c'),profile]:r['artifacts'][str(p)]=sha(p)
  save();print(json.dumps({'label':name,'passed':True,'elapsed_s':o['elapsed_s'],'artifacts':{str(p):sha(p) for p in [header,D/(name+'.c')]}}),flush=True)
 assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
 r['outcome']='passed'
except BaseException as e:
 r['outcome']='failed';r['error']=repr(e);raise
finally:save()
print(json.dumps({'record':str(D/'record.json'),'sha256':sha(D/'record.json'),'outcome':r['outcome']}),flush=True)
