from pathlib import Path
import hashlib,importlib.util,json,os,shutil,time
root=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
base=Path('/tmp/coax-retained-borrows-B1-finish/depth-controls');base.mkdir()
producer=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax')
assert hashlib.sha256(producer.read_bytes()).hexdigest()=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
spec=importlib.util.spec_from_file_location('bp',root/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
s=(root/'coax/lib/compiler/checker.coax').read_text();start=s.index('CR_summary ::');end=s.index('\n}',start)+2;body=s[start:end]
rows=[]
for name,old,new in [('baseline',None,None),('limit33','depth>=32','depth>=33'),('decrement2','defer r.state[0].depth-=1;','defer r.state[0].depth-=2;')]:
 out=base/name;out.mkdir();shutil.copytree(root/'coax/lib/compiler',out/'source');source=out/'source/checker.coax'
 if old is not None:
  assert body.count(old)==1
  source.write_text(s[:start]+body.replace(old,new)+s[end:])
 paths=[producer,Path(__file__),root/'coax/tools/bounded_process.py',root/'coax/tests/quiet_crash.py',*sorted((out/'source').rglob('*.coax'))]
 def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 before=hashes();r=bp.run([str(producer),'test',str(source),'--library','--only','retained summary exact depth','--evidence',str(out/'evidence.json')],root,os.environ.copy(),90,2097152,time.monotonic()+95,quiet_faults=True)
 for k in('stdout','stderr'):(out/(k+'.log')).write_bytes(r.pop(k))
 r.update(inputs_before=before,inputs_after=hashes(),original_checker_sha256=hashlib.sha256(s.encode()).hexdigest(),mutation={'old':old,'new':new},scope='Program semantic controls only, not compiler qualification.')
 r['inputs_unchanged']=r['inputs_before']==r['inputs_after'];(out/'process.json').write_text(json.dumps(r,indent=2)+'\n')
 row={'name':name,'returncode':r['returncode'],'elapsed_s':r['elapsed_s'],'stderr':(out/'stderr.log').read_text(),'stdout':(out/'stdout.log').read_text(),'inputs_unchanged':r['inputs_unchanged']};rows.append(row);print(json.dumps(row),flush=True)
(base/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
