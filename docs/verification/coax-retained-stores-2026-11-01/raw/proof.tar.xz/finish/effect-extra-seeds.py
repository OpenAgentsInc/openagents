from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil,time
F=Path('/tmp/coax-retained-borrows-B1-finish');BASE=F/'faa3-immutable-model';OUT=F/'effect-extra-seeds'
ROOT=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents');COMPILER=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(COMPILER)=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
assert sha(BASE/'checker.coax')=='faa3a02f01cc592a6097c3f98406ae577c30f3e06bd32145a0f7e78ed058da33'
assert sha(BASE/'snapshot.json')=='4c1457968e7e46d8bd5b3e0e12db18716547e2e050d76901f2b81b4198367f95'
for name,value in json.loads((BASE/'snapshot.json').read_bytes())['files'].items():assert sha(BASE/name)==value
V4=F/'effect-pair-controls-v4.coax';assert sha(V4)=='280cac0c81ae294a80206e3192309430dc3c2408885d37a7e510be6b53d8e8ec'
assert sha(F/'apply-controls.coax')=='84804b7e8ee25a399e200e592dddd9cb2349e1403d260db72d2933f7b67d30a5'
original=(BASE/'checker.coax').read_text();prefix='PS exact effect controls: '
adapted=re.sub(r'(#(?:test|forall)\s+)"([^"\n]+)"',lambda q:q[1]+json.dumps(prefix+q[2]),V4.read_text())
FLAGS=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
def func(text,name):
 a=text.index(name+' ::');z=text.index('\n}',a)+2;return a,z,text[a:z]
def check(text,title):
 match=list(re.finditer(r'#(?:test|forall)\s+"'+re.escape(title)+r'"',text));assert len(match)==1
 a=match[0].start();start=text.index('{',match[0].end());level=0;quote=False;escape=False;comment=False
 for i in range(start,len(text)):
  c=text[i]
  if comment:
   if c=='\n':comment=False
   continue
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
   continue
  if c=='"':quote=True
  elif c=='/' and i+1<len(text) and text[i+1]=='/':comment=True
  elif c=='{':level+=1
  elif c=='}':
   level-=1
   if level==0:return text[a:i+1]
 raise AssertionError('unclosed check')
# Actual retained original observations only, with selected original claim admitted.
def prior(path,digest,title,newtext):
 assert sha(path)==digest;r=json.loads(path.read_bytes());obs=r.get('observation',r)
 assert obs['returncode'] in(0,1) and obs['started'] and obs['stdout_eof'] and obs['stderr_eof'] and not any(obs.get(k)for k in FLAGS) and r['inputs_unchanged']
 oldsource=path.parent/'source/checker.coax';oldtext=oldsource.read_text();before=r.get('input_before',r.get('inputs_before'))
 assert sha(oldsource)==before[str(oldsource)]
 evpath=path.parent/'evidence.json';claims=[x for x in json.loads(evpath.read_bytes())['claims']if x['name']==title]
 assert len(claims)==1 and claims[0]['outcome']=='passed'
 assert check(oldtext,title)==check(newtext,title)
 return {'path':str(path),'sha256':sha(path),'overall_original_returncode':obs['returncode'],'evidence_path':str(evpath),'evidence_sha256':sha(evpath),'selected_claim':claims[0],'unchanged_check_sha256':hashlib.sha256(check(newtext,title).encode()).hexdigest(),'original_source':str(oldsource)}
canonical=prefix+'retained canonical effect reuse validates published links and charges lookup work'
shared=prefix+'retained canonical effect publication refuses a full shared pool for a fresh owner'
manual='retained caller preserves a callee manual relation with zero latent effects'
items=[
 ('effect-link-resource','CR_effect','{CK_resource(b.c,b.c.nodes[site].loc);return;}old:=','{return;}old:=',canonical,True,F/'effect-pair-validation/original/process.json','384451f8793efff1d1285557f389bc4fe15122be46a81a5657720c8bb49c09b0','historical959 shard8 CR_effect84539:90'),
 ('effect-capacity-resource','CR_effect','if b.c.nodes[owner].retain_count>=64 || r.state[0].effects>=r.effects.count {CK_resource(b.c,b.c.nodes[site].loc);return;}','if b.c.nodes[owner].retain_count>=64 || r.state[0].effects>=r.effects.count {return;}',shared,True,F/'effect-pair-validation/changed-v4-shared-original/process.json','ebfbf2c7bcefccef17adbe484973ee95c3a7d0d45a0293e5c8ca2eb2cd576fa1','historical959 shard8 CR_effect84540:79'),
 ('apply-relation-assignment','CR_apply','b.c.nodes[owner].retain_relation=b.c.nodes[owner].retain_relation && callee.retain_relation;','',manual,False,F/'apply-controls-execution/full-authored-baseline/process.json','3e208eba7f2f337f2e40cb4a0878ba2f5b8eba134219bb4b6ea99a905b5a5f26','historical959 CR_apply84628:124'),
]
spec=importlib.util.spec_from_file_location('bp',ROOT/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
OUT.mkdir(exist_ok=False);rows=[]
for name,function,old,new,title,append,oldpath,digest,site in items:
 text=original+('\n'+adapted if append else '')
 original_fact=prior(oldpath,digest,title,text)
 if not append:
  _,_,oldfunc=func(Path(original_fact['original_source']).read_text(),function);assert oldfunc==func(original,function)[2]
 a,z,part=func(text,function);assert part.count(old)==1;mutated=text[:a]+part.replace(old,new)+text[z:]
 out=OUT/name;out.mkdir();shutil.copytree(BASE,out/'source');source=out/'source/checker.coax';source.write_text(mutated)
 paths=[COMPILER,Path(__file__),V4,F/'apply-controls.coax',BASE/'snapshot.json',ROOT/'coax/tools/bounded_process.py',ROOT/'coax/tests/quiet_crash.py',*sorted((out/'source').glob('*.coax'))]
 before={str(p):sha(p)for p in paths};argv=[str(COMPILER),'test',str(source),'--library','--only',title,'--evidence',str(out/'evidence.json')]
 now=time.monotonic();r=bp.run(argv,str(ROOT),os.environ.copy(),180,8388608,now+180,quiet_faults=True);raw={}
 for stream in('stdout','stderr'):
  p=out/(stream+'.log');p.write_bytes(r[stream]);raw[stream]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 after={str(p):sha(p)for p in paths};clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and before==after and not any(r.get(k)for k in FLAGS)
 evpath=out/'evidence.json';claims=[x for x in json.loads(evpath.read_bytes())['claims']if x['name']==title]if evpath.is_file()else[]
 red=bool(clean and r['returncode']==1 and len(claims)==1 and claims[0]['outcome']=='counterexample' and claims[0]['code']in('E0406','E0410'))
 q={'schema':'coax.retained-borrows.exact-extra-seeded-comparison.v1','outcome':'passed'if red else'failed','scope':'Only newly requested exact production semantic seeds, historical trusted5c interpreting private FAA3. Selected unchanged original GREEN is retained, never rerun. Not original whole mutation/native/compiler qualification.','historical_site':site,'mutation':{'function':function,'old':old,'new':new},'actual_original':original_fact,'original_function_sha256':hashlib.sha256(part.encode()).hexdigest(),'compiler_sha256':sha(COMPILER),'base_sha256':sha(BASE/'checker.coax'),'argv':argv,'input_before':before,'input_after':after,'inputs_unchanged':before==after,'clean_transport':clean,'actual_counterexample':claims[0]if len(claims)==1 else claims,'observation':{k:v for k,v in r.items()if k not in('stdout','stderr')},'raw':raw,'evidence':{'path':str(evpath),'sha256':sha(evpath)}if evpath.is_file()else None}
 (out/'process.json').write_text(json.dumps(q,indent=2)+'\n');row={'name':name,'outcome':q['outcome'],'record_sha256':sha(out/'process.json'),'elapsed_s':r['elapsed_s'],'actual_code':claims[0].get('code')if len(claims)==1 else None};rows.append(row);print(json.dumps(row),flush=True)
 assert red,'comparison failed: '+name
(OUT/'summary.json').write_text(json.dumps({'schema':'coax.retained-borrows.exact-extra-seeds.v1','outcome':'passed','scope':'Three previously unexecuted exact production semantic seeds. All original passing observations reused, no unchanged baseline replay.','rows':rows,'controller_sha256':sha(__file__)},indent=2)+'\n');print('summary_sha256',sha(OUT/'summary.json'))
