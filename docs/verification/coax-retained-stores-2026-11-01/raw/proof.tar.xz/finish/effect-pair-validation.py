from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,shutil,time

ROOT=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
BASE=Path('/tmp/coax-retained-borrows-B1-finish/faa3-immutable-model')
SNIPPET=Path('/tmp/coax-retained-borrows-B1-finish/effect-pair-controls-v2.coax')
COMPILER=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax')
OUT=Path('/tmp/coax-retained-borrows-B1-finish/effect-pair-validation')
PREFIX='PS exact effect controls: '
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
FLAGS=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
assert sha(COMPILER)=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
assert sha(SNIPPET)=='23f3f0d6af3213f884cf9c8b6d2c07bcfb69e9f708bfc80289d96120fa7b5de5'
assert sha(BASE/'checker.coax')=='faa3a02f01cc592a6097c3f98406ae577c30f3e06bd32145a0f7e78ed058da33'
assert sha(BASE/'snapshot.json')=='4c1457968e7e46d8bd5b3e0e12db18716547e2e050d76901f2b81b4198367f95'
snapshot=json.loads((BASE/'snapshot.json').read_bytes())
for name,value in snapshot['files'].items():assert sha(BASE/name)==value
original=(BASE/'checker.coax').read_text()
titles=re.findall(r'#(?:test|forall)\s+"([^"\n]+)"',SNIPPET.read_text())
assert len(titles)==6
adapted=re.sub(r'(#(?:test|forall)\s+)"([^"\n]+)"',lambda m:m[1]+json.dumps(PREFIX+m[2]),SNIPPET.read_text())
spec=importlib.util.spec_from_file_location('bp',ROOT/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)

def run(name, mutation=None, selected=None):
 out=OUT/name;out.mkdir(parents=True,exist_ok=False);shutil.copytree(BASE,out/'source')
 source=out/'source/checker.coax';text=original
 if mutation:
  func,old,new=mutation;start=text.index(func+' ::');end=text.index('\n}',start)+2;part=text[start:end];assert part.count(old)==1,(name,part.count(old));text=text[:start]+part.replace(old,new)+text[end:]
 source.write_text(text+'\n'+adapted)
 inputs=[COMPILER,SNIPPET,BASE/'snapshot.json',Path(__file__),ROOT/'coax/tools/bounded_process.py',ROOT/'coax/tests/quiet_crash.py',*sorted((out/'source').glob('*.coax'))]
 before={str(p):sha(p) for p in inputs}
 argv=[str(COMPILER),'test',str(source),'--library','--only',PREFIX+(titles[selected] if selected is not None else ''),'--evidence',str(out/'evidence.json')]
 tick=time.monotonic();r=bp.run(argv,str(ROOT),os.environ.copy(),180,8388608,tick+180,quiet_faults=True)
 streams={}
 for stream in ('stdout','stderr'):
  p=out/(stream+'.log');p.write_bytes(r[stream]);streams[stream]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 after={str(p):sha(p) for p in inputs};clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and before==after and not any(r.get(k)for k in FLAGS)
 semantic_red=bool(clean and r['returncode']==1 and b'error[E0406]' in r['stderr'])
 passed=bool(clean and r['returncode']==0) if not mutation else semantic_red
 record={'schema':'coax.retained-borrows.effect-pair.private-comparison.v1','outcome':'passed' if passed else 'failed','scope':'Targeted original/seeded check comparison on private immutable FAA3 plus independently authored input v2. Not whole authority/mutation/compiler/native qualification.','compiler_sha256':sha(COMPILER),'base_sha256':snapshot['checker_sha256'],'snippet_sha256':sha(SNIPPET),'adaptation':'Only six authored check names gain the PS exact effect controls prefix, enabling exact selection; bodies/expected values unchanged.','mutant':mutation,'selection':selected,'argv':argv,'input_before':before,'input_after':after,'inputs_unchanged':before==after,'observation':{k:v for k,v in r.items()if k not in ('stdout','stderr')},'raw':streams,'clean_transport':clean,'semantic_red':semantic_red,'elapsed_s':r['elapsed_s']}
 if (out/'evidence.json').is_file():record['evidence']={'path':str(out/'evidence.json'),'sha256':sha(out/'evidence.json')}
 (out/'process.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'name':name,'outcome':record['outcome'],'rc':r['returncode'],'semantic_red':semantic_red,'elapsed_s':r['elapsed_s'],'record_sha256':sha(out/'process.json'),'stderr_tail':r['stderr'].decode(errors='replace')[-500:]}),flush=True)
 return record

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['original','seeded']);args=p.parse_args()
 if args.phase=='original':
  OUT.mkdir(exist_ok=False);result=run('original');assert result['outcome']=='passed'
 else:
  baseline=json.loads((OUT/'original/process.json').read_bytes());assert baseline['outcome']=='passed' and baseline['snippet_sha256']==sha(SNIPPET)
  items=[
   ('effect-link-prefix',('CR_effect','link<1 || link>r.state[0].effects','link<1 && link>r.state[0].effects'),0),
   ('effect-lookup-budget',('CR_effect','link>r.state[0].effects || !CB_tick','link>r.state[0].effects && !CB_tick'),0),
   ('effect-shared-pool',('CR_effect','retain_count>=64 || r.state[0].effects','retain_count>=64 && r.state[0].effects'),1),
   ('pair-work-resource',('CR_pairs','if decision.status!=RP_Status.ok {CK_resource(b.c,b.c.nodes[site].loc);return CR_Result.{};}','if decision.status!=RP_Status.ok {return CR_Result.{};}'),2),
   ('apply-link-prefix',('CR_apply','link<1 || link>r.state[0].effects','link<1 && link>r.state[0].effects'),4),
   ('apply-destination-resource',('CR_apply','if effect.destination.kind!=BS_PARAMETER {CK_resource(b.c,e.loc);return;}','if effect.destination.kind!=BS_PARAMETER {return;}'),5),
  ]
  rows=[]
  for name,mutation,selection in items:
   result=run(name,mutation,selection);rows.append({'name':name,'outcome':result['outcome'],'semantic_red':result['semantic_red'],'record_sha256':sha(OUT/name/'process.json')})
   assert result['outcome']=='passed','real comparison failure: '+name
  (OUT/'seeded-summary.json').write_text(json.dumps({'scope':'Six meaningful original historical shard2/3 semantic sites only. q.status secondary check and pending-1 cleanup are deliberately not claimed killed.','rows':rows},indent=2)+'\n')
