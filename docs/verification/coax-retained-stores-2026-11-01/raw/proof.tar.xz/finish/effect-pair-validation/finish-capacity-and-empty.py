from pathlib import Path
import hashlib,importlib.util,json,re
base=Path('/tmp/coax-retained-borrows-B1-finish/effect-pair-validation');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Pure classification of the already observed E0410, without replaying it.
oldpath=base/'changed-v4-global-capacity-seed/process.json';assert sha(oldpath)=='203487d7d29aebe1123a0eb05a5cc5c71b4025961307a27ccecde6629847a0ae';old=json.loads(oldpath.read_bytes());assert old['clean_transport'] and old['inputs_unchanged'] and old['observation']['returncode']==1
for f in old['raw'].values():assert sha(f['path'])==f['sha256'] and Path(f['path']).stat().st_size==f['bytes']
evidencepath=base/'changed-v4-global-capacity-seed/evidence.json';ev=json.loads(evidencepath.read_bytes());actual=[r for r in ev['claims']if r['name']=='PS exact effect controls: retained canonical effect publication refuses a full shared pool for a fresh owner'];assert len(actual)==1 and actual[0]['outcome']=='counterexample' and actual[0]['code']=='E0410'
original=base/'changed-v4-shared-original/process.json';assert json.loads(original.read_bytes())['outcome']=='passed'
classification={'schema':'coax.retained-borrows.retained-e0410-classification.v1','outcome':'genuine-seeded-counterexample','scope':'Evidence-only classification, no compiler/native/evaluator replay. Original safe resource refusal GREEN; exact guard seed causes checked evaluator index128 bounds trap. Failed overnarrow E0406-only wrapper receipt is retained unchanged. Not native memory OOB.','prior_failed_wrapper':{'path':str(oldpath),'sha256':sha(oldpath)},'original_green':{'path':str(original),'sha256':sha(original)},'actual_evidence':{'path':str(evidencepath),'sha256':sha(evidencepath)},'actual_counterexample':actual[0]};(base/'global-capacity-e0410-classification.json').write_text(json.dumps(classification,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('effect_continue',base.parent/'effect-pair-validation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def select(path,expected):
 assert sha(path)==expected;m.SNIPPET=path;m.titles=re.findall(r'#(?:test|forall)\s+"([^"\n]+)"',path.read_text());m.adapted=re.sub(r'(#(?:test|forall)\s+)"([^"\n]+)"',lambda q:q[1]+json.dumps(m.PREFIX+q[2]),path.read_text())
select(base.parent/'effect-pair-controls-v4.coax','280cac0c81ae294a80206e3192309430dc3c2408885d37a7e510be6b53d8e8ec')
owner=m.run('changed-v4-owner-capacity-seed',('CR_effect','retain_count>=64 || r.state[0].effects','retain_count>=64 && r.state[0].effects'),3);assert owner['semantic_red']
select(base.parent/'pair-empty-controls.coax','23862433de8b62bf89b686560606bf94eb048e8bd060369972b9eb4315f07de2');assert len(m.titles)==1
orig=m.run('empty-source-original',None,0);assert orig['outcome']=='passed'
rows=[]
for name,old,new in [('empty-source-less-equal','if sources.count<0 ||','if sources.count<=0 ||'),('empty-source-lower-one','if sources.count<0 ||','if sources.count<1 ||')]:
 r=m.run(name,('CR_pairs',old,new),0);assert r['semantic_red'];rows.append({'name':name,'record_sha256':sha(base/name/'process.json')})
q={'schema':'coax.retained-borrows.capacity-empty-continuation.v1','outcome':'passed','scope':'Actual owner64 independent capacity-seed RED; one new empty-sourceforall4cases originalGREEN and2exactREDs. Globalcapacity E0410 classification reuses retained observation; no rerun. No full mutation/native/compiler qualification.','owner_capacity_record_sha256':sha(base/'changed-v4-owner-capacity-seed/process.json'),'global_capacity_classification_sha256':sha(base/'global-capacity-e0410-classification.json'),'empty_original_sha256':sha(base/'empty-source-original/process.json'),'rows':rows,'wrapper_sha256':sha(__file__)};(base/'capacity-empty-summary.json').write_text(json.dumps(q,indent=2)+'\n');print('summary_sha256',sha(base/'capacity-empty-summary.json'))
