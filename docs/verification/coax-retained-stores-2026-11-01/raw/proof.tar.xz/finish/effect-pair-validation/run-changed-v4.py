from pathlib import Path
import hashlib,importlib.util,json,re
base=Path('/tmp/coax-retained-borrows-B1-finish/effect-pair-validation');new=base.parent/'effect-pair-controls-v4.coax';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(new)=='280cac0c81ae294a80206e3192309430dc3c2408885d37a7e510be6b53d8e8ec'
spec=importlib.util.spec_from_file_location('retained_effect_old_controller',base.parent/'effect-pair-validation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.SNIPPET=new;m.titles=re.findall(r'#(?:test|forall)\s+"([^"\n]+)"',new.read_text());assert len(m.titles)==6
m.adapted=re.sub(r'(#(?:test|forall)\s+)"([^"\n]+)"',lambda q:q[1]+json.dumps(m.PREFIX+q[2]),new.read_text())
rows=[]
for name,index in [('changed-v4-shared-original',1),('changed-v4-owner-original',3)]:
 r=m.run(name,None,index);rows.append({'name':name,'outcome':r['outcome'],'record_sha256':sha(base/name/'process.json')});assert r['outcome']=='passed','changed original failure: '+name
q={'schema':'coax.retained-borrows.effect-v4-originals.v1','outcome':'passed','scope':'Only2changed typed-input blocks, sharedpoolonecase+ownerforall2cases.4unchangedpassing originals retained from v2; no repetition. v2original2failures retained; v3neverexecuted.','snippet_sha256':sha(new),'rows':rows,'wrapper_sha256':sha(__file__)};(base/'changed-v4-original-summary.json').write_text(json.dumps(q,indent=2)+'\n');print('summary_sha256',sha(base/'changed-v4-original-summary.json'))
