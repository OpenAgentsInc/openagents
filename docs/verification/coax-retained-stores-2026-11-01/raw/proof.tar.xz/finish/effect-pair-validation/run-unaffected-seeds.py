from pathlib import Path
import hashlib,importlib.util,json
base=Path('/tmp/coax-retained-borrows-B1-finish/effect-pair-validation')
controller=base.parent/'effect-pair-validation.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=base/'original/process.json'
assert sha(baseline)=='384451f8793efff1d1285557f389bc4fe15122be46a81a5657720c8bb49c09b0'
old=json.loads(baseline.read_bytes());assert old['inputs_unchanged'] and old['clean_transport']
assert sha(controller)==old['input_before'][str(controller)]
evidence=json.loads((base/'original/evidence.json').read_bytes())
spec=importlib.util.spec_from_file_location('effect_validation_retained',controller)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
items=[
 ('effect-link-prefix',('CR_effect','link<1 || link>r.state[0].effects','link<1 && link>r.state[0].effects'),0),
 ('effect-lookup-budget',('CR_effect','link>r.state[0].effects || !CB_tick','link>r.state[0].effects && !CB_tick'),0),
 ('pair-work-resource',('CR_pairs','if decision.status!=RP_Status.ok {CK_resource(b.c,b.c.nodes[site].loc);return CR_Result.{};}','if decision.status!=RP_Status.ok {return CR_Result.{};}'),2),
 ('apply-link-prefix',('CR_apply','link<1 || link>r.state[0].effects','link<1 && link>r.state[0].effects'),4),
 ('apply-destination-resource',('CR_apply','if effect.destination.kind!=BS_PARAMETER {CK_resource(b.c,e.loc);return;}','if effect.destination.kind!=BS_PARAMETER {return;}'),5),
]
rows=[]
for name,mutation,index in items:
 title=module.PREFIX+module.titles[index]
 prior=[r for r in evidence['claims'] if r['name']==title]
 assert len(prior)==1 and prior[0]['outcome']=='passed'
 result=module.run(name,mutation,index)
 actual=json.loads((base/name/'evidence.json').read_bytes())
 failures=[r for r in actual['claims'] if r['name']==title]
 assert result['semantic_red'] and len(failures)==1 and failures[0]['outcome']=='counterexample' and failures[0]['code']=='E0406'
 rows.append({'name':name,'retained_original_claim':prior[0],'original_evidence_sha256':sha(base/'original/evidence.json'),'seeded_record':str(base/name/'process.json'),'seeded_record_sha256':sha(base/name/'process.json'),'actual_counterexample':failures[0]})
q={'schema':'coax.retained-borrows.effect-unaffected-seeds.v1','outcome':'passed','scope':'Five exact historical semantic mutations with retained4passing original claims; original2unrelated pool fixture failures remain nonpassing and are not relabelled. No whole authority/mutation/native qualification.','baseline_record_sha256':sha(baseline),'rows':rows,'explicit_exclusions':['q.status secondary redundant guard','rp_insert pending-1 cleanup','shared-pool mutant awaiting2fixture input repairs']}
(base/'unaffected-seeded-summary.json').write_text(json.dumps(q,indent=2)+'\n')
print('summary_sha256',sha(base/'unaffected-seeded-summary.json'))
