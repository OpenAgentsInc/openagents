# New final-seven preparation (not executed)

`run.py` is a byte-for-byte copy of reviewed seven-gate controller5f0ce40b; `producer_binding.py` is the reviewed helper e6aefccd. No gate logic, selection, oracle or budget changes. Old resume receipts/pins remain unchanged and historical.

`collect-bind.py` has two explicit actions. Neither executes a compiler, test, native program, build or final gate. Its only child process is bounded read-only `git rev-parse HEAD`. Source/layout/harness content is read and hashed; Python driver ASTs are parsed without imports/CDLL.

1. After Root's committed/rebased source freeze, `collect` requires exact source revision, expected fingerprint, final checker SHA and actual passed/stable fresh-header layout receipt. It verifies actual HEAD before creating output. It reuses only the old relative file selection, never old hashes/HEAD/FP/layout receipts; current fixture trees and compiler Coax modules supplement it. It observes all hashes twice and records source33/A1source44/native19+2/threeprofiles/legacy10/SystemOne3/independent1000/diagnostics8. The output says `COLLECTED_AWAITING_ROOT_REVIEW`.
2. After Root reviews that exact collection SHA and normal165 is actually complete, `bind` verifies all frozen source/fixture inputs, exact current HEAD, the installed17regular-artifact package, actual empty survivor file, provenance and every required normal receipt through the unchanged helper. It creates a reviewed copy of pins, retaining the unmodified collection, and prepares seven independent whole-gate argv. It launches none.

The helper's exact SHA is `e6aefccd3d5815e75dd74c17c7538dc54b79ece9554751842db12646fce9b0c9`. The final gate controller's exact SHA is `5f0ce40b2bdc2397ca6b098d07f72826869929836f9d1fd4e3220ee1666a09e8`.

Prepared invocation shapes; values below are placeholders, not a current binding:

```text
python3 collect-bind.py collect --repo B --source-revision ACTUAL_ROOT_FROZEN_COMMIT --fingerprint ACTUAL_EXPECTED_FP --checker-sha256 ACTUAL_FINAL_CHECKER_SHA --layout-receipt ACTUAL_FRESH_LAYOUT_Q --layout-sha256 ACTUAL_LAYOUT_Q_SHA --output NEW_FINISH_COLLECTION_DIR

python3 collect-bind.py bind --reviewed-collection NEW_FINISH_COLLECTION_DIR/collection.json --reviewed-collection-sha256 ROOT_REVIEWED_COLLECTION_SHA --normal-receipt ACTUALLY_COMPLETE_NORMAL_Q --normal-sha256 ACTUAL_NORMAL_Q_SHA --compiler-sha256 ACTUAL_INSTALLED_IMAGE_SHA --output NEW_FINISH_BINDING_DIR
```

`run-bindings.json` contains argv arrays, one whole gate per separate command/output. Native has870s internal total; the other gates840s. Preserve the first failure and use an explicitly reviewed affected-only continuation if needed. No normal-prefix or development producer can satisfy the binding.

Native execution still compiles guards against freshly emitted actual headers before C calls. The supplied compile-only layout receipt is separately bound, not replayed by this collector. Source44 and19 native semantic expectations remain unchanged. No B2/helper read-after-write or request-lifetime guarantee is claimed.

All new B1 final-gate outputs belong under finish and must stop before final archive freeze. Chapter30 work after the B1 barrier belongs in a new directory, not this finish evidence tree.

The hardened wrapper additionally pins the exact approved165-step normal plan (`b1f5ba2d...4f40dd8`), reobserves every normal binding input at bind, and requires the actual layout schema/21records/198offsets plus both clean matching header rows. Its full external source/header/guard/raw dependency closure is pinned through execution. A test-only model change after an earlier header guard needs actual new-header evidence or an explicitly reviewed continuity companion; this tool never rewrites an old layout receipt.

For the approved984 continuity case, keep `--layout-receipt`/`--layout-sha256` pointing to the original988 guard. Supply all four additional arguments together:

```text
--layout-continuity /tmp/coax-retained-borrows-B1-finish/header-layout-984-continuity/continuity.json
--layout-continuity-sha256 0b6db1ce7c4a21bba26011d8a06fb290d1ec34455646bea3d9baa52f9d07b514
--layout-continuity-review /tmp/coax-retained-borrows-B1-finish/header-layout-984-continuity/root-review.json
--layout-continuity-review-sha256 2f9a136f96799c2fff4d4e2df43d46e8450c1a8a436bc5f71d2b81323549c5d6
```

This admits only the explicit companion: original compile rows stay988/a073, the exact old model snapshot is retained separately, and final177 model/emitter/profile/current headers are current facts. Both headers must remain byte-identical. Original raw/guard/header/ctypes dependencies and new actual consumed inputs are pinned through later gates. No compile observations are copied or relabelled; no compile/probe replay is performed.
