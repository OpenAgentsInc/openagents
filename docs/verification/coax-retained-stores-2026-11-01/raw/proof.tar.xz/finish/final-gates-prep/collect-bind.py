#!/usr/bin/env python3
"""Prepare final pins after source freeze; bind argv only after actual normal passes.
Neither action runs a compiler, test, native program, build or final gate.
"""
import argparse,ast,hashlib,importlib.util,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
RUN_SHA='5f0ce40b2bdc2397ca6b098d07f72826869929836f9d1fd4e3220ee1666a09e8'
HELPER_SHA='e6aefccd3d5815e75dd74c17c7538dc54b79ece9554751842db12646fce9b0c9'
PLAN_SHA='b1f5ba2ded0512a5b9d3a28a005d5b8810665fd6dce4fc8372a2038fb4f40dd8'
FLAGS=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
GATES=('b1-source','a1-source','b1-native','legacy-checker','systemone','memo1000','diagnostics-json')
SUPPORT=('coax','provenance-check','provenance.record','check-domains.c','check-domains.h','lexer.c','lexer.h','parser.c','parser.h','checker.c','checker.h','sources.c','sources.h','proto_runtime.inc','proto_importer.c','proto_importer.h','mutation-survivors')
def regular(p):
 p=Path(p);assert p.is_file()and not p.is_symlink(),str(p);return p
sha=lambda p:hashlib.sha256(regular(p).read_bytes()).hexdigest()
def load(p,h=None):
 if h:assert sha(p)==h,'record drift '+str(p)
 return json.loads(regular(p).read_bytes())
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
def hashlist(paths):return{str(p):sha(p)for p in sorted(set(paths),key=str)}
def head(root):
 search=[str(Path(entry)if Path(entry).is_absolute()else root/entry)for entry in os.get_exec_path()]
 git=shutil.which('git',path=os.pathsep.join(search));assert git
 alias=Path(os.path.abspath(git));assert alias.is_file()and os.access(alias,os.X_OK)
 r=subprocess.run([str(alias),'rev-parse','HEAD'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=False)
 assert r.returncode==0 and not r.stderr and re.fullmatch(rb'[0-9a-f]{40}\n',r.stdout)
 return r.stdout.decode().strip()
def methodcount(path):
 tree=ast.parse(regular(path).read_bytes());return sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name.startswith('test_')for c in tree.body if isinstance(c,ast.ClassDef)for n in c.body)
def guards(root,revision,files):
 assert head(root)==revision,'actual HEAD differs'
 assert hashlist(map(Path,files))==files,'frozen input drift'
def collect(a):
 root=Path(a.repo).resolve();out=Path(a.output).absolute();assert not out.exists()and not out.is_relative_to(root)
 assert head(root)==a.source_revision,'HEAD mismatch before output mkdir'
 model=root/'coax/lib/compiler/checker.coax';assert sha(model)==a.checker_sha256
 assert sha(HERE/'run.py')==RUN_SHA and sha(HERE/'producer_binding.py')==HELPER_SHA
 selection=load(HERE/'reviewed-file-selection.json');paths=[root/p for p in selection['relative_paths']]
 # Current actual root trees supplement historical relative selection; no old hashes reused.
 for name in('retained-borrows','borrow-summaries','borrow-summary-return','borrow-query-work','diagnostics'):
  paths += [p for p in(root/'coax/tests'/name).rglob('*')if p.is_file()and not p.is_symlink()and '__pycache__'not in p.parts]
 paths += sorted((root/'coax/lib/compiler').rglob('*.coax'))
 approved_plan=load(HERE/'approved-normal-plan.json',PLAN_SHA);assert len(approved_plan['steps'])==165
 paths += [HERE/'run.py',HERE/'producer_binding.py',Path(__file__).resolve(),HERE/'reviewed-file-selection.json',HERE/'approved-normal-plan.json']
 layout=Path(a.layout_receipt).resolve();q=load(layout,a.layout_sha256)
 assert q['schema']=='coax.B1.header-only-layout.v1'and q['outcome']=='passed'and q['inputs_unchanged'],'layout is not passed/stable'
 assert q['layout_record_count']==21 and q['field_offset_count']==198 and len(q['rows'])==2
 facts=dict(q['source_before']);assert facts==q['source_after']
 assert {Path(row['header']).name for row in q['rows']}=={'checker.h','proto_importer.h'}
 for row in q['rows']:
  obs=row['observation'];assert row['transport_clean']and row['matches_ctypes']and obs['started']and obs['returncode']==0 and obs['stdout_eof']and obs['stderr_eof']and not any(obs.get(k)for k in FLAGS)
  actual=row['actual_layouts'];assert len(actual)==21 and sum(len(v['offsets'])for v in actual.values())==198
  assert row['header']in facts
  for raw in row['raw'].values():
   assert sha(raw['path'])==raw['sha256']and regular(raw['path']).stat().st_size==raw['bytes'];facts[raw['path']]=raw['sha256']
 for path,value in q['generated_guard_sources'].items():
  assert path not in facts or facts[path]==value;facts[path]=value
 layout_admission={'original_guard':{'path':str(layout),'sha256':a.layout_sha256},'scope':'Actual original guard execution; no layout compile/probe replay by collector.'}
 if a.layout_continuity:
  continuity_path=Path(a.layout_continuity).resolve();continuity=load(continuity_path,a.layout_continuity_sha256)
  assert continuity['schema']=='coax.B1.header-layout-continuity.v1'and continuity['outcome']=='passed'and continuity['inputs_unchanged']
  assert continuity['layout_record_count']==21 and continuity['field_offset_count']==198
  assert continuity['normal_qualification_claim']is False and continuity['compile_observations_repeated']is False
  origin=continuity['original_layout'];assert Path(origin['path']).resolve()==layout and origin['sha256']==a.layout_sha256 and origin['schema']==q['schema']
  assert origin['layout_record_count']==21 and origin['field_offset_count']==198
  historic=continuity['historical_model_pin_superseded_only_by_header_identity'];assert Path(historic['path']).resolve()==model and historic['original_sha256']==origin['model_sha256']and historic['current_sha256']==a.checker_sha256
  assert continuity['checker_source_sha256']==a.checker_sha256
  review_path=Path(a.layout_continuity_review).resolve();review=load(review_path,a.layout_continuity_review_sha256)
  assert review['schema']=='coax.B1.header-layout-continuity-review.v1'and review['outcome']=='approved-for-final-input-collection'
  assert Path(review['continuity_receipt']['path']).resolve()==continuity_path and review['continuity_receipt']['sha256']==a.layout_continuity_sha256
  assert review['final_model_sha256']==a.checker_sha256 and review['actual_prior_layout_counts']=={'records':21,'offsets':198,'header_rows':2}
  snapshot=review['historical_model_snapshot'];assert snapshot['sha256']==historic['original_sha256']and sha(snapshot['path'])==snapshot['sha256']
  removed=[path for path,value in facts.items()if Path(path).resolve()==model]
  assert len(removed)==1 and facts[removed[0]]==historic['original_sha256'];del facts[removed[0]]
  live=continuity['source_before'];assert live==continuity['source_after']and live[str(model)]==a.checker_sha256
  for path,value in facts.items():assert live.get(path)==value,'continuity lost original guard dependency '+path
  identity=continuity['header_identity'];assert len(identity)==2 and {r['module']for r in identity}=={'checker','proto_importer'}
  original_headers={Path(row['header']).resolve()for row in q['rows']}
  assert {Path(row['original_header']).resolve()for row in identity}==original_headers
  emission_fact=continuity['current_emission'];emission=load(emission_fact['path'],emission_fact['sha256'])
  assert emission['schema']=='coax.B1.current-emitter-artifact-generation.v1'and emission['outcome']=='passed'and emission['inputs_unchanged']
  assert emission['producer_sha256']==emission_fact['producer_sha256']and sha(emission['producer'])==emission['producer_sha256']
  facts.update(live);facts[str(continuity_path)]=a.layout_continuity_sha256;facts[str(review_path)]=a.layout_continuity_review_sha256;facts[snapshot['path']]=snapshot['sha256'];facts[emission_fact['path']]=emission_fact['sha256'];facts[emission['producer']]=emission['producer_sha256']
  assert review['header_identity']==identity
  for item in identity:
   oldh=regular(item['original_header']);newh=regular(item['current_header']);assert item['exact_bytes_equal']is True and oldh.read_bytes()==newh.read_bytes()
   assert sha(oldh)==sha(newh)==item['sha256']and emission['artifacts'].get(str(newh.resolve()))==item['sha256']
   facts[str(oldh)]=item['sha256'];facts[str(newh)]=item['sha256']
  assert len(emission['rows'])==2 and {row['label']for row in emission['rows']}=={'checker','proto_importer'}
  for row in emission['rows']:
   obs=row['observation'];assert row['transport_clean']and obs['started']and obs['returncode']==0 and obs['stdout_eof']and obs['stderr_eof']and not any(obs.get(k)for k in FLAGS)
   facts[row['profile']]=row['profile_sha256']
   for raw in row['raw'].values():
    assert sha(raw['path'])==raw['sha256']and regular(raw['path']).stat().st_size==raw['bytes'];facts[raw['path']]=raw['sha256']
   for field in('actual_consumed_sources','actual_consumed_descriptors'):
    for item in row[field]:
     path=item['path'];value=item['sha256'];assert path not in facts or facts[path]==value;facts[path]=value
  for path,value in emission['artifacts'].items():facts[path]=value
  layout_admission.update(continuity={'path':str(continuity_path),'sha256':a.layout_continuity_sha256},scope='Explicit separately selected continuity: original compile observations remain988/a073; final model/emitter/byte-identical headers bound by companion. Only old whole-model live-path hash is historical; no copied compile rows/new execution claim.',historical_model_input=historic,retained_historical_model_snapshot=snapshot,root_review={'path':str(review_path),'sha256':a.layout_continuity_review_sha256},current_emission=emission_fact)
 else:
  assert any(Path(path).resolve()==model and value==a.checker_sha256 for path,value in facts.items()),'direct layout does not bind actual final model'
 for path,value in facts.items():assert sha(path)==value,'retained layout dependency drift '+path
 paths += [layout,*map(Path,facts)]
 b1=load(root/'coax/tests/retained-borrows/fixtures.json');a1=load(root/'coax/tests/borrow-summaries/fixtures.json');oracle=load(root/'coax/tests/retained-borrows/native-expectations.json')
 assert len(b1['cases'])==33 and len(a1['cases'])==44 and len(oracle['cases'])==19
 assert len({x['id']for x in b1['cases']})==33 and len({x['id']for x in a1['cases']})==44
 counts={name:methodcount(root/'coax/tests'/name)for name in('checker.py','borrow_summary_systemone.py','diagnostics_json.py')}
 assert counts=={'checker.py':10,'borrow_summary_systemone.py':3,'diagnostics_json.py':8}
 before=hashlist(paths);guards(root,a.source_revision,before)
 pins={'schema':'coax.retained-borrows.final-gate-input-pins.v1','status':'COLLECTED_AWAITING_ROOT_REVIEW','source_revision':a.source_revision,'expected_fingerprint':a.fingerprint,'checker_sha256':a.checker_sha256,'review_scope':'Actual post-freeze hash collection, not a completed gate and not yet Root-reviewed exact pins. Bind requires Root review of this exact collection SHA.','inventories':{'B1_source':33,'A1_source':44,'native_sources':19,'native_controls':2,'native_profiles':3,'legacy_checker_methods':10,'SystemOne_profiles':3,'SystemOne_digits_per_profile':129,'SystemOne_stderr_per_profile':45,'memo_procedures':1000,'diagnostics_methods':8},'layout_receipt':layout_admission,'files':before}
 out.mkdir(parents=True);write(out/'collected-input-pins.json',pins)
 record={'schema':'coax.retained-borrows.final-input-collection.v1','outcome':'collected-not-qualified','source_revision':a.source_revision,'expected_fingerprint':a.fingerprint,'checker_sha256':a.checker_sha256,'repo':str(root),'pins':{'path':str(out/'collected-input-pins.json'),'sha256':sha(out/'collected-input-pins.json')},'inventory_count':len(before),'inputs_unchanged':True,'controller_sha256':sha(__file__),'scope':'No compiler/test/build/native call. HEAD checked before mkdir and after hashes. Root must review exact collection before bind; final producer/normal fields still absent.'}
 guards(root,a.source_revision,before);write(out/'collection.json',record);print(json.dumps({'collection':str(out/'collection.json'),'sha256':sha(out/'collection.json'),'files':len(before)}))
def bind(a):
 # Supplying this SHA is the explicit Root-reviewed collection admission; no gate auto-launch.
 c=load(a.reviewed_collection,a.reviewed_collection_sha256);assert c['schema']=='coax.retained-borrows.final-input-collection.v1'and c['outcome']=='collected-not-qualified'and c['inputs_unchanged']
 root=Path(c['repo']);out=Path(a.output).absolute();assert not out.exists()and not out.is_relative_to(root)
 pins=load(c['pins']['path'],c['pins']['sha256']);assert pins['status']=='COLLECTED_AWAITING_ROOT_REVIEW';guards(root,c['source_revision'],pins['files'])
 assert sha(HERE/'run.py')==RUN_SHA and sha(HERE/'producer_binding.py')==HELPER_SHA
 compiler=regular(root/'coax/bin/coax');assert sha(compiler)==a.compiler_sha256
 package={name:sha(compiler.parent/name)for name in SUPPORT};assert regular(compiler.parent/'mutation-survivors').stat().st_size==0
 normal_path=Path(a.normal_receipt).resolve();normal=load(normal_path,a.normal_sha256)
 approved=load(HERE/'approved-normal-plan.json',PLAN_SHA);assert len(approved['steps'])==165
 assert normal['plan_sha256']==PLAN_SHA and load(normal['plan'],PLAN_SHA)==approved,'normal does not use exact approved165plan'
 spec=importlib.util.spec_from_file_location('reviewed_final_binding',HERE/'producer_binding.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 proof=module.qualification_binding({'fingerprint':c['expected_fingerprint'],'qualified_files':package,'qualification':{'kind':'normal','path':str(normal_path),'sha256':a.normal_sha256}})
 assert proof['source_revision']==c['source_revision']
 normal_binding=load(normal['binding'],normal['binding_sha256']);assert Path(normal_binding['source']).resolve()==root
 for path,value in normal_binding['inputs'].items():assert sha(path)==value,'normal prefix input drift '+path
 protected=dict(pins['files'])
 for path,value in normal_binding['inputs'].items():
  assert path not in protected or protected[path]==value;protected[path]=value
 lines=(compiler.parent/'provenance.record').read_text().splitlines();assert len(lines)==4 and lines[1:3]==[c['expected_fingerprint'],a.compiler_sha256]
 guards(root,c['source_revision'],protected);out.mkdir(parents=True)
 pins.update(status='FINAL_FROZEN_INPUTS_REVIEWED',review_scope='Exact prior collection admitted by explicit Root reviewed-collection SHA. Historical collector record is retained unchanged. No final gate has executed.',reviewed_collection={'path':str(Path(a.reviewed_collection).resolve()),'sha256':a.reviewed_collection_sha256})
 write(out/'input-pins.json',pins)
 common=[sys.executable,str(HERE/'run.py'),'--repo',str(root),'--compiler',str(compiler),'--compiler-sha256',a.compiler_sha256,'--fingerprint',c['expected_fingerprint'],'--source-revision',c['source_revision'],'--normal-receipt',str(normal_path),'--normal-sha256',a.normal_sha256,'--binding-helper',str(HERE/'producer_binding.py'),'--input-pins',str(out/'input-pins.json'),'--input-pins-sha256',sha(out/'input-pins.json')]
 rows=[{'gate':gate,'argv':common+['--gate',gate,'--output',str(out/'gates'/gate)],'internal_deadline_s':870 if gate=='b1-native'else 840,'status':'PREPARED_NOT_EXECUTED'}for gate in GATES]
 write(out/'run-bindings.json',{'schema':'coax.retained-borrows.final-seven-run-bindings.v1','status':'PREPARED_NOT_EXECUTED','qualification_claim':False,'source_revision':c['source_revision'],'fingerprint':c['expected_fingerprint'],'compiler_sha256':a.compiler_sha256,'normal_receipt':{'path':str(normal_path),'sha256':a.normal_sha256},'normal_proof':proof,'actual_package':package,'reviewed_collection':{'path':str(Path(a.reviewed_collection).resolve()),'sha256':a.reviewed_collection_sha256},'input_pins':{'path':str(out/'input-pins.json'),'sha256':sha(out/'input-pins.json')},'commands':rows,'controller_sha256':sha(__file__),'scope':'Exact whole seven commands, independent output dirs. No original filters/budgets/oracles changed. Native21/profile×3, source33/44, legacy10,SystemOne3,independent1000,diagnostics8. Execute only on Root cue, stop first failure and preserve raw scope.'})
 guards(root,c['source_revision'],protected);assert hashlist(compiler.parent/n for n in SUPPORT)=={str(compiler.parent/n):h for n,h in package.items()};print(json.dumps({'bindings':str(out/'run-bindings.json'),'sha256':sha(out/'run-bindings.json'),'gates':len(rows)}))
def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
 c=sub.add_parser('collect')
 for n in('repo','source-revision','fingerprint','checker-sha256','layout-receipt','layout-sha256','output'):c.add_argument('--'+n,required=True)
 for n in('layout-continuity','layout-continuity-sha256','layout-continuity-review','layout-continuity-review-sha256'):c.add_argument('--'+n)
 b=sub.add_parser('bind')
 for n in('reviewed-collection','reviewed-collection-sha256','normal-receipt','normal-sha256','compiler-sha256','output'):b.add_argument('--'+n,required=True)
 a=p.parse_args();assert not sys.flags.optimize
 for k,v in vars(a).items():
  if v is not None and(k.endswith('sha256')or k=='fingerprint'):assert re.fullmatch('[0-9a-f]{64}',v),k
 if a.action=='collect':
  assert len({bool(a.layout_continuity),bool(a.layout_continuity_sha256),bool(a.layout_continuity_review),bool(a.layout_continuity_review_sha256)})==1,'continuity path/SHA and Root-review path/SHA must be admitted together'
  assert re.fullmatch('[0-9a-f]{40}',a.source_revision);collect(a)
 else:bind(a)
if __name__=='__main__':main()
