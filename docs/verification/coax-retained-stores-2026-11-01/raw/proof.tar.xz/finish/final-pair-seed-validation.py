from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil,time
F=Path('/tmp/coax-retained-borrows-B1-finish');BASE=F/'faa3-immutable-model';OUT=F/'final-pair-seed-validation';ROOT=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents');COMPILER=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/bin/coax');SNIPPET=F/'final-pair-apply-controls.coax';V4=F/'effect-pair-controls-v4.coax'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(COMPILER)=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
assert sha(BASE/'checker.coax')=='faa3a02f01cc592a6097c3f98406ae577c30f3e06bd32145a0f7e78ed058da33'
assert sha(BASE/'snapshot.json')=='4c1457968e7e46d8bd5b3e0e12db18716547e2e050d76901f2b81b4198367f95'
assert sha(SNIPPET)=='1db2ab6ff7710c305f217d5657079d22206fdd860d96bd9d929b901515888b37'
assert sha(V4)=='280cac0c81ae294a80206e3192309430dc3c2408885d37a7e510be6b53d8e8ec'
for name,value in json.loads((BASE/'snapshot.json').read_bytes())['files'].items():assert sha(BASE/name)==value
original=(BASE/'checker.coax').read_text();prefix='PS final exact controls: ';adapt=lambda text,p:re.sub(r'(#(?:test|forall)\s+)"([^"\n]+)"',lambda q:q[1]+json.dumps(p+q[2]),text)
newextra=adapt(SNIPPET.read_text(),prefix);v4extra=adapt(V4.read_text(),'PS exact effect controls: ')
FLAGS=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
def func(text,name):
 a=text.index(name+' ::');z=text.index('\n}',a)+2;return a,z,text[a:z]
def check(text,title):
 matches=list(re.finditer(r'#(?:test|forall)\s+"'+re.escape(title)+r'"',text));assert len(matches)==1;a=matches[0].start();i=text.index('{',matches[0].end());depth=0;quote=False;escape=False;comment=False
 for j in range(i,len(text)):
  c=text[j]
  if comment:
   if c=='\n':comment=False
   continue
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
   continue
  if c=='"':quote=True
  elif c=='/' and j+1<len(text)and text[j+1]=='/':comment=True
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:return text[a:j+1]
 raise AssertionError('unclosed')
def prior(path,title,text):
 r=json.loads(path.read_bytes());obs=r.get('observation',r);assert obs['started']and obs['stdout_eof']and obs['stderr_eof']and not any(obs.get(k)for k in FLAGS)and r['inputs_unchanged']
 oldsource=path.parent/'source/checker.coax';before=r.get('input_before',r.get('inputs_before'));assert sha(oldsource)==before[str(oldsource)]
 evpath=path.parent/'evidence.json';claims=[c for c in json.loads(evpath.read_bytes())['claims']if c['name']==title];assert len(claims)==1 and claims[0]['outcome']=='passed';assert check(oldsource.read_text(),title)==check(text,title)
 return{'record_path':str(path),'record_sha256':sha(path),'original_returncode':obs['returncode'],'evidence_sha256':sha(evpath),'selected_claim':claims[0],'check_sha256':hashlib.sha256(check(text,title).encode()).hexdigest(),'source_path':str(oldsource)}
spec=importlib.util.spec_from_file_location('bp',ROOT/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
OUT.mkdir(exist_ok=False)
def run(name,extra,title,mutation=None,baseline=None):
 text=original+'\n'+extra;fact=prior(baseline,title,text)if baseline else None
 if mutation:
  function,old,new=mutation;a,z,part=func(text,function);assert part.count(old)==1,(name,part.count(old));text=text[:a]+part.replace(old,new)+text[z:]
 out=OUT/name;out.mkdir();shutil.copytree(BASE,out/'source');source=out/'source/checker.coax';source.write_text(text)
 paths=[COMPILER,Path(__file__),SNIPPET,V4,BASE/'snapshot.json',ROOT/'coax/tools/bounded_process.py',ROOT/'coax/tests/quiet_crash.py',*sorted((out/'source').glob('*.coax'))];before={str(p):sha(p)for p in paths};argv=[str(COMPILER),'test',str(source),'--library','--only',title,'--evidence',str(out/'evidence.json')];now=time.monotonic();r=bp.run(argv,str(ROOT),os.environ.copy(),180,8388608,now+180,quiet_faults=True);raw={}
 for stream in('stdout','stderr'):
  p=out/(stream+'.log');p.write_bytes(r[stream]);raw[stream]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 after={str(p):sha(p)for p in paths};clean=r['started']and r['stdout_eof']and r['stderr_eof']and before==after and not any(r.get(k)for k in FLAGS);evpath=out/'evidence.json';claims=[c for c in json.loads(evpath.read_bytes())['claims']if c['name'].startswith(title)]if evpath.is_file()else[]
 passed=bool(clean and((not mutation and r['returncode']==0 and len(claims)==2 and all(c['outcome']=='passed'for c in claims))or(mutation and r['returncode']==1 and len(claims)==1 and claims[0]['outcome']=='counterexample'and claims[0]['code']in('E0406','E0410'))))
 q={'schema':'coax.retained-borrows.final-pair.private-comparison.v1','outcome':'passed'if passed else'failed','scope':'Private supplied graph controls on frozen FAA3 interpreted by historical trusted5c. New2blocks/5cases original once; every seed reuses an actual retained unchanged original. Not whole mutation/native/compiler qualification. E0410 is checked evaluator bounds refusal/trap, not native OOB.','mutation':mutation,'original_green':fact,'compiler_sha256':sha(COMPILER),'base_sha256':sha(BASE/'checker.coax'),'argv':argv,'input_before':before,'input_after':after,'inputs_unchanged':before==after,'clean_transport':clean,'actual_claims':claims,'observation':{k:v for k,v in r.items()if k not in('stdout','stderr')},'raw':raw,'evidence':{'path':str(evpath),'sha256':sha(evpath)}if evpath.is_file()else None};(out/'process.json').write_text(json.dumps(q,indent=2)+'\n');row={'name':name,'outcome':q['outcome'],'record_sha256':sha(out/'process.json'),'elapsed_s':r['elapsed_s'],'actual_codes':[c.get('code')for c in claims]};print(json.dumps(row),flush=True);assert passed,'actual comparison failure: '+name;return row
rows=[run('new-original',newextra,prefix)]
newbaseline=OUT/'new-original/process.json'
items=[
 ('destination65-upper-literal',newextra,prefix+'retained pair destination65 rejects before fixed staging writes',('CR_pairs','addresses.count>64','addresses.count>65'),newbaseline),
 ('source-kind-role-or',newextra,prefix+'retained applied effects reject nonformal sources and a truncated canonical chain',('CR_apply','effect.source.kind!=BS_PARAMETER || effect.source.role!=BS_DESCRIPTOR','effect.source.kind!=BS_PARAMETER && effect.source.role!=BS_DESCRIPTOR'),newbaseline),
 ('source-kind-role-resource',newextra,prefix+'retained applied effects reject nonformal sources and a truncated canonical chain',('CR_apply','if effect.source.kind!=BS_PARAMETER || effect.source.role!=BS_DESCRIPTOR {CK_resource(b.c,e.loc);return;}','if effect.source.kind!=BS_PARAMETER || effect.source.role!=BS_DESCRIPTOR {return;}'),newbaseline),
 ('truncated-chain-resource',newextra,prefix+'retained applied effects reject nonformal sources and a truncated canonical chain',('CR_apply','if link!=0 {CK_resource(b.c,e.loc);return;}','if link!=0 {return;}'),newbaseline),
 ('owner64-greater-equal',v4extra,'PS exact effect controls: retained accumulated64 pairs admit and a distinct65th refuses at the original site',('CR_effect','retain_count>=64','retain_count>64'),F/'effect-pair-validation/changed-v4-owner-original/process.json'),
 ('globalpool-greater-equal',v4extra,'PS exact effect controls: retained canonical effect publication refuses a full shared pool for a fresh owner',('CR_effect','r.state[0].effects>=r.effects.count','r.state[0].effects>r.effects.count'),F/'effect-pair-validation/changed-v4-shared-original/process.json'),
 ('apply-second-error-count','', 'retained applied local violation stops before a later invalid effect',('CR_apply','b.c.state[0].error_count>0','b.c.state[0].error_count>1'),F/'apply-controls-execution/full-authored-baseline/process.json'),
]
for name,extra,title,mutation,baseline in items:rows.append(run(name,extra,title,mutation,baseline))
(OUT/'summary.json').write_text(json.dumps({'schema':'coax.retained-borrows.final-pair-seed-summary.v1','outcome':'passed','scope':'One new two-block/five-case original GREEN plus seven actual exact seeded comparisons. Existing originals are retained, not replayed. Source-class-false belongs to Book; no duplicate scope.','rows':rows,'controller_sha256':sha(__file__)},indent=2)+'\n');print('summary_sha256',sha(OUT/'summary.json'))
