#!/usr/bin/env python3
"""Actual8-record full-scope historical959 diagnostic merge, never normal qualification."""
import hashlib,json,os,pathlib,sys,time
BASE=pathlib.Path('/tmp/coax-retained-borrows-B1-finish/frozen959-shards')
OLD=pathlib.Path('/tmp/coax-retained-borrows-B1-resume/diagnostic959-shard1')
P=pathlib.Path('/tmp/coax-retained-borrows-B1-resume/normal165-final/snapshot/coax/bin/.bootstrap-bounded-normal/stage0')
INF=pathlib.Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax')
BAD=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def inventory(root):return {str(p):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
def main():
 d=BASE/'merge';assert not d.exists();manifest=json.loads((BASE/'snapshot.json').read_text());assert inventory(BASE/'snapshot')==manifest['files']
 assert sha(P)=='448e978d9448137a31dc38e22491b8f0e34f9cdc5d7466f21296950d2698c4a5'
 records=[OLD/'checker.1.rec',*[BASE/('shard-'+str(n))/('checker.'+str(n)+'.rec') for n in range(2,9)]]
 receipts=[OLD/'process.json',*[BASE/('shard-'+str(n))/'process.json' for n in range(2,9)]]
 for n,(p,q) in enumerate(zip(records,receipts),1):
  r=json.loads(q.read_text());o=r['observation'];assert r['inputs_unchanged'] and r['transport_clean'] and o['returncode'] in [0,1]
  assert o['started'] and o['stdout_eof'] and o['stderr_eof'] and not any(o.get(k) for k in BAD)
  assert sha(p)==o['stdout']['sha256'];lines=p.read_text().split('\n');assert lines[0]=='coax-mutation-shard v1' and lines[1]=='shard '+str(n)+'/8'
  assert lines[2]=='file cab89e49bae6ac8a mutants 9273 shards 8 scheduling full borrowed 1 strings 1 unstable 0'
 tools=[P,pathlib.Path(__file__).resolve(),BASE/'snapshot.json',INF/'tools/bounded_process.py',INF/'tests/quiet_crash.py',pathlib.Path(sys.executable).resolve(),*records,*receipts]
 before={str(p):sha(p) for p in tools};d.mkdir();env=os.environ.copy();env.update(COAX_BUILD_FRESH='1',COAX_MUTATION_CHANGED='strict',COAX_MUTATION_FULL='1',LC_ALL='C')
 argv=[str(P),'mutate','lib/compiler/checker.coax'];
 for p in records:argv+=['--merge',str(p)]
 start=time.monotonic();deadline=start+180;sys.path.insert(0,str(INF/'tools'));import bounded_process
 r=bounded_process.run(argv,str(BASE/'snapshot/coax'),env,max(0,deadline-time.monotonic()),8388608,deadline,quiet_faults=True)
 for stream in ['stdout','stderr']:
  data=r.pop(stream);p=d/(stream+'.log');p.write_bytes(data);r[stream]={'path':str(p),'bytes':len(data),'sha256':sha(p)}
 after={str(p):sha(p) for p in tools};same=after==before and inventory(BASE/'snapshot')==manifest['files'];clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k) for k in BAD)
 result={'schema':'coax.B1.frozen959.actual-full-diagnostic-merge.v1','scope':'Actual8-record merge of full original-scope959source inventory using unqualified947source stage0. Historical diagnostic only, no current-source/normal qualification.','qualified':False,'argv':argv,'inputs_before':before,'inputs_after':after,'inputs_unchanged':same,'source_manifest_sha256':sha(BASE/'snapshot.json'),'observation':r,'transport_clean':clean,'process_completed':clean and r['returncode'] in [0,1]}
 (d/'process.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'record':str(d/'process.json'),'sha256':sha(d/'process.json'),'returncode':r['returncode'],'elapsed_s':r['elapsed_s'],'transport_clean':clean,'inputs_unchanged':same,'qualified':False}))
 return 0 if result['process_completed'] and same else 1
if __name__=='__main__':raise SystemExit(main())
