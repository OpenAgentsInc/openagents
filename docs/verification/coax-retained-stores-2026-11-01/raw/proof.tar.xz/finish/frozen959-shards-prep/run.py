#!/usr/bin/env python3
"""Historical-source full-scope diagnostic shards; no normal qualification."""
import argparse,hashlib,io,json,os,pathlib,shutil,subprocess,sys,tarfile,time
BASE=pathlib.Path('/tmp/coax-retained-borrows-B1-finish/frozen959-shards')
SOURCE=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
REV='4c7e53ea3f0bc4e8d429ef099e41a047aea152cb'
MODEL='a213b0ea462b4248abcb666871840d3f6db6ffaf36859b58823d53e3036e735a'
P=pathlib.Path('/tmp/coax-retained-borrows-B1-resume/normal165-final/snapshot/coax/bin/.bootstrap-bounded-normal/stage0')
PSHA='448e978d9448137a31dc38e22491b8f0e34f9cdc5d7466f21296950d2698c4a5'
INF=pathlib.Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax')
BAD=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def inventory(root):
 assert not any(p.is_symlink() for p in root.rglob('*'))
 return {str(p):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def prepare():
 assert not BASE.exists();assert sha(P)==PSHA
 git=pathlib.Path(shutil.which('git')).resolve();start=time.monotonic()
 r=subprocess.run([str(git),'-C',str(SOURCE),'archive','--format=tar',REV,'coax'],capture_output=True,timeout=60)
 assert r.returncode==0 and not r.stderr
 BASE.mkdir();(BASE/'source.tar').write_bytes(r.stdout);snap=BASE/'snapshot';snap.mkdir()
 with tarfile.open(fileobj=io.BytesIO(r.stdout)) as t:
  for m in t.getmembers():
   p=pathlib.PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts
   assert m.isfile() or m.isdir(),'nonregular Git archive member'
   target=snap.joinpath(*p.parts)
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read());os.chmod(target,m.mode)
 assert sha(snap/'coax/lib/compiler/checker.coax')==MODEL
 files=inventory(snap)
 dump(BASE/'snapshot.json',{'schema':'coax.B1.frozen959.diagnostic-snapshot.v1','qualified':False,'revision':REV,'model_sha256':MODEL,'producer':str(P),'producer_sha256':PSHA,'source_archive_sha256':sha(BASE/'source.tar'),'git_argv':[str(git),'-C',str(SOURCE),'archive','--format=tar',REV,'coax'],'git_sha256':sha(git),'setup_elapsed_s':time.monotonic()-start,'files':files,'scope':'Committed959 source snapshot only; other7 shards complement earlier shard1 on identical source/producer. No current-source or normal qualification.'})
 print(json.dumps({'snapshot':str(BASE/'snapshot.json'),'sha256':sha(BASE/'snapshot.json'),'files':len(files)}))
def run(shard):
 assert 2<=shard<=8 and sha(P)==PSHA
 manifest=json.loads((BASE/'snapshot.json').read_text());snap=BASE/'snapshot';assert inventory(snap)==manifest['files']
 out=BASE/('shard-'+str(shard));assert not out.exists();out.mkdir()
 tools=[P,pathlib.Path(__file__).resolve(),INF/'tools/bounded_process.py',INF/'tests/quiet_crash.py',pathlib.Path(sys.executable).resolve(),BASE/'snapshot.json']
 before={str(p):sha(p) for p in tools};env=os.environ.copy();env.update(COAX_BUILD_FRESH='1',COAX_MUTATION_CHANGED='strict',COAX_MUTATION_FULL='1',LC_ALL='C')
 argv=[str(P),'mutate','lib/compiler/checker.coax','--shard',str(shard)+'/8','--jobs','12'];start=time.monotonic();deadline=start+840
 plan={'scope':manifest['scope'],'argv':argv,'cwd':str(snap/'coax'),'inputs_before':before,'source_manifest_sha256':sha(BASE/'snapshot.json'),'environment':{k:env.get(k) for k in ['PATH','COAX_MUTATE_JOBS','COAX_BUILD_FRESH','COAX_MUTATION_CHANGED','COAX_MUTATION_FULL','COAX_GATE_CACHE']},'qualified':False,'timeout_s':840}
 dump(out/'plan.json',plan);sys.path.insert(0,str(INF/'tools'));import bounded_process
 r=bounded_process.run(argv,str(snap/'coax'),env,max(0,deadline-time.monotonic()),8388608,deadline,quiet_faults=True)
 for stream,name in [('stdout','checker.'+str(shard)+'.rec'),('stderr','stderr.log')]:
  data=r.pop(stream);p=out/name;p.write_bytes(data);r[stream]={'path':str(p),'bytes':len(data),'sha256':sha(p)}
 after={str(p):sha(p) for p in tools};same=after==before and inventory(snap)==manifest['files'];clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k) for k in BAD)
 result={'schema':'coax.B1.frozen959.full-shard-diagnostic.v1','scope':manifest['scope'],'qualified':False,'plan_sha256':sha(out/'plan.json'),'observation':r,'inputs_after':after,'inputs_unchanged':same,'transport_clean':clean,'process_completed':clean and r['returncode'] in [0,1],'normal_epoch_untouched':True}
 dump(out/'process.json',result);print(json.dumps({'shard':shard,'record':str(out/'process.json'),'sha256':sha(out/'process.json'),'elapsed_s':r['elapsed_s'],'returncode':r['returncode'],'transport_clean':clean,'inputs_unchanged':same,'qualified':False}))
 return 0 if result['process_completed'] and same else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','shard']);p.add_argument('number',type=int,nargs='?');a=p.parse_args()
 if a.action=='prepare':prepare()
 else:raise SystemExit(run(a.number))
