#!/usr/bin/env python3
"""Generic procedures through the real driver (spec 7.2, r4a-type-parameters, r4a-instantiation).

TypeParameters: `$T` binds a placeholder type at its first parameter use and
every other use is checked against it; each refused form reports its own
explained code; an uncalled generic procedure is never emitted, so a
program's C is unchanged by one.

Instantiation: each call deduces its bindings; one instance per distinct
binding is checked, evaluated and emitted under its own C name, and the
evaluator (#run, coax test) agrees with native code at -O0 and -O2.
The binding rules are checked and mutation-tested in lib/compiler/checker.coax
(the $ token in lexer.coax, the type node in parser.coax); these fixtures pin
the composed behavior of lexer, parser, checker, bridges and emitters.
"""
from pathlib import Path
import json
import os
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
COAX = Path(os.environ.get("COAX_TEST_COMPILER", ROOT / "bin/coax")).resolve()

GENERIC = (
    "first :: (v: [] $T) -> $T { return v[0]; }\n"
    "swap :: (a: [] $T, i: int, j: int) { t := a[i]; a[i] = a[j]; a[j] = t; }\n"
    "pick :: (a: $T, b: $T, second: bool) -> $T { r: $T = a; if second { r = b; } return r; }\n"
    "count :: (v: [] $T) -> int { n := 0; for x, i: v { n += 1; } return n; }\n"
)
PROGRAM = (
    '#import "Basic";\n'
    "total :: (v: [] int) -> int { s := 0; for x: v { s += x; } return s; }\n"
    'main :: () { a := [3] int.[4, 5, 6]; print("%\\n", total(a[..])); }\n'
)
REFUSED = [
    ("make :: () -> $T { x: $T; return x; }", ["E0392", "E0393"]),
    ("f :: (a: $T) { b: $U; }", ["E0393"]),
    ("K :: size_of($T);", ["E0393"]),
    ('#test "t" { x: $T; }', ["E0393"]),
    ("f :: (a: [4] [] $T) {}", ["E0394"]),
    ("f :: (a: [] [] $T) {}", ["E0394"]),
    ("S :: struct { x: $T; }", ["E0395"]),
    ("f :: (a: $T) -> $T { return f(a); }", ["E0396"]),
    ("f :: (a: $T) {} n :: () {} g :: () { f(n()); }", ["E0397"]),
    ("f :: (a: $T, b: $T) {} g :: () { f(1, true); }", ["E0348"]),
    ("f :: (v: [] $T) {} g :: () { a := [2] int.[1, 2]; f(a); }", ["E0349"]),
    ("f :: (a: $T) -> $T { return a; } g :: () -> bool { return f(1); }", ["E0330"]),
    ("f :: (a: $T) -> $T #export_c { return a; }", ["E0398"]),
    ("f :: (a: $T) -> int { return size_of($T); }", ["E0399"]),
    ("f :: (a: $T) -> string { return type_name(a); }", ["E0399"]),
    ("f :: (a: $T) -> $T { return 1; }", ["E0330"]),
    ("f :: (a: $T, b: $U) { c := a; c = b; }", ["E0327"]),
    ("g :: (x: int) {} f :: (a: $T) { g(a); }", ["E0317"]),
    ("f :: (a: $T, b: $T) -> bool { return a == b; }", ["E0311"]),
    ("f :: (a: $T, b: $T) -> bool { return a < b; }", ["E0310"]),
    ("f :: (a: $T) { x := a + a; }", ["E0309"]),
    ("f :: (a: $ T) {}", ["E0108"]),
    ("f :: () { x := $T; }", ["E0205"]),
]


class TypeParameters(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="coax-generics-")
        self.addCleanup(self.tmp.cleanup)
        self.d = Path(self.tmp.name)

    def write(self, name, text):
        path = self.d / name
        path.write_text(text)
        return path

    def coax(self, *args):
        return subprocess.run([str(COAX), *map(str, args)], capture_output=True, text=True, timeout=120)

    def codes(self, path, *extra):
        r = self.coax("check", path, "--json", *extra)
        return r.returncode, [json.loads(line)["code"] for line in r.stderr.splitlines() if line.startswith("{")]

    def test_generic_procedures_check_and_leave_the_program_unchanged(self):
        (self.d / "plain").mkdir()
        plain = self.write("plain/program.coax", PROGRAM)
        generic = self.write("program.coax", PROGRAM + GENERIC)
        self.assertEqual(self.coax("check", generic).returncode, 0, self.coax("check", generic).stderr)
        run = self.coax("run", generic)
        self.assertEqual((run.returncode, run.stdout), (0, "15\n"), run.stderr)
        c_plain, c_generic = self.coax("c", plain), self.coax("c", generic)
        self.assertEqual(c_generic.returncode, 0, c_generic.stderr)
        # No instance exists, so nothing of a generic procedure reaches C.
        self.assertEqual(c_plain.stdout.replace(str(plain), "PROGRAM"), c_generic.stdout.replace(str(generic), "PROGRAM"))
        for name in ("first", "swap", "pick", "count"):
            self.assertNotIn("coax_p_" + name, c_generic.stdout)
        layout = self.coax("layout", generic)
        self.assertEqual(layout.returncode, 0, layout.stderr)
        self.assertNotIn("$T", layout.stdout)

    def test_declarations_list_generic_procedures(self):
        path = self.write("decls.coax", '#module "app.generic";\n' + PROGRAM + GENERIC)
        r = self.coax("deps", path, "--declarations")
        self.assertEqual(r.returncode, 0, r.stderr)
        ids = [d["id"] for d in json.loads(r.stdout)["declarations"]]
        for name in ("main", "total", "first", "swap", "pick", "count"):
            self.assertIn(f"coax.decl.v1:app.generic:proc:{name}", ids)

    def test_checks_metal_and_mutation_ignore_generic_procedures(self):
        source = GENERIC + "double :: (x: int) -> int { return x * 2; }\nmain :: () {}\n" + '#test "double" { #assert double(3) == 6; }\n'
        path = self.write("checks.coax", source)
        r = self.coax("test", path)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("1 check, 1 passed, 0 failed", r.stdout)
        r = self.coax("mutate", path)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertRegex(r.stdout + r.stderr, r"(\d+) mutants, \1 killed, 0 survived")
        metal = self.write("metal.coax", "scale :: (x: f32) -> f32 { return x * 2.0; }\n" + GENERIC)
        r = self.coax("metal", metal)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("scale", r.stdout)
        self.assertNotIn("first", r.stdout)

    def test_authority_files_still_require_every_procedure_checked(self):
        path = self.write("authority.coax", "#authority;\n" + GENERIC)
        code, codes = self.codes(path, "--library")
        self.assertNotEqual(code, 0)
        self.assertEqual(set(codes), {"E0380"})

    def test_refused_forms_report_their_codes(self):
        for i, (source, want) in enumerate(REFUSED):
            with self.subTest(source=source):
                path = self.write(f"refused{i}.coax", source + "\nmain :: () {}\n")
                code, codes = self.codes(path)
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, want)

    def test_every_new_code_is_explained(self):
        for code in ("E0339", "E0348", "E0349", "E0368", "E0392", "E0393", "E0394", "E0395", "E0396", "E0397", "E0398", "E0399"):
            r = self.coax("explain", code)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertTrue(r.stdout.startswith(code + ": "), r.stdout)
            self.assertGreater(len(r.stdout), 80)


INSTANCES = (
    "P :: struct { x: int; y: f64; }\n"
    "E :: enum u8 { red; blue; }\n"
    "id :: (a: $T) -> $T { return a; }\n"
    "first :: (v: [] $T) -> $T { return v[0]; }\n"
    "swap :: (a: [] $T, i: int, j: int) { t := a[i]; a[i] = a[j]; a[j] = t; }\n"
    "pick :: (a: $T, b: $T, second: bool) -> $T { r: $T = a; if second { r = b; } return r; }\n"
    "count :: (v: [] $T) -> int { n := 0; for x, i: v { n += 1; } return n; }\n"
    "twice :: (a: $T, b: $T) -> $T { return pick(a, id(b), true); }\n"
    "f64_sum :: (v: [] f64) -> f64 { s := 0.0; for x: v { s += x; } return s; }\n"
    "int_result :: () -> int { a := [3] int.[4, 5, 6]; swap(a[..], 0, 2); return first(a[..]) * 100 + pick(7, 8, true) * 10 + count(a[..]); }\n"
    "f64_result :: () -> f64 { a := [3] f64.[0.5, 1.25, 2.0]; swap(a[..], 1, 2); return first(a[..]) + twice(1.5, 2.25) + f64_sum(a[..]); }\n"
    "struct_result :: () -> int { a := [2] P.[P.{x = 1, y = 0.5}, P.{x = 2, y = 1.5}]; swap(a[..], 0, 1); p := pick(a[0], a[1], false); "
    "e := id(E.blue); k := 0; if e == E.blue { k = 1; } return p.x * 10 + first(a[..]).x + count(a[..]) * 100 + k * 1000; }\n"
)
INSTANCE_MAIN = '#import "Basic";\n' + INSTANCES + 'main :: () { print("% % %\\n", int_result(), f64_result(), struct_result()); }\n'
EXPECTED = "683 6.5 1222\n"


class Instantiation(unittest.TestCase):
    setUp = TypeParameters.setUp
    write = TypeParameters.write
    coax = TypeParameters.coax
    codes = TypeParameters.codes

    def test_native_code_agrees_with_the_evaluator(self):
        path = self.write("instances.coax", INSTANCE_MAIN)
        for opt in ("0", "2"):
            r = self.coax("run", path, "--opt", opt)
            self.assertEqual((r.returncode, r.stdout), (0, EXPECTED), r.stderr)
        # The same procedures evaluated while compiling and under coax test.
        ct = self.write("compile_time.coax", '#import "Basic";\n' + INSTANCES +
                        "I :: #run int_result();\nF :: #run f64_result();\nS :: #run struct_result();\n"
                        'main :: () { print("% % %\\n", I, F, S); }\n'
                        '#test "instances" { #assert int_result() == 683 && f64_result() == 6.5 && struct_result() == 1222; }\n')
        for opt in ("0", "2"):
            r = self.coax("run", ct, "--opt", opt)
            self.assertEqual((r.returncode, r.stdout), (0, EXPECTED), r.stderr)
        r = self.coax("test", ct)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("1 check, 1 passed, 0 failed", r.stdout)

    def test_one_instance_per_binding_under_its_own_c_name(self):
        path = self.write("names.coax", INSTANCE_MAIN)
        r = self.coax("c", path)
        self.assertEqual(r.returncode, 0, r.stderr)
        defined = sorted(set(line.split("(")[0].split()[-1] for line in r.stdout.splitlines()
                             if line.startswith("static ") and "__" in line.split("(")[0]))
        self.assertEqual(defined, sorted([
            "coax_p_count__3int", "coax_p_count__4n0_P",
            "coax_p_first__3int", "coax_p_first__3f64", "coax_p_first__4n0_P",
            "coax_p_swap__3int", "coax_p_swap__3f64", "coax_p_swap__4n0_P",
            "coax_p_pick__3int", "coax_p_pick__3f64", "coax_p_pick__4n0_P",
            "coax_p_twice__3f64", "coax_p_id__3f64", "coax_p_id__4n0_E"]))
        timings = self.d / "timings.json"
        r = self.coax("c", path, "--timings", timings)
        self.assertEqual(r.returncode, 0, r.stderr)
        record = json.loads(timings.read_text())
        self.assertEqual(record["instances"], 14)
        self.assertGreater(record["instance_generated_bytes"], 0)
        self.assertLess(record["instance_generated_bytes"], record["generated_bytes"])

    def test_declarations_name_templates_not_instances(self):
        path = self.write("decls.coax", '#module "app.inst";\n' + INSTANCE_MAIN)
        r = self.coax("deps", path, "--declarations")
        self.assertEqual(r.returncode, 0, r.stderr)
        record = json.loads(r.stdout)
        procs = [d["id"] for d in record["declarations"] if ":proc:" in d["id"]]
        self.assertEqual(len(procs), len(set(procs)))
        self.assertIn("coax.decl.v1:app.inst:proc:pick", procs)
        self.assertIn("coax.decl.v1:app.inst:proc:pick", {ref["to"] for ref in record["references"]})

    def test_authority_checks_cover_templates_through_instances(self):
        source = ("#authority;\n" + INSTANCES.replace("f64_sum", "fsum") +
                  '#test "results" { #assert int_result() == 683 && f64_result() == 6.5 && struct_result() == 1222; }\n'
                  '#test "pick" { #assert pick(1, 2, false) == 1 && pick(1, 2, true) == 2 && pick(1.5, 2.5, false) == 1.5; }\n')
        path = self.write("authority.coax", source)
        r = self.coax("test", path, "--library")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        r = self.coax("mutate", path, "--library")
        self.assertIn(" mutants, ", r.stdout + r.stderr)

    def test_instance_budget(self):
        types = "".join(f"S{i} :: struct {{ v: int; }}\n" for i in range(257))
        calls = "".join(f"x{i} := id(S{i}.{{v = {i}}});" for i in range(257))
        path = self.write("budget.coax", "id :: (a: $T) -> $T { return a; }\n" + types + "main :: () { " + calls + " }\n")
        code, codes = self.codes(path)
        self.assertNotEqual(code, 0)
        self.assertEqual(codes, ["E0339"])
        fits = self.write("fits.coax", "id :: (a: $T) -> $T { return a; }\n" + types + "main :: () { " + calls.rsplit("x256", 1)[0] + " }\n")
        self.assertEqual(self.coax("check", fits).returncode, 0, self.coax("check", fits).stderr)


VALUES = (
    "sum :: (a: [$N] int) -> int { s := 0; for x: a { s += x; } return s; }\n"
    "last :: (a: [$N] $T) -> $T { return a[a.count - 1]; }\n"
    "rev :: (a: [$N] $T) -> [$N] $T { b := a; for i: 0..<a.count { b[i] = a[a.count - 1 - i]; } return b; }\n"
    "dot :: (a: [$N] f64, b: [$N] f64) -> f64 { s := 0.0; for x, i: a { s += x * b[i]; } return s; }\n"
    "fourth :: (a: [4] $T) -> $T { return a[3]; }\n"
    "result :: () -> int { x := [3] int.[1, 2, 3]; y := [5] int.[1, 2, 3, 4, 5]; r := rev(y); return sum(x) * 100 + sum(y) + last(r) * 1000 + fourth([4] int.[0, 0, 0, 9]) * 10000; }\n"
    "fresult :: () -> f64 { a := [2] f64.[1.5, 2.0]; return dot(a, rev(a)) + last(a); }\n"
)


class ValueParameters(unittest.TestCase):
    setUp = TypeParameters.setUp
    write = TypeParameters.write
    coax = TypeParameters.coax
    codes = TypeParameters.codes

    def test_fixed_array_lengths_bind_and_agree_with_the_evaluator(self):
        program = self.write("values.coax", '#import "Basic";\n' + VALUES + 'main :: () { print("% %\\n", result(), fresult()); }\n')
        compile_time = self.write("values_ct.coax", '#import "Basic";\n' + VALUES + "R :: #run result();\nF :: #run fresult();\n"
                                  'main :: () { print("% %\\n", R, F); }\n#test "values" { #assert result() == 91615 && fresult() == 8.0; }\n')
        for path in (program, compile_time):
            for opt in ("0", "2"):
                r = self.coax("run", path, "--opt", opt)
                self.assertEqual((r.returncode, r.stdout), (0, "91615 8.0\n"), r.stderr)
        r = self.coax("test", compile_time)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        c = self.coax("c", program).stdout
        for name in ("coax_p_sum__2i3", "coax_p_sum__2i5", "coax_p_rev__2i53int", "coax_p_rev__2i23f64", "coax_p_last__2i53int",
                     "coax_p_last__2i23f64", "coax_p_dot__2i2", "coax_p_fourth__3int"):
            self.assertIn(name + "(", c)

    def test_refused_value_parameter_forms(self):
        cases = [
            ("two :: (a: [$N] int, b: [$N] int) {} g :: () { x := [3] int.[1, 2, 3]; y := [2] int.[1, 2]; two(x, y); }", ["E0348"]),
            ("f :: (a: [$N] int) {} g :: () { x := [3] int.[1, 2, 3]; f(x[..]); }", ["E0349"]),
            ("f :: (a: [4] $T) {} g :: () { x := [3] int.[1, 2, 3]; f(x); }", ["E0349"]),
            ("f :: (a: [$T] int, b: $T) {}", ["E0368"]),
            ("f :: (a: $T, b: [$T] int) {}", ["E0368"]),
            ("f :: () -> [$N] int { x: [$N] int; return x; }", ["E0392", "E0393"]),
            ("f :: (a: [] [$N] int) {}", ["E0394"]),
        ]
        for i, (source, want) in enumerate(cases):
            with self.subTest(source=source):
                code, codes = self.codes(self.write(f"v{i}.coax", source + "\nmain :: () {}\n"))
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, want)


STRUCTS = (
    "Pair :: struct($T) { a: $T; b: $T; }\n"
    "Box :: struct($T, $N) { items: [$N] $T; n: int; }\n"
    "Holder :: struct { p: Pair(int); q: Pair(f64); }\n"
    "swap :: (p: Pair($T)) -> Pair($T) { return Pair.{a = p.b, b = p.a}; }\n"
    "total :: (b: Box(int, $N)) -> int { s := 0; for v: b.items { s += v; } return s + b.n; }\n"
    "pick :: (v: [] Pair($T), i: int) -> $T { return v[i].b; }\n"
    "first :: (b: Box($T, $N)) -> $T { return b.items[0]; }\n"
    "calc :: () -> int {\n"
    "  p := Pair.{a = 1, b = 2}; q: Pair(f64) = Pair.{a = 1.5, b = 2}; r := swap(p); w := swap(q);\n"
    "  bx := Box.{items = [3] int.[1, 2, 3], n = 4}; ps := [2] Pair(int).[p, r];\n"
    "  h := Holder.{p = r, q = w};\n"
    "  fb := Box.{items = [2] f64.[0.5, 9.0], n = 0};\n"
    "  pp: Pair(Pair(int)) = Pair.{a = p, b = r};\n"
    "  x := cast(int)(first(fb) * 10.0);\n"
    "  return r.a * 100000 + total(bx) * 1000 + pick(ps[..], 1) * 100 + h.p.b * 10 + pp.b.a + x + cast(int)h.q.a;\n"
    "}\n"
)


class GenericStructs(unittest.TestCase):
    setUp = TypeParameters.setUp
    write = TypeParameters.write
    coax = TypeParameters.coax
    codes = TypeParameters.codes

    def test_instances_agree_with_the_evaluator_and_are_laid_out(self):
        program = self.write("structs.coax", '#import "Basic";\n' + STRUCTS + 'main :: () { print("%\\n", calc()); }\n')
        compile_time = self.write("structs_ct.coax", '#import "Basic";\n' + STRUCTS + "K :: #run calc();\n"
                                  'main :: () { print("%\\n", K); }\n#test "structs" { #assert calc() == 210119; }\n')
        for path in (program, compile_time):
            for opt in ("0", "2"):
                r = self.coax("run", path, "--opt", opt)
                self.assertEqual((r.returncode, r.stdout), (0, "210119\n"), r.stderr)
        r = self.coax("test", compile_time)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        heads = [line for line in self.coax("layout", program).stdout.splitlines() if not line.startswith(" ")]
        self.assertEqual(heads, ["Holder  size 32  align 8", "Pair(int)  size 16  align 8", "Pair(f64)  size 16  align 8",
                                 "Box(int, 3)  size 32  align 8", "Box(f64, 2)  size 24  align 8", "Pair(Pair(int))  size 32  align 8"])
        c = self.coax("c", program).stdout
        for name in ("coax_t_Pair__3int", "coax_t_Pair__3f64", "coax_t_Box__3int2i3", "coax_t_Pair__11n0_Pair3int",
                     "coax_p_swap__3int(", "coax_p_total__2i3(", "coax_p_first__3f642i2("):
            self.assertIn(name, c)
        self.assertNotIn("coax_t_Pair ", c)
        decls = self.coax("deps", program, "--declarations").stdout
        self.assertIn('"name":"Pair"', decls)
        self.assertNotIn('"name":"Pair(int)"', decls)

    def test_refused_generic_struct_forms(self):
        cases = [
            ("Pair :: struct($T) { a: $T; b: $T; } f :: (p: Pair) {}", ["E0800"]),
            ("Pair :: struct($T) { a: $T; b: $T; } f :: (p: Pair(int, int)) {}", ["E0801"]),
            ("Pair :: struct($T) { a: $T; b: $T; } f :: (p: Pair([] int)) {}", ["E0802"]),
            ("Pair :: struct($T) { a: $T; b: $T; } g :: () { v := [2] int.[1, 2]; p := Pair.{a = v[..], b = v[..]}; }", ["E0802"]),
            ("V :: struct { v: [] int; } Pair :: struct($T) { a: $T; } f :: (p: Pair(V)) {}", ["E0802"]),
            ("P :: struct { x: int; } f :: (p: P(int)) {}", ["E0803"]),
            ("Two :: struct($T, $U) { a: $T; b: $U; } g :: () { t := Two.{a = 1}; }", ["E0804"]),
            ("Box :: struct($T, $N) { items: [$N] $T; } f :: (b: Box(4, int)) {}", ["E0368", "E0368"]),
            ("Pair :: struct($T, $T) { a: $T; }", ["E0223"]),
            ("S :: struct { a: $T; }", ["E0395"]),
            ("Node :: struct($T) { next: Node($T); }", ["E0353"]),
        ]
        for i, (source, want) in enumerate(cases):
            with self.subTest(source=source):
                code, codes = self.codes(self.write(f"s{i}.coax", source + "\nmain :: () {}\n"))
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, want)
        r = self.coax("explain", "E0800")
        self.assertEqual(r.returncode, 0)
        for code in ("E0223", "E0801", "E0802", "E0803", "E0804"):
            self.assertEqual(self.coax("explain", code).returncode, 0, code)


CONSTRAINED = """
max :: (a: $T: ordered, b: $T) -> $T { if a < b { return b; } return a; }
sum :: (v: [] $T: numeric) -> $T { s: $T = 0; for x: v { s += x; } return s; }
same :: (a: $T: equatable, b: $T) -> bool { return a == b; }
Range :: struct($T: ordered) { lo: $T; hi: $T; }
inside :: (r: Range($T: ordered), x: $T) -> bool { return r.lo <= x && x <= r.hi; }
Mode :: enum u8 { a; b; }
calc :: () -> int {
  v := [4] int.[3, 9, 2, 7]; w := [2] f64.[0.5, 2.0]; u := [3] u8.[1, 2, 3];
  r: Range(int) = Range.{lo = 2, hi = 8};
  n := max(4, 11) * 100000 + sum(v[..]) * 1000 + cast(int) (sum(w[..]) * 4.0) * 10 + cast(int) sum(u[..]);
  if same("x", "x") && !same(Mode.a, Mode.b) && inside(r, 5) && !inside(r, 9) && max(2.5, 1.5) == 2.5 { n += 1; }
  return n;
}
"""


class Constraints(unittest.TestCase):
    setUp = TypeParameters.setUp
    write = TypeParameters.write
    coax = TypeParameters.coax
    codes = TypeParameters.codes

    def test_constrained_bodies_agree_with_the_evaluator(self):
        program = self.write("c.coax", '#import "Basic";\n' + CONSTRAINED + 'main :: () { print("%\\n", calc()); }\n')
        compile_time = self.write("c_ct.coax", '#import "Basic";\n' + CONSTRAINED + "K :: #run calc();\n"
                                  'main :: () { print("%\\n", K); }\n#test "constraints" { #assert calc() == 1121107; }\n')
        for path in (program, compile_time):
            for opt in ("0", "2"):
                r = self.coax("run", path, "--opt", opt)
                self.assertEqual((r.returncode, r.stdout), (0, "1121107\n"), r.stderr)
        r = self.coax("test", compile_time)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)

    def test_refused_bodies_and_calls_name_the_constraint(self):
        cases = [
            ("lt :: (a: $T, b: $T) -> bool { return a < b; }", ["E0310"]),
            ("add :: (a: $T: ordered, b: $T) -> $T { return a + b; }", ["E0309"]),
            ("eq :: (a: $T, b: $T) -> bool { return a == b; }", ["E0311"]),
            ("f :: (a: $T: sortable) {}", ["E0805"]),
            ("f :: (v: [$N] int, n: $N: ordered) {}", ["E0805", "E0368"]),
            ("f :: (a: $T: ordered, b: $T: numeric) {}", ["E0808"]),
            ("f :: (a: $T) { x: $T: ordered = a; }", ["E0808"]),
            ("max :: (a: $T: ordered, b: $T) -> $T { return a; } g :: () { m := max(true, false); }", ["E0806"]),
            ("P :: struct { x: int; } same :: (a: $T: equatable) {} g :: () { same(P.{x = 1}); }", ["E0806"]),
            ("R :: struct($T: ordered) { lo: $T; } g :: () { r: R(bool); }", ["E0806"]),
            ("grow :: (x: $T: numeric) -> $T { return x + 300; } g :: () { a: u8 = 1; b := grow(a); }", ["E0350", "E0807"]),
        ]
        for i, (source, want) in enumerate(cases):
            with self.subTest(source=source):
                code, codes = self.codes(self.write(f"k{i}.coax", source + "\nmain :: () {}\n"))
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, want)
        r = self.coax("check", self.write("trace.coax", cases[7][0] + "\nmain :: () {}\n"))
        self.assertIn("bool is not ordered, but 'max' needs '$T: ordered' (declared at line 1)", r.stderr)
        for code in ("E0805", "E0806", "E0807", "E0808"):
            self.assertEqual(self.coax("explain", code).returncode, 0, code)


class LiteralArguments(unittest.TestCase):
    """0.43.0: typed arguments bind $T first, then literals take the bound type."""
    setUp = TypeParameters.setUp
    write = TypeParameters.write
    coax = TypeParameters.coax
    codes = TypeParameters.codes

    def test_literals_take_the_type_a_typed_argument_bound(self):
        source = ('#import "Basic";\n'
                  "clamp :: (v: $T: ordered, lo: $T, hi: $T) -> $T { if v < lo { return lo; } if v > hi { return hi; } return v; }\n"
                  "calc :: () -> int { x: f32 = 1.75; n: u8 = 250; a := clamp(x, 0, 1); b := clamp(0, x, 1.5); c := clamp(n, 1, 200);\n"
                  "  d := clamp(7, 2, 3); e := clamp(0.25, 0, 1); return cast(int) (a * 1000) + cast(int) (b * 100) + cast(int) c * 10 + d + cast(int) (e * 4); }\n")
        program = self.write("l.coax", source + 'main :: () { print("%\\n", calc()); }\n')
        checked = self.write("l_ct.coax", source + "K :: #run calc();\n"
                             'main :: () { print("%\\n", K); }\n#test "literals" { #assert calc() == 3179; }\n')
        for path in (program, checked):
            for opt in ("0", "2"):
                r = self.coax("run", path, "--opt", opt)
                self.assertEqual((r.returncode, r.stdout), (0, "3179\n"), r.stderr)
        self.assertEqual(self.coax("test", checked).returncode, 0)

    def test_literals_that_cannot_take_the_bound_type(self):
        cases = [
            ("clamp :: (v: $T: ordered, lo: $T, hi: $T) -> $T { return v; } g :: () { n: u8 = 1; a := clamp(n, 0, 300); }", ["E0350"]),
            ("pick :: (a: $T, b: $T) -> $T { return a; } g :: () { b := pick(true, 1); }", ["E0348"]),
            ("pick :: (a: $T, b: $T) -> $T { return a; } g :: () { c := pick(2, 1.5); }", ["E0350"]),
        ]
        for i, (source, want) in enumerate(cases):
            with self.subTest(source=source):
                code, codes = self.codes(self.write(f"l{i}.coax", source + "\nmain :: () {}\n"))
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, want)

    def test_the_water_clamp_consumer(self):
        """r4a-generic-consumer: verse/water-spectrum.coax's one wsp_clamp serves int and f32."""
        spectrum = (ROOT.parent / "verse/water-spectrum.coax").resolve()
        head = f'#import "Basic";\n#load "{spectrum}";\n'
        ok = self.write("w.coax", head + "main :: () { x: f32 = 1.5; print(\"% % %\\n\", wsp_clamp(x, 0, 1), wsp_clamp(7, 1, 4), wsp_clamp(-0.25, -0.5, 0.5)); }\n")
        r = self.coax("run", ok)
        self.assertEqual((r.returncode, r.stdout), (0, "1.0 4 -0.25\n"), r.stderr)
        for i, call in enumerate(("wsp_clamp(true, false, true)", "wsp_clamp(\"b\", \"a\", \"c\")")):
            with self.subTest(call=call):
                code, codes = self.codes(self.write(f"w{i}.coax", head + f"main :: () {{ v := {call}; }}\n"))
                self.assertNotEqual(code, 0)
                self.assertEqual(codes, ["E0806"])


if __name__ == "__main__":
    unittest.main()
