# V12 shared-SHA normal plan — prepared only

Prepared against clean committed44b25a4b3e83797ed8d6d3ffd9ca885aab8c1449,
which admits main6225954fae. Bootstrap309, build184, mutation helper111 lines.
No source/FP/precondition is bound and no build/control/compiler ran here.
Root must supply the actual final source revision, new fingerprint and trusted
seed/source precondition before binding. Current0.46 introduction
84da8f01e780e7e9a2a90c75d5a6592bc7db8cf5 is context only.

The prior v11 epoch halted incomplete at61/163 after its parser mutation pass.
Its evidence remains immutable and is never reused or renamed as a v12 pass.
All165 new strict/full/fresh statements must actually complete. The new shared
SHA source changes embedded runtime/compiler identity; this is a new producer.

The plan preserves all old163 statements in order, except the exact original
proto-runtime concatenation now prepends lib/crypto/sha256-kernel.coax. It also
retains the two new original kernel test/mutate gates at source232/233, after
wire and before fingerprint. All309 source lines and original-statement hashes
are accounted for. No source check, step budget, fixture or mutation scope is
removed or lowered.

`runner.py` has one bounded snapshot change: copy the exact regular nonlinked
coax/lib/crypto/sha256-kernel.coax before the existing snapshot inventory and
record that explicit extra file. The normal source/snapshot inventory then
pins BOTH original and copied hashes in every step's frozen input checks.
This matches the actual build184 wrapper and new provenance input list. The
new path is not obtained by copying an arbitrary crypto directory or following
an uncontrolled symlink. All other runner function ASTs are unchanged from the
previously reviewed runner, including actual Git HEAD checking BEFORE binding
mkdir, strict/fresh prefix, raw transport validation, completed-prefix and
failed-receipt refusal, source/tool/receipt guards and840-second step ceiling.
No passing runtime controls were repeated; only static JSON/hash/AST review
and private plan generation occurred.

Required ordering remains:

- Exactly one real survivor initialization, outside repeated child prefix.
- Eight full-source checker shards with original budgets/jobs and an
  authoritative eight-record merge. No root-only/filter/cap reduction.
- Full strict/fresh environment, no changed-line survivor tolerance or gate
  cache reuse. Real empty survivor artifact retained through target/cache.
- All seed comparisons, both compiler fixedpoints and final producer gates.
- Exact current candidate document checks BEFORE target artifacts/install/
  cache; source digest after target install and before keep/cache publication;
  original post-install survivor reporting.

`make-plan.py` and original scripts are retained as review provenance. Running
that private generator only wrote this plan JSON, not a binding or any Coax/
shell gate. Its historical264-plan installation-template input is preserved at
its original location; the already-generated165 statements have no runtime
dependency on rerunning the generator. Infrastructure Python bytes are exact
prior copies and match current Root source.

After separate Root admission, bind once to a fresh external output directory
with actual HEAD/FP/precondition. Inspect the resulting source+snapshot kernel
entries, then execute each step separately under the owner command limit.
Do not wrap the whole165-step sequence in a long shell loop. A failed step
retains its partial epoch and requires explicit reviewed continuation. This
preparation is not build completion, publication or capture authorization.
