#!/usr/bin/env python3
"""Private statement-preserving bounded bootstrap. No work happens on import."""
import argparse,hashlib,json,os,pathlib,shlex,shutil,subprocess,sys,time
BASE=pathlib.Path(__file__).resolve().parent
PLAN=json.loads((BASE/'plan.json').read_text())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
ENV_KEYS=['CC','CXX','PATH','COAX_HOST_TARGET','SDKROOT','MACOSX_DEPLOYMENT_TARGET','IPHONEOS_DEPLOYMENT_TARGET','DEVELOPER_DIR','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','LIBRARY_PATH','COAX_RELEASE_CACHE','COAX_BUILD_FRESH','COAX_GATE_CACHE','COAX_RELEASE_COMPILER','COAX_CC','COAX_MUTATION_CHANGED','COAX_MUTATION_FULL','COAX_MUTATION_BASE','COAX_MUTATE_JOBS']
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def files(path):return {str(p):sha(p) for p in sorted(path.rglob('*')) if p.is_file() and not p.is_symlink()}
def clean_process(r):return r['started'] and r['returncode']==0 and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k) for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'))
def bind(a):
 source=pathlib.Path(a.source).resolve();d=pathlib.Path(a.directory).resolve();assert not d.exists(),'fresh binding directory required'
 revision_argv=['git','-C',str(source),'rev-parse','HEAD'];revision_start=time.monotonic();revision=subprocess.run(revision_argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 assert revision.returncode==0,'cannot observe source Git HEAD'
 observed_revision=revision.stdout.decode('ascii').strip();assert observed_revision==a.source_revision,'source revision argument differs from actual Git HEAD'
 revision_observation={'argv':revision_argv,'returncode':revision.returncode,'observed_revision':observed_revision,'elapsed_s':time.monotonic()-revision_start,'verified_before_binding_directory':True}
 assert sha(source/'coax/bootstrap-build.sh')==PLAN['bootstrap_sha256'],'bootstrap script changed; review/regenerate plan'
 assert sha(source/'coax/build.sh')==PLAN['build_sha256'],'build wrapper changed; review/regenerate plan'
 assert sha(source/'coax/mutation-gate.sh')==PLAN['mutation_gate_sha256'],'mutation gate helper changed; review/regenerate plan'
 seed=pathlib.Path(a.seed_receipt).resolve();assert seed.is_file(),'trusted seed precondition receipt required'
 d.mkdir(parents=True);snapshot=d/'snapshot';(snapshot/'coax').mkdir(parents=True);(snapshot/'scripts').mkdir()
 for p in (source/'coax').iterdir():
  if p.is_file():shutil.copy2(p,snapshot/'coax'/p.name,follow_symlinks=False)
 for name in ['src','bootstrap','lib/compiler','lib/proto','book','generated']:
  p=source/'coax'/name
  if p.is_dir():shutil.copytree(p,snapshot/'coax'/name,symlinks=True)
 # Current build.sh's one extra compiler input outside copied source dirs.
 extra=pathlib.Path('coax/lib/crypto/sha256-kernel.coax');original=source/extra;copied=snapshot/extra
 assert PLAN['snapshot_extra_files']==[str(extra)],'review extra compiler input set'
 assert original.is_file()and not original.is_symlink()and not original.parent.is_symlink(),'missing or linked SHA256 compiler input'
 copied.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,copied,follow_symlinks=False)
 assert copied.is_file()and not copied.is_symlink()and sha(copied)==sha(original),'SHA256 snapshot copy changed'
 shutil.copy2(source/'scripts/coax-release.sh',snapshot/'scripts/coax-release.sh')
 inventory=files(snapshot);inputs={}
 for p,digest in inventory.items():
  relative=pathlib.Path(p).relative_to(snapshot);original=source/relative
  assert original.is_file() and not original.is_symlink() and sha(original)==digest,'changed/linked copied input: '+str(original)
  inputs[str(original)]=digest
 inputs.update(inventory)
 for p in [BASE/'runner.py',BASE/'make-plan.py',BASE/'plan.json',BASE/'bootstrap-build.original.sh',BASE/'build.original.sh',BASE/'mutation-gate.original.sh',*sorted((BASE/'infrastructure').rglob('*.py')),seed]:inputs[str(p)]=sha(p)
 tools={};resolutions={}
 for key,default in [('CC','cc'),('CXX','c++')]:
  resolved=shutil.which(os.environ.get(key,default));assert resolved,key+' missing';tools[str(pathlib.Path(resolved).resolve())]=sha(resolved);resolutions[key]={'logical':os.environ.get(key,default),'resolved':str(pathlib.Path(resolved).resolve())}
 inputs.update(tools)
 config={'schema':'coax.bootstrap.bounded-binding.v1','source':str(source),'snapshot':str(snapshot),'source_revision':a.source_revision,'observed_source_revision':observed_revision,'source_revision_observation':revision_observation,'expected_fingerprint':a.fingerprint,'seed_precondition_receipt':str(seed),'seed_precondition_sha256':sha(seed),'bootstrap_sha256':PLAN['bootstrap_sha256'],'build_sha256':PLAN['build_sha256'],'inputs':inputs,'tool_resolutions':resolutions,'environment':{k:os.environ.get(k) for k in ENV_KEYS},'snapshot_extra_files':PLAN['snapshot_extra_files'],'work':'bin/.bootstrap-bounded-normal','scope':'Fresh private normal bootstrap; historical installed compiler not trusted/resealed. Root supplied committed/rebased source+seed precondition; initial mandatory step verifies both actual fingerprints.'}
 (snapshot/'coax'/config['work']).mkdir(parents=True)
 dump(d/'binding.json',config);dump(d/'state.json',{'binding_sha256':sha(d/'binding.json'),'passed':[],'receipts':{},'artifact_state':files(snapshot/'coax/bin')})
 print(json.dumps({'bound':str(d),'steps':len(PLAN['steps']),'source_revision':a.source_revision,'not_run':True}))
def prefix(c):
 q=shlex.quote
 return '\n'.join(['#!/usr/bin/env bash','set -euo pipefail','export LC_ALL=C','cd '+q(c['snapshot']+'/coax'),'root='+q(c['snapshot']),'target='+q(c['source']),'input_identity='+q(c['expected_fingerprint']),'work='+q(c['work']),*PLAN['shared_flags_lines'],'export COAX_BUILD_FRESH=1 COAX_MUTATION_CHANGED=strict COAX_MUTATION_FULL=1',*PLAN['shared_gate_helper_lines'],'if [[ -f "$work/stage0.identity" ]]; then IFS= read -r stage0_id < "$work/stage0.identity"; else stage0_id=""; fi','[[ "$COAX_BUILD_FRESH" == 1 && -z "$gate_cache" && "$COAX_MUTATION_FULL" == 1 && "$COAX_MUTATION_CHANGED" == strict && "$mutation_changed" == strict ]]'])+'\n'
def run(a):
 d=pathlib.Path(a.directory).resolve();c=json.loads((d/'binding.json').read_text());state=json.loads((d/'state.json').read_text());steps=PLAN['steps']
 assert state['binding_sha256']==sha(d/'binding.json'),'binding changed'
 assert state['passed']==[s['id'] for s in steps[:len(state['passed'])]],'completed statements are not an exact required prefix'
 for prior in steps[:len(state['passed'])]:
  path=d/(prior['id']+'.json');assert sha(path)==state['receipts'][prior['id']],'prior receipt changed'
  receipt=json.loads(path.read_text())
  assert receipt['step']==prior and receipt['outcome']=='passed' and receipt['frozen_inputs_unchanged'] and clean_process(receipt['observation']),'prior step not qualified'
  assert receipt['binding_sha256']==state['binding_sha256'] and receipt['expected_fingerprint']==c['expected_fingerprint'],'prior scope changed'
  assert sha(d/(prior['id']+'.sh'))==receipt['script_sha256'],'prior command changed'
  if receipt.get('raw_gate_log'):
   gate=receipt['raw_gate_log'];assert pathlib.Path(gate['path']).stat().st_size==gate['bytes'] and sha(gate['path'])==gate['sha256'],'prior raw gate log changed'
  for stream in ['stdout','stderr']:
   fact=receipt['observation'][stream];assert pathlib.Path(fact['path']).stat().st_size==fact['bytes'] and sha(fact['path'])==fact['sha256'],'prior raw observation changed'
 chosen=next((s for s in steps if s['id'] not in state['passed']),None) if a.step=='next' else next(s for s in steps if s['id']==a.step)
 assert chosen is not None,'all mandatory statements already passed'
 assert chosen['id'] not in state['passed'],'passing step may not repeat'
 assert all(dep in state['passed'] for dep in chosen['depends']),'mandatory dependency incomplete'
 assert {k:os.environ.get(k) for k in ENV_KEYS}==c['environment'],'toolchain/build environment changed'
 for key,fact in c['tool_resolutions'].items():assert str(pathlib.Path(shutil.which(fact['logical']) or '/missing').resolve())==fact['resolved'],'tool resolution changed: '+key
 for p,digest in c['inputs'].items():assert pathlib.Path(p).is_file() and not pathlib.Path(p).is_symlink() and sha(p)==digest,'frozen input changed: '+p
 snapshot=pathlib.Path(c['snapshot']);assert files(snapshot/'coax/bin')==state['artifact_state'],'retained build artifacts changed'
 receipt=d/(chosen['id']+'.json');assert not receipt.exists(),'existing failed/partial receipt requires explicit reviewed continuation, never overwrite'
 lock=d/'active.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.write(fd,str(os.getpid()).encode());os.close(fd)
 script=d/(chosen['id']+'.sh');script.write_text(prefix(c)+chosen['statement']+'\n')
 sys.path.insert(0,str(BASE/'infrastructure/coax/tools'));import bounded_process
 try:
  observation=bounded_process.run(['bash',str(script)],c['snapshot']+'/coax',None,840,8388608,time.monotonic()+840,quiet_faults=True)
  for stream in ['stdout','stderr']:
   raw=observation.pop(stream);p=d/(chosen['id']+'.'+stream+'.log');p.write_bytes(raw);observation[stream]={'path':str(p),'bytes':len(raw),'sha256':sha(p)}
  gate_log=None
  if chosen['statement'].startswith('gate '):
   raw_gate=snapshot/'coax'/c['work']/'gate.log'
   if raw_gate.is_file():
    retained_gate=d/(chosen['id']+'.gate.log');shutil.copyfile(raw_gate,retained_gate);gate_log={'path':str(retained_gate),'bytes':retained_gate.stat().st_size,'sha256':sha(retained_gate)}
  after={p:sha(p) if pathlib.Path(p).is_file() and not pathlib.Path(p).is_symlink() else None for p in c['inputs']};same=after==c['inputs']
  artifacts=files(snapshot/'coax/bin');passed=clean_process(observation) and same
  r={'schema':'coax.bootstrap.bounded-statement.v1','step':chosen,'binding_sha256':state['binding_sha256'],'source_revision':c['source_revision'],'expected_fingerprint':c['expected_fingerprint'],'bootstrap_sha256':PLAN['bootstrap_sha256'],'script_sha256':sha(script),'observation':observation,'fresh_gate_execution':True,'gate_cache_reuse':False,'strict_mutation_execution':True,'changed_line_survivor_tolerance':False,'forced_execution_environment':PLAN['required_execution_environment'],'raw_gate_log':gate_log,'frozen_inputs_unchanged':same,'inputs_after':after,'artifacts_after':artifacts,'outcome':'passed' if passed else 'failed','scope':'One original mandatory statement or documented deterministic checker-shard/merge/admin adaptation. This receipt is not a monolithic build pass.'}
  dump(receipt,r)
  if passed:
   state['passed'].append(chosen['id']);state['receipts'][chosen['id']]=sha(receipt);state['artifact_state']=artifacts;dump(d/'state.json',state)
  complete=len(state['passed'])==len(steps)
  dump(d/'qualification.json',{'schema':'coax.bootstrap.bounded-composition.v1','outcome':'passed' if complete else 'incomplete','scope':f'Composed complete normal bootstrap only if every {len(steps)} planned statement passes. Eight checker shards+merge replace one full-scope mutation, with no root-only/only/step-limit relaxation. COAX_BUILD_FRESH=1 disables gate cache reuse; COAX_MUTATION_CHANGED=strict and COAX_MUTATION_FULL=1 refuse every survivor. Current wrapper document validation precedes all target artifact/install/cache effects. Work cleanup deferred for archive. Not a relabeled monolithic command.','binding':str(d/'binding.json'),'binding_sha256':sha(d/'binding.json'),'plan':str(BASE/'plan.json'),'plan_sha256':sha(BASE/'plan.json'),'passed_steps':state['passed'],'required_steps':[s['id'] for s in steps],'receipts':{s['id']:{'path':str(d/(s['id']+'.json')),'sha256':sha(d/(s['id']+'.json'))} for s in steps if s['id'] in state['passed']}})
  print(json.dumps({'step':chosen['id'],'outcome':r['outcome'],'elapsed_s':observation['elapsed_s'],'returncode':observation['returncode'],'receipt':str(receipt),'remaining_steps':len(steps)-len(state['passed'])}))
  if not passed:sys.exit(1)
 finally:lock.unlink()
def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='action',required=True)
 b=sub.add_parser('bind');b.add_argument('--source',required=True);b.add_argument('--directory',required=True);b.add_argument('--fingerprint',required=True);b.add_argument('--source-revision',required=True);b.add_argument('--seed-receipt',required=True)
 r=sub.add_parser('step');r.add_argument('directory');r.add_argument('step',nargs='?',default='next')
 sub.add_parser('list');a=p.parse_args()
 if a.action=='bind':bind(a)
 elif a.action=='step':run(a)
 else:
  for s in PLAN['steps']:print(s['id'],s['phase'],s.get('source_lines','administrative'))
if __name__=='__main__':main()
