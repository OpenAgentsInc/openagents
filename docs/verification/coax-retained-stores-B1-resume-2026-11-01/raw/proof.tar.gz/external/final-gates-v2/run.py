#!/usr/bin/env python3
"""One bounded whole B1 final-producer gate; preparation is not execution."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import time

sys.dont_write_bytecode = True
FLAGS = ('timeout', 'deadline_exhausted', 'stdout_limit', 'stderr_limit',
         'output_limit', 'group_killed', 'kill_errno', 'launch_errno',
         'launch_error', 'read_errno')
ENV = ('PATH', 'CC', 'SDKROOT', 'DEVELOPER_DIR', 'MACOSX_DEPLOYMENT_TARGET',
       'COAX_HOST_TARGET', 'COAX_BIN', 'COAX_TEST_COMPILER')
SUPPORT = ('coax', 'provenance-check', 'provenance.record', 'check-domains.c',
           'check-domains.h', 'lexer.c', 'lexer.h', 'parser.c', 'parser.h',
           'checker.c', 'checker.h', 'sources.c', 'sources.h',
           'proto_runtime.inc', 'proto_importer.c', 'proto_importer.h',
           'mutation-survivors')
HELPER_SHA = 'e6aefccd3d5815e75dd74c17c7538dc54b79ece9554751842db12646fce9b0c9'
GATES = ('b1-source', 'a1-source', 'b1-native', 'legacy-checker',
         'systemone', 'memo1000', 'diagnostics-json')


def regular(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    return path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pinned_json(path, expected):
    path = regular(path)
    assert sha(path) == expected, 'pinned record differs: '+str(path)
    return json.loads(path.read_bytes())


def clean(row):
    return (row['started'] and row['returncode'] == 0 and row['stdout_eof']
            and row['stderr_eof'] and not any(row.get(k) for k in FLAGS))


def selected_alias(program, cwd, env):
    if os.path.dirname(program):
        alias = Path(program)
        if not alias.is_absolute():
            alias = cwd/alias
    else:
        search = [str(Path(p) if Path(p).is_absolute() else cwd/p)
                  for p in os.get_exec_path(env)]
        alias = shutil.which(program, path=os.pathsep.join(search))
        assert alias, 'program not found: '+program
    alias = Path(os.path.abspath(alias))
    assert alias.is_file() and os.access(alias, os.X_OK), str(alias)
    return alias


def unittest_count(path):
    tree = ast.parse(Path(path).read_bytes(), filename=str(path))
    return sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
               and n.name.startswith('test_') for c in tree.body
               if isinstance(c, ast.ClassDef) for n in c.body)


def unittest_passed(stderr, count):
    return (re.search(rb'(?m)^Ran '+str(count).encode()+rb' tests? in [^\n]+$', stderr)
            and re.search(rb'(?m)^OK\s*$', stderr)
            and not re.search(rb'(?mi)skipped|FAILED|ERROR:|FAIL:', stderr))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'compiler', 'compiler-sha256', 'fingerprint',
                 'source-revision', 'normal-receipt', 'normal-sha256',
                 'binding-helper', 'input-pins', 'input-pins-sha256', 'output'):
        p.add_argument('--'+name, required=True)
    p.add_argument('--gate', choices=GATES, required=True)
    a = p.parse_args()
    started = time.monotonic()
    budget = 870 if a.gate == 'b1-native' else 840
    deadline = started+budget
    root = Path(a.repo).resolve()
    compiler = Path(a.compiler).resolve()
    output = Path(a.output).resolve()
    assert compiler == root/'coax/bin/coax'
    assert not output.exists() and not output.is_relative_to(root)
    output.mkdir(parents=True)
    record = {'schema': 'coax.retained-borrows.final-whole-gate.v1',
              'outcome': 'not-checked', 'gate': a.gate,
              'scope': 'One actual whole gate on the matching final installed normal-qualified producer. No earlier producer observation is relabelled. No B2/request-lifetime claim.',
              'compiler': str(compiler), 'compiler_sha256': a.compiler_sha256,
              'fingerprint': a.fingerprint, 'source_revision': a.source_revision,
              'normal_receipt': a.normal_receipt, 'normal_sha256': a.normal_sha256,
              'budget_s': budget, 'commands': [], 'inner_receipts': []}
    tracked = {}
    process = None

    def track(path, expected):
        path = str(Path(path).resolve())
        assert path not in tracked or tracked[path] == expected, 'identity conflict: '+path
        assert sha(regular(path)) == expected, 'input drift: '+path
        tracked[path] = expected

    def facts(path):
        path = regular(path)
        return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}

    def save():
        record['elapsed_s'] = time.monotonic()-started
        (output/'qualification.json').write_text(json.dumps(record, indent=2)+'\n')

    def stable():
        assert {k: os.environ.get(k) for k in ENV} == record['environment_before']
        assert selected_alias(cc[0], root, os.environ) == cc_alias
        assert cc_alias.resolve() == cc_physical
        for name, value in tracked.items():
            assert sha(regular(name)) == value, 'source/artifact/tool drift: '+name

    def execute(label, argv, env, timeout):
        stable()
        remaining = deadline-time.monotonic()
        assert remaining > 0, 'whole-gate deadline exhausted'
        observed = process.run(list(map(str, argv)), cwd=str(root), env=env,
                               timeout_s=min(timeout, remaining), deadline=deadline,
                               max_output_bytes=67108864, quiet_faults=True)
        streams = {}
        for stream in ('stdout', 'stderr'):
            path = output/(label+'.'+stream)
            path.write_bytes(observed[stream])
            streams[stream] = facts(path)
        raw = {k: v for k, v in observed.items() if k not in ('stdout', 'stderr')}
        record['commands'].append({'label': label, 'argv': list(map(str, argv)),
                                   'observation': raw, 'raw': streams,
                                   'passed': bool(clean(observed))})
        save()
        assert clean(observed), 'bounded transport failure: '+label
        stable()
        return observed

    def inner(path, schema):
        row = json.loads(regular(path).read_bytes())
        record['inner_receipts'].append(facts(path))
        assert row['schema'] == schema and row['outcome'] == 'passed'
        assert row['compiler_sha256'] == a.compiler_sha256
        assert Path(row['compiler']).resolve() == compiler
        assert row['inputs_unchanged']
        return row

    try:
        assert not sys.flags.optimize, 'assertions must remain enabled'
        helper = regular(a.binding_helper).resolve()
        track(helper, HELPER_SHA)
        track(a.normal_receipt, a.normal_sha256)
        pins = pinned_json(a.input_pins, a.input_pins_sha256)
        assert pins['schema'] == 'coax.retained-borrows.final-gate-input-pins.v1'
        assert pins['status'] == 'FINAL_FROZEN_INPUTS_REVIEWED'
        assert pins['source_revision'] == a.source_revision
        track(a.input_pins, a.input_pins_sha256)
        for path, value in pins['files'].items():
            track(path, value)
        normal = pinned_json(a.normal_receipt, a.normal_sha256)
        package = {name: sha(regular(compiler.parent/name)) for name in SUPPORT}
        assert package['coax'] == a.compiler_sha256
        assert package['mutation-survivors'] == hashlib.sha256(b'').hexdigest()
        lines = (compiler.parent/'provenance.record').read_text().splitlines()
        assert len(lines) == 4 and lines[1:3] == [a.fingerprint, a.compiler_sha256]
        spec = importlib.util.spec_from_file_location('b1_normal_proof', helper)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        proof = module.qualification_binding({'fingerprint': a.fingerprint,
            'qualified_files': package, 'qualification': {'kind': 'normal',
            'path': a.normal_receipt, 'sha256': a.normal_sha256}})
        assert proof['source_revision'] == a.source_revision
        binding = pinned_json(normal['binding'], normal['binding_sha256'])
        assert Path(binding['source']).resolve() == root
        for path, value in binding['inputs'].items():
            track(path, value)
        for fact in [dict(path=normal['binding'], sha256=normal['binding_sha256']),
                     dict(path=normal['plan'], sha256=normal['plan_sha256']),
                     *normal['receipts'].values()]:
            track(fact['path'], fact['sha256'])
        for name, value in package.items():
            track(compiler.parent/name, value)
        track(__file__, sha(__file__))
        record.update(normal_proof=proof, package=package,
                      input_pins=facts(a.input_pins))
        record['environment_before'] = {k: os.environ.get(k) for k in ENV}
        launch = dict(os.environ)
        cc = shlex.split(launch.get('CC', 'cc'))
        assert cc, 'empty CC argv'
        cc_alias = selected_alias(cc[0], root, launch)
        cc_physical = cc_alias.resolve(strict=True)
        track(cc_physical, sha(cc_physical))
        track(Path(sys.executable).resolve(), sha(Path(sys.executable).resolve()))
        git_alias = selected_alias('git', root, launch)
        track(git_alias.resolve(), sha(git_alias.resolve()))
        for base in ('coax/lib', 'psionic/lib'):
            for path in sorted((root/base).rglob('*.coax')):
                track(path, sha(path))
        sdk = launch.get('SDKROOT')
        if sdk:
            for name in ('SDKSettings.json', 'SDKSettings.plist'):
                path = Path(sdk)/name
                if path.is_file():
                    track(path, sha(path))
        record['toolchain'] = {'cc': cc, 'cwd': str(root), 'alias': str(cc_alias),
                               'physical': str(cc_physical), 'sha256': sha(cc_physical),
                               'python': str(Path(sys.executable).resolve()),
                               'git_alias': str(git_alias), 'git_physical': str(git_alias.resolve())}
        record['inputs_before'] = dict(tracked)
        sys.path.insert(0, str(root/'coax/tools'))
        import bounded_process
        process = bounded_process
        revision = execute('head-before', ['git', 'rev-parse', 'HEAD'], launch, 10)
        assert revision['stdout'].decode().strip() == a.source_revision
        test = root/'coax/tests'
        env = {**launch, 'COAX_TEST_COMPILER': str(compiler), 'COAX_BIN': str(compiler),
               'PYTHONDONTWRITEBYTECODE': '1'}
        child = output/'inner'
        if a.gate in ('b1-source', 'a1-source'):
            b1 = a.gate == 'b1-source'
            script = test/('retained_borrows.py' if b1 else 'borrow_summaries.py')
            manifest = json.loads((test/('retained-borrows' if b1 else 'borrow-summaries')/'fixtures.json').read_bytes())
            argv = [sys.executable, script, '--compiler', compiler, '--record-dir', child]
            if b1:
                argv += ['--expected-compiler-sha256', a.compiler_sha256]
            execute('whole-source', argv, env, 820)
            result = inner(child/'qualification.json', 'coax.retained-borrows.source-qualification.v1' if b1 else 'coax.borrow-summaries.source-qualification.v1')
            ids = [r['id'] for r in manifest['cases']]
            assert result['selection'] == ids
            assert len(result['cases']) == len(ids) and all(r['outcome'] == 'passed' for r in result['cases'])
            record['cases'] = len(ids)
        elif a.gate == 'b1-native':
            execute('whole-native', [sys.executable, test/'retained_borrows_native.py',
                '--compiler', compiler, '--expected-compiler-sha256', a.compiler_sha256,
                '--record-dir', child], env, 850)
            result = inner(child/'qualification.json', 'coax.retained-borrows.native-qualification.v1')
            assert result['artifacts_unchanged'] and set(result['profiles']) == {'O0', 'O2', 'sanitized'}
            for row in result['profiles'].values():
                assert row['outcome'] == 'passed' and row['fresh_generated_header_guards_compiled']
                assert sha(regular(row['binary'])) == row['binary_sha256']
                observed = row['observed']
                assert observed['cases'] == 21 and observed['source_cases'] == 19
                assert observed['disabled_controls'] == observed['short_controls'] == 1
                assert len(observed['observations']) == 21
            assert len(result['commands']) == 9
            assert all(r['passed'] and clean(r['observation']) for r in result['commands'])
            record.update(cases_per_profile=21, profiles=3)
        elif a.gate == 'memo1000':
            execute('whole-memo1000', [sys.executable, test/'borrow_query_work.py',
                '--compiler', compiler, '--record-dir', child], env, 100)
            result = inner(child/'qualification.json', 'coax.borrow-query-work.source.v1')
            assert clean(result['observation'])
            assert result['observation']['stdout']['bytes'] == result['observation']['stderr']['bytes'] == 0
            record['independent_procedures'] = 1000
        else:
            script = test/({'legacy-checker': 'checker.py', 'systemone': 'borrow_summary_systemone.py',
                           'diagnostics-json': 'diagnostics_json.py'}[a.gate])
            count = unittest_count(script)
            assert count == {'legacy-checker': 10, 'systemone': 3, 'diagnostics-json': 8}[a.gate]
            if a.gate == 'systemone':
                env['COAX_BORROW_SYSTEMONE_RECORD_DIR'] = str(child)
            observed = execute('whole-unittest', [sys.executable, script, '-v'], env, 820)
            assert unittest_passed(observed['stderr'], count), 'unittest count/result differs'
            record['tests_run'] = count
            if a.gate == 'systemone':
                result = inner(child/'qualification.json', 'coax.borrow-return.systemone.native.v1')
                assert result['artifacts_unchanged'] and result['consumed_inputs_match_manifest']
                assert set(result['profiles']) == {'O0', 'O2', 'sanitized'}
                for row in result['profiles'].values():
                    assert row['outcome'] == 'passed'
                    assert row['observed']['digits_cases'] == 129 and row['observed']['stderr_cases'] == 45
                record.update(profiles=3, digits_per_profile=129, stderr_per_profile=45)
            else:
                record['internal_temporary_artifact_scope'] = 'Original unittest driver deletes some private variants; retained top-level raw unittest evidence does not invent per-variant artifacts.'
        revision = execute('head-after', ['git', 'rev-parse', 'HEAD'], launch, 10)
        assert revision['stdout'].decode().strip() == a.source_revision
        stable()
        record['inputs_after'] = {name: sha(regular(name)) for name in tracked}
        record['inputs_unchanged'] = record['inputs_after'] == record['inputs_before']
        assert record['inputs_unchanged']
        record['outcome'] = 'passed'
    except BaseException as error:
        record['outcome'] = 'failed'
        record['error'] = type(error).__name__+': '+str(error)
        raise
    finally:
        save()
    print(json.dumps({'gate': a.gate, 'outcome': record['outcome'], 'receipt': str(output/'qualification.json')}))


if __name__ == '__main__':
    main()
