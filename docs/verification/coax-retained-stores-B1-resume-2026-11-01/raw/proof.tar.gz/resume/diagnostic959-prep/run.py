#!/usr/bin/env python3
"""One full-scope shard diagnostic, NOT normal/producer qualification."""
import datetime,hashlib,json,os,pathlib,sys,time
B=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
P=pathlib.Path('/tmp/coax-retained-borrows-B1-resume/normal165-final/snapshot/coax/bin/.bootstrap-bounded-normal/stage0')
H=pathlib.Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools/bounded_process.py')
Q=H.parents[1]/'tests/quiet_crash.py'
OUT=pathlib.Path('/tmp/coax-retained-borrows-B1-resume/diagnostic959-shard1')
SHA=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
MODEL='a213b0ea462b4248abcb666871840d3f6db6ffaf36859b58823d53e3036e735a'
PRODUCER='448e978d9448137a31dc38e22491b8f0e34f9cdc5d7466f21296950d2698c4a5'
BAD=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno')
def inventory():
    paths=[p for p in (B/'coax/lib').rglob('*') if p.is_file() and not p.is_symlink()]
    paths += [P,H,Q,pathlib.Path(__file__),pathlib.Path(sys.executable).resolve()]
    return {str(p):SHA(p) for p in sorted(set(paths))}
def main():
    started=time.monotonic();wall=datetime.datetime.now(datetime.timezone.utc)
    hard=datetime.datetime(2026,11,1,8,34,tzinfo=datetime.timezone.utc)
    remaining=(hard-wall).total_seconds()-2
    assert remaining>=150,'insufficient time before08:34; do not launch'
    assert SHA(B/'coax/lib/compiler/checker.coax')==MODEL and SHA(P)==PRODUCER
    assert not OUT.exists(),'fresh diagnostic output required'
    OUT.mkdir();before=inventory()
    env=os.environ.copy();env.update(COAX_BUILD_FRESH='1',COAX_MUTATION_CHANGED='strict',COAX_MUTATION_FULL='1',LC_ALL='C')
    envpins={k:env.get(k) for k in ['PATH','COAX_MUTATE_JOBS','COAX_BUILD_FRESH','COAX_MUTATION_CHANGED','COAX_MUTATION_FULL','COAX_GATE_CACHE','COAX_HOST_TARGET','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR']}
    budget=min(180,remaining);deadline=started+budget
    argv=[str(P),'mutate','lib/compiler/checker.coax','--shard','1/8']
    plan={'schema':'coax.b1.full-shard-diagnostic-plan.v1','scope':'One NEW full original-source shard1/8 on frozen959 source using unqualified original947-source stage0; NOT normal qualification. New inventory must be read from actual raw record. No imported/root-only/only or budget flags.','argv':argv,'cwd':str(B/'coax'),'model_sha256':MODEL,'producer_sha256':PRODUCER,'producer_qualified':False,'inputs_before':before,'environment':envpins,'timeout_s':budget,'absolute_wall_stop':hard.isoformat()}
    (OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    sys.path.insert(0,str(H.parent));import bounded_process
    r=bounded_process.run(argv,str(B/'coax'),env,max(0,deadline-time.monotonic()),8388608,deadline,quiet_faults=True)
    for stream,name in [('stdout','checker.1.rec'),('stderr','stderr.log')]:
        raw=r.pop(stream);path=OUT/name;path.write_bytes(raw);r[stream]={'path':str(path),'bytes':len(raw),'sha256':SHA(path)}
    after=inventory();clean=r['started'] and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k) for k in BAD)
    record={'schema':'coax.b1.full-shard-diagnostic.v1','scope':plan['scope'],'qualified':False,'plan_sha256':SHA(OUT/'plan.json'),'observation':r,'inputs_after':after,'inputs_unchanged':after==before,'transport_clean':clean,'diagnostic_process_completed':clean and r['returncode'] in [0,1],'normal_continued':False,'original_failed_epoch_untouched':True}
    (OUT/'process.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'record':str(OUT/'process.json'),'sha256':SHA(OUT/'process.json'),'returncode':r['returncode'],'elapsed_s':r['elapsed_s'],'transport_clean':clean,'inputs_unchanged':after==before,'qualified':False}))
    return 0 if clean and after==before and r['returncode'] in [0,1] else 1
if __name__=='__main__':raise SystemExit(main())
