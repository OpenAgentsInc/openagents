B1 frozen-field lookup memo (proposed before implementation)

The actual tick observer attributes636,282 of916,718 root-seeding ticks to CB_at. No budget/capacity grows. Only B1's frozen type layout field lookups change; A1's default context continues the original CB_at path.

Carriers:
- Append CK_Type.retain_fields:int after retain_presence:u8: head of a private TYPE namespace.
- Append CB_Context.retain_fields:bool after retain_classes; private context, defaultfalse.
- Reuse CK_BorrowQuery and existing query pool; no new array/allocation. kind4 belongs ONLY to a Type head. Node.borrow_query chains remain kind1..3.
- kind4 row fields: decl=typeID, path=exact one FIELD ordinal, type=resolved field type, start=field nodeID, count=the immutable struct declaration's field-list head, status2, next=prior Type head, retain_classes=false. Keys/shape/status/list monotonicity are checked. This is private checked-input memoization, not proof against arbitrary coordinated corruption of the entire checked graph/workspace.

Function CB_field(b,type,index)->int:
1 Default flagfalse delegates exactly CB_at(b,CB_fields(b,type),index), preserving A1 behavior.
2 Enabled: validate type range/struct kind, nonnegative ordinal, valid struct declaration and nonempty FIELD head. Search the Type head with unchanged CB_tick. Each row must lie in committed query prefix, be kind4/complete/exactType+head, have canonical one-FIELD path, bounded field node of FIELD kind and matching valid resolved type, false classes flag, and monotone next. A matching ordinal returns that field node.
3 On miss use ORIGINAL CB_at once, validate successful FIELD result/type; refuse exhausted query capacity without publication. Append one complete kind4 row and publish Type head only after success. Invalid/work/capacity outcomes remain E0381. No origins are consumed.

Use CB_field only in CB_type and CB_default where a resolved struct/ordinal is already present. CR_run resets retain_fields heads alongside existing presence reset over the exact committed type prefix, then enables the private context flag for both raw addresses and class-source queries. Sources/addresses keep their separate existing value namespaces and identical results. The pass's type graph is immutable throughout this invocation. Do not change CB_at, old raw A1 lookup, global1M work or16K query cap.

Check-first controls (before helper implementation):
- Literal64-FIELD type: first ordinal63 lookup matches original raw result; repeat succeeds with only2 ticks left, while flagfalse preserves raw-walk exhaustion. Two different field indices/types and two distinct root types stay distinct.
- Type0/type_count/nonstruct and negative/past-end ordinal refusals; invalid declaration/head/FIELD-kind/link. Invalid first computation publishes no Type head/query row.
- Warm cache payload corruption one field at a time: key kind/type, status, path kind/count/inactive slot, root list head, result index/kind/type, monotone/bounded link and namespace flag. Require E0381, no misleading value.
- Query pool exact last slot succeeds; exhausted slot refuses without publication; work at limit refuses cache traversal; reset across changed layouts invalidates old Type heads; committed prefix zeroed and unused tail preserved. Optional reports stay independent.
- Existing928 checks and actual compiler self-input remain final regressions; imported authority controls remain intact. No B2 value-flow/strong updates or new lifetime-safety claim.
