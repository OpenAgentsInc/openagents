#include <stddef.h>
#include "/private/tmp/coax-retained-borrows-B1-resume/new-emitter-source-storage-final/proto_importer.h"
#define ABI(T,S) _Static_assert(sizeof(T)==S && _Alignof(T)==8,"LP64 " #T)
#define OFF(T,F,N) _Static_assert(offsetof(T,F)==N,"LP64 " #T "." #F)
_Static_assert(sizeof(void*)==8 && sizeof(int64_t)==8,"LP64 observer");
ABI(coax_t_BS_Origin,168);
ABI(coax_t_CK_RetainEffect,368);
OFF(coax_t_CK_RetainEffect,source,0);
OFF(coax_t_CK_RetainEffect,destination,168);
OFF(coax_t_CK_RetainEffect,value_type,336);
OFF(coax_t_CK_RetainEffect,witness,344);
OFF(coax_t_CK_RetainEffect,next,352);
OFF(coax_t_CK_RetainEffect,source_storage,360);
ABI(coax_t_CK_RetainObservation,40);
OFF(coax_t_CK_RetainObservation,kind,0);
OFF(coax_t_CK_RetainObservation,owner,8);
OFF(coax_t_CK_RetainObservation,site,16);
OFF(coax_t_CK_RetainObservation,facts_complete,24);
OFF(coax_t_CK_RetainObservation,relation_complete,25);
OFF(coax_t_CK_RetainObservation,forbidden,26);
OFF(coax_t_CK_RetainObservation,pending,32);
ABI(coax_t_CK_RetainCaps,24);
OFF(coax_t_CK_RetainCaps,effects,0);
OFF(coax_t_CK_RetainCaps,reports,8);
OFF(coax_t_CK_RetainCaps,work,16);

