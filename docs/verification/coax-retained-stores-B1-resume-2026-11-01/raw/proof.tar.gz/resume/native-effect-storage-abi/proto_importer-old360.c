#include "/private/tmp/coax-retained-borrows-B1-resume/new-emitter-source-storage-final/proto_importer.h"
_Static_assert(sizeof(coax_t_CK_RetainEffect)==360,"original observer Effect360 guard");
