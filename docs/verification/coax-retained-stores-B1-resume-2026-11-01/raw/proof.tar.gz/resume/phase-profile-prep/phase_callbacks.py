import json,lldb

def scalar(value,name):
 v=value.GetChildMemberWithName(name)
 return v.GetValueAsSigned() if v.IsValid() and not v.GetError().Fail() else None

def state_of(value):
 v=value.GetChildMemberWithName('state').GetChildMemberWithName('data').Dereference()
 return {key:scalar(v,key) for key in ('queries','origins','work','depth')}

def capture(frame,bp_loc,internal_dict):
 name=frame.GetFunctionName();context=frame.FindVariable('l_b') if name.endswith('CR_run') else frame.FindVariable('l_r').GetChildMemberWithName('b')
 row={'event':'phase-entry','function':name,'counters':state_of(context)}
 if name.endswith('CR_walk'):
  row['seed']=frame.FindVariable('l_seed').GetValue();row['instances']=frame.FindVariable('l_instances').GetValue()
 print('COAX_PHASE '+json.dumps(row,sort_keys=True),flush=True)
 return False

def finish(debugger):
 p=debugger.GetSelectedTarget().GetProcess();row={'event':'finish','state':p.GetState(),'exit_status':p.GetExitStatus()}
 if p.GetState()==lldb.eStateStopped:
  thread=p.GetSelectedThread();row['frames']=[str(frame) for frame in thread]
  frame=thread.GetFrameAtIndex(1);b=frame.FindVariable('l_b');row['counters']=state_of(b) if b.IsValid() else None
 print('COAX_PHASE '+json.dumps(row,sort_keys=True),flush=True)
