from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
root=Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents');image=Path(sys.argv[1]).resolve();expected=sys.argv[2];out=Path(sys.argv[3]);out.mkdir();here=Path(__file__).resolve().parent;source=root/'coax/lib/compiler/checker.coax';paths=[image,source,here/'phase_callbacks.py',Path(__file__).resolve(),root/'coax/tools/bounded_process.py',*sorted((root/'coax/lib/compiler').rglob('*.coax'))]
def hashes():return{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
before=hashes();assert before[str(image)]==expected;assert before[str(source)]=='dbb1535b99f56c02bf734375aa952cb9fef3e1b5965bde724fea376998e1b6a0'
spec=importlib.util.spec_from_file_location('phase_bp',root/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
commands=['command script import '+str(here/'phase_callbacks.py'),'breakpoint set -n coax_p_CR_run','breakpoint command add -F phase_callbacks.capture 1','breakpoint set -n coax_p_CR_walk','breakpoint command add -F phase_callbacks.capture 2','breakpoint set -n coax_p_CK_resource','run','script phase_callbacks.finish(lldb.debugger)','quit'];argv=['lldb','--batch']
for command in commands:argv+=['-o',command]
argv+=['--',str(image),'c',str(source),'--library']
r=bp.run(argv,root,os.environ.copy(),60,16777216,time.monotonic()+65)
for k in('stdout','stderr'):(out/(k+'.log')).write_bytes(r.pop(k))
r.update(inputs_before=before,inputs_after=hashes());r['inputs_unchanged']=r['inputs_before']==r['inputs_after'];r['scope']='Root-authorized read-only debugger phase counters on actual merged producer; no C artifact/qualification, no source/budget edits.';(out/'process.json').write_text(json.dumps(r,indent=2)+'\n');rows=[]
for line in(out/'stdout.log').read_text().splitlines():
 if line.startswith('COAX_PHASE '):rows.append(json.loads(line[len('COAX_PHASE '):]))
(out/'phases.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'rows':rows,'transport':{k:r[k]for k in('returncode','elapsed_s','timeout','deadline_exhausted','output_limit','read_errno','stdout_eof','stderr_eof','inputs_unchanged')}},indent=2))
