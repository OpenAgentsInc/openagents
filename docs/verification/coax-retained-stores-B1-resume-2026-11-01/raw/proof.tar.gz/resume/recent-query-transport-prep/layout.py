#!/usr/bin/env python3
"""Compile-only written ctypes versus fresh-header layout guard; no model calls."""
import argparse
import ast
import concurrent.futures
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import time
import types

B = Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
D = Path(__file__).resolve().parent
E = None
sys.path[:0] = [str(B/'coax/tools'), str(B/'coax/tests')]
import bounded_process
import quiet_crash


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def definitions(path, names=None):
    tree = ast.parse(path.read_text())
    return [n for n in tree.body if
            (isinstance(n, ast.ClassDef) and any(
                isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name)
                and base.value.id == 'C' and base.attr == 'Structure'
                for base in n.bases) and (names is None or n.name in names))
            or (isinstance(n, ast.FunctionDef) and names is not None and n.name in names)]


def load_definitions(path, namespace, names=None):
    # Only carrier declarations/view factory/record list; never import test modules.
    tree = ast.Module(body=definitions(path, names), type_ignores=[])
    exec(compile(tree, str(path), 'exec'), namespace)


def alias_of(program, cwd, environment):
    if os.path.dirname(program):
        alias = Path(program)
        if not alias.is_absolute():
            alias = cwd/alias
    else:
        search = os.pathsep.join(str(Path(p) if Path(p).is_absolute() else cwd/p)
                                 for p in os.get_exec_path(environment))
        found = shutil.which(program, path=search)
        if found is None:
            raise RuntimeError('native C compiler not found')
        alias = Path(found)
    alias = Path(os.path.abspath(alias))
    if not alias.is_file() or not os.access(alias, os.X_OK):
        raise RuntimeError('C compiler alias not executable')
    return alias


def clean(o):
    return (o['started'] and o['returncode'] == 0 and o['stdout_eof'] and o['stderr_eof']
            and all(not o[k] for k in ('timeout', 'deadline_exhausted', 'stdout_limit',
                'stderr_limit', 'output_limit', 'group_killed', 'kill_errno',
                'launch_errno', 'launch_error', 'read_errno')))


def native_layouts(raw):
    layouts = {}
    for block in raw.decode().split('*** Dumping AST Record Layout'):
        name = re.search(r'^\s*0 \| struct (coax_t_\w+)\s*$', block, re.M)
        extent = re.search(r'\[sizeof=(\d+), align=(\d+)\]', block)
        if name and extent:
            fields = {}
            for offset, declaration in re.findall(r'^\s*(\d+) \|   (\S[^\n]*)$', block, re.M):
                field = re.search(r'(\w+)$', declaration)
                if field:
                    fields[field.group(1)] = int(offset)
            layouts[name.group(1)] = {'size': int(extent.group(1)),
                                     'alignment': int(extent.group(2)), 'offsets': fields}
    return layouts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emission-dir', required=True)
    parser.add_argument('--checker-source-sha256', required=True)
    parser.add_argument('--checker-py-sha256', required=True)
    args = parser.parse_args()
    global E
    E = Path(args.emission_dir).resolve(strict=True)
    environment = dict(os.environ)
    cc = shlex.split(environment.get('CC', 'cc'))
    if not cc:
        raise RuntimeError('empty compiler command')
    alias = alias_of(cc[0], B, environment)
    physical = alias.resolve(strict=True)
    paths = [Path(__file__).resolve(), B/'coax/tests/checker.py', B/'coax/tests/parser.py',
             B/'coax/tests/lexer.py', Path(bounded_process.__file__).resolve(),
             Path(quiet_crash.__file__).resolve(), B/'coax/lib/compiler/checker.coax',
             E/'record.json', *[E/n for n in ('checker.c', 'checker.h',
                                            'proto_importer.c', 'proto_importer.h')], physical]
    before = {str(p): digest(p) for p in paths}
    assert before[str(B/'coax/tests/checker.py')] == args.checker_py_sha256
    assert before[str(B/'coax/lib/compiler/checker.coax')] == args.checker_source_sha256
    emission = json.loads((E/'record.json').read_text())
    assert emission['outcome'] == 'passed' and emission['source_before'] == emission['source_after']
    for row in emission['rows']:
        observed_sha = row['raw']['stdout']['sha256'] if 'raw' in row else row['stdout_sha256']
        assert digest(E/(row['label']+'.c')) == observed_sha
    ns = {'C': C, '__name__': 'declaration_only_layout_guard'}
    load_definitions(B/'coax/tests/lexer.py', ns, {'Text'})
    ns['LX'] = types.SimpleNamespace(Text=ns['Text'])
    load_definitions(B/'coax/tests/parser.py', ns, {'view'})
    ns['PS'] = types.SimpleNamespace(view=ns['view'])
    load_definitions(B/'coax/tests/checker.py', ns)
    load_definitions(B/'coax/tests/checker.py', ns, {'transport_records'})
    records = ns['transport_records']()
    expected = {name: {'size': C.sizeof(record), 'alignment': C.alignment(record),
                      'offsets': {field: getattr(record, field).offset for field, _ in record._fields_}}
                for name, record in records}
    assert len(expected) == 21 and sum(len(v['offsets']) for v in expected.values()) == 198
    (D/'ctypes-expected.json').write_text(json.dumps(expected, indent=2)+'\n')
    sources = []
    for name in ('checker', 'proto_importer'):
        header = E/(name+'.h')
        source = D/(name+'-guard.c')
        lines = ['#include <stddef.h>', '#include '+json.dumps(str(header))]
        for type_name, layout in expected.items():
            lines += [f'_Static_assert(sizeof({type_name})=={layout["size"]},"{type_name}.size");',
                      f'_Static_assert(_Alignof({type_name})=={layout["alignment"]},"{type_name}.alignment");']
            for field, offset in layout['offsets'].items():
                lines.append(f'_Static_assert(offsetof({type_name},{field})=={offset},"{type_name}.{field}");')
        source.write_text('\n'.join(lines)+'\n')
        sources.append((name, source))
    source_pins = {str(source): digest(source) for _, source in sources}
    started = time.monotonic()
    deadline = started+120
    record = {'schema': 'coax.B1.header-only-layout.v1', 'outcome': 'not-checked',
              'scope': 'C static assertions and Clang record-layout output only; no link, executable probe, CDLL, Coax emission, model call or behavior qualification.',
              'source_before': before, 'generated_guard_sources': source_pins,
              'compiler': {'argv': cc, 'alias': str(alias), 'physical': str(physical),
                           'sha256': digest(physical), 'cwd': str(B)},
              'settings': {k: environment.get(k) for k in ('SDKROOT', 'DEVELOPER_DIR',
                   'MACOSX_DEPLOYMENT_TARGET', 'COAX_HOST_TARGET')},
              'toolchain_limit': 'Physical compiler and explicit inputs are hashed. This is not a complete SDK or transitive compiler dependency lock.',
              'rows': [], 'layout_record_count': len(expected),
              'field_offset_count': sum(len(v['offsets']) for v in expected.values())}

    def save():
        record['source_after'] = {str(p): digest(p) for p in paths}
        record['inputs_unchanged'] = (record['source_after'] == before
                    and alias_of(cc[0], B, environment) == alias
                    and alias.resolve(strict=True) == physical
                    and all(digest(p) == sha for p, sha in source_pins.items()))
        record['elapsed_s'] = time.monotonic()-started
        (D/'qualification.json').write_text(json.dumps(record, indent=2)+'\n')

    def compile_guard(item):
        name, source = item
        argv = [*cc, '-std=c11', '-Wall', '-Wextra', '-Werror', '-Xclang',
                '-fdump-record-layouts-complete', '-fsyntax-only', str(source)]
        observation = bounded_process.run(argv, cwd=B, env=environment, timeout_s=60,
                                         max_output_bytes=8388608, deadline=deadline,
                                         quiet_faults=True)
        raw = dict(observation)
        streams = {}
        for channel in ('stdout', 'stderr'):
            destination = D/(name+'.'+channel)
            destination.write_bytes(raw.pop(channel))
            streams[channel] = {'path': str(destination), 'sha256': digest(destination),
                                'bytes': destination.stat().st_size}
        return name, {'argv': argv, 'observation': raw, 'raw': streams,
                      'transport_clean': clean(observation)}

    save()
    try:
        assert record['inputs_unchanged']
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(compile_guard, sources))
        for name, row in results:
            row['header'] = str(E/(name+'.h'))
            record['rows'].append(row)
            save()
        for row in record['rows']:
            assert row['transport_clean'], 'header guard compiler failure'
            output = Path(row['raw']['stdout']['path']).read_bytes()+Path(row['raw']['stderr']['path']).read_bytes()
            observed = native_layouts(output)
            actual = {name: observed.get(name) for name in expected}
            row['actual_layouts'] = actual
            row['matches_ctypes'] = actual == expected
            save()
            assert row['matches_ctypes'], 'layout dump mismatch'
        save()
        assert record['inputs_unchanged']
        record['outcome'] = 'passed'
    except BaseException as error:
        record['outcome'] = 'failed'
        record['error'] = repr(error)
        raise
    finally:
        save()
    print(json.dumps({'outcome': record['outcome'], 'records': len(expected),
          'field_offsets': record['field_offset_count'],
          'node': record['rows'][0]['actual_layouts']['coax_t_CK_Node'],
          'state': record['rows'][0]['actual_layouts']['coax_t_CK_State'],
          'context': record['rows'][0]['actual_layouts']['coax_t_CK_Context'],
          'receipt': str(D/'qualification.json'), 'receipt_sha256': digest(D/'qualification.json')}, indent=2))


if __name__ == '__main__':
    main()
