"""Archive one already-finished normal epoch; no compiler/test/publication effects."""
from pathlib import Path
import gzip,hashlib,io,json,os,re,stat,subprocess,tarfile,time
A=Path('/tmp/coax-return-borrows-A1').resolve();R=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');N=A/'normal046-reset-eligible-v10-current307-181';D=A/'normal-v10-finished-part';P=A/'normal046-plan8-current307-181-v10';START=time.monotonic();DEADLINE=START+220
BASE='8b8b480de350244b49f09b0390a65210c8064b3d';SOURCE='4c173f0a4555b9f109304c0c0653fe4af7388379';FP='cf94a8f3f71fe9f06da1897a2af362bf4a003bedd4a329c07ffdb1c675191f27';IMAGE='854d63b4e132a12fef1b1857ce2d06e0bb07c0a342b8c23211a5ad443060d05a'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def deadline():assert time.monotonic()<DEADLINE,'archive phase exceeded bound'
def regular(p):
 p=Path(p);assert not p.is_symlink()and stat.S_ISREG(p.stat().st_mode),str(p);p=p.resolve();assert p.is_relative_to(A),str(p);assert not any(x in str(p).lower()for x in ['/publication-','/credential-']),str(p);return p
files={};by_source={}
def add(p,name,expected=None,kind='proof'):
 deadline();p=regular(p);assert not name.startswith('/')and'..'not in Path(name).parts and'\\'not in name
 digest=h(p);assert expected is None or digest==expected,(str(p),digest,expected)
 if str(p)in by_source:return by_source[str(p)]
 assert name not in files
 assert p.stat().st_size<=67108864,'unexpected large archive input'
 files[name]={'source':str(p),'sha256':digest,'bytes':p.stat().st_size,'kind':kind};by_source[str(p)]=name;return name
facts=A/'normal-v10-complete-facts.json';assert h(facts)=='b111b91c3dc10864d942342e2f03dc4cd5a922e6a3838ec344b8aa6dfb75f9b1';f=json.loads(facts.read_text());assert f['outcome']=='passed'and f['source_revision']==SOURCE and f['fingerprint']==FP and f['required_steps']==163 and f['installed_files']['coax']==IMAGE
qpath=N/'qualification.json';assert h(qpath)==f['normal_sha256']=='a29813ef67b10af1a152b882647dc8a4138c65a40ca98abd702c4ffaee38a2e3';q=json.loads(qpath.read_text());assert q['outcome']=='passed';bpath=Path(q['binding']);assert h(bpath)==q['binding_sha256'];b=json.loads(bpath.read_text());assert b['source_revision']==b['observed_source_revision']==SOURCE and b['expected_fingerprint']==FP
planpath=Path(q['plan']);assert planpath.resolve()==P/'plan.json'and h(planpath)==q['plan_sha256'];plan=json.loads(planpath.read_text());ids=[x['id']for x in plan['steps']];assert len(ids)==163 and q['required_steps']==q['passed_steps']==ids and set(q['receipts'])==set(ids)
add(facts,'normal/facts.json',kind='completed-facts');add(qpath,'normal/qualification.json',kind='normal-qualification');add(bpath,'normal/binding.json',kind='binding')
rows={};elapsed=[];flags=['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno']
for planned in plan['steps']:
 ident=planned['id'];ref=q['receipts'][ident];p=Path(ref['path']);r=json.loads(p.read_text());assert r['step']==planned and r['outcome']=='passed'and r['binding_sha256']==q['binding_sha256']and r['source_revision']==SOURCE and r['expected_fingerprint']==FP and r['frozen_inputs_unchanged']is True
 assert r['fresh_gate_execution']is True and r['strict_mutation_execution']is True and r['gate_cache_reuse']is False and r['changed_line_survivor_tolerance']is False
 o=r['observation'];assert o['started']and o['returncode']==0 and o['stdout_eof']and o['stderr_eof']and not any(o.get(x)for x in flags);assert o['elapsed_s']<870;elapsed.append(o['elapsed_s'])
 add(p,'normal/receipts/'+ident+'.json',ref['sha256'],'statement-receipt');script=Path(o['argv'][-1]);assert script.resolve()==N/(ident+'.sh');add(script,'normal/scripts/'+ident+'.sh',r['script_sha256'],'exact-executed-script')
 for stream in ['stdout','stderr']:
  v=o[stream];assert Path(v['path']).resolve().is_relative_to(N);name=add(v['path'],'normal/raw/'+Path(v['path']).name,v['sha256'],'raw-'+stream);assert files[name]['bytes']==v['bytes']
 if r['raw_gate_log']:
  v=r['raw_gate_log'];name=add(v['path'],'normal/raw/'+Path(v['path']).name,v['sha256'],'raw-gate-log');assert files[name]['bytes']==v['bytes']
 rows[ident]=r
for p in P.iterdir():
 if p.is_file():add(p,'plan/'+p.name,kind='exact-plan-runner-review')
for p in (P/'infrastructure').rglob('*.py'):add(p,'plan/infrastructure/'+str(p.relative_to(P/'infrastructure')),kind='bounded-transport-tool')
assert h(P/'runner.py')=='1999a240854caa8cf8b3a600bbd9cf8d528c6d84a5fea37689f2c4d2a7d80af0'
seed=Path(b['seed_precondition_receipt']);assert h(seed)==b['seed_precondition_sha256'];s=json.loads(seed.read_text());assert s['source_revision']==SOURCE and s['compiler_input_fingerprint']==FP
add(seed,'seed/seed-precondition.json',b['seed_precondition_sha256'],'seed-precondition')
for path,digest in s['evidence'].items():
 p=Path(path);assert p.suffix=='.json';add(p,'seed/metadata/'+str(p.resolve().relative_to(A)),digest,'seed-composition-review-metadata')
# Retain constructor fragments and audit metadata, not duplicate full C trees.
AUD=A/'seed-defaults-composition-audit'
for name in ['qualification.json','checker.upstream-defaults.c','checker.new-prototypes.txt']:add(AUD/name,'seed/constructor-audit/'+name,kind='constructor-composition-proof')
ART=N/'snapshot/coax/bin';last=rows[ids[-1]];artifacts={};assert len(f['installed_files'])==17
for name,digest in f['installed_files'].items():
 p=ART/name;assert last['artifacts_after'].get(str(p))==digest;artifacts[name]={'member':add(p,'qualified-artifacts/'+name,digest,'final-regular-artifact'),'sha256':digest,'bytes':p.stat().st_size}
assert (ART/'mutation-survivors').stat().st_size==0 and not (ART/'mutation-survivors').is_symlink()
shards=[];WORK=ART/'.bootstrap-bounded-normal'
for i in range(1,9):
 p=WORK/f'checker.{i}.rec';expected=rows[f'checker-shard-{i}']['artifacts_after'][str(p)];assert rows['checker-merge']['artifacts_after'][str(p)]==expected;shards.append({'index':i,'member':add(p,f'normal/checker-shards/{i}.rec',expected,'full-scope-mutation-record'),'sha256':expected})
merge=Path(rows['checker-merge']['raw_gate_log']['path']).read_text().strip();assert merge=='8147 mutants, 8147 killed, 0 survived'
# Composition is explicit: recover trusted body/H from final artifacts/fragments.
tail=(AUD/'checker.upstream-defaults.c').read_bytes();protos=(AUD/'checker.new-prototypes.txt').read_bytes().splitlines(keepends=True);composed=(ART/'checker.c').read_bytes();assert composed.endswith(tail)and len(tail)==665;trusted_body_sha=hashlib.sha256(composed[:-len(tail)]).hexdigest();assert trusted_body_sha=='52bccc1c849111703db7d88b2d38ea53c1f641630e8b8479b2cacae6a3f1d997';head=(ART/'checker.h').read_bytes()
for line in protos:assert head.count(line)==1;head=head.replace(line,b'')
assert hashlib.sha256(head).hexdigest()=='ec8289536aa45d54021d0a9f4d8e685297bfc86212175a6a407af8b13a39e194'
for name in ['state.json','journal.jsonl']:
 p=N/name
 if p.exists():add(p,'normal/'+name,kind='normal-journal-state')
# Exact object-to-object local Git diff: no worktree/index/config writes or
# external diff/textconv, no network/credentials or current-tree assumptions.
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat')
def git(args):
 deadline();p=subprocess.run(['git','-C',str(R),*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);assert p.returncode==0,'local Git object observation failed';return p.stdout
patch=git(['diff','--binary','--full-index','--no-ext-diff','--no-textconv',BASE,SOURCE,'--']);names=git(['diff','--name-only','-z',BASE,SOURCE,'--']).decode().strip('\0').split('\0');trees={x:git(['rev-parse',x+'^{tree}']).decode().strip()for x in [BASE,SOURCE]};assert all(re.fullmatch('[0-9a-f]{40}',v)for v in trees.values())
patchfile=D/'candidate.patch.gz'
with patchfile.open('xb')as fobj:
 with gzip.GzipFile(fileobj=fobj,mode='wb',mtime=0)as z:z.write(patch)
assert gzip.decompress(patchfile.read_bytes())==patch
patch_fact={'member':add(patchfile,'candidate/candidate.patch.gz',kind='exact-compressed-source-patch'),'base':BASE,'source':SOURCE,'trees':trees,'raw_diff_bytes':len(patch),'raw_diff_sha256':hashlib.sha256(patch).hexdigest(),'gzip_sha256':h(patchfile),'changed_paths':names,'scope':'Exact local Git binary diff for reconstructing the4c candidate atop admitted8b8. Archived source only; not applied/installed/published language code.'}
scope={'schema':'coax.normal-v10.finished-qualified-part.v1','outcome':'passed-finished-normal-part','source_revision':SOURCE,'admitted_main':BASE,'fingerprint':FP,'image_sha256':IMAGE,'normal_qualification_sha256':h(qpath),'required_and_passed_steps':163,'full_checker_mutation':{'mutants':8147,'killed':8147,'survived':0,'scope':'Original full-source eight-shard inventory plus authoritative merge; not helper-only feedback.'},'final_artifacts':artifacts,'shard_records':shards,'source_patch':patch_fact,'scope_limit':'Historical qualified normal only at4c/cf94. Not query-merged current main; no native9/source39/SystemOne/visual/publication claim. A1 remains open; incoming query integration requires its own qualification.','proof_limits':'Native compiler/SDK tool identities are retained in raw binding/receipts, not copied toolchain binaries. The patch requires the admitted base Git object. Prior diagnostic/precondition metadata remains historical, not a relabeled pass.'}
scopefile=D/'scope.json';scopefile.write_text(json.dumps(scope,indent=2)+'\n');add(scopefile,'scope.json',kind='scope-and-reviewable-summary');add(Path(__file__),'archive-maintenance.py',kind='archive-only-maintenance-tool')
assert sum(x['bytes']for x in files.values())<209715200
manifest={'schema':'coax.normal-v10.proof-archive-manifest.v1','scope':scope['scope_limit'],'files':files,'logical_file_count':len(files),'source_bytes':sum(v['bytes']for v in files.values()),'object_worktree_duplicates_excluded':True,'no_auth_publication_or_network_observation_inputs':True}
mfile=D/'manifest.json';mfile.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=D/'proof.tar.gz';tarfiles=dict(files);tarfiles['manifest.json']={'source':str(mfile),'sha256':h(mfile),'bytes':mfile.stat().st_size,'kind':'manifest'}
with archive.open('xb')as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0,compresslevel=6)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,info in sorted(tarfiles.items()):
    deadline();path=Path(info['source']);data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==info['sha256'];entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o444;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 seen=set()
 for entry in tar:
  deadline();assert entry.isfile()and not entry.name.startswith('/')and'..'not in Path(entry.name).parts and entry.name not in seen;seen.add(entry.name);data=tar.extractfile(entry).read();assert len(data)==tarfiles[entry.name]['bytes']and hashlib.sha256(data).hexdigest()==tarfiles[entry.name]['sha256']
 assert seen==set(tarfiles)
assert all(h(info['source'])==info['sha256']for info in files.values());deadline()
record={'schema':'coax.normal-v10.finished-part-archive.v1','outcome':'validated-immutable-proof-archive','source_revision':SOURCE,'admitted_main':BASE,'fingerprint':FP,'image_sha256':IMAGE,'historical_qualified_normal_only':True,'normal':{'path':str(qpath),'sha256':h(qpath),'facts_sha256':h(facts),'required_and_passed_steps':163,'original_full_checker_mutants':8147,'survivors':0,'max_statement_elapsed_s':max(elapsed)},'archive':{'path':str(archive),'sha256':h(archive),'bytes':archive.stat().st_size,'regular_members':len(tarfiles),'all_member_hashes_verified':True},'manifest':{'path':str(mfile),'sha256':h(mfile)},'scope':{'path':str(scopefile),'sha256':h(scopefile)},'candidate_patch':patch_fact,'final17_artifact_hashes':f['installed_files'],'limits':'No current query-merged qualification/native9/source39/SystemOne/visual/publication claim; A1 remains open. Candidate source archived only. No tests/compiler/network/credentials/root/Git mutations.','elapsed_s':time.monotonic()-START};rfile=D/'record.json';rfile.write_text(json.dumps(record,indent=2)+'\n')
for p in [archive,mfile,rfile,scopefile,patchfile,Path(__file__)]:p.chmod(0o444)
print(json.dumps({'record':str(rfile),'record_sha256':h(rfile),'archive_sha256':h(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':h(mfile),'members':len(tarfiles),'elapsed_s':record['elapsed_s']}))
