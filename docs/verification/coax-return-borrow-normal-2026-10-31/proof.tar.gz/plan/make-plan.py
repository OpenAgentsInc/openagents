from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;source=B/'bootstrap-build.original.sh';lines=source.read_text().splitlines();wrapper=(B/'build.original.sh').read_text().splitlines();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)=='347907885c890407dd2294d40e7e08a9afecd246d32541758f6878da02f249f7'
assert sha(B/'build.original.sh')=='4d7b64cc595bfebd53c9af8023cd3a7058e3e92216b90c7c451e6e11bb5facf8'
assert sha(B/'mutation-gate.original.sh')=='c84daacc5a4d26a1bb7e73cd767da53f7f37e411ff6afbcb169d04179edf1825'
def anchor(text):
 matches=[i+1 for i,v in enumerate(lines) if v==text];assert len(matches)==1,(text,matches);return matches[0]
start=anchor('./check-proto-cap.sh lib/proto/wire.coax lib/proto/importer.coax');helper=next(i+1 for i,v in enumerate(lines) if v.startswith('sha() {'));identity=anchor('stage0_id="$(stage0_identity)"');initialize=anchor(': > "$work/mutation-survivors"');checker_test=anchor('gate "$work/stage0" test lib/compiler/checker.coax');checker_mut=anchor('gate "$work/stage0" mutate lib/compiler/checker.coax');final_start=anchor('"${CC:-cc}" "${c_flags[@]}" -c "$work/proto_importer.c" -o "$work/proto_importer.o"');publish=anchor('cp "$work/lexer.c" bin/lexer.c')
steps=[];coverage={};previous=None
admin={**{i:'Shared shell setup/flags, private snapshot admission and frozen source identity' for i in range(1,start)},**{i:'Exact helper/variable definitions retained in every child, excluding one-time survivor initialization; strict/full/fresh disables cache and unchanged-line tolerance' for i in range(helper,identity) if i!=initialize}}
for i,v in enumerate(lines,1):
 if v=='work="bin/.bootstrap-$$"':admin[i]='Persistent private work replaces PID-local path'
 if v=='mkdir -p "$work"':admin[i]='Performed once by bind'
 if v=="trap 'rm -rf \"$work\"' EXIT" or v in ['rm -rf "$work"','trap - EXIT']:admin[i]='Cleanup deferred solely for raw evidence retention'
for i,v in admin.items():coverage[i]={'kind':'administrative-adaptation','explanation':v}
def add(id,phase,body,first=None,last=None,kind='original-statement'):
 global previous
 s={'id':id,'phase':phase,'kind':kind,'statement':body,'depends':[] if previous is None else [previous]}
 if first is not None:
  s.update(source_lines=[first,last],source_text_sha256=hashlib.sha256(('\n'.join(lines[first-1:last])+'\n').encode()).hexdigest())
  for n in range(first,last+1):coverage.setdefault(n,{'kind':kind,'steps':[]})['steps'].append(id)
 steps.append(s);previous=id
add('initial-fingerprints','initial','[[ "$(./provenance.sh fingerprint "$root")" == "$input_identity" ]]\n[[ "$("$target/coax/provenance.sh" fingerprint "$target")" == "$input_identity" ]]',kind='Fresh snapshot and target identity precondition')
i=start
while i<=len(lines):
 line=lines[i-1]
 if i in admin:i+=1;continue
 if not line.strip() or line.lstrip().startswith('#'):coverage[i]={'kind':'comment-or-blank'};i+=1;continue
 first=i
 if line=='{':
  while not lines[i-1].startswith('} > '):i+=1
 elif line.startswith('if '):
  while lines[i-1]!='fi':i+=1
 last=i;body='\n'.join(lines[first-1:last])
 if first==checker_mut:
  for n in range(1,9):add(f'checker-shard-{n}','checker',f'''gate bash -c '"$1" mutate lib/compiler/checker.coax --shard "$2" > "$3"' -- "$work/stage0" {n}/8 "$work/checker.{n}.rec"''',first,last,'Full-scope8-shard replacement; inner stdout redirected before original gate logging. Any nonzero fails under forced strict admission.')
  add('checker-merge','checker',body+' '+' '.join(f'--merge "$work/checker.{n}.rec"' for n in range(1,9)),first,last,'Authoritative complete8-record merge replacement')
 else:
  phase='stage0' if first<helper else 'survivor-artifact-initialization' if first==initialize else 'stage0-identity' if first==identity else 'before-checker' if first<checker_test else 'checker-baseline' if first==checker_test else 'after-checker' if first<final_start else 'final' if first<publish else 'snapshot-publication'
  if first==identity:body+='\nprintf \'%s\\n\' "$stage0_id" > "$work/stage0.identity"'
  add(f'line-{first:03}',phase,body,first,last,'Original identity calculation + persistent observation' if first==identity else 'original-statement')
 i+=1
first=wrapper.index('check_documents() {');last=next(i for i in range(first+1,len(wrapper)) if wrapper[i]=='}');doc_function='\n'.join(wrapper[first:last+1]);artifacts=next(v for v in wrapper if v.startswith('artifacts=('));assert 'mutation-survivors)' in artifacts
predoc='"$target/coax/provenance.sh" verify "$target" "$root/coax/bin/coax" "$root/coax/bin/provenance-check" "$root/coax/bin/provenance.record"\ncandidate="$root/coax/bin/coax"\nroot="$target"\ncd "$target/coax"\n'+doc_function+'\ncheck_documents "$candidate"'
add('pre-install-check-documents','pre-install-documents',predoc,kind='Exact current wrapper validation with verified snapshot candidate before any target artifact/install/cache effect')
old=json.loads(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current264/plan.json').read_text());install=next(s['statement'] for s in old['steps'] if s['id']=='target-install-cache');old_artifacts=next(v for v in install.splitlines() if v.startswith('artifacts=('));install=install.replace(old_artifacts,artifacts);install='[[ -f "$root/coax/bin/mutation-survivors" && ! -s "$root/coax/bin/mutation-survivors" ]]\n'+install
sf=wrapper.index('write_source_digest() {');sl=next(i for i in range(sf+1,len(wrapper)) if wrapper[i]=='}');source_digest='\n'.join(wrapper[sf:sl+1]);digest_block='(\n root="$target"\n cd "$target/coax"\n'+source_digest+'\nwrite_source_digest\n)';install_marker='"$target/coax/provenance.sh" install "$target" "$root/coax/bin"';assert install.count(install_marker)==1;install=install.replace(install_marker,install_marker+'\n'+digest_block);add('target-install-cache','installation',install,kind='Current wrapper verified fresh install/cache, all actual artifacts including mutation-survivors; short exclusive publication lock and preserve old cache')
# With strict mode every successful gate has zero survivors. Retain the exact
# wrapper report_survivors function/call after installation as a final statement.
rf=wrapper.index('report_survivors() {');rl=next(i for i in range(rf+1,len(wrapper)) if wrapper[i]=='}');report='\n'.join(wrapper[rf:rl+1]);add('post-install-report-survivors','post-install-report','cd "$target/coax"\n'+report+'\nreport_survivors',kind='Exact wrapper reporting; forced strict admission requires an empty survivor artifact')
assert len(wrapper)==181 and len(lines)==307 and set(coverage)==set(range(1,308));assert sum(s['statement']==': > "$work/mutation-survivors"' for s in steps)==1
f0=next(i for i,v in enumerate(lines) if v.startswith('host_flags='));f1=next(i for i,v in enumerate(lines[f0:],f0) if v.startswith('if [[ -n "${COAX_HOST_TARGET:-}" ]]') and 'c_flags' in v)+1
helpers=[v for i,v in enumerate(lines[helper-1:identity-1],helper) if i!=initialize];assert ': > "$work/mutation-survivors"' not in helpers
plan={'schema':'coax.bootstrap.bounded-plan.v3','scope':'PREPARED ONLY from current307-bootstrap/181-wrapper. Strict zero survivors/full scheduling/fresh execution. Actual postmerge scripts+seed/source require separate reviewed binding. No old plan or epoch relabeled.','bootstrap_sha256':sha(source),'build_sha256':sha(B/'build.original.sh'),'mutation_gate_sha256':sha(B/'mutation-gate.original.sh'),'line_count':307,'steps':steps,'coverage':{str(k):v for k,v in sorted(coverage.items())},'shared_flags_lines':lines[f0:f1],'shared_gate_helper_lines':helpers,'anchors':{'check_proto':start,'helper_start':helper,'survivor_init':initialize,'stage0_identity':identity,'checker_test':checker_test,'checker_mutate':checker_mut,'final_start':final_start,'publish':publish},'required_execution_environment':{'COAX_BUILD_FRESH':'1','COAX_MUTATION_CHANGED':'strict','COAX_MUTATION_FULL':'1'},'fresh_mode':{'cache_reuse':False,'unchanged_line_tolerance':False,'equivalence':'Exact helpers reused, one-time truncate excluded from prefix and retained as its own statement. Gate cache disabled. Strict judge cannot admit any survivor. Shards use conservative nonzero refusal; merge uses original gate/judge.'},'documents':{'position':'before any target artifacts/install/cache','wrapper_lines':[first+1,last+1],'function_sha256':hashlib.sha256(doc_function.encode()).hexdigest()},'artifact_list':artifacts,'wrapper_line_count':len(wrapper),'source_digest':{'function_sha256':hashlib.sha256(source_digest.encode()).hexdigest(),'wrapper_function_lines':[sf+1,sl+1],'execution_position':'after target provenance install, before keep/cache publication; exact function/call in target cwd/root','function':source_digest},'survivor_initialization':'Exactly once in its own original statement, never in child prefix. Actual empty artifact copied through bootstrap/target/cache.','deferred_cleanup':'Only private work cleanup deferred for archive.'}
(B/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'steps':len(steps),'lines':307,'anchors':plan['anchors']}))
