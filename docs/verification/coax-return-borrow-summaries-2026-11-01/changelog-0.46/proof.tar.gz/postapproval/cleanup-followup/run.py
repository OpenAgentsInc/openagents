#!/usr/bin/env python3
"""Cleanup-only observation and composition; no comparison/provenance replay or signal API."""
import sys
sys.dont_write_bytecode=True
import pathlib,hashlib,json,os,subprocess,shutil,re,time
HERE=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result')
STAGE=pathlib.Path('/tmp/coax-return-borrows-A1/changelog046-final-v13')
PINS={'/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/approved-baseline-comparison.json': 'c02d1ffdd50624595e6124c6434ba18d663d6405eacc0a00da91419aaa22386f', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/approved-baseline-comparison.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/approved-baseline-comparison.stdout': '83705e5ccfae9ae01ebff71c4ce712e17b9a0ee205caf27d9c7d1288226a85ad', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/comparison-report.json': '8468617196f28ca9f48c5b444bb709e4fc3f5c20940d1adab821c4718868e28e', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/golden-diff-before.json': '885101537d83658514ab4157090f54614fa456b0aea4d18c3207a8145adb4b00', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/golden-diff-before.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/golden-diff-before.stdout': '0f8509dff70fd514b0bf8e9fe67f511c3ffd4df72fe173819e5e81ee5cdc36b9', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/outer.json': '521853724c1788eebee6d727fe3247aa41a20c634c695d46f34df6561c473a17', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/outer.stderr': '49483f9c81fc54420f03ae31f048ed2202063161b2e7e5447ffedb502e19a8e9', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/outer.stdout': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/owned-server.json': 'ddfcb3cdfd3b3ad1c26343a827a2ee80eb19e2a37160da7df8e28ee8ad0456ce', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-after.json': 'd4b89fde87497bed863abc33a47f260d3b3ae07eff6245044831c07027d1a8f2', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-after.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-after.stdout': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-before.json': '5c577de7f95d6b6bcc823afdd51f1aaff39f6d4a5fdeb0499393b1e8bef93f41', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-before.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/post-approval-provenance-before.stdout': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/server-ready.json': '6ed20492b13fdd9cd61ad8fecda1eb66e0d55bcfdbf9031031174dbcebc6a22d', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/server.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-after.json': '05f37df68af7055d774431f5f05222d791081c8e6db465ba1efa780018a9c198', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-after.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-after.stdout': 'e00ca790ca182dcca0af9dbf2332bb99c7c88d7669fcff5a32947b7beba77547', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-before.json': 'e840ce0d560699d6a3f9e5d19be0ed9426590460d1bcb518e7e4c09dca70234d', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-before.stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/result/source-head-before.stdout': 'e00ca790ca182dcca0af9dbf2332bb99c7c88d7669fcff5a32947b7beba77547', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/run.py': 'a25975bc2db45d58fc9c8d40671522c8c0794727a9ca9a53d17546b2fa021525', '/tmp/coax-return-borrows-A1/changelog046-postapproval-v13/prepared-review.json': '697ed0c3e954e3e5d3931724942ec8e4a7ed7a16feb3242f7ebf705daf3986c3', '/tmp/coax-return-borrows-A1/changelog046-final-v13/config.json': '2a0b4d030dd357224b4b02ad7090cd43ee365e23fbe99dd6dbb435c8c15721c1', '/tmp/coax-return-borrows-A1/changelog046-final-v13/staged.json': '27ffe590d08649dfe58226d30808a8045e219008f91673104de285a3adc82968', '/tmp/coax-return-borrows-A1/changelog046-final-v13/author-review.json': '6b6f52fb4b866a04a730a0abd4c98a8998a302e8948b5c9081729da313ebca46', '/tmp/coax-return-borrows-A1/changelog046-final-v13/approval.json': '5c2bacd160955b5937cd7ffb08c4495df0ff86ab1c14df60951f32b2df374428', '/bin/ps': '1e46cdb824858eb32e4c85ca920ba31b4541a814a133980d8b3484f39942276c'}
NAMES={'coax-changelog','coax-changelog-phone'}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def clean(r):return r['started']and r['returncode']==0 and r['stdout_eof']and r['stderr_eof']and not any(r.get(k)for k in ['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'])
def validate():
 for p,h in PINS.items():assert sha(p)==h,'retained input changed: '+p
 c=json.loads((STAGE/'config.json').read_text())
 for p,h in c['inputs'].items():assert sha(p)==h,'original source/tool/artifact changed: '+p
 for n,h in c['qualified_files'].items():assert sha(pathlib.Path(c['compiler']).parent/n)==h
 assert sha(c['compiler'])==c['compiler_sha256']
 assert sha(c['qualification']['path'])==c['qualification']['sha256']
 for t in c['tools'].values():
  p=shutil.which(t['logical']);assert p and str(pathlib.Path(p).resolve())==t['resolved']and sha(p)==t['sha256']
 assert{n:os.environ.get(n)for n in c['environment']}==c['environment']
 for p,h in json.loads((STAGE/'staged.json').read_text())['files_sha256'].items():assert sha(STAGE/'site'/p)==h
 a=json.loads((STAGE/'approval.json').read_text());note=json.loads((STAGE/'author-review.json').read_text())
 assert note['reviewed']is True and a['review_note_sha256']==sha(STAGE/'author-review.json')
 for n in NAMES:
  assert sha(STAGE/'review'/(n+'.png'))==sha(pathlib.Path(c['repo'])/'coax/web/goldens'/(n+'.png'))==note[n+'_sha256']
 outer=json.loads((OLD/'outer.json').read_text());assert outer['transport_ok']is False and outer['observation']['returncode']==1
 assert outer['stderr_sha256']==sha(OLD/'outer.stderr')and'PermissionError: [Errno 1] Operation not permitted'in(OLD/'outer.stderr').read_text()
 assert 'os.killpg(pgid,0)'in(OLD/'outer.stderr').read_text()
 q=json.loads((OLD/'approved-baseline-comparison.json').read_text());assert q['transport_ok']is True and clean(q['observation'])
 assert q['stdout_sha256']==sha(OLD/'approved-baseline-comparison.stdout')and q['stderr_sha256']==sha(OLD/'approved-baseline-comparison.stderr')
 report=json.loads((OLD/'comparison-report.json').read_text());assert report['failed']==report['golden']==report['other']==[]
 text=(OLD/'approved-baseline-comparison.stdout').read_text();lanes=re.findall(r'^lane ([^ ]+) \(',text,re.M);assert len(lanes)==2 and set(lanes)==NAMES
 for n in NAMES:assert n+': matches its golden (0 blocks changed,'in text
 for n in ['post-approval-provenance-before','post-approval-provenance-after','source-head-before','source-head-after','golden-diff-before']:
  r=json.loads((OLD/(n+'.json')).read_text());assert r['transport_ok']is True and clean(r['observation']);assert r['stdout_sha256']==sha(OLD/(n+'.stdout'))and r['stderr_sha256']==sha(OLD/(n+'.stderr'))
 for n in ['source-head-before','source-head-after']:assert(OLD/(n+'.stdout')).read_text().strip()=='3e95149816d2d296a27670afe413e66bd05a801f'
 return c

def main():
 assert sys.argv[1:]==[];assert not(HERE/'result').exists(),'never repeat retained cleanup observation'
 c=validate();d=HERE/'result';d.mkdir();start=time.monotonic()
 server=json.loads((OLD/'owned-server.json').read_text());ready=json.loads((OLD/'server-ready.json').read_text());check=json.loads((OLD/'approved-baseline-comparison.json').read_text())
 assert server['pid']==server['pgid']==ready['pid']==78104 and check['observation']['pid']==78113
 owned={78104,78113}
 # Read all numeric PID/PGID/UID/state facts, then actual SID for our UID only.
 # No command lines, unrelated data, kill(0), process signals or native/browser launches.
 r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,uid=,stat='],capture_output=True,timeout=5,check=True)
 (d/'ps.stdout').write_bytes(r.stdout);(d/'ps.stderr').write_bytes(r.stderr);assert not r.stderr
 facts=[];uncertain=[]
 for line in r.stdout.decode().splitlines():
  v=line.split();assert len(v)==5
  pid,ppid,pgid,uid=map(int,v[:4]);sid=None
  if uid==os.getuid():
   try:sid=os.getsid(pid)
   except ProcessLookupError:continue
   except OSError as e:uncertain.append({'pid':pid,'errno':e.errno})
  if pgid in owned or sid in owned:facts.append({'pid':pid,'ppid':ppid,'pgid':pgid,'sid':sid,'uid':uid,'stat':v[4]})
 write(d/'owned-session-observation.json',{'ps_argv':['/bin/ps','-axo','pid=,ppid=,pgid=,uid=,stat='],'ps_returncode':r.returncode,'stdout_sha256':sha(d/'ps.stdout'),'stderr_sha256':sha(d/'ps.stderr'),'owned_groups_and_sessions':sorted(owned),'matching_processes':facts,'uncertain_same_uid_sid_queries':uncertain,'signals_sent':[]})
 assert not facts and not uncertain,'absence not established; no signals sent'
 validate();assert time.monotonic()-start<60
 write(d/'composition.json',{'schema':'coax.changelog046.cleanup-only-composition.v1','outcome':'passed-comparison-with-distinct-cleanup-followup','count':2,'names':sorted(NAMES),'original_outer':{'path':str(OLD/'outer.json'),'sha256':sha(OLD/'outer.json'),'outcome':'nonpassing-cleanup-EPERM-unchanged'},'actual_comparison':{'path':str(OLD/'approved-baseline-comparison.json'),'sha256':sha(OLD/'approved-baseline-comparison.json'),'outcome':'passed','seconds':check['observation']['elapsed_s']},'report':{'path':str(OLD/'comparison-report.json'),'sha256':sha(OLD/'comparison-report.json')},'cleanup_followup':{'path':str(d/'owned-session-observation.json'),'sha256':sha(d/'owned-session-observation.json'),'outcome':'owned-PGID-and-SID-absent-no-signals'},'producer':c['compiler_sha256'],'fingerprint':c['fingerprint'],'normal':c['qualification'],'inputs':PINS,'scope':'Original failed transport preserved. Successful exactly-two-page changed-baseline comparison and original before/after provenance are reused without replay. New action is numeric process/SID observation and assembly only; no process signals, browser, native build, provenance replay, capture, golden update, Git or deployment.'})
 print(json.dumps({'composition':str(d/'composition.json'),'sha256':sha(d/'composition.json'),'owned_matching_processes':len(facts),'signals_sent':[]}))
if __name__=='__main__':main()
