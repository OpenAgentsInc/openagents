#!/usr/bin/env python3
"""One fresh two-page comparison of approved baselines; no capture/update/commit mode."""
import sys
sys.dont_write_bytecode=True
import hashlib,json,os,pathlib,runpy,signal,subprocess,time,re
HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents')
PLAN=pathlib.Path('/tmp/coax-return-borrows-A1/changelog046-plan-v13')
STAGE=pathlib.Path('/tmp/coax-return-borrows-A1/changelog046-final-v13')
OUT=HERE/'result'
PINS={'/tmp/coax-return-borrows-A1/changelog046-plan-v13/workflow.py': 'cbf89b85d199c617417981bb99509978e2874e74306e7d138368f8c16e3de7e5', '/tmp/coax-return-borrows-A1/changelog046-plan-v13/serve.ts': '7fee65c37de19c9f04ab9b03ce769638f4583344b3d768202aa558e8791403b9', '/tmp/coax-return-borrows-A1/changelog046-plan-v13/producer_binding.py': 'e6aefccd3d5815e75dd74c17c7538dc54b79ece9554751842db12646fce9b0c9', '/tmp/coax-return-borrows-A1/changelog046-plan-v13/common_reuse.py': '79a5a8ac4b27e8cd7e3c75a97933e330d174178ef24f803db14a371d54756b69', '/tmp/coax-return-borrows-A1/changelog046-final-v13/config.json': '2a0b4d030dd357224b4b02ad7090cd43ee365e23fbe99dd6dbb435c8c15721c1', '/tmp/coax-return-borrows-A1/changelog046-final-v13/staged.json': '27ffe590d08649dfe58226d30808a8045e219008f91673104de285a3adc82968', '/tmp/coax-return-borrows-A1/changelog046-final-v13/author-review.json': '6b6f52fb4b866a04a730a0abd4c98a8998a302e8948b5c9081729da313ebca46', '/tmp/coax-return-borrows-A1/changelog046-final-v13/approval.json': '5c2bacd160955b5937cd7ffb08c4495df0ff86ab1c14df60951f32b2df374428', '/tmp/coax-return-borrows-A1/changelog046-final-v13/capture.json': '2bfff2d7cc7ad0a5ffafa573e9e99eb9d64f5f2aa6a38946dcbefa5858b19762', '/tmp/coax-return-borrows-A1/changelog046-final-v13/review/captures.json': 'b7e4fd44a9e9c6dffe2df1620081241edd2f066c8c056ec2d08d9f387b1ae99d', '/tmp/coax-return-borrows-A1/changelog046-plan-v13/source-delta-reuse.accepted.json': '74597a615931aac9896ebc04f1d2ed8cafd5cea5576ba0dc46cecd633fd52d90', '/tmp/coax-return-borrows-A1/changelog046-plan-v13/root-admission.json': '5a82609e644899ae8264e0843a19152acb6f9d50fe8bb79dff501a73779c5fe1', '/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents/coax/tools/bounded_process.py': 'c9adf3596ad777a40a06537e6ebb3c59fae05f6412a5a82e90ac0627372bbf41'}
NAMES=['coax-changelog','coax-changelog-phone']
EXPECTED_HEAD='3e95149816d2d296a27670afe413e66bd05a801f'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def clean(r):
 return r['started']and r['returncode']==0 and r['stdout_eof']and r['stderr_eof']and not any(r.get(k)for k in ['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'])
def pins():
 for p,h in PINS.items():assert sha(p)==h,'reviewed input changed: '+p

def inner():
 pins();sys.path.insert(0,str(PLAN));w=runpy.run_path(str(PLAN/'workflow.py'))
 c=json.loads((STAGE/'config.json').read_text());deadline=time.monotonic()+840
 # All original producer, tool, environment and source guards remain applicable.
 w['verify'](c,OUT,'post-approval-provenance-before',deadline)
 command=w['command'];gold=ROOT/'coax/web/goldens'
 before={str(p):sha(p)for p in gold.rglob('*.png')}
 approval=json.loads((STAGE/'approval.json').read_text());note=json.loads((STAGE/'author-review.json').read_text())
 assert approval['review_note_sha256']==PINS[str(STAGE/'author-review.json')]and note['reviewed']is True
 assert set(approval['goldens_sha256'])=={str(gold/(n+'.png'))for n in NAMES}
 for n in NAMES:
  g=gold/(n+'.png');original=STAGE/'review'/(n+'.png')
  assert sha(g)==sha(original)==approval['goldens_sha256'][str(g)]==note[n+'_sha256']
 for rel,h in json.loads((STAGE/'staged.json').read_text())['files_sha256'].items():assert sha(STAGE/'site'/rel)==h
 command(ROOT,OUT,'source-head-before',['git','rev-parse','HEAD'],ROOT,deadline)
 assert(OUT/'source-head-before.stdout').read_text().strip()==EXPECTED_HEAD
 command(ROOT,OUT,'golden-diff-before',['git','diff','--name-only'],ROOT,deadline)
 assert set((OUT/'golden-diff-before.stdout').read_text().splitlines())=={'coax/web/goldens/'+n+'.png'for n in NAMES}
 server=None;groups=[];cleanup=[];report=None
 try:
  with(OUT/'server.log').open('xb')as log:
   server=subprocess.Popen(['bun',str(PLAN/'serve.ts'),str(STAGE/'site'),str(OUT/'server-ready.json')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  groups.append(server.pid);write(OUT/'owned-server.json',{'pid':server.pid,'pgid':server.pid,'argv':['bun',str(PLAN/'serve.ts'),str(STAGE/'site'),str(OUT/'server-ready.json')]})
  until=min(deadline,time.monotonic()+15)
  while not(OUT/'server-ready.json').exists():
   assert server.poll()is None and time.monotonic()<until,'local server not ready';time.sleep(.05)
  ready=json.loads((OUT/'server-ready.json').read_text());assert ready['pid']==server.pid
  r=command(ROOT,OUT,'approved-baseline-comparison',['bun',ROOT/'coax/web/goldens.ts',ready['base'],'--full','--only',','.join(NAMES),'--report',OUT/'comparison-report.json'],ROOT,deadline,env=w['browser_environment']())
  report=json.loads((OUT/'comparison-report.json').read_text());assert report['failed']==[]and report['golden']==[]and report['other']==[]
  lines=(OUT/'approved-baseline-comparison.stdout').read_text();lanes=re.findall(r'^lane ([^ ]+) \(',lines,re.M)
  assert len(lanes)==2 and set(lanes)==set(NAMES),'exact two named journeys required'
  assert before=={str(p):sha(p)for p in gold.rglob('*.png')},'comparison changed a golden'
  pins();w['verify'](c,OUT,'post-approval-provenance-after',deadline)
  command(ROOT,OUT,'source-head-after',['git','rev-parse','HEAD'],ROOT,deadline)
  assert(OUT/'source-head-after.stdout').read_text().strip()==EXPECTED_HEAD
 finally:
  q=OUT/'approved-baseline-comparison.json'
  if q.exists():
   pid=json.loads(q.read_text())['observation'].get('pid')
   if pid is not None:groups.append(pid)
  # These groups were created by this server/Popen and this bounded child only.
  for pgid in groups:
   signals=[]
   try:os.killpg(pgid,signal.SIGTERM);signals.append('SIGTERM')
   except ProcessLookupError:pass
   end=time.monotonic()+5
   while time.monotonic()<end:
    try:os.killpg(pgid,0)
    except ProcessLookupError:break
    time.sleep(.05)
   else:
    try:os.killpg(pgid,signal.SIGKILL);signals.append('SIGKILL')
    except ProcessLookupError:pass
   cleanup.append({'owned_pgid':pgid,'signals':signals})
  if server is not None:server.wait(timeout=5)
  ps=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,command='],check=True,capture_output=True,text=True,timeout=5).stdout
  remaining=[line for line in ps.splitlines()if len(line.split(None,3))==4 and int(line.split(None,3)[2])in groups]
  write(OUT/'owned-cleanup.json',{'groups':cleanup,'remaining':remaining,'scope':'Only server/child groups launched above; unrelated production goldens untouched.'})
  assert not remaining,'owned processes remain'
 assert time.monotonic()<deadline
 write(OUT/'qualification.json',{'schema':'coax.changelog046.approved-baseline-comparison.v1','outcome':'passed','count':2,'names':NAMES,'producer':c['compiler_sha256'],'fingerprint':c['fingerprint'],'normal':c['qualification'],'head':EXPECTED_HEAD,'approval_sha256':PINS[str(STAGE/'approval.json')],'author_review_sha256':PINS[str(STAGE/'author-review.json')],'staged_site_sha256':PINS[str(STAGE/'staged.json')],'report':report,'inputs':PINS,'artifacts':{str(p):sha(p)for p in sorted(OUT.rglob('*'))if p.is_file()},'scope':'Fresh comparison on the two changed approved Mac golden inputs against the unchanged staged fixture. Old mismatches, capture and author review remain separate. No update, raw recapture, commit, deploy or broader site claim.'})
 print('Approved-baseline comparison passed for exactly two journeys; no golden files changed.')

def main():
 if sys.argv[1:]==['--inner']:inner();return
 assert sys.argv[1:]==[];pins();assert not OUT.exists(),'never repeat a retained comparison';OUT.mkdir()
 sys.path.insert(0,str(ROOT/'coax/tools'));import bounded_process
 started=time.monotonic();r=bounded_process.run([sys.executable,str(pathlib.Path(__file__).resolve()),'--inner'],str(ROOT),None,870,8388608,started+870,quiet_faults=True)
 out=r.pop('stdout');err=r.pop('stderr');(OUT/'outer.stdout').write_bytes(out);(OUT/'outer.stderr').write_bytes(err)
 write(OUT/'outer.json',{'schema':'coax.changelog046.post-approval-transport.v1','observation':r,'transport_ok':clean(r),'elapsed_seconds':time.monotonic()-started,'stdout_sha256':sha(OUT/'outer.stdout'),'stderr_sha256':sha(OUT/'outer.stderr'),'runner_sha256':sha(__file__)})
 print(json.dumps({'transport_ok':clean(r),'outcome':str(OUT/'qualification.json'),'transport':str(OUT/'outer.json'),'stdout_tail':out[-1200:].decode(errors='replace'),'stderr_tail':err[-1200:].decode(errors='replace')}));sys.exit(0 if clean(r)else 1)
if __name__=='__main__':main()
