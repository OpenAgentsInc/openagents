// coax/web/entropy.js
function createEntropy(memory, contract) {
  return function fill(out, capacity, scratch, scratchCapacity, requested) {
    const integer = (n2) => Number.isSafeInteger(n2);
    const n = integer(requested) ? requested : -1;
    const cap = integer(capacity) ? capacity : -1;
    const scratchCap = integer(scratchCapacity) ? scratchCapacity : -1;
    const bytes = memory.buffer.byteLength;
    const valid = integer(out) && integer(scratch) && out >= 0 && scratch >= 0 && n >= 0 && out + n <= bytes && scratch + n <= bytes;
    const overlap = valid && n > 0 && out < scratch + n && scratch < out + n;
    const admitted = contract.entropy_admit(BigInt(n), BigInt(cap), BigInt(scratchCap), Number(valid), Number(overlap));
    if (admitted)
      return { written: 0, error: admitted };
    let crypto2, random;
    try {
      crypto2 = globalThis.crypto;
      random = crypto2?.getRandomValues;
    } catch {}
    const available = typeof random === "function";
    let ok = false, written = 0;
    if (available && n > 0) {
      try {
        const chunk = Number(contract.entropy_chunk_bytes());
        const full = Number(contract.entropy_full_chunks(BigInt(n)));
        const tail = Number(contract.entropy_tail(BigInt(n)));
        const view = new Uint8Array(memory.buffer, scratch, n);
        for (let i = 0;i < full; i++) {
          const part = view.subarray(written, written + chunk);
          if (random.call(crypto2, part) !== part)
            throw new TypeError("CSPRNG returned a different view");
          written += chunk;
        }
        if (tail) {
          const part = view.subarray(written, written + tail);
          if (random.call(crypto2, part) !== part)
            throw new TypeError("CSPRNG returned a different view");
          written += tail;
        }
        ok = true;
      } catch {}
    }
    const error = contract.entropy_finish(out, scratch, BigInt(cap), BigInt(scratchCap), BigInt(n), Number(valid), Number(overlap), Number(available), Number(ok), BigInt(written));
    return { written: error ? 0 : n, error };
  };
}

// coax/web/entropy-import.js
var contractNames = ["entropy_admit", "entropy_chunk_bytes", "entropy_full_chunks", "entropy_tail", "entropy_finish", "entropy_request_limit", "entropy_output_admit"];
function prepareRandomImport(memory, module, reservation = {}) {
  const needed = WebAssembly.Module.imports(module).some((i) => i.kind === "function" && i.module === "env" && i.name === "coaxial_random");
  if (!needed)
    return { imports: {}, bind() {} };
  const names = new Set(WebAssembly.Module.exports(module).filter((e) => e.kind === "function").map((e) => e.name));
  for (const name of contractNames)
    if (!names.has(name))
      throw new Error(`coaxial_random requires Coax export ${name}`);
  let contract, fill;
  return {
    imports: {
      coaxial_random(out, requested) {
        if (!contract)
          throw new Error("coaxial_random called before its Coax instance was bound");
        const n = Number.isSafeInteger(requested) ? requested : -1;
        const valid = Number.isSafeInteger(out) && out >= 0 && n >= 0 && out + n <= memory.buffer.byteLength;
        const admitted = contract.entropy_output_admit(BigInt(n), BigInt(n), Number(valid));
        if (admitted)
          return admitted;
        if (!n)
          return fill(out, 0, 0, 0, 0).error;
        const capacity = Number(contract.entropy_request_limit());
        if (!reservation.capacity || reservation.capacity < capacity) {
          const start = memory.buffer.byteLength;
          try {
            memory.grow(Math.ceil(capacity / 65536));
          } catch {
            return contract.entropy_admit(BigInt(n), BigInt(n), 0n, 0, 0);
          }
          reservation.ptr = start;
          reservation.capacity = capacity;
        }
        return fill(out, n, reservation.ptr, reservation.capacity, n).error;
      }
    },
    bind(exports) {
      contract = exports;
      if (reservation.capacity && Number(exports.__heap_base?.value ?? 0) > reservation.ptr)
        reservation.capacity = 0;
      fill = createEntropy(memory, contract);
    }
  };
}
function unsupportedImport(module, name) {
  throw new Error(`unsupported Wasm import ${module}.${name}`);
}

// coax/web/drop.js
var STATE_KIND = 40;
var VIEWER_KIND = 3;
var REVIEW_KIND = 41;
var VALUE_KIND = 42;
var ACT_PICK = 20;
var ACT_SIGNIN = 22;
var ACT_DRAFT = 23;
var ACT_EDIT = 24;
var ACT_SAVE = 25;
var ACT_PUBLISH = 26;
var ACT_DISCARD = 27;
var PARALLEL = 3;
var GROW_SECTIONS = [
  ["card", 0, "WHAT IT ADDS"],
  ["mechanics", 0, "NEW MECHANICS"],
  ["design", 0, "DESIGN NOTES"],
  ["roadmap", 1, "PROPOSED WORK"],
  ["engine_needs", 1, "ENGINE NEEDS"],
  ["assets", 1, "ASSETS"],
  ["to_make", 1, "TO MAKE"]
];
var SECTIONS = [
  ["card", 0, "CARD"],
  ["mechanics", 0, "MECHANICS"],
  ["design", 0, "DESIGN"],
  ["roadmap", 1, "ROADMAP"],
  ["engine_needs", 1, "ENGINE NEEDS"],
  ["assets", 1, "ASSETS"],
  ["to_make", 1, "TO MAKE"]
];
var NAMES = {
  name: "Name",
  line: "One line",
  owner: "Owner",
  slug: "Slug",
  cover: "Cover",
  art_direction: "Art direction",
  markdown: "Design document",
  open_questions: "Open question",
  initiative: "Initiative",
  title: "Title",
  body: "Body",
  size: "Size",
  acceptance: "Check",
  mechanics: "Mechanic",
  needs: "Needs",
  existing: "Adds to a milestone it has",
  why: "Why",
  reuses: "Reuses an engine task",
  file: "File",
  kind: "Kind",
  licence: "Licence",
  use: "Use",
  milestones: "Milestone",
  tasks: "Task",
  engine_needs: "Engine need",
  assets: "Asset",
  to_make: "To make"
};
var ORDER = [
  "name",
  "title",
  "slug",
  "line",
  "owner",
  "size",
  "file",
  "kind",
  "licence",
  "use",
  "why",
  "reuses",
  "cover",
  "art_direction",
  "markdown",
  "open_questions",
  "body",
  "acceptance",
  "mechanics",
  "needs",
  "initiative",
  "milestones",
  "tasks"
];
var ONE = { open_questions: "an open question", acceptance: "a check", mechanics: "a mechanic", needs: "a need" };
var named = (k) => NAMES[k] || String(k).replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
var ordered = (o) => Object.keys(o).sort((a, b) => (ORDER.indexOf(a) + 1 || 99) - (ORDER.indexOf(b) + 1 || 99) || a.localeCompare(b));
function target() {
  const q = new URLSearchParams(location.search), slug = q.get("add") || "", key = q.get("key") || "";
  return /^[a-z0-9-]{1,80}$/.test(slug) && /^[0-9a-f]{64}$/.test(key) ? { slug, key, name: slug.replace(/-/g, " "), member: true } : null;
}
function startDrops({ send }) {
  const files = [], add = target();
  const blocked = () => !!add && !add.member;
  let signed = "", dragging = false, dropId = "", making = null, depth = 0, note = "", draft = null, resumed = false;
  let fields = [], reviewNote = "", reviewState = "";
  const picker = Object.assign(document.createElement("input"), { type: "file", multiple: true });
  picker.hidden = true;
  document.body.appendChild(picker);
  const clean = (s) => String(s ?? "").replace(/[|\r\n\t]/g, " ");
  const signer = () => !!(globalThis.nostr && typeof globalThis.nostr.signEvent === "function");
  function push() {
    const lines = [`S|${signed ? blocked() ? 2 : 1 : 0}|${signer() ? 1 : 0}|${dragging ? 1 : 0}|${clean(note)}|${add ? clean(add.name).slice(0, 80) : ""}`];
    for (const f of files.slice(-40))
      lines.push(`F|${clean(f.name).slice(0, 80)}|${f.kind}|${f.bytes}|${f.permille}|${f.status}|${clean(f.note).slice(0, 60)}`);
    if (draft)
      lines.push(draftLine(draft));
    send(STATE_KIND, lines.join(`
`));
    if (draft?.status === "ready")
      pushReview();
  }
  function draftLine(x) {
    const d = x.draft || {}, ms = d.roadmap?.milestones || [];
    const tasks = ms.reduce((n, m) => n + (m.tasks?.length || 0), 0);
    return `D|${x.status}|${clean(d.card?.name).slice(0, 80)}|${clean(d.card?.line).slice(0, 200)}|${ms.length}|${tasks}|${d.mechanics?.length || 0}|${d.design?.open_questions?.length || 0}|${d.engine_needs?.length || 0}|${clean(x.note).slice(0, 120)}|${x.approved ? 1 : 0}`;
  }
  function flatten(d) {
    const out = [];
    const row = (col, kind, label, path, value) => out.push({ col, kind, label, path, value });
    const walk = (col, v, path, label) => {
      if (Array.isArray(v)) {
        const strings = v.every((x) => typeof x === "string");
        v.forEach((x, i) => {
          if (x && typeof x === "object") {
            row(col, "G", `${named(path[path.length - 1]).toUpperCase()} ${i + 1}  ${x.title || x.file || x.slug || ""}`, null, "");
            walk(col, x, [...path, i], "");
          } else
            walk(col, x, [...path, i], `${label} ${i + 1}`);
        });
        if (strings)
          row(col, "A", `+ add ${ONE[path[path.length - 1]] || "one"}`, [...path, v.length], "");
      } else if (v && typeof v === "object") {
        for (const k of ordered(v)) {
          if (v[k] && typeof v[k] === "object" && !Array.isArray(v[k]))
            row(col, "G", named(k).toUpperCase(), null, "");
          walk(col, v[k], [...path, k], named(k));
        }
      } else if (typeof v === "boolean")
        row(col, "B", label, path, v ? "yes" : "no");
      else if (typeof v === "string")
        row(col, "T", label, path, v);
    };
    const grows = !!d.grow;
    for (const [key, col, title] of grows ? GROW_SECTIONS : SECTIONS) {
      if (d[key] === undefined)
        continue;
      row(col, "H", title, null, "");
      walk(col, grows && key === "card" ? { line: d.card.line } : d[key], [key], named(key));
    }
    return out;
  }
  function pushReview() {
    const d = draft?.draft;
    fields = d && draft.status === "ready" ? flatten(d) : [];
    const state = reviewState || (draft?.published ? "published" : draft?.approved ? "approved" : "ready");
    const lines = [`V|${state}|${draft?.edits || 0}|${clean(reviewNote).slice(0, 160)}|${clean(d?.card?.name).slice(0, 80)}|${d?.grow ? 1 : 0}`];
    let room = 60000;
    for (const f of fields) {
      const line = `R|${f.col}|${f.kind}|${clean(f.label).slice(0, 90)}|${clean(f.value).slice(0, 140)}${f.value.length > 140 ? "..." : ""}`;
      room -= line.length + 1;
      if (room < 0)
        break;
      lines.push(line);
    }
    send(REVIEW_KIND, lines.join(`
`));
  }
  function edit(i) {
    const f = fields[i];
    if (f)
      send(VALUE_KIND, `${i}|${f.value}`);
  }
  async function save(text) {
    const bar = text.indexOf("|"), f = fields[Number(text.slice(0, bar))];
    if (!dropId || bar < 0 || !f?.path)
      return;
    reviewState = "saving";
    reviewNote = "";
    try {
      const [s, x] = await post(`/api/drops/${dropId}/draft/edit`, { path: f.path.map(String), value: text.slice(bar + 1) });
      if (s === 200)
        draft = x;
      else
        reviewNote = `Not saved: ${x.error || "refused"}`;
    } catch {
      reviewNote = "Not saved: no answer";
    }
    reviewState = "";
    pushReview();
    push();
  }
  async function finish(what) {
    if (!dropId)
      return;
    reviewNote = "";
    try {
      const [s, x] = await post(`/api/drops/${dropId}/${what}`, {});
      if (s !== 200)
        reviewNote = x.error || "refused";
      else if (what === "publish") {
        draft = x;
        if (x.published?.added !== undefined)
          reviewNote = `Added to openagents.com${x.published.page}: ${x.published.added} new ${x.published.added === 1 ? "task" : "tasks"}`;
        else if (x.published)
          reviewNote = `Live at openagents.com${x.published.page}`;
      } else {
        dropId = "";
        draft = null;
        files.length = 0;
        reviewState = "discarded";
        pushReview();
        reviewState = "";
        push();
        return;
      }
    } catch {
      reviewNote = "no answer";
    }
    pushReview();
    push();
  }
  async function get(url) {
    const r = await fetch(url, { credentials: "same-origin", cache: "no-store" });
    return r.ok ? r.json() : null;
  }
  async function resume() {
    if (resumed || dropId)
      return;
    resumed = true;
    try {
      const list = await get("/api/drops");
      const open = list?.drops?.find((d2) => (d2.status === "open" || d2.status === "approved") && d2.files > 0 && (d2.project || "") === (add?.slug || ""));
      if (!open || dropId)
        return;
      dropId = open.id;
      const d = await get(`/api/drops/${open.id}`);
      for (const f of d?.files || [])
        if (f.status !== "uploading" && f.status !== "waiting")
          files.push({ file: null, name: f.name, kind: f.kind, bytes: f.bytes, permille: 1000, status: f.status === "scanned" ? "kept" : "refused", note: f.note });
      const x = await get(`/api/drops/${open.id}/draft`);
      if (x && x.status !== "none")
        draft = x;
    } catch {}
    push();
  }
  async function read() {
    if (!dropId || draft?.status === "reading")
      return;
    draft = { status: "reading", note: "" };
    push();
    try {
      const [, x] = await post(`/api/drops/${dropId}/draft`, {});
      draft = x && x.status ? x : { status: "failed", note: x?.error || "no answer" };
    } catch {
      draft = { status: "failed", note: "no answer" };
    }
    push();
  }
  async function me() {
    try {
      const r = await fetch("/api/drops/me", { credentials: "same-origin", cache: "no-store" });
      const j = r.ok ? await r.json() : null;
      signed = j && j.may ? j.pubkey : "";
      note = j && !j.may ? "this key may not drop files yet" : "";
      if (signed && add) {
        const h = await fetch(`/api/drops/home/${add.slug}/${add.key}`, { credentials: "same-origin", cache: "no-store" });
        const k = await h.json().catch(() => ({}));
        if (h.ok) {
          add.name = k.name || add.name;
          add.member = !!k.member;
        } else
          add.member = false;
        if (!add.member)
          note = h.ok ? `Only ${add.name}'s members add to it.` : k.error || "This project doesn't take drops yet.";
      }
    } catch {
      signed = "";
    }
    if (signed)
      send(VIEWER_KIND, signed);
    push();
    if (signed) {
      pump();
      resume();
    }
  }
  async function signin() {
    if (!signer()) {
      note = "a Nostr signer is needed";
      push();
      return;
    }
    const url = `${location.origin}/api/drops/signin`;
    try {
      const ev = await globalThis.nostr.signEvent({ kind: 27235, created_at: Math.floor(Date.now() / 1000), content: "", tags: [["u", url], ["method", "POST"]] });
      const auth = btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(ev))));
      const r = await fetch("/api/drops/signin", { method: "POST", credentials: "same-origin", headers: { Authorization: `Nostr ${auth}` } });
      note = r.ok ? "" : (await r.json().catch(() => ({}))).error || "login refused";
    } catch {
      note = "login was cancelled";
    }
    push();
    await me();
  }
  function take(list) {
    if (!signed || blocked())
      return;
    for (const file of list)
      files.push({ file, name: file.name, kind: "", bytes: file.size, permille: 0, status: "queued", note: "" });
    push();
    pump();
  }
  async function post(url, body) {
    const r = await fetch(url, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    const j = await r.json().catch(() => ({}));
    return [r.status, j];
  }
  function ensureDrop() {
    if (dropId)
      return Promise.resolve(dropId);
    making ||= post("/api/drops", add ? { project: add.slug, pubkey: add.key } : {}).then(([s, j]) => {
      making = null;
      if (s !== 200)
        throw new Error(j.error || "no drop");
      return dropId = j.id;
    });
    return making;
  }
  function put(f, url) {
    return new Promise((ok) => {
      const x = new XMLHttpRequest;
      x.open("PUT", url);
      x.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          f.permille = Math.min(999, Math.floor(e.loaded / e.total * 1000));
          push();
        }
      };
      x.onload = () => ok(x.status >= 200 && x.status < 300);
      x.onerror = x.onabort = () => ok(false);
      x.send(f.file.slice(0, f.file.size, ""));
    });
  }
  async function upload(f) {
    try {
      const d = await ensureDrop();
      const [s, j] = await post(`/api/drops/${d}/files`, { name: f.name, bytes: f.bytes });
      if (s !== 200) {
        f.status = "refused";
        f.note = j.error || "refused";
        return;
      }
      f.id = j.file.id;
      f.kind = j.file.kind;
      f.status = "uploading";
      push();
      if (!await put(f, j.upload)) {
        f.status = "refused";
        f.note = "the upload failed; drop it again";
        return;
      }
      f.permille = 1000;
      f.status = "scanning";
      push();
      const [s2, k] = await post(`/api/drops/${d}/files/${f.id}/done`, {});
      if (s2 !== 200) {
        f.status = "refused";
        f.note = k.error || "not scanned";
        return;
      }
      f.status = k.file.status === "scanned" ? "kept" : "refused";
      f.note = k.file.note || "";
    } catch (e) {
      f.status = "refused";
      f.note = e.message || "failed";
    } finally {
      f.file = f.status === "kept" || f.status === "refused" ? null : f.file;
      push();
      pump();
    }
  }
  function pump() {
    if (!signed || blocked())
      return;
    let busy = files.filter((f) => f.status === "uploading" || f.status === "scanning" || f.status === "starting").length;
    for (const f of files) {
      if (busy >= PARALLEL)
        break;
      if (f.status !== "queued")
        continue;
      f.status = "starting";
      busy++;
      upload(f);
    }
  }
  const hasFiles = (e) => [...e.dataTransfer?.types || []].includes("Files");
  addEventListener("dragenter", (e) => {
    if (!hasFiles(e))
      return;
    e.preventDefault();
    if (!signed)
      return;
    depth++;
    if (!dragging) {
      dragging = true;
      push();
    }
  });
  addEventListener("dragover", (e) => {
    if (!hasFiles(e))
      return;
    e.preventDefault();
    e.dataTransfer.dropEffect = signed ? "copy" : "none";
  });
  addEventListener("dragleave", (e) => {
    if (!hasFiles(e))
      return;
    depth = Math.max(0, depth - 1);
    if (!depth && dragging) {
      dragging = false;
      push();
    }
  });
  addEventListener("drop", (e) => {
    if (!hasFiles(e))
      return;
    e.preventDefault();
    depth = 0;
    dragging = false;
    take([...e.dataTransfer.files]);
  });
  picker.addEventListener("change", () => {
    take([...picker.files]);
    picker.value = "";
  });
  addEventListener("coaxial", (e) => {
    const code = e.detail?.code;
    if (code === 0) {
      push();
      if (signed)
        send(VIEWER_KIND, signed);
    } else if (code === ACT_PICK && signed)
      picker.click();
    else if (code === ACT_SIGNIN)
      signin();
    else if (code === ACT_DRAFT)
      read();
    else if (code === ACT_EDIT)
      edit(Number(e.detail.text));
    else if (code === ACT_SAVE)
      save(e.detail.text || "");
    else if (code === ACT_PUBLISH)
      finish("publish");
    else if (code === ACT_DISCARD)
      finish("discard");
  });
  setTimeout(push, 1500);
  me();
}

// coax/web/uploads.js
var ACT_PICK2 = 30;
var STATE_KIND2 = 52;
var DONE_KIND = 53;
function startUploads({ send, accept }) {
  const files = [];
  let target2 = "";
  const picker = Object.assign(document.createElement("input"), { type: "file", multiple: true, accept });
  picker.hidden = true;
  document.body.appendChild(picker);
  const clean = (s) => String(s ?? "").replace(/[|\r\n\t]/g, " ");
  const push = () => send(STATE_KIND2, files.slice(-12).map((f) => `${clean(f.name).slice(0, 60)}|${f.permille}|${f.status}|${clean(f.note).slice(0, 80)}`).join(`
`));
  const key = () => {
    try {
      return JSON.parse(localStorage.getItem("verse.player") || "null")?.key || "";
    } catch {
      return "";
    }
  };
  const post = async (url, body) => {
    const r = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      cache: "no-store",
      headers: { "Content-Type": "application/json", "X-Verse-Player": key() },
      body: JSON.stringify(body || {})
    });
    let j = {};
    try {
      j = await r.json();
    } catch {}
    return { status: r.status, body: j };
  };
  const put = (url, file, f) => new Promise((ok) => {
    const x = new XMLHttpRequest;
    x.open("PUT", url);
    x.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        f.permille = Math.floor(1000 * e.loaded / e.total);
        push();
      }
    };
    x.onload = () => ok(x.status >= 200 && x.status < 300);
    x.onerror = x.onabort = () => ok(false);
    x.send(file);
  });
  async function one(file, url) {
    const f = { name: file.name, permille: 0, status: "sending", note: "" };
    files.push(f);
    push();
    const a = await post(url, { name: file.name, bytes: file.size });
    if (a.status !== 200) {
      f.status = "refused";
      f.note = a.body.error || "we could not take it";
      push();
      return;
    }
    if (!await put(a.body.upload, file, f)) {
      f.status = "failed";
      f.note = "it did not finish sending";
      push();
      return;
    }
    f.status = "scanning";
    f.permille = 1000;
    push();
    const d = await post(`${url}/${a.body.file}/done`);
    const mine = (d.body.files || []).find((x) => x.id === a.body.file);
    f.status = mine?.status === "kept" ? "kept" : "refused";
    f.note = mine?.note || (d.status === 200 ? "" : d.body.error || "");
    push();
    if (d.status === 200)
      send(DONE_KIND, JSON.stringify(d.body));
  }
  picker.addEventListener("change", async () => {
    const list = [...picker.files];
    picker.value = "";
    for (const file of list)
      await one(file, target2);
  });
  addEventListener("coaxial", (e) => {
    const { code, text } = e.detail || {};
    if (code !== ACT_PICK2 || !/^\/api\/[A-Za-z0-9/_-]+$/.test(text || ""))
      return;
    target2 = text;
    picker.click();
  });
}

// coax/web/docs.js
var ACT_DOC = 31;
var DOC_KIND = 54;
var MOST = 360 * 1024;
var ACCEPT = ".md,.markdown,.txt,.pdf,.docx,text/markdown,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
function startDocs({ send }) {
  let target2 = "", extra = {}, picker = null;
  const key = () => {
    try {
      return JSON.parse(localStorage.getItem("verse.player") || "null")?.key || "";
    } catch {
      return "";
    }
  };
  const base64 = (buf) => {
    const b = new Uint8Array(buf);
    let s = "";
    for (let i = 0;i < b.length; i += 32768)
      s += String.fromCharCode.apply(null, b.subarray(i, i + 32768));
    return btoa(s);
  };
  async function one(file) {
    if (file.size > MOST) {
      send(DOC_KIND, `413
too large`);
      return;
    }
    send(DOC_KIND, `1
${String(file.name).replace(/[\r\n]/g, " ").slice(0, 80)}`);
    try {
      const data = base64(await file.arrayBuffer());
      const r = await fetch(target2, {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        headers: { "Content-Type": "application/json", "X-Verse-Player": key() },
        body: JSON.stringify({ ...extra, name: file.name, data })
      });
      send(DOC_KIND, `${r.status}
${await r.text()}`);
    } catch {
      send(DOC_KIND, `0
`);
    }
  }
  addEventListener("coaxial", (e) => {
    const { code, text } = e.detail || {};
    if (code !== ACT_DOC)
      return;
    const cut = String(text || "").indexOf(`
`);
    const url = cut < 0 ? text : text.slice(0, cut);
    if (!/^\/api\/[A-Za-z0-9/_-]+(\?as=lines)?$/.test(url || ""))
      return;
    target2 = url;
    extra = {};
    if (cut >= 0) {
      try {
        const o = JSON.parse(text.slice(cut + 1));
        if (o && typeof o === "object" && !Array.isArray(o))
          extra = o;
      } catch {}
    }
    if (!picker) {
      picker = Object.assign(document.createElement("input"), { type: "file", accept: ACCEPT });
      picker.hidden = true;
      document.body.appendChild(picker);
      picker.addEventListener("change", () => {
        const f = picker.files?.[0];
        picker.value = "";
        if (f)
          one(f);
      });
    }
    picker.click();
  });
  addEventListener("dragover", (e) => {
    if (target2 && e.dataTransfer?.types?.includes("Files"))
      e.preventDefault();
  });
  addEventListener("drop", (e) => {
    if (!target2 || !e.dataTransfer?.files?.length)
      return;
    e.preventDefault();
    one(e.dataTransfer.files[0]);
  });
}

// coax/web/card.js
var W = 1200;
var H = 630;
var MAX = 300 * 1024;
var SETTLE_MS = 3000;
var AGAIN_MS = 60000;
function startCard({ url, key, snapshot, ready, moment }) {
  if (!url || typeof document === "undefined")
    return;
  const headers = () => key() ? { "X-Verse-Player": key() } : {};
  let busy = false;
  const round = async () => {
    if (busy || document.hidden)
      return;
    busy = true;
    try {
      const want = await fetch(url, { headers: headers(), cache: "no-store" }).then((r) => r.ok ? r.text() : "no");
      if (want.trim() !== "want")
        return;
      let shot = null;
      if (moment)
        shot = await moment();
      else {
        const until = Date.now() + 60000;
        while (!ready() && Date.now() < until)
          await sleep(500);
        await sleep(SETTLE_MS);
        shot = ready() ? await snapshot() : null;
      }
      const frame = shot && !blank(shot) ? shot : null;
      const blob = await jpeg(compose(frame, meta("og:title") || document.title, meta("og:description")));
      if (!blob || blob.size > MAX)
        return;
      await fetch(url, { method: "POST", headers: { ...headers(), "Content-Type": "image/jpeg" }, body: blob });
    } catch {} finally {
      busy = false;
    }
  };
  setTimeout(round, 1000);
  setInterval(round, AGAIN_MS);
}
function startMoment({ key, snapshot }) {
  let held = null;
  const waiting = [];
  if (typeof addEventListener === "undefined")
    return () => Promise.resolve(null);
  addEventListener("coaxial", async (e) => {
    const { code, text } = e.detail || {};
    if (code === 31) {
      const shot = await snapshot();
      if (shot && !blank(shot))
        held = shot;
      for (const w of waiting.splice(0))
        w(held);
    }
    if (code === 32) {
      const [url, title = "", line = ""] = String(text || "").split(`
`);
      if (!/^\/api\/playtest\/replies\/[a-z0-9]{12}\/card$/.test(url || ""))
        return;
      try {
        const blob = await jpeg(compose(held, title, line));
        if (!blob || blob.size > MAX)
          return;
        await fetch(url, { method: "POST", headers: { ...key() ? { "X-Verse-Player": key() } : {}, "Content-Type": "image/jpeg" }, body: blob });
      } catch {}
    }
  });
  return () => held ? Promise.resolve(held) : new Promise((resolve) => waiting.push(resolve));
}
function blank(c) {
  try {
    const t = document.createElement("canvas");
    t.width = 32;
    t.height = 18;
    const g = t.getContext("2d", { willReadFrequently: true });
    g.drawImage(c, 0, 0, 32, 18);
    const px = g.getImageData(0, 0, 32, 18).data;
    let peak = 0;
    for (let i = 0;i < px.length; i += 4)
      peak = Math.max(peak, px[i], px[i + 1], px[i + 2]);
    return peak < 12;
  } catch {
    return true;
  }
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var meta = (p) => document.querySelector(`meta[property="${p}"]`)?.getAttribute("content") || "";
function compose(frame, title, line) {
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const g = c.getContext("2d");
  g.fillStyle = "#000";
  g.fillRect(0, 0, W, H);
  const band = frame ? 180 : H;
  if (frame) {
    const { width: fw, height: fh } = frame, s = Math.max(W / fw, (H - band + 60) / fh);
    const dw = fw * s, dh = fh * s;
    g.drawImage(frame, (W - dw) / 2, (H - band + 60 - dh) / 2, dw, dh);
  } else {
    g.fillStyle = "rgba(255,255,255,0.35)";
    for (let i = 0;i < 90; i++) {
      const x = i * 7919 % W, y = i * 104729 % H;
      g.fillRect(x, y, 1.5, 1.5);
    }
  }
  const top = H - band;
  if (frame) {
    const fade = g.createLinearGradient(0, top - 60, 0, top);
    fade.addColorStop(0, "rgba(0,0,0,0)");
    fade.addColorStop(1, "#000");
    g.fillStyle = fade;
    g.fillRect(0, top - 60, W, 60);
    g.fillStyle = "#000";
    g.fillRect(0, top, W, band);
  }
  g.strokeStyle = "rgba(255,255,255,0.9)";
  g.lineWidth = 2;
  const mark = (x, y, dx, dy) => {
    g.beginPath();
    g.moveTo(x, y + dy * 32);
    g.lineTo(x, y);
    g.lineTo(x + dx * 54, y);
    g.stroke();
  };
  mark(20, top + 12, 1, 1);
  mark(W - 20, H - 12, -1, -1);
  const sans = 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  const small = frame ? top + 36 : 110;
  g.fillStyle = "rgba(255,255,255,0.7)";
  g.font = `400 15px ${sans}`;
  spaced(g, "OPENAGENTS  /  VERSE", 62, small, 2.5);
  g.textAlign = "right";
  spaced(g, "OPENAGENTS.COM", W - 62, small, 2.5, true);
  g.textAlign = "left";
  let size = 58;
  let name = String(title || "").toUpperCase();
  g.font = `200 ${size}px ${sans}`;
  while (size > 28 && g.measureText(name).width + name.length * 6 > W - 124) {
    size -= 2;
    g.font = `200 ${size}px ${sans}`;
  }
  let shown = name;
  while (shown.length > 1 && g.measureText(shown + "...").width + (shown.length + 3) * 6 > W - 124)
    shown = shown.slice(0, -1);
  if (shown !== name)
    name = shown.trimEnd() + "...";
  g.strokeStyle = "#fff";
  g.lineWidth = 1.6;
  spaced(g, name, 62, frame ? top + 98 : 250, 6, false, true);
  g.fillStyle = "rgba(205,210,225,0.9)";
  g.font = `400 22px ${sans}`;
  g.fillText(fit(g, String(line || ""), W - 124), 64, frame ? top + 146 : 320);
  return c;
}
function spaced(g, text, x, y, gap, right = false, outline = false) {
  let w = 0;
  for (const ch of text)
    w += g.measureText(ch).width + gap;
  const align = g.textAlign;
  g.textAlign = "left";
  let at = right ? x - w : x;
  for (const ch of text) {
    if (outline)
      g.strokeText(ch, at, y);
    else
      g.fillText(ch, at, y);
    at += g.measureText(ch).width + gap;
  }
  g.textAlign = align;
}
function fit(g, text, width) {
  if (g.measureText(text).width <= width)
    return text;
  let t = text;
  while (t.length > 1 && g.measureText(t + "...").width > width)
    t = t.slice(0, t.lastIndexOf(" ") > 0 ? t.lastIndexOf(" ") : t.length - 1);
  return t.replace(/[,;:.]$/, "") + "...";
}
async function jpeg(canvas) {
  for (const q of [0.86, 0.78, 0.68, 0.55, 0.4]) {
    const b = await new Promise((r) => canvas.toBlob(r, "image/jpeg", q));
    if (b && b.size <= MAX)
      return b;
  }
  return null;
}

// coax/web/voice.js
var VOICE_KIND = 50;
var ACT_VOICE = 7;
var ACT_VOICE_TO = 8;
var ACT_VOICE_SAY = 9;
var ANSWER_WAIT = 20000;
var LET_GO_WAIT = 20000;
var DEFAULT_HOST = "wss://voice.openagents.com";
var OUT_RATE = 24000;
var AHEAD = 0.2;
var EV = { TURN_START: 1, TURN_END: 2, BARGE_IN: 4, FORWARD: 8, DROPPED: 128, UNDERRUN: 256 };
var MSG = { WELCOME: 2, AUDIO: 3, CONTROL: 4, TURN_EVENT: 5, SPEECH: 6, ERROR: 9 };
var CONTROL = { TURN_START: 1, TURN_END: 2, BARGE_IN: 3, CANCEL: 5, PING: 6, PONG: 7, SPEECH_END: 8 };
var PHASE = { PARTIAL: 2, FINAL: 3, INTERRUPTED: 4, ENDED: 5 };
var WORDS = {
  3: "Today's free voice time is used up.",
  4: "Speech isn't working right now. Try again in a moment.",
  5: "That was too long for one turn. Try a shorter one.",
  2: "This voice server won't take this browser."
};
var WORKLET = `
class OaVoice extends AudioWorkletProcessor {
  constructor() {
    super(); this.q = []; this.at = 0; this.played = 0; this.since = 0;
    this.port.onmessage = (e) => { if (e.data === "flush") { this.q = []; this.at = 0; } else this.q.push(e.data); };
  }
  process(inputs, outputs) {
    const mic = inputs[0] && inputs[0][0];
    if (mic) this.port.postMessage(mic.slice(0));
    const out = outputs[0][0];
    let n = 0;
    while (n < out.length && this.q.length) {
      const b = this.q[0], k = Math.min(out.length - n, b.length - this.at);
      out.set(b.subarray(this.at, this.at + k), n); n += k; this.at += k;
      if (this.at >= b.length) { this.q.shift(); this.at = 0; }
    }
    for (let c = 1; c < outputs[0].length; c++) outputs[0][c].set(out);
    this.played += n; this.since += out.length;
    if (this.since >= 960) { this.port.postMessage(this.played); this.since = 0; }
    return true;
  }
}
registerProcessor("oa-voice", OaVoice);`;
var wasi = new Proxy({}, { get: (_, name) => name === "proc_exit" ? (c) => {
  throw new Error(`voice.wasm exit ${c}`);
} : () => 52 });
function startVoice({ send, route, wasmUrl }) {
  const params = new URLSearchParams(location.search);
  const host = params.get("voice") || DEFAULT_HOST;
  let speaker = "";
  try {
    speaker = localStorage.getItem("verse.voice.speaker") || "";
  } catch {}
  if (!/^web-[0-9a-f]{12}$/.test(speaker)) {
    speaker = "web-" + [...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, "0")).join("");
    try {
      localStorage.setItem("verse.voice.speaker", speaker);
    } catch {}
  }
  let x = null, mem = null, ctx = null, node = null, mic = null, ws = null, timer = 0;
  let running = false, welcomed = false, frame = 320, pending = new Float32Array(0), backoff = 0.5;
  let turn = "", turns = 0, speaking = false, ended = false, utterance = "", replyTurn = "", sent = 0, played = 0, playedAtStart = 0;
  let phase = "off", caption = "";
  let facing = "", heardTurn = "", heardAt = 0, letGo = 0;
  const enc = new TextEncoder, dec = new TextDecoder;
  const show = (p, c = caption) => {
    if (p === phase && c === caption)
      return;
    phase = p;
    caption = c;
    send(VOICE_KIND, `${p}|${c.replace(/[\r\n|]+/g, " ")}`);
    if (letGo && p === "listening")
      setTimeout(() => {
        if (letGo)
          off();
      }, 0);
    (globalThis.coaxialVoice ||= []).push(`${p}|${c}`);
  };
  const u8 = (p, n) => new Uint8Array(mem.buffer, p, n);
  const strings = (...s) => {
    const b = s.map((t) => enc.encode(t).slice(0, 255));
    let at = 0;
    for (const t of b) {
      u8(x.vw_text() + at, t.length).set(t);
      at += t.length;
    }
    return b.map((t) => t.length);
  };
  const string = (i) => dec.decode(u8(x.vw_text(), x.vw_string(i)).slice());
  const out = (n) => {
    if (n && ws?.readyState === 1)
      ws.send(u8(x.vw_out(), n).slice());
  };
  const control = (kind, t = "", utt = "", playedSamples = 0) => {
    const [a, b] = strings(t, utt);
    out(x.vw_control(kind, a, b, playedSamples, Date.now()));
  };
  async function engine() {
    if (x)
      return;
    const r = await fetch(wasmUrl);
    const { instance } = await WebAssembly.instantiate(await r.arrayBuffer(), { wasi_snapshot_preview1: wasi });
    x = instance.exports;
    mem = x.memory;
    x._initialize?.();
  }
  async function on() {
    if (letGo) {
      clearTimeout(letGo);
      letGo = 0;
      off();
    }
    if (running)
      return;
    running = true;
    show("connecting", "");
    try {
      ctx = new AudioContext;
      const resumed = ctx.resume();
      mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
      await resumed;
      await engine();
      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([WORKLET], { type: "text/javascript" })));
      node = new AudioWorkletNode(ctx, "oa-voice", { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1] });
      node.port.onmessage = (e) => {
        if (typeof e.data === "number")
          played = e.data;
        else
          take(e.data);
      };
      ctx.createMediaStreamSource(mic).connect(node);
      node.connect(ctx.destination);
      frame = x.vw_start(Math.round(ctx.sampleRate));
      if (x.vw_rate() !== Math.round(ctx.sampleRate))
        throw new Error(`no engine for ${ctx.sampleRate} Hz`);
    } catch (e) {
      console.warn("voice:", e);
      off(e?.name === "NotAllowedError" ? "Voice needs the microphone. Allow it for this site and try again." : "Voice can't use the microphone here.");
      return;
    }
    connect();
    timer = setInterval(tick, 10);
  }
  function off(notice = "") {
    if (letGo) {
      clearTimeout(letGo);
      letGo = 0;
    }
    if (!running)
      return;
    running = false;
    if (turn)
      control(CONTROL.CANCEL, turn);
    clearInterval(timer);
    timer = 0;
    try {
      ws?.close();
    } catch {}
    ws = null;
    welcomed = false;
    turn = "";
    speaking = false;
    mic?.getTracks().forEach((t) => t.stop());
    mic = null;
    ctx?.close().catch(() => {});
    ctx = null;
    node = null;
    pending = new Float32Array(0);
    show(notice ? "notice" : "off", notice);
  }
  function connect() {
    if (!running)
      return;
    const s = new WebSocket(host);
    s.binaryType = "arraybuffer";
    ws = s;
    s.onopen = () => {
      backoff = 0.5;
      const [a, b] = strings(speaker, route);
      out(x.vw_hello(a, b, OUT_RATE));
      if (facing) {
        const [t] = strings(facing);
        out(x.vw_route(t));
      }
    };
    s.onmessage = (e) => {
      if (e.data instanceof ArrayBuffer)
        receive(new Uint8Array(e.data));
    };
    s.onclose = () => {
      if (ws !== s || !running)
        return;
      welcomed = false;
      turn = "";
      cut();
      show("connecting", "Voice needs a connection. Trying again…");
      setTimeout(connect, backoff * 1000);
      backoff = Math.min(backoff * 2, 10);
    };
  }
  function release() {
    if (!running)
      return;
    mic?.getTracks().forEach((t) => t.stop());
    mic = null;
    pending = new Float32Array(0);
    if (!turn && !heardTurn) {
      off();
      return;
    }
    if (turn) {
      control(CONTROL.TURN_END, turn);
      turn = "";
      show("thinking");
    }
    letGo = setTimeout(() => {
      letGo = 0;
      off();
    }, LET_GO_WAIT);
  }
  function take(samples) {
    const all = new Float32Array(pending.length + samples.length);
    all.set(pending);
    all.set(samples, pending.length);
    pending = all;
  }
  function tick() {
    if (!running || !x)
      return;
    const input = new Int16Array(mem.buffer, x.vw_in(), frame);
    while (pending.length >= frame) {
      for (let i = 0;i < frame; i++)
        input[i] = Math.max(-32768, Math.min(32767, Math.round(pending[i] * 32767)));
      pending = pending.subarray(frame);
      uplink();
    }
    feed();
    if (heardTurn && Date.now() - heardAt > ANSWER_WAIT) {
      heardTurn = "";
      if (phase === "heard" || phase === "thinking")
        show("listening", "");
    }
  }
  function uplink() {
    const ev = x.vw_uplink();
    if (ev & EV.BARGE_IN)
      bargeIn();
    if (ev & EV.TURN_START && welcomed) {
      turn = `${speaker}-${++turns}`;
      control(CONTROL.TURN_START, turn);
      const n = x.vw_preroll();
      const [t] = strings(turn);
      for (let off2 = 0;off2 < n; off2 += 4800)
        out(x.vw_audio(t, 1, off2, Math.min(4800, n - off2)));
      show("hearing", "");
    }
    if (ev & (EV.FORWARD | EV.TURN_START) && !(ev & EV.DROPPED) && turn && welcomed) {
      const [t] = strings(turn);
      out(x.vw_audio(t, 0, 0, 0));
    }
    if (ev & EV.TURN_END && turn) {
      control(CONTROL.TURN_END, turn);
      turn = "";
      show("thinking");
    }
  }
  function feed() {
    if (!speaking || !ctx)
      return;
    const ratio = ctx.sampleRate / OUT_RATE;
    x.vw_playing(sent > played ? 1 : 0);
    while (sent - played < AHEAD * ctx.sampleRate) {
      const n = OUT_RATE / 50;
      const ev = x.vw_pop(n, OUT_RATE);
      if (ev & EV.UNDERRUN) {
        if (ended && x.vw_depth() === 0 && sent <= played) {
          speaking = false;
          x.vw_playing(0);
          show("listening", "");
        }
        break;
      }
      const pcm = new Int16Array(mem.buffer, x.vw_play(), n);
      const m = Math.round(n * ratio), f = new Float32Array(m);
      for (let i = 0;i < m; i++) {
        const p = i / ratio, k = Math.floor(p), t = p - k;
        const a = pcm[Math.min(k, n - 1)], b = pcm[Math.min(k + 1, n - 1)];
        f[i] = (a + (b - a) * t) / 32768;
      }
      node.port.postMessage(f, [f.buffer]);
      sent += m;
    }
  }
  function cut() {
    node?.port.postMessage("flush");
    if (x) {
      x.vw_flush();
      x.vw_playing(0);
    }
    sent = played;
    speaking = false;
  }
  function bargeIn() {
    if (!speaking)
      return;
    const heard = Math.max(0, Math.round((played - playedAtStart) * OUT_RATE / ctx.sampleRate));
    cut();
    x.vw_cut();
    control(CONTROL.BARGE_IN, replyTurn, utterance, heard);
  }
  function receive(bytes) {
    if (bytes.length > 16384)
      return;
    u8(x.vw_frame(), bytes.length).set(bytes);
    const kind = x.vw_decode(bytes.length);
    if (kind === MSG.WELCOME) {
      welcomed = true;
      show("listening", "");
    } else if (kind === MSG.TURN_EVENT) {
      const p = x.vw_field(0), text = string(0);
      if (p === PHASE.PARTIAL && !speaking)
        show("hearing", text);
      else if (p === PHASE.FINAL) {
        if (facing) {
          heardTurn = string(2);
          heardAt = Date.now();
        }
        show("heard", text);
      } else if ((p === PHASE.ENDED || p === PHASE.INTERRUPTED) && !speaking && (phase === "thinking" || phase === "heard"))
        show("listening", "");
    } else if (kind === MSG.SPEECH) {
      const epoch = x.vw_field(3), text = string(0), utt = string(1), t = string(2);
      globalThis.coaxialVoiceWho = string(3);
      if (epoch && epoch < x.vw_epoch())
        return;
      if (speaking && utt && utt === utterance) {
        show("replying", text);
        return;
      }
      if (epoch)
        x.vw_set_epoch(epoch);
      if (speaking)
        cut();
      speaking = true;
      ended = false;
      utterance = utt;
      replyTurn = t;
      playedAtStart = played;
      sent = played;
      show("replying", text);
    } else if (kind === MSG.AUDIO) {
      if (speaking)
        x.vw_push();
    } else if (kind === MSG.CONTROL) {
      const k = x.vw_field(0);
      if (k === CONTROL.SPEECH_END)
        ended = true;
      else if (k === CONTROL.CANCEL) {
        cut();
        show("listening", "");
      } else if (k === CONTROL.PING)
        control(CONTROL.PONG);
    } else if (kind === MSG.ERROR) {
      console.warn("voice host:", string(0));
      if (!welcomed && x.vw_field(0) === 3) {
        off(WORDS[3]);
        return;
      }
      show(phase === "thinking" || phase === "heard" ? "listening" : phase, WORDS[x.vw_field(0)] || "Voice hit a problem. Try again.");
    }
  }
  function face(name) {
    if (name === facing)
      return;
    facing = name;
    heardTurn = "";
    if (x && ws?.readyState === 1) {
      const [t] = strings(name);
      out(x.vw_route(t));
    }
  }
  function say(words) {
    if (!running || !heardTurn || !welcomed || ws?.readyState !== 1)
      return;
    const t = enc.encode(heardTurn).slice(0, 64);
    let w = enc.encode(words.replace(/\s+/g, " ").trim());
    if (w.length > 600) {
      let n = 600;
      while (n && (w[n] & 192) === 128)
        n--;
      w = w.slice(0, n);
    }
    heardTurn = "";
    if (!w.length)
      return;
    u8(x.vw_text(), t.length).set(t);
    u8(x.vw_text() + t.length, w.length).set(w);
    out(x.vw_say(t.length, w.length));
    show("thinking", caption);
  }
  return { toggle: (want) => want === "end" ? release() : want ? on() : off(), running: () => running, face, say };
}

// coax/web/gpui.js
var LEVELS = 2;
var STROKE = [0, 0];
var WIDTH = 8192;
var CELL_EM = 1.6;
var PEN_X = 0.2;
var PEN_Y = 0.7;
var SUBPIXEL = 4;
var DYN_MONO = 2048;
var DYN_COLOR = 256;
var FALLBACK = 'system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji"';
var family = (weight) => `zr-geist-${weight}`;
function startGpui({ device, memory, assets, say }) {
  const fontUrls = assets.filter((a) => a.kind === "font").map((a) => a.url);
  const iconsUrl = assets.find((a) => a.kind === "icons")?.url;
  const placeholder = (format) => device.createTexture({ size: [1, 1], format, usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
  const g = { mono: placeholder("r8unorm"), color: placeholder("rgba8unorm"), built: 0, version: 0 };
  let icons = {};
  const loaded = (async () => {
    await Promise.all(fontUrls.slice(0, 4).map(async (url, weight) => {
      const face = new FontFace(family(weight), await (await fetch(url)).arrayBuffer());
      await face.load();
      document.fonts.add(face);
    }));
    if (iconsUrl)
      icons = await (await fetch(iconsUrl)).json();
  })().catch((e) => say?.(`gpui: ${e.message}`, true));
  const measure = new OffscreenCanvas(8, 8).getContext("2d");
  measure.fontKerning = "normal";
  const metrics = new Map;
  function fontMetrics(weight, codes) {
    if (metrics.has(weight))
      return metrics.get(weight);
    const n = codes.length, big = 1000;
    measure.font = `${big}px "${family(weight)}"`;
    const m = measure.measureText("H");
    const advance = codes.map((c) => measure.measureText(String.fromCodePoint(c)).width / big);
    const kern = new Float32Array(n * n);
    if (weight !== 3)
      for (let a = 1;a < 95; a++)
        for (let b = 1;b < 95; b++) {
          const k = measure.measureText(String.fromCodePoint(codes[a], codes[b])).width / big - advance[a] - advance[b];
          if (Math.abs(k) > 0.000001)
            kern[a * n + b] = k;
        }
    const out = { ascent: m.fontBoundingBoxAscent / big, descent: m.fontBoundingBoxDescent / big, advance, kern };
    metrics.set(weight, out);
    return out;
  }
  function ink(ctx, text, x, y, level) {
    ctx.fillText(text, x, y);
    if (STROKE[level] > 0) {
      ctx.lineWidth = STROKE[level];
      ctx.strokeText(text, x, y);
    }
  }
  async function build(x, state, dpr) {
    await loaded;
    await document.fonts.ready;
    const glyphs = x.coaxial_gpui_glyphs(), fonts = x.coaxial_gpui_fonts(), count = x.coaxial_gpui_icons();
    const codes = Array.from({ length: glyphs }, (_, i) => x.coaxial_gpui_glyph_code(i));
    const slots = [];
    let y0 = 0;
    for (let f = 0;f < fonts; f++) {
      const size = x.coaxial_gpui_font_size(f), weight = x.coaxial_gpui_font_weight(f);
      const cell = Math.ceil(size * dpr * CELL_EM), cols = Math.floor(WIDTH / cell);
      const rows = Math.ceil(glyphs * SUBPIXEL * LEVELS / cols);
      slots.push({ size, weight, cell, cols, rows, y0, penX: Math.round(cell * PEN_X), penY: Math.round(cell * PEN_Y) });
      y0 += rows * cell;
    }
    let iconX = 0, iconY = y0, rowH = 0;
    const tiles = [];
    for (let i = 0;i < count; i++) {
      const px = Math.ceil(x.coaxial_gpui_icon_size(i) * dpr * 2);
      if (iconX + px > WIDTH) {
        iconX = 0;
        iconY += rowH;
        rowH = 0;
      }
      tiles.push([iconX, iconY, px]);
      iconX += px + 2;
      rowH = Math.max(rowH, px + 2);
    }
    const dynCell = Math.max(...slots.map((s) => s.cell)), dynY0 = iconY + rowH + 1, dynCols = Math.floor(WIDTH / dynCell);
    const height = Math.min(device.limits.maxTextureDimension2D, dynY0 + Math.ceil(DYN_MONO / dynCols) * dynCell);
    const alpha = new Uint8Array(WIDTH * height);
    const scratch = () => new Float32Array(memory.buffer, x.coaxial_gpui_scratch(state), 7 + glyphs + glyphs * glyphs);
    for (let f = 0;f < fonts; f++) {
      const s = slots[f], m = fontMetrics(s.weight, codes);
      const sc = scratch();
      sc.set([m.ascent * s.size, m.descent * s.size, s.cell, s.penX, s.penY, s.y0, s.cols], 0);
      for (let i = 0;i < glyphs; i++)
        sc[7 + i] = m.advance[i] * s.size;
      for (let k = 0;k < glyphs * glyphs; k++)
        sc[7 + glyphs + k] = m.kern[k] * s.size;
      x.coaxial_gpui_set_font(state, f);
      const h = s.rows * s.cell, canvas = new OffscreenCanvas(WIDTH, h), ctx = canvas.getContext("2d", { willReadFrequently: true });
      ctx.font = `${s.size * dpr}px "${family(s.weight)}"`;
      ctx.fontKerning = "none";
      ctx.textBaseline = "alphabetic";
      ctx.fillStyle = ctx.strokeStyle = "#fff";
      for (let level = 0;level < LEVELS; level++)
        for (let variant = 0;variant < SUBPIXEL; variant++)
          for (let i = 0;i < glyphs; i++) {
            const c = codes[i];
            if (c === 32 || c === 160)
              continue;
            const cell = (level * SUBPIXEL + variant) * glyphs + i;
            const cx = cell % s.cols * s.cell, cy = Math.floor(cell / s.cols) * s.cell;
            ctx.save();
            ctx.beginPath();
            ctx.rect(cx, cy, s.cell, s.cell);
            ctx.clip();
            ink(ctx, String.fromCodePoint(c), cx + s.penX + variant / SUBPIXEL, cy + s.penY, level);
            ctx.restore();
          }
      const px = ctx.getImageData(0, 0, WIDTH, h).data;
      for (let k = 0, o = s.y0 * WIDTH;k < WIDTH * h; k++)
        alpha[o + k] = px[k * 4 + 3];
    }
    const nameAt = () => new Uint8Array(memory.buffer, x.coaxial_gpui_bytes(state), 64);
    await Promise.all(tiles.map(async ([tx, ty, px], i) => {
      const n = x.coaxial_gpui_icon_name(state, i);
      const svg = icons[new TextDecoder().decode(nameAt().slice(0, n))];
      if (!svg)
        return;
      const sized = svg.replace(/<svg\b[^>]*>/, (head) => head.replace(/\s(width|height)="[^"]*"/g, "").replace("<svg", `<svg width="${px}" height="${px}"`));
      const url = URL.createObjectURL(new Blob([sized], { type: "image/svg+xml" }));
      try {
        const img = new Image;
        img.src = url;
        await img.decode();
        const c = new OffscreenCanvas(px, px), ctx = c.getContext("2d", { willReadFrequently: true });
        ctx.drawImage(img, 0, 0, px, px);
        const d = ctx.getImageData(0, 0, px, px).data;
        for (let yy = 0;yy < px; yy++)
          for (let xx = 0;xx < px; xx++)
            alpha[(ty + yy) * WIDTH + tx + xx] = d[(yy * px + xx) * 4 + 3];
        x.coaxial_gpui_set_icon(state, i, tx, ty, px, px);
      } finally {
        URL.revokeObjectURL(url);
      }
    }));
    const mono = device.createTexture({ size: [WIDTH, height], format: "r8unorm", usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
    device.queue.writeTexture({ texture: mono }, alpha, { bytesPerRow: WIDTH }, [WIDTH, height]);
    const colorCols = Math.floor(WIDTH / dynCell), colorHeight = Math.ceil(DYN_COLOR / colorCols) * dynCell;
    const color = device.createTexture({ size: [WIDTH, colorHeight], format: "rgba8unorm", usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
    g.mono.destroy();
    g.color.destroy();
    Object.assign(g, { mono, color, dpr, dynCell, penX: Math.round(dynCell * PEN_X), penY: Math.round(dynCell * PEN_Y), slots });
    x.coaxial_gpui_set_atlas(state, WIDTH, height, LEVELS);
    x.coaxial_gpui_set_dynamic(state, dynCell, g.penX, g.penY, dynY0, dynCols, colorCols, WIDTH, colorHeight);
    g.version += 1;
  }
  const cellCanvas = new OffscreenCanvas(8, 8);
  const probe = new OffscreenCanvas(40, 40).getContext("2d", { willReadFrequently: true });
  function cluster(x, state, slot) {
    const code = x.coaxial_gpui_cluster(state, slot), n = code & 255, font = code >> 8;
    const text = new TextDecoder().decode(new Uint8Array(memory.buffer, x.coaxial_gpui_bytes(state), n).slice());
    return { text, slot: g.slots[Math.min(Math.max(font, 0), g.slots.length - 1)] };
  }
  function serve(x, state) {
    if (!g.slots)
      return;
    for (let k = 0, slot;k < 600 && (slot = x.coaxial_gpui_next_cluster(state)) >= 0; k++) {
      const { text, slot: s } = cluster(x, state, slot);
      measure.font = `${s.size}px "${family(s.weight)}", ${FALLBACK}`;
      const advance = measure.measureText(text).width;
      probe.clearRect(0, 0, 40, 40);
      probe.font = `28px "${family(s.weight)}", ${FALLBACK}`;
      probe.fillStyle = "#f00";
      probe.textBaseline = "alphabetic";
      probe.fillText(text, 4, 30);
      const d = probe.getImageData(0, 0, 40, 40).data;
      let colored = false;
      for (let i = 0;i < d.length && !colored; i += 4)
        if (d[i + 3] > 64 && (d[i + 1] > 60 || d[i + 2] > 60))
          colored = true;
      x.coaxial_gpui_measured(state, slot, advance, colored ? 1 : 0);
    }
    const side = g.dynCell;
    if (cellCanvas.width !== side) {
      cellCanvas.width = side;
      cellCanvas.height = side;
    }
    const ctx = cellCanvas.getContext("2d", { willReadFrequently: true });
    for (let k = 0, cell;k < 3000 && (cell = x.coaxial_gpui_next_cell(state)) >= 0; k++) {
      if (!x.coaxial_gpui_cell(state, cell))
        break;
      const [slot, level, variant, isColor, tx, ty] = new Float32Array(memory.buffer, x.coaxial_gpui_scratch(state), 6);
      const { text, slot: s } = cluster(x, state, slot);
      if (ty + side > (isColor > 0.5 ? g.color : g.mono).height) {
        x.coaxial_gpui_cell_ready(state, cell);
        continue;
      }
      ctx.clearRect(0, 0, side, side);
      ctx.font = `${s.size * g.dpr}px "${family(s.weight)}", ${FALLBACK}`;
      ctx.textBaseline = "alphabetic";
      ctx.fillStyle = ctx.strokeStyle = "#fff";
      if (isColor > 0.5) {
        ctx.fillText(text, g.penX, g.penY);
        const d = ctx.getImageData(0, 0, side, side).data;
        device.queue.writeTexture({ texture: g.color, origin: [tx, ty] }, d, { bytesPerRow: side * 4 }, [side, side]);
      } else {
        ink(ctx, text, g.penX + variant / SUBPIXEL, g.penY, Math.min(level, LEVELS - 1));
        const d = ctx.getImageData(0, 0, side, side).data, a = new Uint8Array(side * side);
        for (let i = 0;i < a.length; i++)
          a[i] = d[i * 4 + 3];
        device.queue.writeTexture({ texture: g.mono, origin: [tx, ty] }, a, { bytesPerRow: side }, [side, side]);
      }
      x.coaxial_gpui_cell_ready(state, cell);
    }
  }
  return { g, build, serve };
}

// coax/web/loader.js
var esc = (s) => String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
var LOADER_CSS = `#coaxial-load{position:fixed;inset:0;z-index:2;display:flex;align-items:center;justify-content:center;padding:0 16px;background:#000;color:#f0f0f0;font:500 11px/1.5 ui-monospace,"SF Mono",SFMono-Regular,Menlo,Consolas,monospace;letter-spacing:.14em;text-transform:uppercase;transition:opacity .35s ease-out}
#coaxial-load.gone{opacity:0;pointer-events:none}
#coaxial-load .lf{position:relative;box-sizing:border-box;width:min(360px,100%);padding:22px 22px 20px;background:rgba(240,240,240,.28);clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px))}
#coaxial-load .lf::before{content:"";position:absolute;inset:1px;background:#000;clip-path:polygon(0 0,calc(100% - 11.6px) 0,100% 11.6px,100% 100%,11.6px 100%,0 calc(100% - 11.6px))}
#coaxial-load .lf>*{position:relative}
#coaxial-load .lf>s{position:absolute;width:22px;height:13px;border:0 solid #f0f0f0}
#coaxial-load .lf>.c1{top:0;left:0;border-width:1px 0 0 1px}
#coaxial-load .lf>.c2{right:0;bottom:0;border-width:0 1px 1px 0}
#coaxial-load .ln{display:block;margin:0 0 18px;font:600 16px/1.3 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;letter-spacing:.2em;overflow-wrap:anywhere}
#coaxial-load .lr{display:grid;grid-template-columns:1fr auto;column-gap:12px}
#coaxial-load .lb{grid-column:1/3;display:block;height:2px;margin:0 0 10px;background:rgba(240,240,240,.14);overflow:hidden}
#coaxial-load .lb i{display:block;height:100%;background:hsl(180,68.07%,53.33%);transform:scaleX(0);transform-origin:0 50%;transition:transform .2s linear}
#coaxial-load .lt{color:#c7c7c7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#coaxial-load .lp{color:#999;font-variant-numeric:tabular-nums}
#coaxial-load .le,#coaxial-load .la{display:none}
html:not(.gpu) #coaxial-load .lr,#coaxial-load[data-state=fail] .lr{display:none}
html:not(.gpu) #coaxial-load .le,#coaxial-load[data-state=fail] .le{display:block;color:#f0f0f0}
html:not(.gpu) #coaxial-load .la,#coaxial-load[data-state=fail] .la{display:inline-block;margin-top:16px;padding:8px 12px;border:1px solid rgba(240,240,240,.45);color:#f0f0f0;text-decoration:none}
#coaxial-load .la:hover,#coaxial-load .la:focus-visible{color:hsl(180,68.07%,53.33%);border-color:hsl(180,68.07%,53.33%);outline:none}
@media (prefers-reduced-motion:reduce){#coaxial-load,#coaxial-load .lb i{transition:none}}`;
function loaderMarkup(title, href) {
  const t = esc(title), h = esc(href);
  return `<!-- loader: coax/web/loader.js -->
<div id="coaxial-load" role="progressbar" aria-label="Loading ${t}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="lf"><s class="c1"></s><s class="c2"></s>
<b class="ln">${t}</b>
<div class="lr"><i class="lb"><i></i></i><span class="lt">ENGINE</span><span class="lp">0%</span></div>
<span class="le">NO WEBGPU IN THIS BROWSER</span>
<a class="la" href="${h}">READ ABOUT ${t}</a>
</div></div>
<!-- /loader -->`;
}
var SHARE = { engine: 30, compile: 5, gpu: 3, shaders: 12, assets: 40, textures: 5, world: 5 };
var ORDER2 = ["engine", "compile", "gpu", "shaders", "assets", "textures", "world"];
var mb = (n) => (n / 1048576).toFixed(1);
async function readBytes(response, progress) {
  const total = Number(response.headers.get("x-goog-meta-length") || (response.headers.get("content-encoding") ? 0 : response.headers.get("content-length"))) || 0;
  if (!response.body) {
    const b = new Uint8Array(await response.arrayBuffer());
    progress(b.length, b.length);
    return b;
  }
  const reader = response.body.getReader(), chunks = [];
  let loaded = 0;
  for (;; ) {
    const { done, value } = await reader.read();
    if (done)
      break;
    chunks.push(value);
    loaded += value.length;
    progress(loaded, Math.max(total, loaded));
  }
  if (chunks.length === 1)
    return chunks[0];
  const out = new Uint8Array(loaded);
  let at = 0;
  for (const c of chunks) {
    out.set(c, at);
    at += c.length;
  }
  return out;
}
var NONE = { on: false, engine() {}, step() {}, watch() {}, bytes() {}, textures() {}, assetDone() {}, frame() {}, fail() {} };
function startLoading({ realm, assets = 0, textured = false, scene = false, golden = false }) {
  let el = document.getElementById("coaxial-load");
  if (!el && realm) {
    const h1 = document.querySelector("main h1"), link = document.querySelector("main a[href]");
    const style = document.head.appendChild(document.createElement("style"));
    style.textContent = LOADER_CSS;
    document.body.insertAdjacentHTML("afterbegin", loaderMarkup(h1?.textContent || "Realm", link?.getAttribute("href") || location.pathname));
    el = document.getElementById("coaxial-load");
  }
  if (!el)
    return NONE;
  const bar = el.querySelector(".lb i"), line = el.querySelector(".lt"), pct = el.querySelector(".lp");
  const share = { ...SHARE, assets: assets ? SHARE.assets : 0, textures: textured ? SHARE.textures : 0 };
  const whole = ORDER2.reduce((s, k) => s + share[k], 0);
  const done = Object.fromEntries(ORDER2.map((k) => [k, 0]));
  let text = "ENGINE", shown = -1, queued = false, phase = "engine", finished = false, failed = false;
  const files = new Map, tex = { done: 0, total: 0 };
  let left = assets, pipes = 0, pipesDone = 0, worldFrames = 0;
  const paint = () => {
    queued = false;
    if (finished && !failed)
      return;
    const f = ORDER2.reduce((s, k) => s + share[k] * Math.min(1, done[k]), 0) / whole;
    const p = Math.max(shown, Math.floor(f * 100));
    if (p !== shown) {
      shown = p;
      bar.style.transform = `scaleX(${p / 100})`;
      pct.textContent = `${p}%`;
      el.setAttribute("aria-valuenow", String(p));
    }
    if (line.textContent !== text)
      line.textContent = text;
  };
  const later = () => {
    if (!queued) {
      queued = true;
      requestAnimationFrame(paint);
    }
  };
  const enter = (k, t) => {
    const at = ORDER2.indexOf(k);
    for (let i = 0;i < at; i++)
      done[ORDER2[i]] = 1;
    phase = k;
    text = t;
    later();
  };
  const finish = () => {
    finished = true;
    if (golden) {
      el.remove();
      return;
    }
    el.classList.add("gone");
    const away = () => el.remove();
    el.addEventListener("transitionend", away, { once: true });
    setTimeout(away, 600);
  };
  const within = () => {
    if (phase !== "assets" && phase !== "textures")
      return;
    let l = 0, t = 0;
    for (const [a, b] of files.values()) {
      l += a;
      t += b;
    }
    done.assets = t ? l / t : 0;
    done.textures = tex.total ? tex.done / tex.total : 0;
    if (l < t || !t) {
      phase = "assets";
      text = t ? `ASSETS ${mb(l)} / ${mb(t)} MB` : "ASSETS";
    } else if (textured && tex.done < tex.total) {
      phase = "textures";
      text = `TEXTURES ${tex.done}/${tex.total}`;
    } else
      text = `ASSETS ${mb(l)} / ${mb(t)} MB`;
    later();
  };
  const assetsIn = () => {
    if (left > 0)
      return;
    enter("world", "WORLD");
  };
  return {
    on: true,
    engine(loaded, total) {
      if (finished)
        return;
      done.engine = total ? loaded / total : 0;
      text = total ? `ENGINE ${mb(loaded)} / ${mb(total)} MB` : `ENGINE ${mb(loaded)} MB`;
      later();
    },
    step(k) {
      if (finished)
        return;
      if (k === "compile")
        enter("compile", "COMPILING ENGINE");
      else if (k === "gpu")
        enter("gpu", "GPU DEVICE");
      else if (k === "shaders")
        enter("shaders", "SHADERS");
      else if (k === "assets") {
        if (assets)
          enter("assets", "ASSETS");
        else
          assetsIn();
      }
    },
    watch(device) {
      const make = device.createRenderPipelineAsync.bind(device);
      device.createRenderPipelineAsync = (d) => {
        pipes += 1;
        const count = () => {
          pipesDone += 1;
          if (!finished && phase === "shaders") {
            done.shaders = pipesDone / pipes;
            text = `SHADERS ${pipesDone}/${pipes}`;
            later();
          }
        };
        if (!finished && phase === "shaders") {
          text = `SHADERS ${pipesDone}/${pipes}`;
          later();
        }
        const p = make(d);
        p.then(count, count);
        return p;
      };
    },
    bytes(key, loaded, total) {
      if (finished)
        return;
      files.set(key, [loaded, Math.max(total, loaded)]);
      within();
    },
    textures(n, total) {
      if (finished)
        return;
      tex.done += n;
      tex.total += total;
      within();
    },
    assetDone(failedWhat) {
      if (finished)
        return;
      if (failedWhat) {
        this.fail(failedWhat);
        return;
      }
      left -= 1;
      assetsIn();
    },
    frame(sceneDrawn) {
      if (finished || phase !== "world")
        return;
      worldFrames += 1;
      if (!scene || sceneDrawn || worldFrames > 120) {
        done.world = 1;
        paint();
        finish();
      }
    },
    fail(what, nogpu = false) {
      if (finished)
        return;
      finished = true;
      failed = true;
      const le = el.querySelector(".le"), la = el.querySelector(".la");
      el.setAttribute("aria-valuenow", String(Math.max(0, shown)));
      if (nogpu) {
        document.documentElement.classList.remove("gpu");
        el.dataset.state = "fail";
        return;
      }
      le.textContent = String(what).slice(0, 160);
      la.textContent = "TRY AGAIN";
      la.setAttribute("href", "");
      la.addEventListener("click", (e) => {
        e.preventDefault();
        location.reload();
      });
      el.dataset.state = "fail";
    }
  };
}

// coax/web/http-requests.js
function makeHttpRequests({
  fetch: fetchEffect = globalThis.fetch.bind(globalThis),
  emit,
  capacity = () => 65536,
  player = () => null,
  sendBeacon,
  origin = globalThis.location?.origin,
  setTimer = (fn, ms) => setTimeout(fn, ms),
  clearTimer = (id) => clearTimeout(id)
} = {}) {
  const slots = new Array(8).fill(null);
  let generation = 0;
  const owns = (r) => slots[r.id] === r && r.generation === generation;
  function release(r) {
    slots[r.id] = null;
    if (r.timer !== null)
      clearTimer(r.timer);
  }
  function finish(r, text, abort = false) {
    if (!owns(r))
      return;
    release(r);
    try {
      emit(r.id, text);
    } finally {
      if (abort)
        r.controller.abort();
    }
  }
  async function boundedBody(r, response) {
    const header = `${response.status}
`;
    const limit = r.capacity - new TextEncoder().encode(header).length;
    if (limit < 0)
      throw Error("response header exceeds inbox");
    if (!response.body)
      return header;
    const reader = response.body.getReader(), chunks = [];
    let total = 0;
    try {
      while (owns(r)) {
        const chunk = await reader.read();
        if (!owns(r)) {
          await reader.cancel();
          return null;
        }
        if (chunk.done)
          break;
        if (chunk.value.byteLength > limit - total) {
          await reader.cancel();
          throw Error("response exceeds inbox");
        }
        total += chunk.value.byteLength;
        chunks.push(chunk.value);
      }
      if (!owns(r))
        return null;
      const bytes = new Uint8Array(total);
      let offset = 0;
      for (const chunk of chunks) {
        bytes.set(chunk, offset);
        offset += chunk.byteLength;
      }
      return header + new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } finally {
      reader.releaseLock?.();
    }
  }
  function request(url, input, flags, timeoutMs) {
    if (typeof url !== "string" || !url.startsWith("/") || url.startsWith("//"))
      return -1;
    try {
      if (origin && new URL(url, origin).origin !== origin)
        return -1;
    } catch {
      return -1;
    }
    const post = (flags & 1) !== 0, wanted = (flags & 4) !== 0;
    const bounded = timeoutMs !== undefined;
    const cap = bounded ? capacity() : 0;
    if (bounded && (!wanted || flags & 2 || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 2147483647 || !Number.isInteger(cap) || cap < 2))
      return -1;
    let body = input?.byteLength ? new Uint8Array(input).slice() : null;
    const originalLength = body?.byteLength ?? 0;
    let auth = "";
    if (flags & 16 && body) {
      const nl = body.indexOf(10);
      if (nl < 0)
        return -1;
      auth = new TextDecoder().decode(body.subarray(0, nl));
      body = body.slice(nl + 1);
    }
    if (flags & 2 && sendBeacon?.(url, new Blob([body || ""], { type: "application/json" })))
      return 0;
    const id = wanted ? slots.indexOf(null) : 0;
    if (id < 0)
      return -1;
    const headers = post ? { "Content-Type": "application/json" } : {};
    const who = flags & 8 ? player() : null;
    if (who)
      headers["X-Verse-Player"] = who.key;
    if (auth)
      headers.Authorization = auth;
    const r = wanted ? { id, generation, controller: new AbortController, timer: null, capacity: cap } : null;
    if (r) {
      slots[id] = r;
      if (bounded)
        r.timer = setTimer(() => finish(r, `0
`, true), timeoutMs);
    }
    Promise.resolve().then(async () => {
      if (r && !owns(r))
        return;
      const response = await fetchEffect(url, {
        method: post ? "POST" : "GET",
        body: post ? body : undefined,
        credentials: "same-origin",
        cache: "no-store",
        keepalive: !wanted && originalLength < 60000,
        headers,
        ...r ? { signal: r.controller.signal } : {}
      });
      if (!r || !owns(r))
        return;
      const text = bounded ? await boundedBody(r, response) : `${response.status}
${await response.text()}`;
      if (text !== null)
        finish(r, text);
    }).catch(() => {
      if (r)
        finish(r, `0
`, true);
    });
    return id;
  }
  function cancel(id) {
    if (!Number.isInteger(id) || id < 0 || id >= slots.length || !slots[id])
      return 0;
    const r = slots[id];
    release(r);
    r.controller.abort();
    return 1;
  }
  function reset() {
    generation++;
    const old = slots.slice();
    slots.fill(null);
    for (const r of old)
      if (r) {
        if (r.timer !== null)
          clearTimer(r.timer);
        r.controller.abort();
      }
  }
  return { request, cancel, reset };
}

// coax/web/host.js
var script = document.currentScript || document.querySelector("script[data-app]");
var app = script && script.dataset.app || "app";
var wasmUrl = script && script.dataset.wasm || `/build/${app}.wasm`;
var wgslUrl = script && script.dataset.wgsl || `/${app}.wgsl`;
var realmId = script && script.dataset.realm || "";
var slot = script && script.dataset.slot || app;
var slotWas = script && script.dataset.slotWas || "";
var root = script && script.dataset.root || "";
var canvas = document.getElementById("coaxial");
var dev = ["localhost", "127.0.0.1", "[::1]"].includes(location.hostname);
var probe = dev && new URLSearchParams(location.search).has("probe");
var probeAt = probe ? Number(new URLSearchParams(location.search).get("at")) || 0 : 0;
var still = probe && !probeAt || matchMedia("(prefers-reduced-motion: reduce)").matches;
var golden = globalThis.coaxialGolden === true || new URLSearchParams(location.search).has("golden");
var frames = 0;
var probeDo = probe ? new URLSearchParams(location.search).get("do") || "" : "";
var memory = new WebAssembly.Memory({ initial: 128, maximum: 1024 });
var engine = null;
var arena = null;
var gpu = null;
var wanted = 0;
var PACK_PARTS = ["data", "storage", "index", "layers"];
var PACK_KIND = 605;
var PACK_CATALOG = 1;
var PACK_VERTICES = 2;
var PACK_INDICES = 3;
var PACK_LAYER = 4;
var PACK_SOUND = 5;
var assets = parseAssets(script && script.dataset.assets || "");
var LATER = ["sound", "loop", "particles", "font", "icons", "licence"];
var firstAssets = assets.filter((a) => !a.pack && !LATER.includes(a.kind));
var firstPacks = new Set(assets.filter((a) => a.pack).map((a) => a.pack));
var loading = startLoading({
  realm: realmId,
  assets: firstAssets.length + firstPacks.size,
  textured: firstPacks.size > 0 || firstAssets.some((a) => a.kind === "layers"),
  scene: firstPacks.size > 0 || firstAssets.some((a) => a.kind === "index"),
  golden
});
var MAKER_KIND = 608;
var makerName = "";
if (realmId && !golden && script?.dataset.maker === "1" && /^[a-z0-9-]{1,64}$/.test(realmId)) {
  fetch(`/api/playtest/makers/${realmId}`, { credentials: "same-origin" }).then((r) => r.ok ? r.json() : null).then((m) => {
    if (!m || typeof m.name !== "string" || !m.name)
      return;
    makerName = m.name.slice(0, 40);
    if (globalThis.coaxial.ready)
      send(MAKER_KIND, makerName);
  }).catch(() => {});
}
var last = 0;
var sceneEpoch = 0;
var pendingSceneEpoch = -1;
var installedGeneration = 0;
var shaderLoads = 0;
function invalidateScene() {
  sceneEpoch += 1;
  pendingSceneEpoch = -1;
  globalThis.coaxial.sceneReady = false;
}
function beginEngine() {
  const generation = ++wanted;
  httpRequests.reset();
  invalidateScene();
  return generation;
}
var randomScratch = {};
function importedMemoryPages(bytes) {
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let i = 8;
  const leb = () => {
    let v = 0, shift = 0, c;
    do {
      c = b[i++];
      v += (c & 127) * 2 ** shift;
      shift += 7;
    } while (c & 128);
    return v;
  };
  const skipName = () => {
    const n = leb();
    i += n;
  };
  while (i < b.length) {
    const id = b[i++], size = leb(), end = i + size;
    if (id === 2) {
      for (let n = leb();n > 0; n--) {
        skipName();
        skipName();
        const kind = b[i++];
        if (kind === 0)
          leb();
        else if (kind === 1) {
          i++;
          const f = leb();
          leb();
          if (f & 1)
            leb();
        } else if (kind === 2) {
          const f = leb();
          return leb();
        } else if (kind === 3) {
          i += 2;
        } else
          return 0;
      }
      return 0;
    }
    i = end;
  }
  return 0;
}
async function loadEngine(bytes, generation) {
  const module = await WebAssembly.compile(bytes);
  const pages = importedMemoryPages(bytes), have = memory.buffer.byteLength / 65536;
  if (pages > have)
    memory.grow(pages - have);
  const random = prepareRandomImport(memory, module, randomScratch);
  const imports = Object.create(null);
  imports.env = Object.assign(Object.create(null), {
    memory,
    coaxial_now_seconds: () => BigInt(Math.floor(Date.now() / 1000)),
    coaxial_now_ms: () => BigInt(Math.floor(performance.now())),
    ...socketImports,
    ...httpImports,
    ...random.imports,
    ...storageImports,
    ...nip07Imports
  });
  for (const imp of WebAssembly.Module.imports(module)) {
    if (imp.kind !== "function")
      continue;
    (imports[imp.module] ||= Object.create(null))[imp.name] ||= wasiStub(imp.module, imp.name);
  }
  const instance = await WebAssembly.instantiate(module, imports);
  if (generation !== wanted)
    return false;
  const kept = await keptRead;
  if (generation !== wanted)
    return false;
  byteStorage.reset();
  httpRequests.reset();
  const x = instance.exports;
  random.bind(x);
  x._initialize?.();
  const layout = x.coaxial_layout();
  const heapBase = x.__heap_base?.value ?? 0;
  const floats = x.coaxial_vertex_floats(), maxVertices = x.coaxial_max_vertices();
  const uniformFloats = x.coaxial_uniform_floats(), stateSize = x.coaxial_state_size();
  if (!arena || heapBase > arena.base || floats !== arena.floats || maxVertices !== arena.maxVertices || uniformFloats !== arena.uniformFloats || stateSize > arena.stateCap) {
    const base = align(Math.max(heapBase, memory.buffer.byteLength), 65536);
    const stateCap = align(Math.max(stateSize, 1024), 16);
    const need = base + stateCap + maxVertices * floats * 4 + uniformFloats * 4 + 64;
    if (need > memory.buffer.byteLength)
      memory.grow(Math.ceil((need - memory.buffer.byteLength) / 65536));
    arena = { base, stateCap, state: base, vertices: base + stateCap, uniforms: base + stateCap + maxVertices * floats * 4, floats, maxVertices, uniformFloats, layout: -1 };
    if (gpu)
      makeBuffers();
  }
  if (arena.layout !== layout) {
    new Uint8Array(memory.buffer, arena.state, arena.stateCap).fill(0);
    x.coaxial_state_init?.(arena.state);
    if (engine)
      say(`state layout changed: ${app} starts over`);
    arena.layout = layout;
  }
  x.coaxial_page?.(arena.state, Number(script && script.dataset.page || 0));
  if (golden)
    x.coaxial_golden?.(1);
  x.coaxial_quality?.(arena.state, golden ? 0 : quality);
  engine = { exports: x, layout };
  installedGeneration = generation;
  invalidateScene();
  if (script?.dataset.text)
    send(2, script.dataset.text);
  if (script?.dataset.lines && location.protocol !== "file:") {
    const [kind, url] = script.dataset.lines.split(/:(.*)/);
    fetch(url, { cache: "no-store" }).then((r) => r.ok ? r.text() : "", () => "").then((t) => {
      if (t)
        send(Number(kind), t);
    });
  }
  for (const a of assets)
    if (a.done)
      deliver(a);
  sendHash();
  if (kept)
    send(4, kept);
  globalThis.coaxial.ready = true;
  if (x.coaxial_message)
    send(PAGE_KIND, pageFacts());
  if (makerName)
    send(MAKER_KIND, makerName);
  const place = golden ? "" : local(placeKey);
  if (place)
    send(PLACE_KIND, place);
  const bar = golden ? "" : local(barKey);
  if (bar)
    send(BAR_KIND, bar);
  viewer();
  dispatchEvent(new CustomEvent("coaxial", { detail: { code: 0, text: "" } }));
  return true;
}
function wasiStub(module, name) {
  if (module !== "wasi_snapshot_preview1")
    return unsupportedImport(module, name);
  if (name === "fd_write")
    return (fd, iovs, n, written) => {
      const v = new DataView(memory.buffer);
      let text = "", total = 0;
      for (let i = 0;i < n; i++) {
        const p = v.getUint32(iovs + i * 8, true), len = v.getUint32(iovs + i * 8 + 4, true);
        text += new TextDecoder().decode(new Uint8Array(memory.buffer, p, len));
        total += len;
      }
      v.setUint32(written, total, true);
      (fd === 2 ? console.error : console.log)(text.trimEnd());
      return 0;
    };
  if (name === "proc_exit")
    return (code) => {
      throw new Error(`${app} exited (${code})`);
    };
  if (["fd_fdstat_get", "fd_seek", "fd_close", "clock_time_get"].includes(name))
    return () => 52;
  return unsupportedImport(module, name);
}
var align = (n, a) => Math.ceil(n / a) * a;
var SOCKETS = 4;
var SOCKET_KIND = 256;
var SOCKET_OPENED = 0;
var SOCKET_FRAME = 1;
var SOCKET_CLOSED = 2;
var SOCKET_ERROR = 3;
var sockets = new Array(SOCKETS).fill(null);
var utf8 = (ptr, len) => new TextDecoder().decode(new Uint8Array(memory.buffer, ptr, len).slice());
var SOCKET_BUDGET_MS = 12;
var socketQueue = [];
var socketHead = 0;
var socketTimer = 0;
var socketDrained = 0;
function socketQueued(ws, id, event, text = "") {
  socketQueue.push([ws, id, event, text]);
  if (!socketTimer)
    socketTimer = setTimeout(socketIdle, 100);
}
function socketIdle() {
  socketTimer = 0;
  if (performance.now() - socketDrained > 90)
    drainSockets();
  if (socketHead < socketQueue.length)
    socketTimer = setTimeout(socketIdle, 100);
}
function drainSockets(budget = SOCKET_BUDGET_MS) {
  const t0 = socketDrained = performance.now();
  while (socketHead < socketQueue.length) {
    const [ws, id, event, text] = socketQueue[socketHead];
    socketQueue[socketHead++] = null;
    if (sockets[id] !== ws)
      continue;
    if (event === SOCKET_CLOSED)
      sockets[id] = null;
    try {
      socketEvent(id, event, text);
    } catch (e) {
      say(`${app} socket: ${e.message}`, true);
    }
    if (performance.now() - t0 > budget)
      break;
  }
  if (socketHead === socketQueue.length) {
    socketQueue.length = 0;
    socketHead = 0;
  } else if (socketHead > 4096) {
    socketQueue.splice(0, socketHead);
    socketHead = 0;
  }
}
function socketEvent(id, event, text = "") {
  const x = engine?.exports;
  if (!x?.coaxial_message)
    return;
  const bytes = new TextEncoder().encode(text);
  if (bytes.length > x.coaxial_inbox_cap()) {
    socketEvent(id, SOCKET_ERROR, "frame over the inbox cap");
    return;
  }
  new Uint8Array(memory.buffer, x.coaxial_inbox(arena.state), bytes.length).set(bytes);
  x.coaxial_message(arena.state, SOCKET_KIND + 4 * id + event, bytes.length);
  after(false);
}
var socketImports = {
  coaxial_socket_open(ptr, len) {
    const id = sockets.indexOf(null);
    if (id < 0)
      return -1;
    let ws;
    try {
      ws = new WebSocket(utf8(ptr, len));
    } catch {
      return -1;
    }
    sockets[id] = ws;
    const mine = () => sockets[id] === ws;
    ws.onopen = () => mine() && socketQueued(ws, id, SOCKET_OPENED);
    ws.onmessage = (m) => mine() && typeof m.data === "string" && socketQueued(ws, id, SOCKET_FRAME, m.data);
    ws.onerror = () => mine() && socketQueued(ws, id, SOCKET_ERROR);
    ws.onclose = () => mine() && socketQueued(ws, id, SOCKET_CLOSED);
    return id;
  },
  coaxial_socket_send(id, ptr, len) {
    const ws = sockets[id];
    if (ws && ws.readyState === WebSocket.OPEN)
      ws.send(utf8(ptr, len));
  },
  coaxial_socket_close(id) {
    const ws = sockets[id];
    if (!ws)
      return;
    sockets[id] = null;
    ws.close();
    setTimeout(() => socketEvent(id, SOCKET_CLOSED));
  }
};
var HTTP_KIND = 512;
function answer(id, text) {
  const x = engine?.exports;
  if (!x?.coaxial_message)
    return;
  const bytes = new TextEncoder().encode(text);
  send(HTTP_KIND + id, bytes.length > x.coaxial_inbox_cap() ? text.slice(0, text.indexOf(`
`) + 1) : text);
}
var httpRequests = makeHttpRequests({
  emit: answer,
  capacity: () => engine?.exports.coaxial_inbox_cap() ?? 0,
  player,
  origin: location.origin,
  sendBeacon: navigator.sendBeacon ? (url, body) => navigator.sendBeacon(url, body) : undefined
});
function httpRequest(urlPtr, urlLen, bodyPtr, bodyLen, flags, timeoutMs) {
  return httpRequests.request(utf8(urlPtr, urlLen), bodyLen ? new Uint8Array(memory.buffer, bodyPtr, bodyLen) : null, flags, timeoutMs);
}
var httpImports = {
  coaxial_http: (urlPtr, urlLen, bodyPtr, bodyLen, flags) => httpRequest(urlPtr, urlLen, bodyPtr, bodyLen, flags),
  coaxial_http_bounded: (urlPtr, urlLen, bodyPtr, bodyLen, flags, timeoutMs) => httpRequest(urlPtr, urlLen, bodyPtr, bodyLen, flags, Number(timeoutMs)),
  coaxial_http_cancel: (id) => httpRequests.cancel(id)
};
function makeByteStorage({ memory: memory2, capacity, emit, indexedDB: indexedDB2, timeout = 1e4 }) {
  const HEADER = 16, MAX_BYTES = 1048576, SLOTS = 8;
  const OK = 0, MISSING = 1, UNAVAILABLE = 2, QUOTA = 3, LIMIT = 4, INVALID = 5;
  const BUSY = 6, ERROR = 7, TIMEOUT = 8, CAPACITY = 9, CORRUPT = 10;
  const requests = new Array(SLOTS).fill(null), decoder = new TextDecoder("utf-8", { fatal: true });
  let db = null, opening = null, generation = 0;
  const validToken = (token) => Number.isInteger(token) && token !== 0 && token >= -2147483648 && token <= 4294967295;
  const errorCode = (e) => e?.name === "QuotaExceededError" ? QUOTA : ["SecurityError", "NotAllowedError", "InvalidStateError", "NotFoundError", "VersionError"].includes(e?.name) ? UNAVAILABLE : ERROR;
  const mine = (r) => requests[r.slot] === r && r.generation === generation;
  const abort = (r) => {
    try {
      r.tx?.abort();
    } catch {}
  };
  function forget(r) {
    requests[r.slot] = null;
    clearTimeout(r.timer);
  }
  function finish(r, status, payload = null, needed = payload?.byteLength || 0) {
    if (!mine(r))
      return;
    forget(r);
    const cap = capacity();
    if (!Number.isInteger(cap) || cap < HEADER)
      return;
    if (payload && payload.byteLength > cap - HEADER) {
      status = CAPACITY;
      payload = null;
    }
    const wire = new Uint8Array(HEADER + (payload?.byteLength || 0)), h = new DataView(wire.buffer);
    h.setUint32(0, r.token, true);
    h.setUint32(4, status, true);
    h.setUint32(8, wire.length - HEADER, true);
    h.setUint32(12, needed, true);
    if (payload)
      wire.set(new Uint8Array(payload), HEADER);
    emit(r.slot, wire);
  }
  function open() {
    if (db)
      return Promise.resolve([db, OK]);
    if (opening)
      return opening;
    const attempt = new Promise((resolve) => {
      let request, settled = false;
      const timer = setTimeout(() => done(null, TIMEOUT), timeout);
      function done(connection, status) {
        if (settled) {
          connection?.close();
          return;
        }
        settled = true;
        clearTimeout(timer);
        if (connection) {
          db = connection;
          connection.onversionchange = () => {
            if (db === connection)
              db = null;
            connection.close();
            for (const r of requests)
              if (r?.tx?.db === connection) {
                abort(r);
                finish(r, UNAVAILABLE);
              }
          };
          connection.onclose = () => {
            if (db === connection)
              db = null;
          };
        }
        resolve([connection, status]);
      }
      try {
        const factory = indexedDB2();
        if (!factory) {
          done(null, UNAVAILABLE);
          return;
        }
        request = factory.open("coaxial-bytes", 1);
        request.onupgradeneeded = () => {
          try {
            if (!request.result.objectStoreNames.contains("bytes"))
              request.result.createObjectStore("bytes");
          } catch (e) {
            try {
              request.transaction?.abort();
            } catch {}
            done(null, errorCode(e));
          }
        };
        request.onsuccess = () => done(request.result, OK);
        request.onerror = () => done(null, errorCode(request.error));
        request.onblocked = () => done(null, UNAVAILABLE);
      } catch (e) {
        done(null, errorCode(e));
      }
    });
    opening = attempt;
    attempt.then(() => {
      if (opening === attempt)
        opening = null;
    });
    return attempt;
  }
  function span(ptr, len) {
    const buffer = memory2().buffer;
    if (!Number.isInteger(ptr) || !Number.isInteger(len) || ptr < 0 || len < 0 || ptr > buffer.byteLength || len > buffer.byteLength - ptr)
      throw INVALID;
    return new Uint8Array(buffer, ptr, len);
  }
  function text(ptr, len, max) {
    if (!Number.isInteger(len) || len < 1 || len > max)
      throw INVALID;
    return decoder.decode(span(ptr, len));
  }
  function start(op, slot2, token, np, nn, version, kp, kn, vp = 0, vn = 0) {
    if (!Number.isInteger(slot2) || slot2 < 0 || slot2 >= SLOTS || !validToken(token))
      return INVALID;
    if (requests[slot2])
      return BUSY;
    if (!Number.isInteger(version) || version < 1 || version > 2147483647)
      return INVALID;
    const cap = capacity();
    if (!Number.isInteger(cap) || cap < HEADER)
      return CAPACITY;
    let key, bytes;
    try {
      if (op === "put" && (!Number.isInteger(vn) || vn < 0))
        return INVALID;
      if (op === "put" && vn > MAX_BYTES)
        return LIMIT;
      key = [text(np, nn, 64), version, text(kp, kn, 128)];
      if (op === "put")
        bytes = span(vp, vn).slice().buffer;
    } catch {
      return INVALID;
    }
    const r = { slot: slot2, token: token >>> 0, generation, tx: null, timer: null };
    requests[slot2] = r;
    r.timer = setTimeout(() => {
      if (mine(r)) {
        abort(r);
        finish(r, TIMEOUT);
      }
    }, timeout);
    open().then(([connection, status]) => {
      if (!mine(r))
        return;
      if (!connection) {
        finish(r, status);
        return;
      }
      try {
        const tx = connection.transaction("bytes", op === "get" ? "readonly" : "readwrite");
        r.tx = tx;
        const store = tx.objectStore("bytes");
        const request = op === "put" ? store.put(bytes, key) : op === "get" ? store.get(key) : store.delete(key);
        let value, failure = OK;
        request.onsuccess = () => {
          if (op === "get")
            value = request.result;
        };
        request.onerror = () => {
          failure = errorCode(request.error);
        };
        tx.onabort = () => finish(r, failure || errorCode(tx.error));
        tx.oncomplete = () => {
          if (failure) {
            finish(r, failure);
            return;
          }
          if (op !== "get") {
            finish(r, OK);
            return;
          }
          if (value === undefined) {
            finish(r, MISSING);
            return;
          }
          if (!(value instanceof ArrayBuffer)) {
            finish(r, CORRUPT);
            return;
          }
          if (value.byteLength > MAX_BYTES) {
            finish(r, LIMIT, null, value.byteLength);
            return;
          }
          finish(r, OK, value);
        };
      } catch (e) {
        abort(r);
        finish(r, errorCode(e));
      }
    });
    return OK;
  }
  function cancel(slot2, token) {
    if (!Number.isInteger(slot2) || slot2 < 0 || slot2 >= SLOTS || !validToken(token))
      return INVALID;
    const r = requests[slot2];
    if (!r || r.token !== token >>> 0)
      return MISSING;
    forget(r);
    abort(r);
    return OK;
  }
  return {
    imports: {
      coaxial_storage_put: (slot2, token, np, nn, version, kp, kn, vp, vn) => start("put", slot2, token, np, nn, version, kp, kn, vp, vn),
      coaxial_storage_get: (slot2, token, np, nn, version, kp, kn) => start("get", slot2, token, np, nn, version, kp, kn),
      coaxial_storage_delete: (slot2, token, np, nn, version, kp, kn) => start("delete", slot2, token, np, nn, version, kp, kn),
      coaxial_storage_cancel: cancel
    },
    reset() {
      generation++;
      for (const r of requests)
        if (r) {
          forget(r);
          abort(r);
        }
    }
  };
}
var byteStorage = makeByteStorage({
  memory: () => memory,
  indexedDB: () => globalThis.indexedDB,
  capacity: () => engine?.exports.coaxial_message && engine.exports.coaxial_inbox && arena ? engine.exports.coaxial_inbox_cap?.() || 0 : 0,
  emit: (slot2, bytes) => {
    const x = engine?.exports;
    if (!x?.coaxial_message || !x.coaxial_inbox || !arena)
      return;
    const dest = x.coaxial_inbox(arena.state);
    if (dest < 0 || dest > memory.buffer.byteLength || bytes.length > memory.buffer.byteLength - dest)
      return;
    new Uint8Array(memory.buffer, dest, bytes.length).set(bytes);
    x.coaxial_message(arena.state, 768 + slot2, bytes.length);
    after(false);
  }
});
var storageImports = byteStorage.imports;
var SIGNER_NIP07_KIND = 609;
var nip07Imports = {
  coaxial_nip07_sign: (id, ptr, len) => {
    if (!Number.isInteger(id) || id <= 0 || len <= 0 || len > 65536 || ptr < 0 || ptr + len > memory.buffer.byteLength)
      return -1;
    let template;
    try {
      template = JSON.parse(new TextDecoder().decode(new Uint8Array(memory.buffer, ptr, len)));
    } catch {
      return -1;
    }
    const signer = globalThis.nostr;
    if (!signer || typeof signer.signEvent !== "function") {
      queueMicrotask(() => send(SIGNER_NIP07_KIND, `${id}
`));
      return 0;
    }
    Promise.resolve().then(() => signer.signEvent(template)).then((ev) => send(SIGNER_NIP07_KIND, `${id}
${ev ? JSON.stringify(ev) : ""}`), () => send(SIGNER_NIP07_KIND, `${id}
`));
    return 0;
  }
};
var PAGE_KIND = 600;
var HIDDEN_KIND = 601;
var SHOWN_KIND = 602;
var LEAVE_KIND = 603;
var ERROR_KIND = 604;
var VIEWER_KIND2 = 606;
function viewer() {
  if (!engine?.exports.coaxial_message || location.protocol === "file:")
    return;
  fetch("/api/auth/viewer", { credentials: "same-origin" }).then((r) => r.text().then((t) => r.ok ? t : ""), () => "").then((t) => send(VIEWER_KIND2, t), () => send(VIEWER_KIND2, ""));
}
var randomId = () => [...crypto.getRandomValues(new Uint8Array(8))].map((b) => b.toString(16).padStart(2, "0")).join("");
function kept(store, key) {
  try {
    const v = store.getItem(key);
    if (v)
      return [v, false];
    const n = randomId();
    store.setItem(key, n);
    return [n, true];
  } catch {
    return [randomId(), true];
  }
}
function styleFacts() {
  const d = script?.dataset || {}, out = { style: d.style || "" };
  for (const z of (d.zones || "").split(/\s+/)) {
    const [id, st] = z.split(":");
    if (id && st)
      out[`zone.${id}`] = st;
  }
  const pin = new URLSearchParams(location.search).get("clock");
  out.clock = pin !== null && /^(0(\.\d{1,4})?|1(\.0{1,4})?)$/.test(pin) ? `fixed:${pin}` : pin === "cycle" || pin === "real" ? pin : d.clock || "";
  const t = new Date;
  out.day = ((t.getHours() * 3600 + t.getMinutes() * 60 + t.getSeconds()) / 86400).toFixed(5);
  return out;
}
function pageFacts() {
  const [tab, fresh] = kept(sessionStorage, "coaxial.tab"), [visitor] = kept(localStorage, "coaxial.visitor");
  let tz = "";
  try {
    tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  } catch {}
  const nav = performance.getEntriesByType?.("navigation")?.[0], fcp = performance.getEntriesByName?.("first-contentful-paint")?.[0];
  const clean = (v) => String(v ?? "").replace(/[\r\n]/g, " ");
  return Object.entries({
    tab,
    fresh: fresh ? 1 : 0,
    visitor,
    now: Date.now(),
    nav: performance.now().toFixed(1),
    url: location.href,
    ref: document.referrer,
    ua: navigator.userAgent,
    lang: navigator.language,
    tz,
    sw: screen.width,
    sh: screen.height,
    vw: innerWidth,
    vh: innerHeight,
    dpr: devicePixelRatio || 1,
    coarse: matchMedia("(pointer: coarse)").matches ? 1 : 0,
    touch: navigator.maxTouchPoints || 0,
    gpu: navigator.gpu ? 1 : 0,
    hidden: document.hidden ? 1 : 0,
    focused: document.hasFocus() ? 1 : 0,
    clip: globalThis.coaxialClip === true ? 1 : 0,
    webdriver: navigator.webdriver ? 1 : 0,
    fcp: fcp ? Math.round(fcp.startTime) : 0,
    dcl: nav ? Math.round(nav.domContentLoadedEventEnd) : 0,
    player: player()?.id || "",
    account: player()?.account || "",
    realm: realmId,
    slot,
    voice: script?.dataset.voice || "",
    ruleset: script?.dataset.ruleset || "",
    fork: script?.dataset.fork || "",
    rules: script?.dataset.rules || "",
    ...styleFacts()
  }).map(([k, v]) => `${k}=${clean(v)}`).join(`
`);
}
addEventListener("visibilitychange", () => send(document.hidden ? HIDDEN_KIND : SHOWN_KIND));
addEventListener("pagehide", () => {
  send(LEAVE_KIND);
  httpRequests.reset();
});
addEventListener("error", (e) => send(ERROR_KIND, `${String(e.message || "").slice(0, 200)}
${String(e.filename || "").split("/").pop()}
${e.lineno || 0}`));
addEventListener("unhandledrejection", (e) => send(ERROR_KIND, `${String(e.reason?.message || e.reason || "").slice(0, 200)}
promise
0`));
async function startGpu() {
  if (!navigator.gpu)
    return false;
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter)
    return false;
  const device = await adapter.requestDevice();
  loading.watch(device);
  loading.step("shaders");
  const context = canvas.getContext("webgpu");
  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: "opaque", usage: GPUTextureUsage.RENDER_ATTACHMENT | (probe ? GPUTextureUsage.COPY_SRC : 0) });
  gpu = { device, context, format };
  makeBuffers();
  return loadShaders();
}
function makeBuffers() {
  const { device } = gpu;
  gpu.uniformBuffer = device.createBuffer({ size: align(arena.uniformFloats * 4, 16), usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  gpu.vertexBuffer = device.createBuffer({ size: arena.maxVertices * arena.floats * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  gpu.layout = device.createBindGroupLayout({ entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: {} }] });
  gpu.bindGroup = device.createBindGroup({ layout: gpu.layout, entries: [{ binding: 0, resource: { buffer: gpu.uniformBuffer } }] });
  if (gpu.sans)
    useSans();
  if (gpu.gpuiOn)
    useGpui();
  if (gpu.meshOn)
    useMesh();
}
var SANS_EXTRA = [183, 8211, 8212, 8216, 8217, 8220, 8221, 8226, 8230, 8594, 8383, 8722, 215, 8804, 8805, 8800];
var SANS_FONT = 'Helvetica, Arial, "Liberation Sans", "Nimbus Sans", sans-serif';
function sansAtlas(device) {
  const codes = [...Array.from({ length: 95 }, (_, i) => 32 + i), ...SANS_EXTRA];
  const cols = 16, rows = Math.ceil(codes.length / cols), cell = 96, levels = 5;
  const texture = device.createTexture({
    size: [cols * cell, rows * cell],
    format: "rgba8unorm",
    mipLevelCount: levels,
    usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT
  });
  for (let level = 0;level < levels; level++) {
    const c = cell >> level, w = cols * c, h = rows * c;
    const canvas2 = new OffscreenCanvas(w, h), g = canvas2.getContext("2d");
    g.fillStyle = "#fff";
    g.textBaseline = "alphabetic";
    g.font = `${64 / (1 << level)}px ${SANS_FONT}`;
    codes.forEach((code, i) => g.fillText(String.fromCodePoint(code), i % cols * c + 16 / (1 << level), Math.floor(i / cols) * c + 72 / (1 << level)));
    device.queue.copyExternalImageToTexture({ source: canvas2 }, { texture, mipLevel: level, premultipliedAlpha: true }, [w, h]);
  }
  return texture;
}
function useMesh() {
  const { device } = gpu;
  gpu.meshOn = true;
  gpu.layout = device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: {} },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, buffer: { type: "read-only-storage" } }
  ] });
  bindMesh();
}
function bindMesh() {
  if (!gpu.meshOn)
    return;
  const { device } = gpu, a = assets.find((x) => x.kind === "mesh" && x.done && !x.failed && x.buffer);
  gpu.meshEmpty ||= device.createBuffer({ size: 16, usage: GPUBufferUsage.STORAGE });
  gpu.bindGroup = device.createBindGroup({ layout: gpu.layout, entries: [
    { binding: 0, resource: { buffer: gpu.uniformBuffer } },
    { binding: 1, resource: { buffer: a ? a.buffer : gpu.meshEmpty } }
  ] });
}
function useSans() {
  const { device } = gpu;
  gpu.sans ||= sansAtlas(device);
  const both = GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT;
  gpu.layout = device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: both, buffer: {} },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: {} },
    { binding: 2, visibility: GPUShaderStage.FRAGMENT, sampler: {} }
  ] });
  gpu.bindGroup = device.createBindGroup({ layout: gpu.layout, entries: [
    { binding: 0, resource: { buffer: gpu.uniformBuffer } },
    { binding: 1, resource: gpu.sans.createView() },
    { binding: 2, resource: device.createSampler({ magFilter: "linear", minFilter: "linear", mipmapFilter: "linear" }) }
  ] });
}
function useGpui() {
  const { device } = gpu;
  gpu.gpuiOn = true;
  gpu.gpui ||= startGpui({ device, memory, assets, say });
  const both = GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, f = GPUShaderStage.FRAGMENT;
  gpu.layout = device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: both, buffer: {} },
    { binding: 1, visibility: f, texture: {} },
    { binding: 2, visibility: f, texture: {} },
    { binding: 3, visibility: f, sampler: {} }
  ] });
  gpu.bindGroup = device.createBindGroup({ layout: gpu.layout, entries: [
    { binding: 0, resource: { buffer: gpu.uniformBuffer } },
    { binding: 1, resource: gpu.gpui.g.mono.createView() },
    { binding: 2, resource: gpu.gpui.g.color.createView() },
    { binding: 3, resource: device.createSampler({ magFilter: "linear", minFilter: "linear" }) }
  ] });
}
function gpuiFrame(dpr) {
  const x = engine?.exports, k = gpu?.gpui;
  if (!x?.coaxial_gpui_set_atlas || !k)
    return;
  if (k.engine !== engine || k.dpr !== dpr) {
    if (k.building)
      return;
    k.building = true;
    k.engine = engine;
    k.dpr = dpr;
    const at = engine;
    k.build(x, arena.state, dpr).then(() => {
      if (engine === at)
        useGpui();
      else
        k.engine = null;
    }).catch((e) => {
      say(`${app}: atlas: ${e.message}`, true);
    }).finally(() => {
      k.building = false;
    });
    return;
  }
  if (!k.building)
    k.serve(x, arena.state);
}
async function loadShaders() {
  shaderLoads += 1;
  invalidateScene();
  try {
    const { device, format } = gpu;
    const code = await (await fetch(wgslUrl, { cache: dev ? "no-store" : "default" })).text();
    if (/var\s+sans_atlas\b/.test(code))
      useSans();
    if (/var\s+gpui_atlas\b/.test(code))
      useGpui();
    if (/var<storage,\s*read>\s+mesh\b/.test(code))
      useMesh();
    const module = device.createShaderModule({ code });
    const info = await module.getCompilationInfo();
    const errors = info.messages.filter((m) => m.type === "error");
    if (errors.length) {
      say(errors.map((m) => `${app}.wgsl:${m.lineNum}:${m.linePos}: ${m.message}`).join(`
`), true);
      return false;
    }
    const layout = device.createPipelineLayout({ bindGroupLayouts: [gpu.layout] });
    const stride = arena.floats * 4;
    const scene = !!engine?.exports.coaxial_draws;
    gpu.scene3d = scene;
    const surfaced = !scene && /fn\s+surface_vs\b/.test(code) && /fn\s+surface_fs\b/.test(code) && !!engine?.exports.coaxial_surface_vertices;
    const depthed = scene || surfaced;
    const flat = depthed ? { depthStencil: { format: "depth32float", depthWriteEnabled: false, depthCompare: "always" } } : {};
    const shadows = scene && /fn\s+shadow_vs\b/.test(code);
    const casters = scene && /fn\s+caster_vs\b/.test(code);
    const post = scene && /fn\s+post_fs\b/.test(code);
    const lit = post ? [{ format: "rgba16float" }, { format: "rgba16float" }] : [{ format }];
    const sceneGroups = scene ? [gpu.layout, sceneLayout(), ...shadows ? [shadowLayout()] : []] : [];
    const bgLayout = casters ? device.createPipelineLayout({ bindGroupLayouts: [gpu.layout, emptyLayout(), shadowLayout()] }) : layout;
    const bgDepth = depthed && /@builtin\(frag_depth\)/.test(code) ? { depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "always" } } : flat;
    const grassy = scene && /fn\s+grass_vs\b/.test(code) && !!engine?.exports.coaxial_grass_instances;
    const [bg, fx, sc, sh, bl, po, ca, gr, su] = await Promise.all([
      device.createRenderPipelineAsync({ layout: bgLayout, ...bgDepth, vertex: { module, entryPoint: "bg_vs" }, fragment: { module, entryPoint: "bg_fs", targets: lit } }),
      device.createRenderPipelineAsync({
        layout,
        ...post ? {} : flat,
        vertex: { module, entryPoint: "fx_vs", buffers: [{ arrayStride: stride, attributes: Array.from({ length: Math.ceil(arena.floats / 4) }, (_, i) => ({ shaderLocation: i, offset: i * 16, format: "float32x4" })) }] },
        fragment: { module, entryPoint: "fx_fs", targets: [{ format, blend: gpu.gpuiOn ? {
          color: { operation: "add", srcFactor: "src-alpha", dstFactor: "one-minus-src-alpha" },
          alpha: { operation: "add", srcFactor: "one", dstFactor: "one-minus-src-alpha" }
        } : {
          color: { operation: "max", srcFactor: "one", dstFactor: "one" },
          alpha: { operation: "max", srcFactor: "one", dstFactor: "one" }
        } }] }
      }),
      scene ? device.createRenderPipelineAsync({
        layout: device.createPipelineLayout({ bindGroupLayouts: sceneGroups }),
        vertex: { module, entryPoint: "scene_vs" },
        fragment: { module, entryPoint: "scene_fs", targets: lit },
        primitive: { topology: "triangle-list", cullMode: "none" },
        depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less" }
      }) : null,
      shadows ? device.createRenderPipelineAsync({
        layout: device.createPipelineLayout({ bindGroupLayouts: [gpu.layout, sceneLayout()] }),
        vertex: { module, entryPoint: "shadow_vs" },
        fragment: { module, entryPoint: "shadow_fs", targets: [] },
        primitive: { topology: "triangle-list", cullMode: "none" },
        depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less", depthBias: 2, depthBiasSlopeScale: 2 }
      }) : null,
      post ? device.createRenderPipelineAsync({
        layout: device.createPipelineLayout({ bindGroupLayouts: [gpu.layout, postLayouts().bloom] }),
        vertex: { module, entryPoint: "bg_vs" },
        fragment: { module, entryPoint: "bloom_fs", targets: [{ format: "rgba16float" }] }
      }) : null,
      post ? device.createRenderPipelineAsync({
        layout: device.createPipelineLayout({ bindGroupLayouts: [gpu.layout, postLayouts().post] }),
        vertex: { module, entryPoint: "bg_vs" },
        fragment: { module, entryPoint: "post_fs", targets: [{ format }] }
      }) : null,
      casters ? device.createRenderPipelineAsync({
        layout,
        vertex: { module, entryPoint: "caster_vs" },
        primitive: { topology: "triangle-list", cullMode: "none" },
        depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less", depthBias: 2, depthBiasSlopeScale: 2 }
      }) : null,
      grassy ? device.createRenderPipelineAsync({
        layout: casters ? bgLayout : device.createPipelineLayout({ bindGroupLayouts: sceneGroups }),
        vertex: { module, entryPoint: "grass_vs" },
        fragment: { module, entryPoint: "grass_fs", targets: lit },
        primitive: { topology: "triangle-list", cullMode: "none" },
        depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less" }
      }) : null,
      surfaced ? device.createRenderPipelineAsync({
        layout,
        vertex: { module, entryPoint: "surface_vs" },
        fragment: { module, entryPoint: "surface_fs", targets: lit },
        primitive: { topology: "triangle-list", cullMode: "none" },
        depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less" }
      }) : null
    ]);
    gpu.surface = su;
    gpu.bg = bg;
    gpu.fx = fx;
    gpu.scene = sc;
    gpu.shadow = sh;
    gpu.bloom = bl;
    gpu.post = po;
    gpu.caster = ca;
    gpu.grass = gr;
    gpu.waterCopy = post && /var\s+water_scene\b/.test(code);
    gpu.particles = sc ? await particlePipeline(post) : null;
    const waterGroups = gpu.waterCopy ? [...sceneGroups, ...sceneGroups.length < 3 ? [emptyLayout()] : [], waterCopyLayout()] : sceneGroups;
    [gpu.waterTransmit, gpu.waterEmit] = sc && /fn\s+water_vs\b/.test(code) ? await waterPipelines(module, waterGroups, post) : [null, null];
    return true;
  } finally {
    shaderLoads -= 1;
    invalidateScene();
  }
}
async function waterPipelines(module, groups, post) {
  const { device, format } = gpu;
  const keep = { operation: "add", srcFactor: "zero", dstFactor: "one" };
  const half = (entryPoint, color) => device.createRenderPipelineAsync({
    layout: device.createPipelineLayout({ bindGroupLayouts: groups }),
    vertex: { module, entryPoint: "water_vs" },
    fragment: { module, entryPoint, targets: post ? [{ format: "rgba16float", blend: { color, alpha: keep } }, { format: "rgba16float", writeMask: 0 }] : [{ format, blend: { color, alpha: keep } }] },
    primitive: { topology: "triangle-list", cullMode: "none" },
    depthStencil: { format: "depth32float", depthWriteEnabled: false, depthCompare: "less" }
  });
  return Promise.all([
    half("water_transmit_fs", { operation: "add", srcFactor: "zero", dstFactor: "src" }),
    half("water_emit_fs", { operation: "add", srcFactor: "one", dstFactor: "one" })
  ]);
}
function waterCopyLayout() {
  gpu.waterCopyLayout ||= gpu.device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: "unfilterable-float" } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: "depth" } }
  ] });
  return gpu.waterCopyLayout;
}
async function particlePipeline(post) {
  const a = assets.find((s) => s.kind === "particles"), x = engine?.exports;
  gpu.particlesOver = null;
  gpu.particleDepth = false;
  if (!a || !x?.coaxial_particles)
    return null;
  const { device, format } = gpu;
  try {
    const code = await (await fetch(a.url, { cache: dev ? "no-store" : "default" })).text();
    const module = device.createShaderModule({ code });
    const errors = (await module.getCompilationInfo()).messages.filter((m) => m.type === "error");
    if (errors.length) {
      say(errors.map((m) => `particles.wgsl:${m.lineNum}:${m.linePos}: ${m.message}`).join(`
`), true);
      return null;
    }
    const group = device.createBindGroupLayout({ entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: "read-only-storage" } }] });
    gpu.particleBuffer ||= device.createBuffer({ size: align(Math.max(x.coaxial_particle_cap(), 16), 16), usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
    gpu.particleGroup = device.createBindGroup({ layout: group, entries: [{ binding: 0, resource: { buffer: gpu.particleBuffer } }] });
    const add = { operation: "add", srcFactor: "one", dstFactor: "one" };
    const over = { operation: "add", srcFactor: "one", dstFactor: "one-minus-src-alpha" };
    const under = { operation: "add", srcFactor: "zero", dstFactor: "one-minus-src-alpha" };
    gpu.particleDepth = gpu.waterCopy && /\bparticle_depth\b/.test(code);
    const layout = device.createPipelineLayout({ bindGroupLayouts: gpu.particleDepth ? [gpu.layout, group, emptyLayout(), waterCopyLayout()] : [gpu.layout, group] });
    const pipe = (vs, fs, color, alpha) => device.createRenderPipelineAsync({
      layout,
      vertex: { module, entryPoint: vs },
      fragment: { module, entryPoint: fs, targets: post ? [{ format: "rgba16float", blend: { color, alpha } }, { format: "rgba16float", writeMask: 0 }] : [{ format, blend: { color, alpha } }] },
      primitive: { topology: "triangle-list", cullMode: "none" },
      depthStencil: { format: "depth32float", depthWriteEnabled: false, depthCompare: "less" }
    });
    const [lit, shade] = await Promise.all([
      pipe("particle_vs", "particle_fs", add, add),
      /fn\s+particle_over_vs\b/.test(code) ? pipe("particle_over_vs", "particle_over_fs", over, under) : null
    ]);
    gpu.particlesOver = shade;
    return lit;
  } catch (e) {
    say(`${app}: particles: ${e.message}`, true);
    return null;
  }
}
function parseAssets(text) {
  const list = [];
  for (const entry of text.split(/\s+/).filter(Boolean)) {
    const k = entry.indexOf(":"), kind = entry.slice(0, k), rest = entry.slice(k + 1), i = list.length;
    if (kind === "sound") {
      const e = rest.indexOf("=");
      list.push({ i, kind, name: rest.slice(0, e), url: rest.slice(e + 1) });
    } else if (kind === "pack") {
      const pack = { url: rest };
      for (const part of PACK_PARTS)
        list.push({ i: list.length, kind: part, pack });
    } else
      list.push({ i, kind, url: rest, urls: rest.split("|") });
  }
  return list;
}
async function loadPack(pack) {
  const parts = assets.filter((a) => a.pack === pack);
  let entries = null;
  try {
    const r = await fetch(pack.url);
    if (!r.ok || !r.body)
      throw new Error(`${pack.url}: ${r.status}`);
    const reader = r.body.getReader(), chunks = [];
    let loaded = 0, total = Number(r.headers.get("content-length")) || 0, told = 0;
    for (;; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      chunks.push(value);
      loaded += value.length;
      if (loaded >= 12 && chunks[0].length >= 12)
        total = new DataView(chunks[0].buffer, chunks[0].byteOffset).getUint32(8, true);
      loading.bytes(pack.url, loaded, total);
      if (performance.now() - told > 100) {
        told = performance.now();
        send(PACK_KIND, `${loaded} ${total}`);
      }
    }
    const bytes = new Uint8Array(loaded);
    let at = 0;
    for (const c of chunks) {
      bytes.set(c, at);
      at += c.length;
    }
    send(PACK_KIND, `${loaded} ${loaded}`);
    entries = unpack(bytes);
    const { device } = gpu, of = (kind) => entries.filter((e) => e.kind === kind);
    const [catalog, vertices, indices, layers] = parts;
    catalog.bytes = of(PACK_CATALOG)[0].bytes;
    catalog.size = catalog.bytes.length;
    for (const [a, e] of [[vertices, of(PACK_VERTICES)[0]], [indices, of(PACK_INDICES)[0]]]) {
      const whole = new Uint8Array(align(Math.max(e.bytes.length, 4), 4));
      whole.set(e.bytes);
      a.buffer = device.createBuffer({ size: whole.length, usage: (a.kind === "index" ? GPUBufferUsage.INDEX : GPUBufferUsage.STORAGE) | GPUBufferUsage.COPY_DST });
      device.queue.writeBuffer(a.buffer, 0, whole);
      a.size = e.bytes.length;
    }
    loading.textures(0, 2 * of(PACK_LAYER).length);
    const images = await Promise.all(of(PACK_LAYER).map((e) => createImageBitmap(new Blob([e.bytes])).then((b) => (loading.textures(1, 0), b))));
    if (images.length) {
      layers.texture = await layerTexture(images);
      layers.size = images.length;
    } else
      layers.failed = true;
    for (const e of of(PACK_SOUND))
      assets.push({ i: assets.length, kind: "sound", name: e.name, bytes: e.bytes, done: true });
  } catch (e) {
    for (const a of parts)
      a.failed = true;
    say(`${app}: ${e.message}`, true);
  }
  for (const a of parts) {
    a.done = true;
    deliver(a);
  }
  bindScene();
  loading.assetDone(parts[0].failed && `WORLD FAILED TO LOAD: ${pack.url.split("/").pop()}`);
}
function unpack(bytes) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
  if (bytes.length < 32 || String.fromCharCode(...bytes.subarray(0, 4)) !== "VPK1" || v.getUint32(8, true) !== bytes.length)
    throw new Error("not a whole asset pack");
  const n = v.getUint32(4, true), table = v.getUint32(16, true), out = [];
  if (table + n * 48 > bytes.length)
    throw new Error("asset pack: its table runs past its end");
  for (let k = 0;k < n; k++) {
    const at = table + k * 48, offset = v.getUint32(at + 4, true), length = v.getUint32(at + 8, true);
    if (offset + length > bytes.length)
      throw new Error("asset pack: an entry runs past its end");
    const name = new TextDecoder().decode(bytes.subarray(at + 16, at + 48)).replace(/\0.*$/s, "");
    out.push({ kind: bytes[at], licence: bytes[at + 1], name, bytes: bytes.subarray(offset, offset + length) });
  }
  return out;
}
function deliver(a) {
  const x = engine?.exports;
  if (!x)
    return;
  if (a.kind === "data" && a.bytes) {
    const at = x.coaxial_asset?.(arena.state, a.i, a.bytes.length) || 0;
    if (at)
      new Uint8Array(memory.buffer, at, a.bytes.length).set(a.bytes);
  }
  x.coaxial_asset_ready?.(arena.state, a.i, a.failed ? 0 : a.size);
}
async function loadAsset(a) {
  const { device } = gpu;
  try {
    if (a.kind === "layers") {
      loading.textures(0, 2 * a.urls.length);
      const images = await Promise.all(a.urls.map(async (u) => {
        const r = await fetch(u);
        if (!r.ok)
          throw new Error(`${u}: ${r.status}`);
        const b = await createImageBitmap(new Blob([await readBytes(r, (l, t) => loading.bytes(u, l, t))]));
        loading.textures(1, 0);
        return b;
      }));
      a.texture = await layerTexture(images);
      a.size = images.length;
    } else {
      const bytes = await fetchedOnce(a.url);
      a.size = bytes.length;
      if (a.kind === "data")
        a.bytes = bytes;
      else {
        const usage = (a.kind === "index" ? GPUBufferUsage.INDEX : GPUBufferUsage.STORAGE) | GPUBufferUsage.COPY_DST;
        const whole = new Uint8Array(align(bytes.length, 4));
        whole.set(bytes);
        a.buffer = device.createBuffer({ size: whole.length, usage });
        device.queue.writeBuffer(a.buffer, 0, whole);
      }
    }
  } catch (e) {
    a.failed = true;
    say(`${app}: ${e.message}`, true);
  }
  a.done = true;
  deliver(a);
  if (a.kind === "mesh")
    bindMesh();
  bindScene();
  loading.assetDone(a.failed && `ASSET FAILED TO LOAD: ${(a.url || "").split("/").pop()}`);
}
var fetches = new Map;
function fetchedOnce(url) {
  if (!fetches.has(url))
    fetches.set(url, (async () => {
      const r = await fetch(url);
      if (!r.ok)
        throw new Error(`${url}: ${r.status}`);
      return readBytes(r, (l, t) => loading.bytes(url, l, t));
    })());
  return fetches.get(url);
}
async function layerTexture(images) {
  const { device } = gpu, [w, h] = [images[0].width, images[0].height];
  const levels = Math.floor(Math.log2(Math.max(w, h))) + 1;
  const texture = device.createTexture({
    size: [w, h, images.length],
    format: "rgba8unorm-srgb",
    mipLevelCount: levels,
    usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT
  });
  for (const [layer, image] of images.entries()) {
    for (let level = 0;level < levels; level++) {
      const lw = Math.max(1, w >> level), lh = Math.max(1, h >> level);
      const source = level === 0 && image.width === w && image.height === h ? image : await createImageBitmap(image, { resizeWidth: lw, resizeHeight: lh, resizeQuality: "high" });
      device.queue.copyExternalImageToTexture({ source }, { texture, mipLevel: level, origin: [0, 0, layer] }, [lw, lh]);
    }
    loading.textures(1, 0);
  }
  return texture;
}
function sceneLayout() {
  if (gpu.sceneLayout)
    return gpu.sceneLayout;
  const x = engine.exports, entries = [];
  const buffer = { visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: "read-only-storage" } };
  for (const a of assets)
    if (a.kind === "storage")
      entries.push({ binding: entries.length, ...buffer });
  for (let k = 0;k < (x.coaxial_stores?.() || 0); k++)
    entries.push({ binding: entries.length, ...buffer });
  if (assets.some((a) => a.kind === "layers")) {
    entries.push({ binding: entries.length, visibility: GPUShaderStage.FRAGMENT, texture: { viewDimension: "2d-array" } });
    entries.push({ binding: entries.length, visibility: GPUShaderStage.FRAGMENT, sampler: {} });
  }
  return gpu.sceneLayout = gpu.device.createBindGroupLayout({ entries });
}
function emptyLayout() {
  if (!gpu.emptyLayout) {
    gpu.emptyLayout = gpu.device.createBindGroupLayout({ entries: [] });
    gpu.emptyGroup = gpu.device.createBindGroup({ layout: gpu.emptyLayout, entries: [] });
  }
  return gpu.emptyLayout;
}
function shadowLayout() {
  if (gpu.shadowLayout)
    return gpu.shadowLayout;
  const { device } = gpu, size = matchMedia("(pointer: coarse)").matches ? 1024 : 2048;
  gpu.shadowLayout = device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: "depth" } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: "comparison" } }
  ] });
  gpu.shadowMap = device.createTexture({ size: [size, size], format: "depth32float", usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
  gpu.shadowGroup = device.createBindGroup({ layout: gpu.shadowLayout, entries: [
    { binding: 0, resource: gpu.shadowMap.createView() },
    { binding: 1, resource: device.createSampler({ compare: "less", magFilter: "linear", minFilter: "linear" }) }
  ] });
  return gpu.shadowLayout;
}
function postLayouts() {
  if (gpu.postLayouts)
    return gpu.postLayouts;
  const f = GPUShaderStage.FRAGMENT, device = gpu.device;
  const tex = (binding) => ({ binding, visibility: f, texture: {} });
  gpu.postLayouts = {
    bloom: device.createBindGroupLayout({ entries: [tex(0), { binding: 1, visibility: f, sampler: {} }, { binding: 2, visibility: f, buffer: {} }] }),
    post: device.createBindGroupLayout({ entries: [
      tex(0),
      tex(1),
      tex(2),
      tex(3),
      { binding: 4, visibility: f, texture: { sampleType: "depth" } },
      { binding: 5, visibility: f, sampler: {} }
    ] })
  };
  gpu.linear = device.createSampler({ magFilter: "linear", minFilter: "linear", addressModeU: "clamp-to-edge", addressModeV: "clamp-to-edge" });
  gpu.steps = [[0, 0, 0, 4], [1, 0, 1, 1], [0, 1, 1, 1], [1, 0, 1, 2], [0, 1, 1, 1]].map((v) => {
    const b = device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    device.queue.writeBuffer(b, 0, new Float32Array(v));
    return b;
  });
  return gpu.postLayouts;
}
function postTargets(w, h) {
  const { device } = gpu, use = GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING;
  for (const t of gpu.postTextures || [])
    t.destroy();
  const copied = gpu.waterCopy ? GPUTextureUsage.COPY_SRC : 0;
  const make = (tw, th, format) => device.createTexture({ size: [Math.max(1, tw), Math.max(1, th)], format, usage: use });
  const light = device.createTexture({ size: [w, h], format: "rgba16float", usage: use | copied }), aux = make(w, h, "rgba16float");
  const q0 = make(Math.ceil(w / 4), Math.ceil(h / 4), "rgba16float"), q1 = make(q0.width, q0.height, "rgba16float");
  const e0 = make(Math.ceil(w / 8), Math.ceil(h / 8), "rgba16float"), e1 = make(e0.width, e0.height, "rgba16float");
  gpu.depth?.destroy();
  gpu.depth = device.createTexture({ size: [w, h], format: "depth32float", usage: use | copied });
  gpu.postTextures = [light, aux, q0, q1, e0, e1];
  gpu.waterCopyGroup = null;
  if (gpu.waterCopy) {
    const into = (format) => device.createTexture({ size: [w, h], format, usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
    gpu.waterLight = into("rgba16float");
    gpu.waterDepth = into("depth32float");
    gpu.postTextures.push(gpu.waterLight, gpu.waterDepth);
    gpu.waterCopyGroup = device.createBindGroup({ layout: waterCopyLayout(), entries: [
      { binding: 0, resource: gpu.waterLight.createView() },
      { binding: 1, resource: gpu.waterDepth.createView() }
    ] });
  }
  const { bloom, post } = postLayouts();
  const group = (src, k) => device.createBindGroup({ layout: bloom, entries: [
    { binding: 0, resource: src.createView() },
    { binding: 1, resource: gpu.linear },
    { binding: 2, resource: { buffer: gpu.steps[k] } }
  ] });
  gpu.light = light;
  gpu.aux = aux;
  gpu.blooms = [[q0, group(light, 0)], [q1, group(q0, 1)], [q0, group(q1, 2)], [e1, group(q0, 3)], [e0, group(e1, 4)]];
  gpu.postGroup = device.createBindGroup({ layout: post, entries: [light, q0, e0, aux, gpu.depth].map((t, binding) => ({ binding, resource: t.createView() })).concat([{ binding: 5, resource: gpu.linear }]) });
}
function bindScene() {
  const gpuAssets = assets.filter((a) => ["storage", "index", "layers"].includes(a.kind));
  if (!gpu || gpu.sceneGroup || !engine?.exports.coaxial_draws || gpuAssets.some((a) => !a.done || a.failed))
    return;
  const x = engine.exports, { device } = gpu, resources = [];
  for (const a of assets)
    if (a.kind === "storage")
      resources.push({ buffer: a.buffer });
  gpu.stores = [];
  gpu.storeVersions = [];
  for (let k = 0;k < (x.coaxial_stores?.() || 0); k++) {
    const buffer = device.createBuffer({ size: align(Math.max(x.coaxial_store_cap(k), 16), 16), usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
    gpu.stores.push(buffer);
    resources.push({ buffer });
  }
  const layers = assets.find((a) => a.kind === "layers");
  if (layers) {
    resources.push(layers.texture.createView({ dimension: "2d-array" }));
    resources.push(device.createSampler({ magFilter: "linear", minFilter: "linear", mipmapFilter: "linear", addressModeU: "repeat", addressModeV: "repeat", maxAnisotropy: 8 }));
  }
  gpu.index = assets.find((a) => a.kind === "index")?.buffer;
  gpu.sceneGroup = device.createBindGroup({ layout: sceneLayout(), entries: resources.map((resource, binding) => ({ binding, resource })) });
}
var MEDIA_KIND = 607;
var MEDIA_MAX = 112;
var media = new Map;
var MEDIA_WGSL = `
struct M { rect: vec4f, look: vec4f };
@group(0) @binding(0) var<uniform> m: M;
@group(0) @binding(1) var t: texture_2d<f32>;
@group(0) @binding(2) var s: sampler;
struct O { @builtin(position) p: vec4f, @location(0) uv: vec2f };
@vertex fn vs(@builtin(vertex_index) i: u32) -> O {
  var c = array(vec2f(0, 0), vec2f(1, 0), vec2f(0, 1), vec2f(0, 1), vec2f(1, 0), vec2f(1, 1));
  let k = c[i];
  var o: O;
  o.p = vec4f(mix(m.rect.x, m.rect.z, k.x), mix(m.rect.y, m.rect.w, k.y), 0, 1);
  o.uv = k;
  return o;
}
@fragment fn fs(o: O) -> @location(0) vec4f { return vec4f(textureSample(t, s, o.uv).rgb * m.look.x, 1); }`;
function mediaPipeline(depth) {
  const key = depth ? "mediaDepth" : "media";
  if (gpu[key] !== undefined)
    return gpu[key];
  const { device, format } = gpu;
  gpu.mediaLayout ||= device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: {} },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: {} },
    { binding: 2, visibility: GPUShaderStage.FRAGMENT, sampler: {} }
  ] });
  gpu.mediaSampler ||= device.createSampler({ magFilter: "linear", minFilter: "linear", addressModeU: "clamp-to-edge", addressModeV: "clamp-to-edge" });
  const module = device.createShaderModule({ code: MEDIA_WGSL });
  gpu[key] = device.createRenderPipeline({
    layout: device.createPipelineLayout({ bindGroupLayouts: [gpu.mediaLayout] }),
    vertex: { module, entryPoint: "vs" },
    fragment: { module, entryPoint: "fs", targets: [{ format }] },
    ...depth ? { depthStencil: { format: "depth32float", depthWriteEnabled: false, depthCompare: "always" } } : {}
  });
  return gpu[key];
}
function mediaTold() {
  send(MEDIA_KIND, [...media.values()].filter((m) => m.ready || m.failed).map((m) => `${m.url} ${m.failed ? 0 : m.w} ${m.failed ? 0 : m.h}`).join(`
`));
}
function mediaTexture(m, w, h) {
  m.w = w;
  m.h = h;
  m.texture = gpu.device.createTexture({ size: [w, h], format: "rgba8unorm", usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT });
  m.buffer = gpu.device.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  mediaPipeline(false);
  m.group = gpu.device.createBindGroup({ layout: gpu.mediaLayout, entries: [
    { binding: 0, resource: { buffer: m.buffer } },
    { binding: 1, resource: m.texture.createView() },
    { binding: 2, resource: gpu.mediaSampler }
  ] });
}
function mediaOpen(kind, url) {
  const m = { kind, url, el: null, texture: null, w: 0, h: 0, ready: false, failed: false, unseen: 0, buffer: null, group: null };
  media.set(`${kind} ${url}`, m);
  const fail = () => {
    if (media.get(`${kind} ${url}`) !== m)
      return;
    m.failed = true;
    mediaTold();
  };
  if (kind === "image") {
    fetch(url, { credentials: "same-origin" }).then((r) => r.ok ? r.blob() : Promise.reject(new Error(String(r.status)))).then((b) => createImageBitmap(b)).then(async (img) => {
      if (media.get(`${kind} ${url}`) !== m)
        return;
      const f = Math.min(1, 2048 / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * f)), h = Math.max(1, Math.round(img.height * f));
      const src = f < 1 ? await createImageBitmap(img, { resizeWidth: w, resizeHeight: h, resizeQuality: "high" }) : img;
      mediaTexture(m, w, h);
      gpu.device.queue.copyExternalImageToTexture({ source: src }, { texture: m.texture }, [w, h]);
      m.ready = true;
      mediaTold();
    }).catch(fail);
  } else {
    const v = document.createElement("video");
    v.muted = true;
    v.defaultMuted = true;
    v.loop = true;
    v.playsInline = true;
    v.autoplay = true;
    v.preload = "auto";
    v.setAttribute("muted", "");
    v.setAttribute("playsinline", "");
    v.addEventListener("loadeddata", () => {
      if (media.get(`${kind} ${url}`) !== m || m.ready)
        return;
      mediaTexture(m, Math.max(1, v.videoWidth), Math.max(1, v.videoHeight));
      m.ready = true;
      mediaTold();
      v.play().catch(() => {});
    });
    v.addEventListener("error", fail);
    v.src = url;
    m.el = v;
    v.play().catch(() => {});
  }
}
function mediaClose(key, m) {
  media.delete(key);
  if (m.el) {
    m.el.pause();
    m.el.removeAttribute("src");
    m.el.load();
  }
  m.texture?.destroy();
  m.buffer?.destroy();
}
function drawMedia(x, pass, w, h, depth, over = false) {
  const n = x.coaxial_media && x.coaxial_media_len ? x.coaxial_media_len(arena.state) : 0;
  const wanted2 = new Set;
  if (n > 0) {
    const text = new TextDecoder().decode(new Uint8Array(memory.buffer, x.coaxial_media(arena.state), n).slice());
    for (const line of text.split(`
`).slice(0, MEDIA_MAX)) {
      const [named2, url, ...b] = line.split(" ");
      const box = b.map(Number);
      const kind = named2 === "over" ? "image" : named2;
      if (kind !== "image" && kind !== "video" || !url?.startsWith("/") || url.startsWith("//") || box.length !== 4 || box.some((v) => !Number.isFinite(v)))
        continue;
      const key = `${kind} ${url}`;
      if (named2 === "over" !== over) {
        wanted2.add(key);
        continue;
      }
      wanted2.add(key);
      if (!media.has(key))
        mediaOpen(kind, url);
      const m = media.get(key);
      if (!m.ready || !m.group)
        continue;
      if (m.el && m.el.readyState >= 2) {
        try {
          gpu.device.queue.copyExternalImageToTexture({ source: m.el }, { texture: m.texture }, [m.w, m.h]);
        } catch {}
      }
      const [x0, y0, x1, y1] = box, bw = x1 - x0, bh = y1 - y0;
      if (bw <= 1 || bh <= 1)
        continue;
      const f = Math.min(bw / m.w, bh / m.h), dw = m.w * f, dh = m.h * f, cx = x0 + (bw - dw) / 2, cy = y0 + (bh - dh) / 2;
      gpu.device.queue.writeBuffer(m.buffer, 0, new Float32Array([cx / w * 2 - 1, 1 - cy / h * 2, (cx + dw) / w * 2 - 1, 1 - (cy + dh) / h * 2, 1, 0, 0, 0]));
      pass.setPipeline(mediaPipeline(depth));
      pass.setBindGroup(0, m.group);
      pass.draw(6);
    }
  }
  if (!over) {
    for (const [key, m] of media)
      if (!wanted2.has(key) && ++m.unseen > 60)
        mediaClose(key, m);
      else if (wanted2.has(key))
        m.unseen = 0;
  }
  if (n > 0 || media.size)
    pass.setBindGroup(0, gpu.bindGroup);
}
var audio = null;
var sounds = new Map;
function startAudio() {
  if (audio || !assets.some((a) => a.kind === "sound" || a.kind === "loop"))
    return;
  try {
    audio = new AudioContext;
  } catch {
    return;
  }
  const loop = assets.find((a) => a.kind === "loop");
  if (loop)
    decoded(loop).then((b) => {
      const s = audio.createBufferSource(), g = audio.createGain();
      s.buffer = b;
      s.loop = true;
      g.gain.value = 0.35;
      s.connect(g).connect(audio.destination);
      s.start();
    }).catch(() => {});
}
function decoded(a) {
  const key = a.url || `pack:${a.name}`;
  if (!sounds.has(key))
    sounds.set(key, (a.bytes ? Promise.resolve(a.bytes.slice().buffer) : fetch(a.url).then((r) => r.arrayBuffer())).then((b) => audio.decodeAudioData(b)));
  return sounds.get(key);
}
var playing = 0;
function playSounds(x) {
  const n = x.coaxial_sounds_len(arena.state);
  if (!n || !audio)
    return;
  const text = new TextDecoder().decode(new Uint8Array(memory.buffer, x.coaxial_sounds(arena.state), n).slice());
  for (const line of text.split(`
`)) {
    const [name, gain, pan] = line.split(" ");
    const a = assets.find((s) => s.kind === "sound" && s.name === name);
    if (!a || playing >= 16)
      continue;
    decoded(a).then((b) => {
      const s = audio.createBufferSource(), g = audio.createGain(), p = audio.createStereoPanner();
      s.buffer = b;
      g.gain.value = Number(gain) || 0;
      p.pan.value = Math.max(-1, Math.min(1, Number(pan) || 0));
      s.connect(g).connect(p).connect(audio.destination);
      playing++;
      s.onended = () => playing--;
      s.start();
    }).catch(() => {});
  }
}
var devicePixels = null;
function observeSize() {
  const take = ([e]) => {
    const s = e.devicePixelContentBoxSize?.[0];
    devicePixels = s ? [s.inlineSize, s.blockSize] : [Math.round(e.contentRect.width * devicePixelRatio), Math.round(e.contentRect.height * devicePixelRatio)];
  };
  try {
    new ResizeObserver(take).observe(canvas, { box: "device-pixel-content-box" });
  } catch {
    new ResizeObserver(take).observe(canvas);
  }
}
var QUALITY = ["high", "medium", "low"];
var QUALITY_CAP = [Infinity, 1.5, 1];
var quality = (() => {
  try {
    const q = QUALITY.indexOf(localStorage.getItem("verse.quality"));
    if (q >= 0)
      return q;
  } catch {}
  return matchMedia("(pointer: coarse)").matches ? 1 : 0;
})();
function setQuality(name) {
  const q = QUALITY.indexOf(name);
  if (q < 0)
    return;
  quality = q;
  try {
    localStorage.setItem("verse.quality", name);
  } catch {}
}
var drawn = (deviceWidth) => {
  if (golden || !canvas.clientWidth)
    return 1;
  const budget = engine?.exports.coaxial_pixel_budget?.() || 0;
  if (budget > 0) {
    const per = deviceWidth / canvas.clientWidth;
    return Math.min(1, Math.sqrt(budget / (canvas.clientWidth * Math.max(1, canvas.clientHeight))) / per, QUALITY_CAP[quality] / per);
  }
  if (!gpu?.scene3d)
    return 1;
  return Math.min(1, QUALITY_CAP[quality] / (deviceWidth / canvas.clientWidth));
};
var scale = () => canvas.width && canvas.clientWidth ? canvas.width / canvas.clientWidth : devicePixelRatio || 1;
var clipping = globalThis.coaxialClip === true;
var clipNow = 0;
if (clipping)
  globalThis.coaxialClipStep = async (frames2 = 1, fps = 30) => {
    for (let k = 0;k < frames2; k++) {
      clipNow += 1000 / fps;
      draw(clipNow);
    }
    if (gpu?.device)
      await gpu.device.queue.onSubmittedWorkDone();
    return engine && gpu?.bg ? 1 : 0;
  };
function frame(now) {
  requestAnimationFrame(frame);
  if (clipping)
    return;
  if (engine && socketHead < socketQueue.length)
    drainSockets(Math.max(2, SOCKET_BUDGET_MS - frameCost));
  const t0 = performance.now();
  try {
    draw(now);
  } finally {
    frameCost = 0.9 * frameCost + 0.1 * (performance.now() - t0);
  }
}
var frameCost = 0;
function draw(now) {
  if (!engine || !gpu?.bg)
    return;
  const dt = last ? (now - last) / 1000 : 0;
  last = now;
  const [dw, dh] = devicePixels || [Math.max(1, Math.round(canvas.clientWidth * devicePixelRatio)), Math.max(1, Math.round(canvas.clientHeight * devicePixelRatio))];
  const f = drawn(dw), w = Math.max(1, Math.round(dw * f)), h = Math.max(1, Math.round(dh * f));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }
  const dpr = scale();
  let n = 0;
  try {
    for (let k = 0;probeAt && !gpu.probed && k < probeAt * 10; k++)
      engine.exports.coaxial_frame(arena.state, arena.vertices, arena.uniforms, w, h, dpr, 0.1, 0);
    if (probeDo && !gpu.probed)
      runProbe(w, h, dpr);
    n = engine.exports.coaxial_frame(arena.state, arena.vertices, arena.uniforms, w, h, dpr, dt, still ? 1 : 0);
    if (gpu.gpuiOn)
      gpuiFrame(dpr);
  } catch (e) {
    say(`${app} trapped: ${e.message}`, true);
    loading.fail(`ENGINE STOPPED: ${e.message}`);
    engine = null;
    return;
  }
  n = Math.min(n, arena.maxVertices);
  const { device, context } = gpu;
  const x = engine.exports;
  device.queue.writeBuffer(gpu.uniformBuffer, 0, new Float32Array(memory.buffer, arena.uniforms, arena.uniformFloats));
  if (n)
    device.queue.writeBuffer(gpu.vertexBuffer, 0, new Float32Array(memory.buffer, arena.vertices, n * arena.floats));
  const draws = gpu.scene && gpu.sceneGroup ? x.coaxial_draw_count(arena.state) : 0;
  if (draws)
    gpu.stores.forEach((buffer, k) => {
      const version = x.coaxial_store_version?.(arena.state, k);
      if (version !== undefined && gpu.storeVersions[k] === version)
        return;
      const bytes = Math.min(x.coaxial_store_bytes(arena.state, k), buffer.size) & ~3;
      if (bytes) {
        device.queue.writeBuffer(buffer, 0, memory.buffer, x.coaxial_store(arena.state, k), bytes);
        gpu.storeVersions[k] = version;
      }
    });
  if ((gpu.scene || gpu.surface) && (!gpu.depth || gpu.depth.width !== w || gpu.depth.height !== h || !!gpu.post !== !!gpu.postGroup || gpu.post && !!gpu.waterCopy !== !!gpu.waterCopyGroup)) {
    if (gpu.post)
      postTargets(w, h);
    else {
      gpu.depth?.destroy();
      gpu.postGroup = null;
      gpu.depth = device.createTexture({ size: [w, h], format: "depth32float", usage: GPUTextureUsage.RENDER_ATTACHMENT });
    }
  }
  const post = gpu.post && gpu.postGroup;
  const encoder = device.createCommandEncoder();
  const list = draws ? new Uint32Array(memory.buffer, x.coaxial_draws(arena.state), draws * 4) : null;
  const wet = draws && gpu.waterTransmit && x.coaxial_water_draws ? Math.min(x.coaxial_water_draws(arena.state), draws) : 0;
  const drawOne = (pass2, i) => {
    const [first, count, base, instances] = [list[i * 4], list[i * 4 + 1], list[i * 4 + 2], list[i * 4 + 3]];
    if (!count || !instances)
      return;
    if (base & 2147483648)
      pass2.draw(count, instances, first, base & 2147483647);
    else
      pass2.drawIndexed(count, instances, first, 0, base);
  };
  const drawScene = (pass2) => {
    pass2.setBindGroup(1, gpu.sceneGroup);
    pass2.setIndexBuffer(gpu.index, "uint32");
    for (let i = 0;i < draws - wet; i++)
      drawOne(pass2, i);
  };
  const cast = gpu.caster && x.coaxial_caster_instances ? [x.coaxial_caster_vertices(arena.state), x.coaxial_caster_instances(arena.state)] : [0, 0];
  if (draws && gpu.shadow || gpu.caster) {
    const shade = encoder.beginRenderPass({
      colorAttachments: [],
      depthStencilAttachment: { view: gpu.shadowMap.createView(), depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" }
    });
    shade.setBindGroup(0, gpu.bindGroup);
    if (draws && gpu.shadow) {
      shade.setPipeline(gpu.shadow);
      drawScene(shade);
    }
    if (cast[0] && cast[1]) {
      shade.setPipeline(gpu.caster);
      shade.draw(cast[0], cast[1]);
    }
    shade.end();
  }
  const target2 = (view) => ({ view, loadOp: "clear", storeOp: "store", clearValue: { r: 0, g: 0, b: 0, a: 1 } });
  const screen2 = () => target2(context.getCurrentTexture().createView());
  let pass = encoder.beginRenderPass({
    colorAttachments: post ? [target2(gpu.light.createView()), target2(gpu.aux.createView())] : [screen2()],
    ...gpu.scene || gpu.surface ? { depthStencilAttachment: { view: gpu.depth.createView(), depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: post ? "store" : "discard" } } : {}
  });
  pass.setBindGroup(0, gpu.bindGroup);
  if (gpu.caster) {
    pass.setBindGroup(1, gpu.emptyGroup);
    pass.setBindGroup(2, gpu.shadowGroup);
  }
  pass.setPipeline(gpu.bg);
  pass.draw(3);
  const blades = gpu.grass && (gpu.caster || gpu.sceneGroup) ? x.coaxial_grass_instances(arena.state) : 0;
  if (blades) {
    if (!gpu.caster) {
      pass.setBindGroup(1, gpu.sceneGroup);
      if (gpu.shadow)
        pass.setBindGroup(2, gpu.shadowGroup);
    }
    pass.setPipeline(gpu.grass);
    pass.draw(3, blades);
  }
  const surface = gpu.surface ? x.coaxial_surface_vertices(arena.state) : 0;
  if (surface) {
    pass.setPipeline(gpu.surface);
    pass.draw(surface);
  }
  if (draws) {
    pass.setPipeline(gpu.scene);
    if (gpu.shadow)
      pass.setBindGroup(2, gpu.shadowGroup);
    drawScene(pass);
    const sparks = gpu.particles ? x.coaxial_particle_instances(arena.state) : 0;
    if ((wet || sparks && gpu.particleDepth) && post && gpu.waterCopyGroup) {
      pass.end();
      encoder.copyTextureToTexture({ texture: gpu.light }, { texture: gpu.waterLight }, [w, h]);
      encoder.copyTextureToTexture({ texture: gpu.depth }, { texture: gpu.waterDepth }, [w, h]);
      const keep = (view) => ({ view, loadOp: "load", storeOp: "store" });
      pass = encoder.beginRenderPass({
        colorAttachments: [keep(gpu.light.createView()), keep(gpu.aux.createView())],
        depthStencilAttachment: { view: gpu.depth.createView(), depthLoadOp: "load", depthStoreOp: "store" }
      });
      pass.setBindGroup(0, gpu.bindGroup);
      pass.setBindGroup(1, gpu.sceneGroup);
      pass.setBindGroup(2, gpu.shadow ? gpu.shadowGroup : (emptyLayout(), gpu.emptyGroup));
      pass.setBindGroup(3, gpu.waterCopyGroup);
      pass.setIndexBuffer(gpu.index, "uint32");
    }
    for (let i = draws - wet;i < draws; i++) {
      pass.setPipeline(gpu.waterTransmit);
      drawOne(pass, i);
      pass.setPipeline(gpu.waterEmit);
      drawOne(pass, i);
    }
    const bytes = sparks && (!gpu.particleDepth || gpu.waterCopyGroup) ? Math.min(x.coaxial_particle_bytes(arena.state), gpu.particleBuffer.size) & ~3 : 0;
    if (bytes) {
      device.queue.writeBuffer(gpu.particleBuffer, 0, memory.buffer, x.coaxial_particles(arena.state), bytes);
      pass.setBindGroup(1, gpu.particleGroup);
      if (gpu.particleDepth) {
        pass.setBindGroup(2, (emptyLayout(), gpu.emptyGroup));
        pass.setBindGroup(3, gpu.waterCopyGroup);
      }
      if (gpu.particlesOver) {
        pass.setPipeline(gpu.particlesOver);
        pass.draw(6, sparks);
      }
      pass.setPipeline(gpu.particles);
      pass.draw(6, sparks);
    }
  }
  if (post) {
    pass.end();
    for (const [into, group] of gpu.blooms) {
      const b = encoder.beginRenderPass({ colorAttachments: [target2(into.createView())] });
      b.setBindGroup(0, gpu.bindGroup);
      b.setBindGroup(1, group);
      b.setPipeline(gpu.bloom);
      b.draw(3);
      b.end();
    }
    pass = encoder.beginRenderPass({ colorAttachments: [screen2()] });
    pass.setBindGroup(0, gpu.bindGroup);
    pass.setBindGroup(1, gpu.postGroup);
    pass.setPipeline(gpu.post);
    pass.draw(3);
  }
  if (x.coaxial_media)
    drawMedia(x, pass, w, h, !!(gpu.scene || gpu.surface) && !post);
  if (n) {
    pass.setPipeline(gpu.fx);
    pass.setVertexBuffer(0, gpu.vertexBuffer);
    pass.draw(n);
  }
  if (x.coaxial_media)
    drawMedia(x, pass, w, h, !!(gpu.scene || gpu.surface) && !post, true);
  pass.end();
  const texture = context.getCurrentTexture();
  const readback = probe && ++frames >= 1 && !gpu.probed ? readBack(encoder, texture) : null;
  device.queue.submit([encoder.finish()]);
  if (gpu.snap) {
    const take = gpu.snap;
    gpu.snap = null;
    take();
  }
  if (draws && shaderLoads === 0 && installedGeneration === wanted && !globalThis.coaxial.sceneReady && pendingSceneEpoch !== sceneEpoch) {
    let nonempty = false;
    for (let i = 0;i < draws; i++)
      if (list[i * 4 + 1] && list[i * 4 + 3]) {
        nonempty = true;
        break;
      }
    if (nonempty) {
      const epoch = sceneEpoch, generation = installedGeneration, frameEngine = engine, frameGpu = gpu, frameScene = gpu.scene;
      pendingSceneEpoch = epoch;
      device.queue.onSubmittedWorkDone().then(() => {
        if (epoch === sceneEpoch && generation === wanted && shaderLoads === 0 && engine === frameEngine && gpu === frameGpu && gpu.scene === frameScene)
          globalThis.coaxial.sceneReady = true;
      }, (error) => {
        if (epoch === sceneEpoch)
          say(`scene frame: ${error?.message || error}`, true);
      });
    }
  }
  document.documentElement.classList.add("gpu");
  if (loading.on)
    loading.frame(globalThis.coaxial.sceneReady);
  if (readback)
    report(readback, texture);
  if (x.coaxial_sounds)
    playSounds(x);
  after(false);
}
var KEYS = {
  Escape: -1,
  Enter: -2,
  Backspace: -3,
  ArrowLeft: -4,
  ArrowRight: -5,
  ArrowUp: -6,
  ArrowDown: -7,
  Home: -8,
  End: -9,
  PageUp: -10,
  PageDown: -11,
  Delete: -12,
  Shift: -13,
  Control: -14,
  Tab: -15
};
var call = (name, ...args) => engine && engine.exports[name] ? engine.exports[name](arena.state, ...args) : 0;
var field = null;
var touched = false;
var keptKey = `coaxial.${slot}.kept`;
var keptDb = null;
var keptRead = (async () => {
  keptDb = await new Promise((ok) => {
    try {
      const r = indexedDB.open("coaxial", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kept");
      r.onsuccess = () => ok(r.result);
      r.onerror = r.onblocked = () => ok(null);
    } catch {
      ok(null);
    }
  });
  const read = (key) => !keptDb ? "" : new Promise((ok) => {
    try {
      const q = keptDb.transaction("kept").objectStore("kept").get(key);
      q.onsuccess = () => ok(typeof q.result === "string" ? q.result : "");
      q.onerror = () => ok("");
    } catch {
      ok("");
    }
  });
  const local = (key) => {
    try {
      return localStorage.getItem(key) || "";
    } catch {
      return "";
    }
  };
  let text = await read(slot) || local(keptKey);
  if (!text && slotWas)
    text = await read(slotWas) || local(`coaxial.${slotWas}.kept`);
  return text;
})();
function keep(text) {
  if (keptDb) {
    try {
      const t = keptDb.transaction("kept", "readwrite");
      t.objectStore("kept").put(text, slot);
      t.oncomplete = () => {
        try {
          localStorage.removeItem(keptKey);
        } catch {}
      };
      return;
    } catch {}
  }
  try {
    localStorage.setItem(keptKey, text);
  } catch {}
}
var PLACE_KIND = 11;
var placeKey = `coaxial.${slot}.place`;
var BAR_KIND = 12;
var barKey = `coaxial.${slot}.bar`;
function local(key) {
  try {
    return localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}
function player() {
  try {
    const p = JSON.parse(localStorage.getItem("verse.player") || "null");
    return p && typeof p.key === "string" ? p : null;
  } catch {
    return null;
  }
}
function send(kind, text = "") {
  const x = engine?.exports;
  if (!x?.coaxial_message)
    return;
  const bytes = new TextEncoder().encode(text).subarray(0, x.coaxial_inbox_cap());
  new Uint8Array(memory.buffer, x.coaxial_inbox(arena.state), bytes.length).set(bytes);
  x.coaxial_message(arena.state, kind, bytes.length);
  after(false);
}
globalThis.coaxial = {
  send,
  ready: false,
  sceneReady: false,
  facts: () => pageFacts(),
  probe: () => engine?.exports.coaxial_probe?.(arena.state) ?? 0,
  guardProbe: (field2 = 0) => engine?.exports.coaxial_guard_probe?.(arena.state, field2) ?? 0
};
globalThis.coaxial.tilt = (dyaw, dpitch) => {
  engine?.exports.coaxial_tilt?.(arena.state, dyaw, dpitch);
};
if (script?.dataset.drops)
  startDrops({ send });
if (script?.dataset.uploads)
  startUploads({ send, accept: script.dataset.uploads });
startDocs({ send });
function snapshot() {
  return new Promise((resolve) => {
    if (!gpu) {
      resolve(null);
      return;
    }
    const timer = setTimeout(() => {
      if (gpu)
        gpu.snap = null;
      resolve(null);
    }, 5000);
    gpu.snap = () => {
      clearTimeout(timer);
      try {
        const c = new OffscreenCanvas(canvas.width, canvas.height);
        c.getContext("2d").drawImage(canvas, 0, 0);
        resolve(c);
      } catch {
        resolve(null);
      }
    };
  });
}
var moment = startMoment({ key: () => player()?.key || "", snapshot });
if (script?.dataset.card)
  startCard({
    url: script.dataset.card,
    key: () => player()?.key || "",
    snapshot,
    ready: () => !!globalThis.coaxial.sceneReady,
    moment: script.dataset.cardOn === "impact" ? moment : null
  });
var voice = script?.dataset.voice ? startVoice({ send, route: script.dataset.voice, wasmUrl: script.dataset.voiceWasm || "/build/voice.wasm" }) : null;
function sendHash() {
  const x = engine?.exports;
  if (!x?.coaxial_hash || !x.coaxial_inbox)
    return;
  let hash = location.hash.slice(1);
  try {
    hash = decodeURIComponent(hash);
  } catch {}
  const bytes = new TextEncoder().encode(hash).subarray(0, x.coaxial_inbox_cap());
  new Uint8Array(memory.buffer, x.coaxial_inbox(arena.state), bytes.length).set(bytes);
  x.coaxial_hash(arena.state, bytes.length);
  after(false);
}
addEventListener("hashchange", sendHash);
function after(gesture, tap = false) {
  if (!engine)
    return;
  const x = engine.exports;
  const want = call("coaxial_wants_text") === 1;
  if (want && document.activeElement !== field ? gesture || !touched : want && tap && touched)
    focusField();
  else if (!want && field && document.activeElement === field)
    field.blur();
  if (field)
    placeField(want);
  const code = call("coaxial_action");
  if (code) {
    const text = new TextDecoder().decode(new Uint8Array(memory.buffer, x.coaxial_outbox(arena.state), x.coaxial_outbox_len(arena.state)).slice());
    call("coaxial_action_done");
    if (code === 1) {
      if (text.startsWith("https://") || /^lightning:ln[a-z0-9]+$/i.test(text))
        location.assign(text);
      else if (text.startsWith("/"))
        location.assign(root && !text.startsWith(root + "/") ? root + (text === "/" ? "/index.html" : text) : text);
    } else if (code === 2)
      navigator.clipboard?.writeText(text).catch(() => {});
    else if (code === 3) {
      if (location.hash.slice(1) !== text)
        history.replaceState(history.state, "", text ? `#${encodeURIComponent(text)}` : location.pathname + location.search);
    } else if (code === 4)
      keep(text);
    else if (code === PLACE_KIND) {
      if (!golden)
        try {
          localStorage.setItem(placeKey, text);
        } catch {}
    } else if (code === BAR_KIND) {
      if (!golden)
        try {
          localStorage.setItem(barKey, text);
        } catch {}
    } else if (code === 6)
      setQuality(text);
    else if (code === ACT_VOICE && voice)
      voice.toggle(text === "end" ? "end" : text === "on");
    else if (code === ACT_VOICE_TO && voice)
      voice.face(text);
    else if (code === ACT_VOICE_SAY && voice)
      voice.say(text);
    else if (code === 5) {
      try {
        const p = JSON.parse(text);
        if (p && typeof p.key === "string")
          localStorage.setItem("verse.player", text);
      } catch {}
    } else
      dispatchEvent(new CustomEvent("coaxial", { detail: { code, text } }));
  }
  const cursor = ["", "pointer", "crosshair", "text"][call("coaxial_cursor")] || "";
  if ((canvas.dataset.cursor || "") !== cursor)
    canvas.dataset.cursor = cursor;
}
function placeField(want) {
  const x = engine.exports;
  const r = want && x.coaxial_field ? new Float32Array(memory.buffer, x.coaxial_field(arena.state), 4) : [0, 0, 0, 0];
  const dpr = scale();
  const box = r[2] > r[0] ? [r[0] / dpr, r[1] / dpr, (r[2] - r[0]) / dpr, (r[3] - r[1]) / dpr] : [0, 0, 1, 1];
  const key = box.map(Math.round).join();
  if (field.dataset.at === key)
    return;
  field.dataset.at = key;
  field.style.left = `${box[0]}px`;
  field.style.top = `${box[1]}px`;
  field.style.width = `${box[2]}px`;
  field.style.height = `${box[3]}px`;
}
function focusField() {
  if (!field) {
    field = document.createElement("input");
    for (const [k, v] of Object.entries({
      "aria-label": "Typed text",
      autocomplete: "off",
      autocapitalize: "off",
      autocorrect: "off",
      spellcheck: "false",
      enterkeyhint: "go"
    }))
      field.setAttribute(k, v);
    field.style.cssText = "position:fixed;left:0;top:0;width:1px;height:1px;margin:0;padding:0;border:0;outline:0;opacity:0;background:transparent;color:transparent;caret-color:transparent;font-size:16px";
    const flush = () => {
      const v = field.value;
      if (v === " ")
        return;
      if (v === "")
        call("coaxial_key", KEYS.Backspace, 0);
      else
        send(1, v.startsWith(" ") ? v.slice(1) : v);
      field.value = " ";
      field.setSelectionRange(1, 1);
      after(false);
    };
    field.addEventListener("input", (e) => {
      if (!e.isComposing)
        flush();
    });
    field.addEventListener("compositionend", flush);
    document.body.append(field);
  }
  if (document.activeElement === field)
    field.blur();
  field.value = " ";
  field.focus({ preventScroll: true });
  field.setSelectionRange(1, 1);
}
var keyOf = (e) => KEYS[e.key] ?? ([...e.key].length === 1 ? e.key.codePointAt(0) : 0);
var modsOf = (e) => (e.shiftKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.altKey ? 4 : 0) | (e.metaKey ? 8 : 0);
addEventListener("keydown", (e) => {
  if (!engine || e.isComposing)
    return;
  startAudio();
  const named2 = KEYS[e.key];
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "v")
    return;
  if (!named2 && e.target === field && !e.metaKey && !e.ctrlKey)
    return;
  const key = keyOf(e);
  if (!key)
    return;
  if (call("coaxial_key", key, modsOf(e)))
    e.preventDefault();
  after(true);
});
addEventListener("keyup", (e) => {
  if (!engine?.exports.coaxial_key_up || e.isComposing)
    return;
  const key = keyOf(e);
  if (key && call("coaxial_key_up", key, modsOf(e)))
    e.preventDefault();
});
addEventListener("blur", () => call("coaxial_blur"));
addEventListener("focus", () => call("coaxial_focus"));
addEventListener("visibilitychange", () => {
  if (document.hidden)
    call("coaxial_blur");
});
canvas.addEventListener("wheel", (e) => {
  if (!engine?.exports.coaxial_wheel)
    return;
  e.preventDefault();
  call("coaxial_wheel", e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 400 : 1));
}, { passive: false });
addEventListener("paste", (e) => {
  if (e.target === field || !engine)
    return;
  const text = e.clipboardData?.getData("text") || "";
  if (text) {
    e.preventDefault();
    send(1, text);
  }
});
var TAP_MS = 600;
var TAP_MOVE = 24;
var AFTER_TOUCH_MS = 800;
var touches = new Map;
var touchAt = -1e9;
canvas?.addEventListener("touchmove", (e) => {
  if (e.cancelable)
    e.preventDefault();
}, { passive: false });
canvas?.addEventListener("contextmenu", (e) => e.preventDefault());
for (const [type, phase] of [["pointerdown", 0], ["pointermove", 1], ["pointerup", 2], ["pointercancel", 3]])
  addEventListener(type, (e) => {
    if (!engine)
      return;
    const touch = e.pointerType !== "mouse", now = performance.now();
    if (touch)
      touchAt = now;
    else if (now - touchAt < AFTER_TOUCH_MS)
      return;
    let { clientX: x, clientY: y } = e, ph = phase;
    if (touch) {
      if (phase === 0)
        touches.set(e.pointerId, { t: now, x0: x, y0: y, x, y });
      const p = touches.get(e.pointerId);
      if (p && phase === 1) {
        p.x = x;
        p.y = y;
      }
      if (p && phase === 3) {
        x = p.x;
        y = p.y;
        if (now - p.t < TAP_MS && Math.hypot(p.x - p.x0, p.y - p.y0) < TAP_MOVE)
          ph = 2;
      }
      if (phase >= 2)
        touches.delete(e.pointerId);
    }
    const dpr = scale();
    if (ph !== 1)
      touched = touch;
    if (ph === 0)
      startAudio();
    call("coaxial_pointer", x * dpr, y * dpr, ph, touch ? 1 : 0, e.pointerId);
    after(ph === 2, ph === 2);
  });
function runProbe(w, h, dpr) {
  for (const step of probeDo.split(";").filter(Boolean)) {
    const op = step[0], arg = step.slice(1);
    if (op === "k")
      for (const c of arg)
        call("coaxial_key", c.codePointAt(0), 0);
    if (op === "K")
      call("coaxial_key", Number(arg), 0);
    if (op === "c") {
      const [cx, cy] = arg.split(",").map(Number);
      for (const ph of [0, 2])
        call("coaxial_pointer", cx * dpr, cy * dpr, ph, 0, 1);
    }
    if (op === "m") {
      const i = arg.indexOf(":");
      send(Number(i < 0 ? arg : arg.slice(0, i)), i < 0 ? "" : arg.slice(i + 1));
    }
    if (op === "t")
      for (let k = 0;k < Number(arg) * 10; k++)
        engine.exports.coaxial_frame(arena.state, arena.vertices, arena.uniforms, w, h, dpr, 0.1, 0);
  }
}
function readBack(encoder, texture) {
  gpu.probed = true;
  const row = align(texture.width * 4, 256);
  const buffer = gpu.device.createBuffer({ size: row * texture.height, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
  encoder.copyTextureToBuffer({ texture }, { buffer, bytesPerRow: row }, [texture.width, texture.height]);
  return { buffer, row };
}
async function report({ buffer, row }, texture) {
  await buffer.mapAsync(GPUMapMode.READ);
  const px = new Uint8Array(buffer.getMappedRange());
  const { width: w, height: h } = texture, cols = 110, rows = 14;
  const x0 = Math.floor(w * 0.3), x1 = Math.floor(w * 0.7), y0 = Math.floor(h * 0.47), y1 = Math.floor(h * 0.53);
  let art = "", peak = 0, sum = 0;
  for (let r = 0;r < rows; r++) {
    let line = "";
    for (let c = 0;c < cols; c++) {
      let m = 0;
      for (let y = y0 + Math.floor((y1 - y0) * r / rows);y < y0 + Math.floor((y1 - y0) * (r + 1) / rows); y++)
        for (let x = x0 + Math.floor((x1 - x0) * c / cols);x < x0 + Math.floor((x1 - x0) * (c + 1) / cols); x++)
          m = Math.max(m, px[y * row + x * 4 + 1]);
      line += " .:-=+*#%@"[Math.min(9, Math.floor(m / 26))];
    }
    art += line + `
`;
  }
  for (let i = 0;i < px.length; i += 4) {
    peak = Math.max(peak, px[i + 1]);
    sum += px[i + 1];
  }
  console.log(`coaxial probe ${w}x${h} peak ${peak} mean ${(sum / (px.length / 4)).toFixed(2)}
${art}`);
}
var note = null;
function say(text, error = false) {
  (error ? console.error : console.log)(`coaxial: ${text}`);
  if (!dev)
    return;
  note ||= Object.assign(document.body.appendChild(document.createElement("pre")), { role: "status" });
  note.style.cssText = `position:fixed;left:12px;bottom:12px;margin:0;max-width:80vw;white-space:pre-wrap;font:12px ui-monospace,monospace;padding:6px 8px;border-radius:6px;background:${error ? "#3a0d0d" : "#111"};color:${error ? "#ffb4b4" : "#9a9a9a"};pointer-events:none`;
  note.textContent = text;
  clearTimeout(note.timer);
  if (!error)
    note.timer = setTimeout(() => (note.textContent = "", note.style.display = "none"), 2500);
  note.style.display = "block";
}
async function fetchEngine(generation) {
  const response = await fetch(wasmUrl, { cache: dev ? "no-store" : "default" });
  if (!response.ok)
    throw new Error(`engine: ${response.status}`);
  const bytes = await readBytes(response, (l, t) => loading.engine(l, t));
  loading.step("compile");
  return loadEngine(bytes, generation);
}
function live() {
  const socket = new WebSocket(`ws://${location.host}/coaxial/live`);
  socket.onmessage = async (event) => {
    const m = JSON.parse(event.data);
    const t0 = performance.now();
    if (m.kind === "page") {
      location.reload();
      return;
    }
    if (m.kind === "error") {
      say(m.text, true);
      return;
    }
    if (m.kind === "wgsl" && gpu) {
      if (await loadShaders())
        say(`shaders swapped in ${Math.round(performance.now() - t0)} ms`);
      return;
    }
    if (m.kind === "wasm") {
      const generation = beginEngine();
      try {
        if (await fetchEngine(generation))
          say(`${app} rebuilt in ${m.ms} ms, swapped in ${Math.round(performance.now() - t0)} ms`);
      } catch (e) {
        say(`${app}: ${e.message}`, true);
      }
    }
  };
  socket.onclose = () => setTimeout(live, 1000);
}
async function main() {
  try {
    await fetchEngine(beginEngine());
    loading.step("gpu");
    const started = await startGpu();
    if (!started) {
      document.documentElement.classList.remove("gpu");
      loading.fail("SHADERS FAILED TO COMPILE", !gpu);
      return;
    }
    observeSize();
    requestAnimationFrame(frame);
    loading.step("assets");
    for (const a of firstAssets)
      loadAsset(a);
    for (const pack of firstPacks)
      loadPack(pack);
  } catch (e) {
    document.documentElement.classList.remove("gpu");
    loading.fail(`${gpu || /gpu|adapter|device/i.test(e.message) ? "GPU" : "ENGINE"} FAILED: ${e.message}`);
    say(`${app}: ${e.message}`, true);
  }
  if (dev)
    live();
}
main();
