"""Private exact Root acceptance for unconsumed common-inventory drift only.

This never builds, runs checks, changes a proof or grants compiler qualification.
Original common receipt/producer hashes stay intact. No work on import.
"""
from pathlib import Path
import hashlib,json
ALLOWED={'coax/platform/screen-native.c','coax/platform/screen-native.h','coax/platform/wayland-native.c','coax/platform/wayland-native.h'}
ROOTS=['coax/src','coax/bootstrap','coax/lib','coax/platform','coax/tools','coax/tests/query','coax/tests/steps']
LINK=['tool-native.c','process-native.c','store-file-native.c','socket-native.c','entropy-native.c','entropy-foreign.c']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def admit(root,common_path,common,reuse_path,reuse_sha256,head,image,fingerprint,normal_sha256,environment):
 root=Path(root).resolve();common_path=Path(common_path).resolve();reuse_path=Path(reuse_path).resolve();assert reuse_path.is_file()and not reuse_path.is_symlink()and sha(reuse_path)==reuse_sha256
 r=json.loads(reuse_path.read_text());assert r['schema']=='coax.changelog.common-entropy-unconsumed-delta-reuse.v1'and r['root_accepted']is True,'exact Root acceptance required'
 assert r['source_base']=='44b25a4b3e83797ed8d6d3ffd9ca885aab8c1449'and r['current_head']==head
 assert r['common']=={'path':str(common_path),'sha256':sha(common_path)}and r['image_sha256']==image and r['fingerprint']==fingerprint and r['normal_receipt_sha256']==normal_sha256
 assert common['schema']=='coax.return-borrow.official-language-tools.v1'and common['gate']=='common'and common['outcome']=='passed'and common['inputs_before']==common['inputs_after']and common['inputs_unchanged']is True
 assert common['compiler_sha256']==image and common['fingerprint']==fingerprint and common['normal_receipt_sha256']==normal_sha256
 assert set(r['allowed_changed_paths'])==ALLOWED and r['protected_roots']==ROOTS and r['forbidden_compiler_library_proto_tool_delta']==[]
 expected={x['path']:x for x in r['changed_unconsumed_inputs']};assert set(expected)==ALLOWED and len(r['changed_unconsumed_inputs'])==4
 changed={};current={}
 for name,digest in common['inputs_before'].items():
  path=Path(name);assert path.is_file()and not path.is_symlink();now=sha(path);current[str(path)]=now
  if now!=digest:
   assert path.is_relative_to(root);rel=str(path.relative_to(root));assert rel in ALLOWED and expected[rel]=={'path':rel,'old_sha256':digest,'new_sha256':now};changed[rel]=expected[rel]
 assert set(changed)==ALLOWED,'no other old input may drift and no missing delta may be relabeled'
 protected={str(p.relative_to(root)):sha(p)for base in ROOTS for p in sorted((root/base).rglob('*'))if p.is_file()and '__pycache__'not in p.parts};assert protected==r['current_protected_inputs'],'current Root code/model/tool/file-set changed'
 assert r['entropy_consumed_inputs']==common['consumed_inputs']and common['consumed_inputs']
 for name,digest in common['consumed_inputs'].items():assert sha(name)==digest and name in common['inputs_before']and common['inputs_before'][name]==digest and not(Path(name).is_relative_to(root)and str(Path(name).relative_to(root))in ALLOWED)
 actual={str(root/'coax/platform'/n):sha(root/'coax/platform'/n)for n in LINK};assert actual==r['actual_native_link_inputs']and all(common['inputs_before'][name]==digest for name,digest in actual.items())
 assert r['entropy_artifacts']==common['artifacts']
 for group in ['artifacts','tool_files']:
  for name,digest in common[group].items():assert Path(name).is_file()and not Path(name).is_symlink()and sha(name)==digest
 assert all(environment.get(key)==value for key,value in common['environment'].items())
 return {'record':{'path':str(reuse_path),'sha256':reuse_sha256},'original_common':{'path':str(common_path),'sha256':sha(common_path)},'unchanged_consumed_entropy':common['consumed_inputs'],'unchanged_native_link_inputs':actual,'allowed_unconsumed_input_delta':changed,'current_inputs':current,'scope':'Explicit Root-accepted four-file unconsumed coarse-inventory delta only. Original common producer/source attribution retained; no new module/entropy emission, no compiler/model/tool/artifact/consumed-source waiver.'}
