"""PREPARED ONLY. Archive completed evidence; never build/test/install/publish.

normal: admit the complete 165-step epoch, not a partial prefix.
final: admit that immutable normal archive and all ten explicitly mapped gates.
No work happens on import. Root must separately authorize execution.
"""
from pathlib import Path
import argparse, gzip, hashlib, io, json, os, re, shlex, stat, subprocess, tarfile, time

A=Path('/tmp/coax-return-borrows-A1').resolve()
R=Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents')
N=A/'normal046-shared-sha-v12-current309-184'
P=A/'normal046-plan8-current309-184-v12-sha'
G=A/'final-v12'
BASE='6225954fae6e81935dae3d19d9024b3c24cda218'
SOURCE='44b25a4b3e83797ed8d6d3ffd9ca885aab8c1449'
FLAGS=['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno']
GATES={'source39','native9','systemone','release','defaults4','independent1000','main11','tools-common','tools-query','tools-steps'}
SHA=re.compile(r'[0-9a-f]{64}')
SCHEMAS={'source39':'coax.borrow-summaries.source-qualification.v1','native9':'coax.return-borrow.final-native-kernel.v1','systemone':'coax.return-borrow.systemone.final-producer.v1','defaults4':'coax.state-defaults.final-qualified-image.v1','independent1000':'coax.borrow-query-work.source.v1','tools-common':'coax.return-borrow.official-language-tools.v1','tools-query':'coax.return-borrow.official-language-tools.v1','tools-steps':'coax.return-borrow.official-language-tools.v1'}
LIMITS='Named normal/final gate evidence only; no visual, publication, credentials, retained async request lifetime, generic alternate-target or whole-model qualification. Source fixtures prove admission, not manual-summary completeness; that is a separate native9 scope.'

class Archive:
    def __init__(self,directory):
        self.start=time.monotonic();self.end=self.start+220
        self.directory=Path(directory).resolve()
        assert self.directory.is_relative_to(A) and not self.directory.exists(),'fresh private output directory required'
        self.files={};self.by_source={};self.omitted=[]
    def tick(self):
        assert time.monotonic()<self.end,'archive exceeded220s; stop without retry'
    def regular(self,path):
        p=Path(path);assert not p.is_symlink() and stat.S_ISREG(p.stat().st_mode),str(p)
        p=p.resolve();assert p.is_relative_to(A),str(p)
        assert not any(s in str(p).lower() for s in ['/publication','/credential','/gcloud','/.env','/oauth']),str(p)
        return p
    def digest(self,path):
        self.tick();h=hashlib.sha256()
        with Path(path).open('rb') as f:
            for block in iter(lambda:f.read(1048576),b''):
                self.tick();h.update(block)
        return h.hexdigest()
    def add(self,path,name,expected=None,kind='proof'):
        self.tick();p=self.regular(path)
        assert not name.startswith('/') and '..'not in Path(name).parts and '\\'not in name
        h=self.digest(p);assert expected is None or h==expected,(str(p),h,expected)
        if str(p)in self.by_source:return self.by_source[str(p)]
        assert name not in self.files and p.stat().st_size<=67108864
        self.files[name]={'source':str(p),'sha256':h,'bytes':p.stat().st_size,'kind':kind}
        self.by_source[str(p)]=name;return name
    def json(self,path,expected=None):
        p=self.regular(path)
        if expected is not None:assert SHA.fullmatch(expected) and self.digest(p)==expected
        return json.loads(p.read_text())
    def raw(self,fact,name):
        assert type(fact)is dict and type(fact['bytes'])is int and fact['bytes']>=0
        member=self.add(fact['path'],name,fact['sha256'],'raw-stream')
        assert self.files[member]['bytes']==fact['bytes'];return Path(fact['path']).read_bytes()
    def process(self,o,name,expected=0):
        assert o['started']is True and o['returncode']==expected
        assert o['stdout_eof']is True and o['stderr_eof']is True
        assert all(k in o and not o[k]for k in FLAGS)
        assert 0<=o['elapsed_s']<870
        return {s:self.raw(o[s],name+'.'+s)for s in ['stdout','stderr']}
    def metadata(self,path,name,expected=None):
        self.add(path,name,expected,'exact-receipt-or-metadata')
        return self.json(path,expected)
    def directory_ready(self):
        self.directory.mkdir(parents=True,exist_ok=False)
    def write(self,name,value):
        p=self.directory/name;p.write_text(json.dumps(value,indent=2)+'\n');return p
    def finish(self,scope):
        self.tick();assert sum(v['bytes']for v in self.files.values())<536870912
        scope['limits']=LIMITS;scope['omitted_temporary_or_external_refs']=list({(r['path'],r['sha256'],r['reason']):r for r in self.omitted}.values())
        self.add(self.write('scope.json',scope),'scope.json',kind='scope')
        self.add(Path(__file__),'archive-maintenance.py',kind='assembler-source')
        manifest={'schema':'coax.a1.v12.archive-manifest.v1','files':self.files,'source_bytes':sum(v['bytes']for v in self.files.values()),'no_directory_sweep':True}
        mf=self.write('manifest.json',manifest)
        members=dict(self.files);members['manifest.json']={'source':str(mf),'sha256':self.digest(mf),'bytes':mf.stat().st_size,'kind':'manifest'}
        out=self.directory/'proof.tar.gz'
        with out.open('xb')as f:
            with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=6)as gz:
                with tarfile.open(fileobj=gz,mode='w')as tar:
                    for name,fact in sorted(members.items()):
                        self.tick();data=Path(fact['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==fact['sha256']
                        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o444;tar.addfile(entry,io.BytesIO(data))
        assert out.stat().st_size<100000000,'compressed archive exceeds100MB'
        seen=set()
        with tarfile.open(out,'r:gz')as tar:
            for entry in tar:
                self.tick();assert entry.isfile() and not entry.name.startswith('/') and '..'not in Path(entry.name).parts and entry.name not in seen
                seen.add(entry.name);data=tar.extractfile(entry).read();fact=members[entry.name]
                assert len(data)==fact['bytes'] and hashlib.sha256(data).hexdigest()==fact['sha256']
        assert seen==set(members)
        assert all(self.digest(v['source'])==v['sha256']for v in self.files.values())
        record={'schema':'coax.a1.v12.validated-proof-archive.v1','outcome':'validated-archive','phase':scope['phase'],'source_revision':SOURCE,'base':BASE,'fingerprint':scope['fingerprint'],'image_sha256':scope['image_sha256'],'normal_sha256':scope['normal_sha256'],'archive':{'path':str(out),'sha256':self.digest(out),'bytes':out.stat().st_size,'members':len(members),'all_member_hashes_verified':True},'manifest':{'path':str(mf),'sha256':self.digest(mf)},'scope':{'path':str(self.directory/'scope.json'),'sha256':self.digest(self.directory/'scope.json')},'limits':LIMITS,'elapsed_s':time.monotonic()-self.start}
        p=self.write('record.json',record)
        for f in [out,mf,p,self.directory/'scope.json']:f.chmod(0o444)
        print(json.dumps({'record':str(p),'sha256':self.digest(p),'archive_sha256':record['archive']['sha256'],'bytes':out.stat().st_size,'phase':scope['phase']}))

def normal(z,a):
    qpath=N/'qualification.json';q=z.json(qpath,a.normal_sha256)
    assert q['schema']=='coax.bootstrap.bounded-composition.v1' and q['outcome']=='passed'
    b=z.json(q['binding'],q['binding_sha256']);plan=z.json(q['plan'],q['plan_sha256'])
    assert Path(q['plan']).resolve()==P/'plan.json'
    assert b['source_revision']==b['observed_source_revision']==SOURCE and b['expected_fingerprint']==a.fingerprint
    ids=[x['id']for x in plan['steps']]
    assert len(ids)==len(set(ids))==165 and q['passed_steps']==q['required_steps']==ids and set(q['receipts'])==set(ids)
    assert plan['required_execution_environment']=={'COAX_BUILD_FRESH':'1','COAX_MUTATION_CHANGED':'strict','COAX_MUTATION_FULL':'1'}
    z.directory_ready();z.metadata(qpath,'normal/qualification.json',a.normal_sha256);z.metadata(q['binding'],'normal/binding.json',q['binding_sha256'])
    rows={}
    for planned in plan['steps']:
        ident=planned['id'];fact=q['receipts'][ident];r=z.metadata(fact['path'],'normal/receipts/'+ident+'.json',fact['sha256'])
        assert r['step']==planned and r['outcome']=='passed' and r['binding_sha256']==q['binding_sha256'] and r['source_revision']==SOURCE and r['expected_fingerprint']==a.fingerprint
        assert r['frozen_inputs_unchanged']is True and r['fresh_gate_execution']is True and r['strict_mutation_execution']is True and r['gate_cache_reuse']is False and r['changed_line_survivor_tolerance']is False
        z.process(r['observation'],'normal/raw/'+ident)
        z.add(N/(ident+'.sh'),'normal/scripts/'+ident+'.sh',r['script_sha256'],'exact-executed-command')
        if r.get('raw_gate_log'):z.raw(r['raw_gate_log'],'normal/raw/'+ident+'.gate.log')
        rows[ident]=r
    for p in P.iterdir():
        if p.is_file():z.add(p,'plan/'+p.name,kind='exact-plan-and-review')
    for p in (P/'infrastructure').rglob('*.py'):z.add(p,'plan/infrastructure/'+str(p.relative_to(P/'infrastructure')),kind='bounded-transport-source')
    seed=z.metadata(b['seed_precondition_receipt'],'seed/precondition.json',b['seed_precondition_sha256'])
    assert seed['source_revision']==SOURCE and seed['compiler_input_fingerprint']==a.fingerprint
    for name,digest in seed['files'].items():
        p=Path(b['snapshot'])/name
        if p.is_file():assert z.digest(p)==digest
        else:
            # Tests/docs in the reviewed precondition need not be compiler
            # snapshot inputs. Bind their committed bytes, never current files.
            z.tick();r=subprocess.run(['git','-C',str(R),'show',SOURCE+':'+name],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_PAGER':'cat'},capture_output=True,timeout=min(10,z.end-time.monotonic()))
            assert r.returncode==0 and hashlib.sha256(r.stdout).hexdigest()==digest
    for name,digest in seed['evidence'].items():
        assert Path(name).suffix=='.json'
        z.add(name,'seed/metadata/'+str(Path(name).resolve().relative_to(A)),digest,'historical-precondition-or-peer-review-metadata')
    for name in ['qualification.json','checker.upstream-defaults.c','checker.new-prototypes.txt']:
        p=A/'seed-defaults-composition-audit'/name
        if p.is_file():z.add(p,'seed/constructor-origin/'+name,kind='historical-exact-constructor-composition-proof')
    for name in ['review.json','inventory.json','audit.py']:
        p=A/'current-books-v12'/name;z.add(p,'books/'+name,kind='static-books-only')
    assert z.digest(A/'current-books-v12/review.json')=='b481e910d990c2f25e1ef8700d625bd61024881a9faba5ab7a3e522f193c617b'
    art=N/'snapshot/coax/bin';names=['coax','provenance-check','provenance.record',*shlex.split(plan['artifact_list'].removeprefix('artifacts=(').removesuffix(')'))]
    assert len(names)==len(set(names))==17
    last=rows[ids[-1]];artifacts={}
    for name in names:
        p=art/name;expected=last['artifacts_after'][str(p)];z.add(p,'qualified-artifacts/'+name,expected,'final-regular-artifact');artifacts[name]=expected
    assert artifacts['coax']==a.image_sha256 and (art/'mutation-survivors').stat().st_size==0
    assert (art/'provenance.record').read_text().splitlines()[1:3]==[a.fingerprint,a.image_sha256]
    for i in range(1,9):
        p=art/f'.bootstrap-bounded-normal/checker.{i}.rec';h=rows[f'checker-shard-{i}']['artifacts_after'][str(p)]
        assert rows['checker-merge']['artifacts_after'][str(p)]==h
        z.add(p,f'normal/checker-shards/{i}.rec',h,'actual-full-scope-shard')
    merge=Path(rows['checker-merge']['raw_gate_log']['path']).read_text()
    m=re.fullmatch(r'\s*(\d+) mutants, (\d+) killed, (\d+) survived\s*',merge)
    assert m and int(m[1])>0 and int(m[1])==int(m[2]) and int(m[3])==0
    # No repeated mutation merger, build, compiler, tests or publication effects.
    env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_PAGER':'cat'}
    def git(args):
        z.tick();r=subprocess.run(['git','-C',str(R),*args],env=env,capture_output=True,timeout=min(30,z.end-time.monotonic()));assert r.returncode==0,'local object read failed';return r.stdout
    paths=git(['diff','--name-only','-z',BASE,SOURCE,'--']).decode().strip('\0').split('\0')
    assert not any(any(s in n.lower()for s in ['credential','publication','.env','secret'])for n in paths)
    patch=git(['diff','--binary','--full-index','--no-ext-diff','--no-textconv',BASE,SOURCE,'--'])
    patchfile=z.directory/'candidate.patch.gz'
    with patchfile.open('xb')as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as gz:gz.write(patch)
    assert gzip.decompress(patchfile.read_bytes())==patch
    z.add(patchfile,'candidate/candidate.patch.gz',kind='exact-source-reconstruction-patch')
    for name in ['state.json','journal.jsonl']:
        if (N/name).is_file():z.add(N/name,'normal/'+name,kind='normal-journal')
    return {'phase':'finished-normal-only','fingerprint':a.fingerprint,'image_sha256':a.image_sha256,'normal_sha256':a.normal_sha256,'required_and_passed_steps':165,'checker_full_mutation':{'mutants':int(m[1]),'killed':int(m[2]),'survived':0,'eight_records_plus_actual_authoritative_merge':True},'final17_artifact_hashes':artifacts,'source_patch':{'base':BASE,'source':SOURCE,'sha256':hashlib.sha256(patch).hexdigest(),'changed_paths':paths},'scope':'Completed44b v12 normal only. No final native/source/SystemOne/tool/visual/publication qualification from this phase. Historical preconditions remain under their own source/producer scope.'}

def unittest_receipt(z,q,name,count,image,fp):
    assert 'schema'not in q and q['compiler_sha256_before']==q['compiler_sha256_after']==image and q['fingerprint']==fp
    streams=z.process(q,'final/'+name)
    text=(streams['stdout']+b'\n'+streams['stderr']).decode(errors='replace')
    matches=re.findall(r'^Ran (\d+) tests? in [0-9.]+s$',text,re.M)
    assert matches==[str(count)] and re.search(r'^OK\s*$',text,re.M)
    assert not re.search(r'^(?:FAILED|OK \(|.*\.\.\. skipped )',text,re.M)

def final(z,a):
    old=z.json(a.normal_record,a.normal_record_sha256)
    assert old['schema']=='coax.a1.v12.validated-proof-archive.v1' and old['phase']=='finished-normal-only' and old['outcome']=='validated-archive' and old['source_revision']==SOURCE
    image,fp,normal_sha=old['image_sha256'],old['fingerprint'],old['normal_sha256']
    normal_scope=z.json(old['scope']['path'],old['scope']['sha256'])
    normal_artifacts=normal_scope['final17_artifact_hashes']
    cfg=z.json(a.gates)
    assert cfg['schema']=='coax.a1.v12.explicit-final-gate-map.v1' and set(cfg['gates'])==GATES
    assert cfg['normal_record_sha256']==a.normal_record_sha256 and cfg['image_sha256']==image and cfg['fingerprint']==fp
    z.directory_ready();z.metadata(a.normal_record,'normal-package/record.json',a.normal_record_sha256)
    for name in ['archive','manifest','scope']:z.add(old[name]['path'],'normal-package/'+Path(old[name]['path']).name,old[name]['sha256'],'previously-self-verified-normal-package')
    z.add(a.gates,'final-gate-map.json',kind='explicit-caller-map')
    admitted={};receipts={}
    def local(path,gate):
        p=z.regular(path);assert p.is_relative_to(G/gate);return p
    def collect(value,gate):
        # Follow explicit fact refs, not directories or full Root input inventories.
        if isinstance(value,dict):
            refs=[]
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):refs.append((value['path'],value['sha256']))
            for key in ['binary','c','header','library']:
                if isinstance(value.get(key),str) and isinstance(value.get(key+'_sha256'),str):refs.append((value[key],value[key+'_sha256']))
            for key,digest in value.items():
                if isinstance(key,str) and key.startswith('/') and isinstance(digest,str) and SHA.fullmatch(digest):refs.append((key,digest))
            for path,digest in refs:
                if not SHA.fullmatch(digest):continue
                p=Path(path)
                if p.is_file() and p.resolve().is_relative_to(G):
                    z.add(p,'final/files/'+str(p.resolve().relative_to(G)),digest,'explicit-gate-ref')
                else:z.omitted.append({'path':path,'sha256':digest,'reason':'External tool/SDK/Root input, normal-package ref or cleaned internal temporary variant; receipt hash preserved. Not claimed retained/reexecuted.'})
            for v in value.values():collect(v,gate)
        elif isinstance(value,list):
            for v in value:collect(v,gate)
    for gate in sorted(GATES):
        e=cfg['gates'][gate];assert e['kind']==gate and len(e['receipts'])==(3 if gate=='main11'else 1)
        qs=[]
        for i,ref in enumerate(e['receipts']):
            path=local(ref['path'],gate);q=z.metadata(path,f'final/{gate}/receipt-{i}.json',ref['sha256']);qs.append(q)
        q=qs[0];receipts[gate]=q
        if gate in ['release','main11']:
            expected=[18]if gate=='release'else[7,3,1]
            assert e['expected_unittest_counts']==expected
            for i,(r,count)in enumerate(zip(qs,expected)):unittest_receipt(z,r,f'{gate}/run-{i}',count,image,fp)
        else:
            assert q['schema']==e['schema'] and q['outcome']=='passed'
            if gate in SCHEMAS:assert q['schema']==SCHEMAS[gate]
            assert q['compiler_sha256']==image
            if 'fingerprint'in q:assert q['fingerprint']==fp
            if 'normal_receipt_sha256'in q:assert q['normal_receipt_sha256']==normal_sha
            assert q['inputs_unchanged']is True
            if gate=='source39':
                assert q['compiler_sha256_after']==image and q['source_before']==q['source_after'] and len(q['cases'])==len(q['selection'])==len(set(q['selection']))==39
                manifest=Path(e['manifest']['path']).resolve();assert manifest==R/'coax/tests/borrow-summaries/fixtures.json' and z.digest(manifest)==e['manifest']['sha256']
                assert q['source_before'][str(manifest)]==e['manifest']['sha256'] and q['selection']==[x['id']for x in json.loads(manifest.read_text())['cases']]
                ids=[]
                for c in q['cases']:
                    assert c['outcome']=='passed' and c['diagnostic_transport_error']is None and c['returncode']==(1 if c['expected_diagnostics']else 0)
                    ids.append(c['id'])
                    for stream in ['stdout','stderr']:z.add(path.parent/(c['id']+'.'+stream),f'final/source39/raw/{c["id"]}.{stream}',c[stream+'_sha256'],'raw-source-fixture')
                    assert not (path.parent/(c['id']+'.stdout')).read_bytes()
                    diagnostics=[json.loads(line)for line in (path.parent/(c['id']+'.stderr')).read_text().splitlines()]
                    assert [{'file':str(Path(x['file']).resolve()),'line':x['line'],'col':x['col'],'code':x['code']}for x in diagnostics]==c['expected_diagnostics']
                assert ids==q['selection']
            elif gate=='native9':
                assert q['tests_run']==len(q['methods'])==9 and len({x['method']for x in q['methods']})==9 and all(x['outcome']=='passed'for x in q['methods'])
                assert q['source_before']==q['source_after'] and q['layouts'] and all(x['before_cdll']is True for x in q['layouts']) and q['loads']
                for i,r in enumerate(q['commands']):
                    if r.get('kind')=='retained-qualified-normal-emission':
                        module=r['module'];assert module in ['lexer','parser','checker'] and r['c_sha256']==normal_artifacts[module+'.c'] and r['header_sha256']==normal_artifacts[module+'.h']
                        for ext in ['c','h']:z.add(path.parent/(module+'.'+ext),'final/native9/normal-reused/'+module+'.'+ext,normal_artifacts[module+'.'+ext],'retained-qualified-normal-module')
                        continue
                    z.process(r,f'final/native9/command-{i}')
            elif gate=='systemone':
                assert q['reuse_requirements'] and q['c_sha256'] and q['header_sha256']
                z.add(path.parent/'systemone.c','final/systemone/actual-systemone.c',q['c_sha256'],'actual-consumer-C')
                z.add(path.parent/'systemone.h','final/systemone/actual-systemone.h',q['header_sha256'],'actual-consumer-header')
                assert json.loads((path.parent/'profile.json').read_text())==q['input_manifest']
                z.add(path.parent/'profile.json','final/systemone/emission-profile.json',kind='actual-consumed-manifest')
                if q.get('reuse_eligible'):
                    assert all(x is True for x in q['reuse_requirements'].values()) and q['retained_profiles'] and 'retained'in q['native_scope'].lower()
                    nr=z.json(q['prior_receipt'],q['prior_receipt_sha256'])
                    z.add(q['prior_receipt'],'final/systemone/retained-prior-receipt.json',q['prior_receipt_sha256'],'historical-native-producer-scope')
                else:
                    ref=q['fresh_native_receipt'];nr=z.metadata(local(ref['path'],gate),'final/systemone/fresh-native.json',ref['sha256'])
                    assert nr['inputs_unchanged']is True and nr['artifacts_unchanged']is True and nr['c_sha256']==q['c_sha256'] and nr['header_sha256']==q['header_sha256']
                    collect(nr,gate)
                assert nr['schema']=='coax.borrow-return.systemone.native.v1' and nr['outcome']=='passed' and set(nr['profiles'])=={'O0','O2','sanitized'}
                for name,profile in nr['profiles'].items():
                    assert profile['outcome']=='passed' and profile['observed']['digits_cases']==129 and profile['observed']['stderr_cases']==45
                    z.add(profile['binary'],'final/systemone/profiles/'+name+'.bin',profile['binary_sha256'],'actual-profile-binary-original-attribution')
                for i,r in enumerate(q['commands']):z.process(r,f'final/systemone/command-{i}')
                for r in nr['commands']:
                    if r.get('kind')=='retained-fresh-normal-emission':continue
                    assert r['returncode']==0
                    for stream in ['stdout','stderr']:
                        p=Path(q.get('fresh_native_receipt',{}).get('path',q['prior_receipt'])).parent/(r['label']+'.'+stream)
                        if p.is_file():z.add(p,'final/systemone/native-raw/'+p.name,r[stream+'_sha256'],'native-profile-raw')
                        else:z.omitted.append({'path':str(p),'sha256':r[stream+'_sha256'],'reason':'Historical/cleaned internal native raw path; not claimed newly retained.'})
            elif gate=='independent1000':
                assert q['source_before']==q['source_after'];streams=z.process(q['observation'],'final/independent1000/run');assert not streams['stdout'] and not streams['stderr']
            elif gate.startswith('tools-'):
                assert q['gate']==gate.removeprefix('tools-') and q['inputs_before']==q['inputs_after']
                labels={}
                for i,r in enumerate(q['observations']):
                    assert r['passed']is True;labels[r['label']]=z.process(r['observation'],f'final/{gate}/observation-{i}',r['expected_exit'])
                if gate=='tools-common':assert {'current-provenance','entropy-emission'}<=set(labels)
                else:
                    assert {'tool-emission','native-driver-build','whole-official-'+q['gate']}<=set(labels)
                    assert (q['gate']+': ok\n').encode()in labels['whole-official-'+q['gate']]['stdout']
                    if gate=='tools-steps':
                        for name in ['steps_zero-E0220','steps_name-E0220']:assert b'E0220'in labels[name]['stderr']and not labels[name]['stdout']
            elif gate=='defaults4':
                validate_defaults(z,q,e,path,image,fp)
        for r in qs:collect(r,gate)
        admitted[gate]={'receipt_refs':e['receipts'],'scope':'Actual recorded gate only; any retained native producer attribution stays unchanged.'}
    for gate in ['tools-query','tools-steps']:
        assert receipts[gate]['common_reference']['sha256']==cfg['gates']['tools-common']['receipts'][0]['sha256']
    for ref in cfg.get('pinned_inputs',[]):
        p=Path(ref['path']).resolve();assert p.is_file() and (p.is_relative_to(A)or p.is_relative_to(R/'coax/tests')or p.is_relative_to(R/'coax/tools')) and p.suffix in ['.py','.sh','.json','.md']
        # Root files are explicit reviewed tooling only, never a broad inventory.
        if p.is_relative_to(R):
            assert z.digest(p)==ref['sha256'];copy=z.directory/('pinned-'+str(len(z.files))+p.suffix);copy.write_bytes(p.read_bytes());z.add(copy,'pinned-inputs/'+str(p.relative_to(R)),ref['sha256'],'explicit-pinned-tooling')
        else:z.add(p,'pinned-inputs/'+str(p.relative_to(A)),ref['sha256'],'explicit-pinned-tooling')
    return {'phase':'all-ten-listed-final-gates','fingerprint':fp,'image_sha256':image,'normal_sha256':normal_sha,'normal_archive_record_sha256':a.normal_record_sha256,'admitted_final_gates':admitted,'internal_unittest_artifacts':'Main11/release retain top-level group raw output/count and supplied tooling pins. Their internal temporary C/native variants may be deleted and may lack individual byte/hash records; this archive does not claim to reconstruct every such variant.','scope':'All ten explicitly listed gates, attached to an actual complete normal archive. This is not an additional bootstrap or a visual/publication/lifetime qualification.'}

def validate_defaults(z,q,e,path,image,fp):
    assert q['action']=='state-defaults' and q['tests_run']==4 and q['source_revision']==SOURCE
    assert q['broader_inventory_before']==q['broader_inventory_after']
    for i,row in enumerate(q['commands']):
        assert row['passed']is True;z.process(row['observation'],f'final/defaults4/outer-{i}')
    ref=q['test_result'];child=Path(ref['path']).resolve();assert child.is_relative_to(G/'defaults4')
    r=z.metadata(child,'final/defaults4/test-result.json',ref['sha256'])
    assert r['schema']=='coax.state-defaults.qualified-test-observation.v1' and r['outcome']=='passed' and r['compiler_sha256']==image
    assert r['tests_run']==4 and r['failures']==r['errors']==0 and r['skipped']==[] and r['official_test_bodies_unchanged']is True
    expected={'test_header_declares_defaulted_types_only','test_native_in_place_defaults_match_coax_init','test_two_libraries_sharing_a_defaulted_type_link','test_wasm_state_starts_with_native_bytes'}
    assert len(r['methods'])==4 and {x['method'].split('.')[-1]for x in r['methods']}==expected and all(x['outcome']=='passed'for x in r['methods'])
    assert len(r['profiles'])==9
    for i,row in enumerate(r['commands']):
        assert row['passed']is True;z.process(row['observation'],f'final/defaults4/child-{i}')
    for i,profile in enumerate(r['profiles']):
        assert Path(profile['path']).resolve().is_relative_to(G/'defaults4') and profile['consumed_inputs']
        z.metadata(profile['path'],f'final/defaults4/profile-{i}.json',profile['sha256'])
        z.add(profile['emitted_C'],f'final/defaults4/emitted-{i}.c',profile['emitted_C_sha256'],'actual-emitted-C')

def main():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='phase',required=True)
    n=s.add_parser('normal');n.add_argument('--normal-sha256',required=True);n.add_argument('--image-sha256',required=True);n.add_argument('--fingerprint',required=True)
    f=s.add_parser('final');f.add_argument('--normal-record',required=True);f.add_argument('--normal-record-sha256',required=True);f.add_argument('--gates',required=True)
    for x in [n,f]:x.add_argument('--output',required=True)
    a=p.parse_args();z=Archive(a.output)
    scope=normal(z,a)if a.phase=='normal'else final(z,a);z.finish(scope)
if __name__=='__main__':main()
