#include "state.c"
#include <stdio.h>
#include <string.h>
static coax_t_State want, got;
int main(void) {
  want = coax_init_t_State();
  memset(&got, 0xab, sizeof got);
  coax_default_t_State(&got);
  fwrite(&want, sizeof want, 1, stdout);
  fwrite(&got, sizeof got, 1, stdout);
  return 0;
}
