#include "state.h"
#include "other.h"
#include <string.h>
static coax_t_State s;
__attribute__((export_name("size"))) unsigned size(void) { return sizeof s; }
__attribute__((export_name("init"))) unsigned init(void) {
  memset(&s, 0xab, sizeof s);
  coax_default_t_State(&s);
  return (unsigned)(unsigned long)&s;
}
__attribute__((export_name("step"))) long long step(void) { return other_step(s.clock); }
