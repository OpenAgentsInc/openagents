const x = (await WebAssembly.instantiate(require("fs").readFileSync(process.argv[2]), {})).instance.exports
const at = x.init(), n = x.size()
process.stdout.write(Buffer.from(new Uint8Array(x.memory.buffer, at, n)).toString("hex") + " " + x.step())
