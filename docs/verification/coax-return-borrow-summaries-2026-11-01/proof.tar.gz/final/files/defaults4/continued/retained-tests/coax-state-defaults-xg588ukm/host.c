#include "state.h"
#include "other.h"
#include <stdio.h>
int main(void) { coax_t_Clock c; coax_default_t_Clock(&c);
  printf("%lld %lld\n", (long long)other_step(c), (long long)c.max_steps); return 0; }
