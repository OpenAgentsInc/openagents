#!/usr/bin/env python3
"""Prepare/run focused final native transport, only on a parent-qualified compiler."""
import argparse,ctypes as C,hashlib,json,os,pathlib,shutil,sys,time,unittest
p=argparse.ArgumentParser();p.add_argument('--compiler',required=True);p.add_argument('--sha256',required=True);p.add_argument('--fingerprint',required=True);p.add_argument('--normal-receipt',required=True);p.add_argument('--record-dir',required=True);a=p.parse_args()
ROOT=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');compiler=pathlib.Path(a.compiler).resolve();D=pathlib.Path(a.record_dir).resolve();D.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(compiler)==a.sha256;assert (ROOT/'coax/bin/provenance.record').read_text().splitlines()[1:3]==[a.fingerprint,a.sha256]
sys.path[:0]=[str(ROOT/'coax/tests'),str(ROOT/'coax/tools')];import checker as CK,parser as PS,lexer as LX,bounded_process
methods=['test_independent_layout_and_constant_typing','test_quantity_graph_transport_and_device_option','test_spatial_graph_transport_and_device_option','test_independent_policy_errors','test_local_backed_borrow_returns','test_borrowed_parameter_returns_remain_valid','test_return_borrow_completeness_is_observed_not_assumed','test_actual_kernel_capacity_and_types_under_sanitizers']
inputs=[compiler,pathlib.Path(a.normal_receipt).resolve(),pathlib.Path(__file__),ROOT/'coax/tests/checker.py',ROOT/'coax/tests/parser.py',ROOT/'coax/tests/lexer.py',ROOT/'coax/tools/bounded_process.py',ROOT/'coax/tests/quiet_crash.py',ROOT/'coax/bin/provenance.record',ROOT/'coax/bin/provenance-check',*sorted((ROOT/'coax/lib/compiler').rglob('*.coax')),*sorted((ROOT/'coax/tests/borrow-summaries').rglob('*')),*[ROOT/f'coax/{folder}/{m}.{s}' for folder in ['bin','bootstrap'] for m in ['lexer','parser','checker'] for s in ['c','h']]]
inputs=[p for p in inputs if p.is_file()];before={str(p):sha(p) for p in inputs}
record={'schema':'coax.return-borrow.final-native-kernel.v1','scope':'Focused actual native layout/type/return-origin/workspace controls on the newly qualified normal compiler artifacts. No retained checkpoint1 status claims are relabeled. Coax compiler module C/H are reused from the completed normal seed/fixed-point gate rather than re-emitting/repeating its passing authority checks.','compiler':str(compiler),'compiler_sha256':a.sha256,'fingerprint':a.fingerprint,'normal_receipt':str(pathlib.Path(a.normal_receipt).resolve()),'normal_receipt_sha256':sha(a.normal_receipt),'source_before':before,'commands':[],'layouts':[],'loads':[],'observations':[],'methods':[],'outcome':'not-checked'}
def save():
 record['source_after']={k:sha(k) if pathlib.Path(k).is_file() else None for k in before};record['inputs_unchanged']=record['source_after']==before
 if not record['inputs_unchanged']:record['outcome']='input-changed'
 (D/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
def clean(r):return r['started'] and r['returncode']==0 and r['stdout_eof'] and r['stderr_eof'] and not any(r.get(k) for k in ['timeout', 'deadline_exhausted', 'stdout_limit', 'stderr_limit', 'output_limit', 'group_killed', 'kill_errno', 'launch_errno', 'launch_error', 'read_errno'])
deadline=time.monotonic()+810
def checked(args,**kwargs):
 save();assert record['inputs_unchanged'],'frozen input changed';args=list(map(str,args));i=len(record['commands']);stem=D/f'command-{i:03}'
 if args[0]==str(ROOT/'coax/bin/coax'):
  assert args[1]=='c' and '--header' in args;name=pathlib.Path(args[2]).stem;assert name in ['lexer','parser','checker'];c=ROOT/f'coax/bin/{name}.c';h=ROOT/f'coax/bin/{name}.h';assert sha(c)==sha(ROOT/f'coax/bootstrap/{name}.c') and sha(h)==sha(ROOT/f'coax/bootstrap/{name}.h')
  shutil.copyfile(h,pathlib.Path(args[args.index('--header')+1]));shutil.copyfile(c,D/(name+'.c'));shutil.copyfile(h,D/(name+'.h'));record['commands'].append({'kind':'retained-qualified-normal-emission','requested_argv':args,'module':name,'c_sha256':sha(c),'header_sha256':sha(h),'scope':'No producer rerun; actual normal-build module artifacts and source/seed fixed-point equality retained.'});save();return c.read_bytes()
 r=bounded_process.run(args,None,kwargs.get('env'),180,8388608,deadline,quiet_faults=True)
 for stream in ['stdout','stderr']:
  raw=r.pop(stream);q=stem.with_suffix('.'+stream);q.write_bytes(raw);r[stream]={'path':str(q),'bytes':len(raw),'sha256':sha(q)}
 if '-o' in args:
  product=pathlib.Path(args[args.index('-o')+1])
  if product.is_file():target=stem.with_suffix('.artifact');shutil.copyfile(product,target);r['artifact']={'path':str(target),'original_path':str(product),'sha256':sha(target)}
 record['commands'].append(r);save();assert clean(r),pathlib.Path(r['stderr']['path']).read_text(errors='replace');return pathlib.Path(r['stdout']['path']).read_bytes()
LX.checked=checked
checked([ROOT/'coax/provenance.sh','verify',ROOT,compiler,ROOT/'coax/bin/provenance-check',ROOT/'coax/bin/provenance.record'])
layout=PS.assert_native_layouts

def guard(header,records):
 actual=layout(header,records);record['layouts'].append({'header_sha256':sha(header),'actual':actual,'before_cdll':True});save();return actual
PS.assert_native_layouts=guard
rename={'begin':'text_begin','end':'text_end','integer':'int_value','floating':'float_value','width':'float_bits'}
class LxToken(C.Structure):_fields_=[(rename.get(n,n),t) for n,t in LX.Token._fields_]
class LxItem(C.Structure):_fields_=[(n,LxToken if n=='token' else t) for n,t in LX.Item._fields_]
for native,alias in [(LxToken,LX.Token),(LxItem,LX.Item)]:
 assert C.sizeof(native)==C.sizeof(alias) and C.alignment(native)==C.alignment(alias)
 for n,_ in alias._fields_:assert getattr(native,rename.get(n,n)).offset==getattr(alias,n).offset
cdll=C.CDLL

def load(path,*args,**kwargs):
 if str(path).endswith('lexer.dylib'):guard(LX.Lexer.header,[('coax_string',LX.Text),('coax_t_LX_Loc',LX.Loc),('coax_t_LX_Token',LxToken),('coax_t_LX_Diagnostic',LX.Diagnostic),('coax_t_LX_Item',LxItem),('coax_t_LX_State',LX.State),('coax_v_t_LX_State',LX.StateView),('coax_v_u8',LX.BytesView)])
 p=pathlib.Path(path);record['loads'].append({'path':str(path),'sha256':sha(p)});save();return cdll(path,*args,**kwargs)
C.CDLL=load
original_check=CK.Checker.check

def check(self,source,*args,**kwargs):
 result=original_check(self,source,*args,**kwargs);ok,n,t,e,s,_=result
 record['observations'].append({'source':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'accepted':bool(ok),'typed_graph_published':bool(ok),'procedures':[{'declaration_index':i,'name':LX.raw(x.name).decode(errors='replace'),'status':x.borrow_status} for i,x in enumerate(n[:s.used+1]) if x.kind==64] if ok else None,'diagnostics':[{'code':LX.raw(x.code).decode(),'line':x.loc.line,'column':x.loc.column} for x in e[:s.error_count]]});save();return result
CK.Checker.check=check
class Result(unittest.TextTestResult):
 def addSuccess(self,test):super().addSuccess(test);record['methods'].append({'method':test.id(),'outcome':'passed'});save()
 def addFailure(self,test,err):super().addFailure(test,err);record['methods'].append({'method':test.id(),'outcome':'failed','traceback':self._exc_info_to_string(err,test)});save()
 def addError(self,test,err):super().addError(test,err);record['methods'].append({'method':test.id(),'outcome':'error','traceback':self._exc_info_to_string(err,test)});save()
suite=unittest.TestSuite([CK.TransportABI('test_generated_seed_headers_match_ctypes'),*[CK.Checker(n) for n in methods]])
try:
 start=time.monotonic();r=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite);record.update(outcome='passed' if r.wasSuccessful() and r.testsRun==9 else 'failed',tests_run=r.testsRun,elapsed_s=time.monotonic()-start)
finally:save()
sys.exit(0 if record['outcome']=='passed' else 1)
