"""Prepared only: fresh official query/steps tools on one completed normal image."""
import argparse,base64,hashlib,json,os,pathlib,platform,shutil,sys,time
p=argparse.ArgumentParser();p.add_argument('--gate',choices=['common','query','steps'],required=True);p.add_argument('--compiler',required=True);p.add_argument('--sha256',required=True);p.add_argument('--fingerprint',required=True);p.add_argument('--normal-receipt',required=True);p.add_argument('--normal-sha256',required=True);p.add_argument('--record-dir',required=True);p.add_argument('--common');a=p.parse_args()
R=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');B=pathlib.Path(a.compiler).resolve();D=pathlib.Path(a.record_dir).resolve();D.mkdir(parents=True,exist_ok=False);sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert platform.system()=='Darwin','Prepared flags mirror actual audited Darwin tool.sh; review another host explicitly'
assert sha(B)==a.sha256 and B== (R/'coax/bin/coax').resolve() and not (R/'coax/bin/coax').is_symlink()
provenance=R/'coax/bin/provenance.record';assert provenance.read_text().splitlines()[1:3]==[a.fingerprint,a.sha256]
Q=pathlib.Path(a.normal_receipt).resolve();assert sha(Q)==a.normal_sha256;q=json.loads(Q.read_text());assert q['schema']=='coax.bootstrap.bounded-composition.v1'and q['outcome']=='passed'and q['required_steps']and q['passed_steps']==q['required_steps']and 'target-install-cache'in q['passed_steps']
assert len(q['required_steps'])==len(set(q['required_steps'])) and set(q['receipts'])==set(q['required_steps'])
proof={str(Q):sha(Q)}
for key in ['binding','plan']:
 path=pathlib.Path(q[key]);assert sha(path)==q[key+'_sha256'];proof[str(path)]=sha(path)
binding=json.loads(pathlib.Path(q['binding']).read_text());assert binding['expected_fingerprint']==a.fingerprint
snapshot=pathlib.Path(binding['snapshot'])/'coax/bin/coax';assert sha(snapshot)==a.sha256;proof[str(snapshot)]=sha(snapshot)
for fact in q['receipts'].values():
 path=pathlib.Path(fact['path']);assert sha(path)==fact['sha256'];proof[str(path)]=sha(path)
sys.path[:0]=[str(R/'coax/tools'),str(R/'coax/tests')];from bounded_process import run
FLAGS=['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'];deadline=time.monotonic()+840;env=os.environ.copy();(D/'tmp').mkdir();env['TMPDIR']=str(D/'tmp')
roots=['coax/src','coax/bootstrap','coax/lib','coax/platform','coax/tools','coax/tests/query','coax/tests/steps'];extras=['coax/tests/query.coax','coax/tests/steps.coax','coax/tests/fail/steps_zero.coax','coax/tests/fail/steps_name.coax','coax/tests/proto/types.pb','coax/tests/quiet_crash.py','coax/provenance.sh','coax/bin/provenance.record','coax/bin/provenance-check','coax/build.sh','coax/bootstrap-build.sh','coax/mutation-gate.sh','coax/check-proto-cap.sh','coax/provenance-bridge.c','coax/release.coax','coax/release-model.coax','coax/changelog.coax','coax/changelog-model.coax','coax/changelog-bridge.c','scripts/coax-release.sh','coax/web/tool.sh']
def inventory():
 paths=[p for d in roots for p in (R/d).rglob('*')if p.is_file()and '__pycache__'not in p.parts]+[R/n for n in extras]+[B,pathlib.Path(__file__).resolve(),pathlib.Path(sys.executable).resolve()]
 return {str(p):sha(p)for p in sorted(set(paths))}
environment={n:os.environ.get(n)for n in ['PATH','CC','CXX','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET','COAX_HOST_TARGET','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','LIBRARY_PATH','COAX_CC']}
before=inventory();artifacts={};observations=[];tools={};record={'schema':'coax.return-borrow.official-language-tools.v1','gate':a.gate,'outcome':'not-checked','compiler':str(B),'compiler_sha256':a.sha256,'fingerprint':a.fingerprint,'normal_receipt':str(Q),'normal_receipt_sha256':a.normal_sha256,'normal_proof_documents':proof,'environment':environment,'inputs_before':before,'artifacts':artifacts,'tool_files':tools,'observations':observations,'scope':'Exact current completed-normal installed image. Fresh explicit private tool emission/link; no tool.sh cache, fallback/bootstrap, query --write or source changes. Each whole official driver runs once. Common entropy emission is shared without repeating its passed authority compile.'}
def save():
 record['inputs_after']=inventory();record['inputs_unchanged']=before==record['inputs_after'];(D/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
def guard():
 assert environment=={n:os.environ.get(n)for n in environment}
 assert before==inventory()and proof=={p:sha(p)for p in proof}and artifacts=={p:sha(p)for p in artifacts}and tools=={p:sha(p)for p in tools}
def invoke(label,argv,seconds=120,expected=0,cap=33554432,out=None):
 guard();row=run([str(x)for x in argv],str(R/'coax'),env,seconds,cap,deadline,quiet_faults=True);raw={}
 for key in ['stdout','stderr']:
  raw[key]=row.pop(key);path=D/(label+'.'+key);path.write_bytes(raw[key]);row[key]={'path':str(path),'bytes':len(raw[key]),'sha256':sha(path)}
 clean=row['started']and row['returncode']==expected and row['stdout_eof']and row['stderr_eof']and not any(row.get(n)for n in FLAGS);observations.append({'label':label,'argv':[str(x)for x in argv],'cwd':str(R/'coax'),'expected_exit':expected,'observation':row,'passed':clean});save();assert clean,(label,raw['stderr'][-1800:]);guard()
 if out:pathlib.Path(out).write_bytes(raw['stdout'])
 return raw
def encode(value):
 if isinstance(value,bytes):return {'base64':base64.b64encode(value).decode(),'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}
 if isinstance(value,dict):return {str(k):encode(v)for k,v in value.items()}
 if isinstance(value,(list,tuple)):return [encode(v)for v in value]
 return value

def emission_profile(path,cfile):
 m=json.loads(path.read_text())
 for key in ['emitted_sha256','artifact_sha256']:
  if key in m:assert m[key]==sha(cfile),(key,'does not match actual emitted C')
 consumed={}
 for kind in ['sources','descriptors']:
  assert type(m[kind])is list
  for item in m[kind]:
   name=item.get('resolved_path')or item['path'];assert sha(name)==item['sha256'];consumed[name]=item['sha256']
 assert consumed;artifacts[str(path)]=sha(path);record.setdefault('consumed_inputs',{}).update(consumed)

if a.gate=='common':
 invoke('current-provenance',[R/'coax/provenance.sh','verify',R,B,R/'coax/bin/provenance-check',provenance])
 cc=pathlib.Path('/usr/bin/clang').resolve();tools[str(cc)]=sha(cc)
 from native_execution_identities import inspect
 def identify(argv,timeout_s=10,max_output_bytes=1048576,quiet_faults=True):
  raw=invoke('identity-'+str(len(observations)),argv,timeout_s,cap=max_output_bytes)
  o=observations[-1]['observation'].copy();o.update(raw);return o
 chain=inspect([str(cc)],identify,cwd=R/'coax',environment=env);record['native_toolchain']=encode(chain)
 for item in chain.get('sdk',{}).get('settings_files',[]):
  path=item.get('resolved_path')or item.get('path');tools[path]=sha(path)
 invoke('entropy-emission',[B,'c',R/'coax/lib/crypto/entropy.coax','--library','--header',D/'entropy-policy.h','--profile-report',D/'entropy-profile.json'],out=D/'entropy.c')
 emission_profile(D/'entropy-profile.json',D/'entropy.c')
 for path in [D/'entropy.c',D/'entropy-policy.h']:artifacts[str(path)]=sha(path)
else:
 assert a.common,'A passed same-producer common gate must be supplied; no implicit entropy rebuild'
 C=pathlib.Path(a.common).resolve();cq=C/'qualification.json';common=json.loads(cq.read_text());assert common['gate']=='common'and common['outcome']=='passed'and common['compiler_sha256']==a.sha256 and common['fingerprint']==a.fingerprint and common['normal_receipt_sha256']==a.normal_sha256 and common['environment']==environment
 assert common['inputs_before']==common['inputs_after']and all(sha(n)==v for n,v in common['inputs_before'].items())
 assert all(sha(n)==v for n,v in common['artifacts'].items())and all(sha(n)==v for n,v in common['tool_files'].items());tools.update(common['tool_files']);artifacts.update(common['artifacts']);record['common_reference']={'path':str(cq),'sha256':sha(cq)};proof[str(cq)]=sha(cq);record['native_toolchain']=common['native_toolchain']
 source=R/('coax/tests/'+a.gate+'.coax');invoke('tool-emission',[B,'c',source,'--library','--profile-report',D/'emission-profile.json'],out=D/(a.gate+'.c'));emission_profile(D/'emission-profile.json',D/(a.gate+'.c'));artifacts[str(D/(a.gate+'.c'))]=sha(D/(a.gate+'.c'))
 cc=pathlib.Path('/usr/bin/clang').resolve();assert tools[str(cc)]==sha(cc);P=R/'coax/platform';driver=D/(a.gate+'-driver');argv=[cc,'-D_DARWIN_C_SOURCE','-std=c11','-O2','-I'+str(C),'-I'+str(P),'-o',driver,D/(a.gate+'.c'),*[P/n for n in ['tool-native.c','process-native.c','store-file-native.c','socket-native.c','entropy-native.c','entropy-foreign.c']],C/'entropy.c','-framework','Security','-lm'];invoke('native-driver-build',argv,180);artifacts[str(driver)]=sha(driver)
 raw=invoke('whole-official-'+a.gate,[driver,B],300);assert (a.gate+': ok\n').encode()in raw['stdout']
 if a.gate=='steps':
  for name in ['steps_zero','steps_name']:
   raw=invoke(name+'-E0220',[B,'check',R/('coax/tests/fail/'+name+'.coax')],30,expected=1);assert b'E0220'in raw['stderr']and not raw['stdout']
record['outcome']='passed';guard();save();print(json.dumps({'outcome':'passed','gate':a.gate,'receipt':str(D/'qualification.json'),'sha256':sha(D/'qualification.json')}))
