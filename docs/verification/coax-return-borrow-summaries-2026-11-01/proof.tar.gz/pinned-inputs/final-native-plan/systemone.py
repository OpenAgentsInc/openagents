#!/usr/bin/env python3
"""One fresh producer emission, exact reuse admission or fresh native profiles."""
import argparse,hashlib,json,os,pathlib,shlex,shutil,sys,time,unittest
p=argparse.ArgumentParser();p.add_argument('--compiler',required=True);p.add_argument('--sha256',required=True);p.add_argument('--fingerprint',required=True);p.add_argument('--record-dir',required=True);a=p.parse_args()
ROOT=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');D=pathlib.Path(a.record_dir).resolve();D.mkdir(parents=True,exist_ok=False);compiler=pathlib.Path(a.compiler).resolve();sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(compiler)==a.sha256;assert (ROOT/'coax/bin/provenance.record').read_text().splitlines()[1:3]==[a.fingerprint,a.sha256]
sys.path[:0]=[str(ROOT/'coax/tools'),str(ROOT/'coax/tests')];import bounded_process
old_path=pathlib.Path('/tmp/coax-return-borrows-A1/systemone-checkpoint-1/qualification.json');old=json.loads(old_path.read_text());assert sha(old_path)=='326f1e4df2702aad1b21ee81fb36cdc4e7c53527f8b09e8d06c00b2938a513df' and old['outcome']=='passed';deadline=time.monotonic()+810
r={'schema':'coax.return-borrow.systemone.final-producer.v1','scope':'Fresh normal producer acceptance plus exact immutable native reuse when fully established, otherwise new native profiles using the same already-emitted artifacts. Prior development receipts retain their actual producer attribution. No request/cancellation lifetime proof.','compiler':str(compiler),'compiler_sha256':a.sha256,'fingerprint':a.fingerprint,'prior_receipt':str(old_path),'prior_receipt_sha256':sha(old_path),'commands':[],'outcome':'not-checked'}
def save():(D/'qualification.json').write_text(json.dumps(r,indent=2)+'\n')
def command(label,argv):
 fact=bounded_process.run(list(map(str,argv)),str(ROOT),None,180,8388608,deadline,quiet_faults=True)
 for stream in ['stdout','stderr']:
  raw=fact.pop(stream);q=D/(label+'.'+stream);q.write_bytes(raw);fact[stream]={'path':str(q),'bytes':len(raw),'sha256':sha(q)}
 r['commands'].append(fact);save();assert fact['started'] and fact['returncode']==0 and fact['stdout_eof'] and fact['stderr_eof'] and not any(fact.get(k) for k in ['timeout', 'deadline_exhausted', 'stdout_limit', 'stderr_limit', 'output_limit', 'group_killed', 'kill_errno', 'launch_errno', 'launch_error', 'read_errno']),fact
 return pathlib.Path(fact['stdout']['path']).read_bytes()
command('provenance',[ROOT/'coax/provenance.sh','verify',ROOT,compiler,ROOT/'coax/bin/provenance-check',ROOT/'coax/bin/provenance.record'])
fixture=ROOT/'coax/tests/borrow-summary-return/systemone.coax';header=D/'systemone.h';c=D/'systemone.c';manifest=D/'profile.json'
raw=command('emission',[compiler,'c',fixture,'--library','--arithmetic','checked','--header',header,'--profile-report',manifest]);c.write_bytes(raw);profile=json.loads(manifest.read_text());consumed={}
for key in ['emitted_sha256','artifact_sha256']:
 if key in profile:assert profile[key]==sha(c),f'{key} does not bind the fresh C bytes'
for category in ['sources','descriptors']:
 assert type(profile[category]) is list
 for fact in profile[category]:
  name=fact.get('resolved_path') or fact['path'];assert sha(name)==fact['sha256'];consumed[name]=fact['sha256']
assert consumed
native_files={str(ROOT/p):sha(ROOT/p) for p in ['coax/tests/borrow-summary-return/systemone-native.c','coax/tests/borrow_summary_systemone.py','coax/tests/quiet_crash.py']}
cc=shlex.split(os.environ.get('CC','cc'));resolved=shutil.which(cc[0]);assert resolved
chain={'argv':cc,'resolved_program':str(pathlib.Path(resolved).resolve()),'program_sha256':sha(resolved),'version':command('cc-version',[*cc,'--version']).decode(errors='replace')}
if sys.platform=='darwin':
 sdk=command('sdk-path',['xcrun','--show-sdk-path']).decode().strip();chain['sdk_path']=sdk;chain['sdk_version']=command('sdk-version',['xcrun','--show-sdk-version']).decode().strip();chain['sdk_settings']={str(path):sha(path) for path in [pathlib.Path(sdk)/'SDKSettings.json',pathlib.Path(sdk)/'SDKSettings.plist'] if path.is_file()}
env={key:os.environ.get(key) for key in ['CC','PATH','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR','CPATH','C_INCLUDE_PATH','LIBRARY_PATH']}
same_sources=old.get('consumed_input_before')==consumed
old_native_ok=all(pathlib.Path(p).is_file() and sha(p)==digest for p,digest in old['source_before'].items())
same_native_files=all(old['source_before'].get(p)==digest for p,digest in native_files.items() if p.endswith(('systemone-native.c','borrow_summary_systemone.py')))
reuse=sha(c)==old['c_sha256'] and sha(header)==old['header_sha256'] and same_sources and old_native_ok and same_native_files and old.get('native_toolchain')==chain and old.get('native_environment')==env
r.update(c_sha256=sha(c),header_sha256=sha(header),input_manifest=profile,consumed_inputs=consumed,native_files=native_files,native_toolchain=chain,native_environment=env,reuse_eligible=reuse,reuse_requirements={'exact_C_H':sha(c)==old['c_sha256'] and sha(header)==old['header_sha256'],'exact_consumed_inputs':same_sources,'all_old_native_inputs_present_and_unchanged':old_native_ok and same_native_files,'retained_toolchain_and_environment_proof':old.get('native_toolchain')==chain and old.get('native_environment')==env});save()
if reuse:
 for name,fact in old['profiles'].items():assert sha(fact['binary'])==fact['binary_sha256']
 r['retained_profiles']=old['profiles'];r['native_scope']='Retained actual checkpoint1 development executions, separately bound through exact artifacts/inputs/toolchain/flags.'
else:
 # Reuse only the fresh emission above, not an old native result. The existing independent driver and exact profile flags remain authoritative.
 os.environ['COAX_TEST_COMPILER']=str(compiler);os.environ['COAX_BORROW_SYSTEMONE_RECORD_DIR']=str(D/'fresh-native')
 import borrow_summary_systemone as M
 cls=M.SystemOneReturnedBuffers;original=cls.execute.__func__
 def execute(k,label,argv,env=None):
  if label!='emit':return original(k,label,argv,env)
  shutil.copyfile(header,k.header);shutil.copyfile(manifest,k.directory/'emission-profile.json');k.record['commands'].append({'label':'emit','kind':'retained-fresh-normal-emission','reference':str(D/'emission.stdout'),'sha256':sha(c),'scope':'No producer rerun; fresh acceptance above.'});return c.read_bytes()
 cls.execute=classmethod(execute)
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(cls);result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);assert result.wasSuccessful() and result.testsRun==3
 native=D/'fresh-native/qualification.json';nr=json.loads(native.read_text());assert nr['outcome']=='passed' and nr['c_sha256']==r['c_sha256'] and nr['header_sha256']==r['header_sha256'];r['fresh_native_receipt']={'path':str(native),'sha256':sha(native)};r['native_scope']='New O0/O2/ASan+UBSan executions on fresh artifacts. Prior development profile receipts remain unchanged.'
assert sha(compiler)==a.sha256 and sha(c)==r['c_sha256'] and sha(header)==r['header_sha256'] and all(sha(p)==digest for p,digest in consumed.items()) and all(sha(p)==digest for p,digest in native_files.items()) and sha(resolved)==chain['program_sha256']
if 'sdk_settings' in chain:assert all(sha(p)==digest for p,digest in chain['sdk_settings'].items())
r['outcome']='passed';r['inputs_unchanged']=True;save();print(json.dumps({'outcome':'passed','reused_native':reuse,'receipt':str(D/'qualification.json')}))
