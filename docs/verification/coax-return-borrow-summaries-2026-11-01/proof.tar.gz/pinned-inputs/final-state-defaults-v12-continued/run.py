"""PREPARED ONLY: retain six real passed probes, correct alias, run four unexecuted methods.
Original failed receipt/controller/observer and all raw evidence stay immutable.
"""
import hashlib,json,os,pathlib,shutil,subprocess,sys,time
START=time.monotonic();DEADLINE=START+840
R=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents')
A=pathlib.Path('/tmp/coax-return-borrows-A1');G=A/'final-v12';ORIGINAL=A/'final-state-defaults-v12'
D=G/'defaults4/continued';OLD=G/'defaults4/qualification.json';OLD_OUTER=G/'transports/defaults4.json'
B=R/'coax/bin/coax';IMAGE='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
FP='7c749e9b2c4f487d74a0b506393d104104cafcbe058ec6c39d4af1fb7e956f2d';SOURCE='44b25a4b3e83797ed8d6d3ffd9ca885aab8c1449'
Q=A/'normal046-shared-sha-v12-current309-184/qualification.json';QS='cfd90bb0b29e59417478a69c69cb25bf46bb39416fbe6e87f8db9b2575e2aef8'
FLAGS=['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno']
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(ORIGINAL/'run.py')=='1232e45f504e60423ab25220b35bf30eb6a32a3b267c8c4ea08c10bfa3b2a1f2'
assert sha(ORIGINAL/'observe.py')=='3306df56b4ce46ae5d103302fd5b4c4b81006bed723bd9839c716c664314a98b'
assert sha(OLD)=='8bd175e5fccf606b7af915220c80c366fb507d7501d4998bebd28758d543494c'
assert sha(OLD_OUTER)=='2ea573159776a8f470cb52fead407359e8a89dc3883f43d6e23307b508935057'
old=json.loads(OLD.read_text());assert old['inputs_unchanged']is True and old['broader_inventory_before']==old['broader_inventory_after']
assert old['compiler_sha256']==IMAGE and old['fingerprint']==FP and old['normal_receipt_sha256']==QS and old['source_revision']==SOURCE
labels=['source-head','current-provenance','actual-wasm-linker','native-cc-version','bun-version','wasm-clang-version']
assert [r['label']for r in old['commands']]==labels+['wasm-ld-version']
retained=[]
for r in old['commands'][:6]:
    o=r['observation'];assert r['passed']is True and o['started']and o['returncode']==0 and o['stdout_eof']and o['stderr_eof']and not any(o[k]for k in FLAGS)
    for stream in ['stdout','stderr']:
        f=o[stream];assert sha(f['path'])==f['sha256']and pathlib.Path(f['path']).stat().st_size==f['bytes']
    retained.append({**r,'execution_scope':'Retained actual prior successful probe, not executed in this continuation.','retained_from':{'path':str(OLD),'sha256':sha(OLD)}})
failed=old['commands'][-1];assert failed['passed']is False and failed['observation']['returncode']==1
for stream in ['stdout','stderr']:
    f=failed['observation'][stream];assert sha(f['path'])==f['sha256']and pathlib.Path(f['path']).stat().st_size==f['bytes']
assert not(G/'defaults4/retained-tests').exists(),'Original four methods unexpectedly executed'
assert sha(B)==IMAGE and sha(Q)==QS and (R/'coax/bin/provenance.record').read_text().splitlines()[1:3]==[FP,IMAGE]
proof={**old['normal_proof_documents'],str(OLD):sha(OLD),str(OLD_OUTER):sha(OLD_OUTER)}
normal=json.loads(Q.read_text());assert normal['outcome']=='passed'and normal['required_steps']==normal['passed_steps']and len(normal['required_steps'])==len(set(normal['required_steps']))==165 and set(normal['receipts'])==set(normal['required_steps'])
before={**old['broader_inventory_before'],str(pathlib.Path(__file__).resolve()):sha(__file__)}
tools=dict(old['tool_files'])
assert all(sha(p)==h for p,h in {**before,**tools,**proof}.items())
env=os.environ.copy();env['COAX_BIN']=str(B)
for name in ['COAXIAL_CLANG','COAXIAL_SYSROOT','COAXIAL_RESOURCES']:
    env[name]=env.get(name)or old['environment'][name]
keys=list(old['environment']);expected_environment={k:env.get(k)for k in keys}
assert expected_environment==old['environment'],'Actual source/toolchain environment differs from retained probes'
for row in retained:
    logical=row['argv'][0];p=pathlib.Path(logical)
    resolved=p.resolve(strict=True)if p.is_absolute()else pathlib.Path(shutil.which(logical,path=env.get('PATH'))or'/missing').resolve(strict=True)
    assert str(resolved)in tools and sha(resolved)==tools[str(resolved)],'Retained tool resolution differs'
alias=pathlib.Path(retained[2]['observation']['stdout']['path']).read_text().strip()
assert alias and '\n'not in alias
prepend='/opt/homebrew/opt/lld/bin'if sys.platform=='darwin'else str(pathlib.Path(env.get('COAXIAL_TOOLCHAIN',str(pathlib.Path.home()/'.cache/coax-wasm-toolchain')))/'bin')
link_env=dict(env,PATH=prepend+os.pathsep+env.get('PATH',''))
alias_path=pathlib.Path(alias)if pathlib.Path(alias).is_absolute()else pathlib.Path(shutil.which(alias,path=link_env['PATH'])or'/missing')
physical=alias_path.resolve(strict=True)
assert str(physical)==old['wasm_linker']['path']and sha(physical)==old['wasm_linker']['sha256']
assert not D.exists();D.mkdir();(D/'tmp').mkdir();env['TMPDIR']=str(D/'tmp');link_env['TMPDIR']=env['TMPDIR']
sys.path.insert(0,str(R/'coax/tools'));from bounded_process import run
commands=list(retained)
record={**{k:old[k]for k in ['schema','action','compiler','compiler_sha256','fingerprint','normal_receipt','normal_receipt_sha256','source_revision','native_SDK_scope']},'outcome':'not-checked','scope':'Explicit continuation: six prior successful probes retained under original PID/timing/argv; corrected wasm-ld alias identity and four never-executed official methods run now, with read-only consistency guards. Prior failed physical-lld probe remains nonpassing history. No new compiler/build.','normal_proof_documents':proof,'broader_inventory_before':before,'broader_inventory_not_consumed_closure':True,'environment':expected_environment,'tool_files':tools,'commands':commands,'failed_prior':{'receipt':{'path':str(OLD),'sha256':sha(OLD)},'outer':{'path':str(OLD_OUTER),'sha256':sha(OLD_OUTER)},'failed_probe':failed,'prior_tests_executed':0},'wasm_linker':{'requested_alias_from_retained_clang_stdout':alias,'resolved_physical_binary':str(physical),'sha256':sha(physical),'argv0_dispatch_preserved':True}}
def save():
    record['broader_inventory_after']={p:sha(p)for p in before};record['inputs_unchanged']=record['broader_inventory_after']==before
    (D/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
def guard():
    assert {k:env.get(k)for k in keys}==expected_environment
    assert all(sha(p)==h for p,h in {**before,**tools,**proof}.items())and alias_path.resolve()==physical
def invoke(label,argv,seconds,environment=None):
    guard();e=environment or env;p=pathlib.Path(str(argv[0]))
    resolved=p.resolve(strict=True)if p.is_absolute()else pathlib.Path(shutil.which(str(p),path=e.get('PATH'))or'/missing').resolve(strict=True)
    tools[str(resolved)]=sha(resolved);remaining=DEADLINE-time.monotonic();assert remaining>0
    o=run(list(map(str,argv)),str(R),e,min(seconds,remaining),8388608,DEADLINE,quiet_faults=True);raw={}
    for stream in ['stdout','stderr']:
        raw[stream]=o.pop(stream);p=D/(label+'.'+stream);p.write_bytes(raw[stream]);o[stream]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
    clean=o['started']and o['returncode']==0 and o['stdout_eof']and o['stderr_eof']and not any(o[k]for k in FLAGS)
    commands.append({'label':label,'argv':list(map(str,argv)),'cwd':str(R),'observation':o,'passed':clean,'execution_scope':'Actual continuation command.'});save();assert clean,(label,raw['stderr'][-1800:]);guard();return raw
assert invoke('continuation-source-head-before',['git','rev-parse','HEAD'],10)['stdout'].decode().strip()==SOURCE
assert invoke('continuation-current-fingerprint',[R/'coax/provenance.sh','fingerprint',R],60)['stdout'].decode().strip()==FP
# Invoke the actual original alias, not physical.resolve(); lld dispatches by argv0.
invoke('wasm-ld-alias-version',[alias,'--version'],10,link_env)
invoke('four-original-methods',[sys.executable,ORIGINAL/'observe.py','--compiler',B,'--sha256',IMAGE,'--deadline',str(DEADLINE),'--output',D/'retained-tests'],max(0,DEADLINE-time.monotonic()))
child=D/'retained-tests/test-result.json';result=json.loads(child.read_text())
assert result['outcome']=='passed'and result['tests_run']==4 and result['failures']==result['errors']==0 and result['skipped']==[] and len(result['methods'])==4 and all(r['outcome']=='passed'for r in result['methods'])and len(result['profiles'])==9
assert invoke('source-head-after',['git','rev-parse','HEAD'],10)['stdout'].decode().strip()==SOURCE
record['tests_run']=4;record['test_result']={'path':str(child),'sha256':sha(child)};record['actual_consumed_emission_inputs']=result['emission_consumed_inputs']
record['artifacts']={str(p):sha(p)for p in(D/'retained-tests').rglob('*')if p.is_file()}
guard();record['outcome']='passed';save()
print(json.dumps({'outcome':'passed','tests_run':4,'profiles':9,'receipt':str(D/'qualification.json'),'sha256':sha(D/'qualification.json')}))
