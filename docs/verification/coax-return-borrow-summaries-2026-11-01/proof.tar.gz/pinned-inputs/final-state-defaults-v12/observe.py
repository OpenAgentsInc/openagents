"""Transport/retention only: run four unchanged official StateDefaults methods."""
import argparse,hashlib,importlib.util,json,locale,os,pathlib,shutil,subprocess,sys,tempfile,time,types,unittest
p=argparse.ArgumentParser();p.add_argument('--compiler',required=True);p.add_argument('--sha256',required=True);p.add_argument('--deadline',required=True,type=float);p.add_argument('--output',required=True);a=p.parse_args()
R=pathlib.Path('/Users/christopherdavid/.codex/worktrees/coax-audit-issues/openagents');D=pathlib.Path(a.output).resolve();D.mkdir(exist_ok=False);B=pathlib.Path(a.compiler).resolve();sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();assert sha(B)==a.sha256 and pathlib.Path(os.environ['COAX_BIN']).resolve()==B
sys.path.insert(0,str(R/'coax/tools'));from bounded_process import run
FLAGS=['timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno'];official=R/'coax/tests/state_defaults.py';initial=sha(official);records=[];tools={};consumed={};methods=[]
state={'schema':'coax.state-defaults.qualified-test-observation.v1','outcome':'not-checked','compiler_sha256':a.sha256,'official_source':str(official),'official_source_sha256':initial,'official_test_bodies_unchanged':True,'fixture_cleanup_only':'All original fixtures retained; no fixture/body/assertion or ordinary compiler/linker flag changes. Actual compiler emission adds only observational --profile-report.','commands':records,'tool_files':tools,'emission_consumed_inputs':consumed,'methods':methods,'profiles':[]}
def save():(D/'test-result.json').write_text(json.dumps(state,indent=2)+'\n')
def guard():
 assert sha(official)==initial and sha(B)==a.sha256 and all(sha(p)==v for p,v in tools.items()) and all(sha(p)==v for p,v in consumed.items())
def resolve(program,cwd,environment):
 x=pathlib.Path(program)
 if x.is_absolute():return x.resolve(strict=True)
 if os.path.dirname(program):return (cwd/x).resolve(strict=True)
 path=os.pathsep.join(str(pathlib.Path(v)if pathlib.Path(v).is_absolute()else cwd/pathlib.Path(v))for v in os.get_exec_path(environment));found=shutil.which(program,path=path);assert found,program;return pathlib.Path(found).resolve(strict=True)
def observed(argv,**kwargs):
 guard();argv=list(map(str,argv));requested=argv.copy();cwd=pathlib.Path(kwargs.get('cwd')or R).resolve();environment=kwargs.get('env')or os.environ.copy();program=resolve(argv[0],cwd,environment);tools[str(program)]=sha(program)
 number=len(records);stem=D/('command-%03d'%number);report=None
 if program==B and len(argv)>1 and argv[1]=='c':
  assert '--profile-report'not in argv;report=stem.with_suffix('.profile.json');argv+=['--profile-report',str(report)]
 timeout=min(float(kwargs.get('timeout',120)),max(0,a.deadline-time.monotonic()));assert timeout>0,'shared phase budget exhausted before launch';raw=run(argv,str(cwd),environment,timeout,8388608,a.deadline,quiet_faults=True);streams={}
 for key in ['stdout','stderr']:
  streams[key]=raw.pop(key);path=stem.with_suffix('.'+key);path.write_bytes(streams[key]);raw[key]={'path':str(path),'bytes':len(streams[key]),'sha256':sha(path)}
 clean=raw['started']and raw['returncode']==0 and raw['stdout_eof']and raw['stderr_eof']and not any(raw.get(n)for n in FLAGS);row={'requested_argv':requested,'actual_argv':argv,'cwd':str(cwd),'program':{'path':str(program),'sha256':sha(program)},'observation':raw,'passed':clean};records.append(row);save();assert clean,(argv,streams['stderr'][-1800:]);guard()
 if report:
  profile=json.loads(report.read_text());assert report.is_file();cpath=stem.with_suffix('.generated.c');cpath.write_bytes(streams['stdout'])
  assert profile.get('emitted_sha256')==sha(cpath)
  for name in ['emitted_sha256','artifact_sha256']:
   if name in profile:assert profile[name]==sha(cpath)
  actual={}
  for kind in ['sources','descriptors']:
   assert type(profile[kind])is list
   for fact in profile[kind]:
    path=fact.get('resolved_path')or str(cwd/fact['path']);assert sha(path)==fact['sha256'];actual[path]=fact['sha256'];consumed[path]=fact['sha256']
  assert actual;state['profiles'].append({'path':str(report),'sha256':sha(report),'emitted_C':str(cpath),'emitted_C_sha256':sha(cpath),'consumed_inputs':actual})
 if '-o'in argv:
  artifact=cwd/argv[argv.index('-o')+1]
  if artifact.is_file():row['output_artifact']={'path':str(artifact),'sha256':sha(artifact)}
 save();is_text=kwargs.get('text',False)or kwargs.get('universal_newlines',False);encoding=kwargs.get('encoding')or locale.getpreferredencoding(False);stdout=streams['stdout'].decode(encoding,kwargs.get('errors')or'strict')if is_text else streams['stdout'];stderr=streams['stderr'].decode(encoding,kwargs.get('errors')or'strict')if is_text else streams['stderr'];return subprocess.CompletedProcess(requested,raw['returncode'],stdout,stderr)
spec=importlib.util.spec_from_file_location('coax_official_state_defaults',official);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert pathlib.Path(m.COMPILER).resolve()==B
class RetainedTemporaryDirectory:
 def __init__(self,prefix='tmp',**kw):self.name=tempfile.mkdtemp(prefix=prefix,dir=D)
 def cleanup(self):pass
m.tempfile=types.SimpleNamespace(TemporaryDirectory=RetainedTemporaryDirectory);m.subprocess=types.SimpleNamespace(run=observed)
expected=['test_header_declares_defaulted_types_only','test_native_in_place_defaults_match_coax_init','test_two_libraries_sharing_a_defaulted_type_link','test_wasm_state_starts_with_native_bytes'];assert unittest.defaultTestLoader.getTestCaseNames(m.StateDefaults)==expected
class Result(unittest.TextTestResult):
 def addSuccess(self,test):super().addSuccess(test);methods.append({'method':test.id(),'outcome':'passed'});save()
 def addFailure(self,test,err):super().addFailure(test,err);methods.append({'method':test.id(),'outcome':'failed','detail':self._exc_info_to_string(err,test)});save()
 def addError(self,test,err):super().addError(test,err);methods.append({'method':test.id(),'outcome':'error','detail':self._exc_info_to_string(err,test)});save()
 def addSkip(self,test,reason):super().addSkip(test,reason);methods.append({'method':test.id(),'outcome':'skipped','reason':reason});save()
suite=unittest.defaultTestLoader.loadTestsFromTestCase(m.StateDefaults);result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite);guard();state.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=[(str(t),why)for t,why in result.skipped],outcome='passed'if result.wasSuccessful()and result.testsRun==4 and not result.skipped else'failed');save();raise SystemExit(0 if state['outcome']=='passed'else 1)
