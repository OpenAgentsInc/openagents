#!/usr/bin/env python3
"""Actual matching unqualified development image emits new predecessor and workspace-row-hint source artifacts with actual profiles; no current qualification."""
from pathlib import Path
import hashlib,json,os,sys,time
S=Path('/Users/christopherdavid/.codex/worktrees/coax-book30-cost/openagents/coax').resolve()
W=Path('/tmp/coax-chapter30-full/cost-prerequisite/development-prefix-fixed').resolve()
D=Path(__file__).resolve().parent
sys.path[:0]=[str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools')),str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tests'))]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
paths=[Path(__file__).resolve(),W/'coax',W/'proto_runtime.inc',Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[p for root in [S/'lib/compiler',S/'lib/proto',S/'lib/crypto'] for p in root.rglob('*') if p.is_file()]]
before={str(p):sha(p) for p in paths}
assert before[str(W/'coax')]=='e9d276059b1de53c2ae74e608eb977eafbe3880e49883fa6aeda7799952d957a'
assert before[str(S/'lib/compiler/checker.coax')]=='4fc4444c8d0c15c9642395b11fad56f37a9c4443b89f5fe5c3f9e0ae0de0f1e9'
r={'schema':'coax.chapter30.cost-current-emitter.v1','scope':'Actual matching current-source unqualified development image emits final checker and aggregate C/H with actual source profiles. Broad manual inventory is distinguished from actual consumed closure. No completed-normal, trim fixedpoint, seal or install claim.','producer':str(W/'coax'),'producer_sha256':sha(W/'coax'),'source_revision':'146058962561916ad88e0ccd750e89a3b28209f2','producer_scope':'Actual current-source development image e9d27605 emits frozen4fc4444c/995-check source. Development only; no qualified-producer, normal or installed-candidate claim','source_before':before,'rows':[],'artifacts':{},'outcome':'not-checked'}
started=time.monotonic();deadline=started+840
def save():
 r['source_after']={str(p):sha(p) for p in paths};r['inputs_unchanged']=r['source_after']==before;r['elapsed_s']=time.monotonic()-started
 (D/'record.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name in ['checker','proto_importer']:
  save();assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
  module='lib/compiler/'+('checker' if name=='checker' else 'compiler')+'.coax'
  header=D/(name+'.h');assert not header.exists() and not (D/(name+'.c')).exists()
  profile=D/(name+'.profile.json')
  argv=[str(W/'coax'),'c',module,'--library','--header',str(header),'--profile-report',str(profile)]
  o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=33554432,deadline=deadline,quiet_faults=True)
  row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
  for stream in ['stdout','stderr']:
   data=row['observation'].pop(stream);p=D/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  (D/(name+'.c')).write_bytes(o['stdout'])
  row['transport_clean']=clean(o);r['rows'].append(row);save()
  assert row['transport_clean'] and r['inputs_unchanged'],'actual emission failed'
  assert header.is_file() and header.stat().st_size>0
  manifest=json.loads(profile.read_text())
  assert manifest['schema_version']==1 and manifest['command']=='c' and manifest['backend']=='c11' and manifest['runtime_arithmetic']=='checked' and manifest['success'] and manifest['exit_status']==0
  assert manifest['emitted_sha256']==sha(D/(name+'.c')) and manifest['artifact_sha256']==sha(D/(name+'.c'))
  for consumed in [*manifest['sources'],*manifest['descriptors']]:assert sha(consumed['path'])==consumed['sha256']
  row['profile']=str(profile);row['profile_sha256']=sha(profile);row['actual_consumed_sources']=manifest['sources'];row['actual_consumed_descriptors']=manifest['descriptors']
  for p in [header,D/(name+'.c'),profile]:r['artifacts'][str(p)]=sha(p)
  save();print(json.dumps({'label':name,'passed':True,'elapsed_s':o['elapsed_s'],'artifacts':{str(p):sha(p) for p in [header,D/(name+'.c')]}}),flush=True)
 assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
 r['outcome']='passed'
except BaseException as e:
 r['outcome']='failed';r['error']=repr(e);raise
finally:save()
print(json.dumps({'record':str(D/'record.json'),'sha256':sha(D/'record.json'),'outcome':r['outcome']}),flush=True)
