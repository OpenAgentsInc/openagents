# Chapter 30 analysis-cost prerequisite — prepared, unexecuted

Current starting model: checker177892429a (B1 final984), qualified image3b2b6225,
normal165Qc3743c5d and FP1fb5436c. The local source copy is a historical baseline;
new work must use a fresh origin/main worktree after Root tracker/claim cue.
Do not write B, frozen B1-finish, R, or a completed proof directory.

## Proposed production change

Preserve retain_fields=false's existing CB_at(b,CB_fields(b,type),index) path.
Retain every existing Type/declaration/head/block/status/row-prefix/link/namespace
and eight-lane kind check. Only when a matching row's requested slot is zero,
scan the at most seven lower slots from offset-1 toward0. Use the nearest nonzero
slot only after its ID is in2..used, kind is FIELD, and committed type is in
1..type_count-1. Then call the original CB_at(b,precedingID,offset-precedingOffset).
No predecessor or no matching row means original CB_at(head,index). Validate the
requested final field exactly as before; publish only after success. Do not
publish visited intermediates, rewrite filled slots, alter row keys/links,
allocate extra storage, change ABI/caps or normalize origin modes.

Proof: a successful immutable slotk names exactly block*8+k. Starting there and
walking index-(block*8+k) next links reaches exactly the original ordinal. Existing
CB_at charges/validates each actually traversed node. Fixed seven-slot inspection
adds no hidden graph traversal. Maximum same-block walk is eight nodes. The
negative-index check remains before division/remainder and any slot access.

## Before-code checks (24 cases, four blocks)

checks-before-code.coax.snippet is written BEFORE implementation and unexecuted.
Its 64-ID literal permutation is the independent ordinal oracle. Ascending
admission has512 work left (8*64); original cold walks alone require2080. Sparse,
descending and7/8/final endpoints test semantics in both source modes and the
unchanged A1 flagfalse path. Full-pool nearest6->7 succeeds within three ticks
without row allocation. Selected predecessor corruption/fuel/dangling-next/row
cycle refuse with exact physicalE0381 and unchanged committed slots/head/count.
The tests do not assert C padding or unrelated inactive query bytes.

Reuse unchanged existing controls rather than replay them during development:
'retained field lookup rejects invalid checked inputs before publishing a memo'
21cases; 'retained field memo keys shape and bounded links keep their own namespace'
28cases; last-pool-slot4cases; failed-existing-slot1case; exact-prefix4cases;
existing run whole-write1case. Integration's changed full-source baseline and full
normal mutation still necessarily exercise every retained body on new code.
Type/declaration separation remains covered by existing exact-ordinal5case block.

## Frozen-layout boundary

Do not invent arbitrary cache-membership authentication. A valid but unrelated
ID cannot be proven to belong to an ordinal without rewalking immutable layout.
CB_at currently has no general field-list cycle detector; it performs a bounded
ordinal walk, so an underlying cycle can yield a field. Preserve this behavior.
Existing strict decreasing QUERY ROW links do reject cycles, tested here. Dangling
FIELD links are refused by original bounds checks. Do not label a new field-list
cycle refusal as an existing contract or add one merely for mutation sharpness.

## Ordered experiment / qualification plan

1. Root publishes/claims cost issue and authorizes fresh worktree+sole checker
writer. Pin actual HEAD, current applicable INVARIANTS and compiler/SDK/tools.
2. Integrate these exact authored blocks first. Preserve original snapshot/check
body hashes. Run only changed selections on starting producer to retain genuine
cost/metadata REDs; unchanged semantic groups are GREEN controls, not fresh B1
qualification. Do not change expectations to fit an implementation result.
3. Implement the narrow predecessor change. Run affected selected checks, then
one full authored authority baseline. Investigate actual semantic failures.
4. Old qualified producer's actual default-profile BOTH emission, canonical
current-C++ development build, then actual matching image's complete compiler
analysis. Record real phase/work/query/origin/depth and raw transport/source guards.
This is changed-source development evidence, no provenance/current qualification.
5. wide-whole-write.coax is an independently inspectable public64-field/8-write
source workload for actual emission/profile observation. It is not an executed
or asserted timing claim. The existing public32-field8-write4096-remaining-work
CR_run check must remain. A stronger public admission threshold can be predeclared
from the typed graph's operation bound; do not choose it after seeing optimized
results. Helper512/3 bounds above are already fixed before code.
6. After actual complete-source success and substantial measured headroom, emit
fresh matching checker+aggregate C/H; actual header compare/layout guard only if
changed; mechanical seed copy after Root approval; Root commit/rebase and exactFP.
7. Fresh canonical full normal, all source/dependency authority checks and full
checker8shards+mergeZERO, seed comparisons and both fixed points. No diagnostic
substitution, raised limits, checks omitted, cache waiver or equivalence label.
8. Actual final installed matching producer runs affected whole B1source33,
A1source44, native21x3, legacychecker10, SystemOne3, memo1000, diagnostics8 under
independent bounded receipts. Root owns scope review/Git/push/issue resolution.
Each command <=15min; never replay a passing unchanged producer/input result.

Current record is PREPARED ONLY: no check, build, emission, debugger, profile,
mutation, browser or service effect has run for this prerequisite.
