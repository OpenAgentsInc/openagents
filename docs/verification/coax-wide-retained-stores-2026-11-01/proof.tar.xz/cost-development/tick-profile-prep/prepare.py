from pathlib import Path
import ast,difflib,hashlib,json,re
BASE=Path('/tmp/coax-chapter30-full/cost-prerequisite');ROOT=Path('/Users/christopherdavid/.codex/worktrees/coax-book30-cost/openagents');OLD=BASE/'development-v1';E=BASE/'trusted-emission-v1';D=BASE/'tick-profile-v1';D.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(E/'record.json')=='f2eb1d43cce3737c9bc8f60eaf2e046d0691bcd99533a7f8809d82a0ed2fec0e'
assert sha(OLD/'record.json')=='1f54e11d3a109121abeb3c67b59a9de0965345a1a768fc50f7108c4ead0474ec'
p=Path('/tmp/coax-retained-borrows-B1-resume/tick-profile-prep/prepare.py');tree=ast.parse(p.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='region');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),ns);region=ns['region']
prior=Path('/tmp/coax-retained-borrows-B1-resume/tick-profile-private-v2/proto_importer.c');text=prior.read_text();start=text.index('/* PRIVATE DIAGNOSTIC OBSERVER:');end=text.index('#define coax_p_CB_tick(b,loc) coax_profile_tick((b),(loc),__func__)')+len('#define coax_p_CB_tick(b,loc) coax_profile_tick((b),(loc),__func__)');oldobserver=text[start:end]
# Factor only the old diagnostic dump so successful CR_run completion can emit it.
a=oldobserver.index('  if(!ok && !coax_profile_printed){');z=oldobserver.index('\n  return ok;',a);dump=oldobserver[a:z].replace('  if(!ok && !coax_profile_printed){','  if(!coax_profile_printed){',1)
a=oldobserver.index('static _Bool coax_profile_tick');prefix=oldobserver[:a];tickwrapper=oldobserver[a:];tickwrapper=tickwrapper.replace(oldobserver[oldobserver.index('  if(!ok && !coax_profile_printed){'):z],'  if(!ok)coax_profile_dump(b);')
observer='\n'+prefix+'static void coax_profile_dump(coax_t_CB_Context b) {\n'+dump+'\n}\n'+tickwrapper+'\n'
original=(E/'proto_importer.c').read_text();a,b,end=region(original,'coax_p_CB_tick');tick=original[a:end];assert len(re.findall(r'\bcoax_p_CB_tick\s*\(',original[:end]))==2
insertions=[(end,observer)]
for name,body in [('coax_p_CB_run','coax_profile_reset();'),('coax_p_CR_run','coax_profile_phase=1;'),('coax_p_CR_walk','coax_profile_phase=l_seed?(l_instances?3:2):(l_instances?5:4);')]:
 a,b,end=region(original,name);insertions.append((b+1,'\n  '+body+'\n'))
a,b,end=region(original,'coax_p_CR_run');insertions.append((end-1,'\n  coax_profile_dump(l_b);\n'))
new=original
for pos,s in sorted(insertions,reverse=True):new=new[:pos]+s+new[pos:]
restored=new
for _,s in insertions:assert restored.count(s)==1;restored=restored.replace(s,'',1)
assert restored==original and tick in new
(D/'proto_importer.c').write_text(new);(D/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='original-predecessor-v1.c',tofile='private-counter-profile.c')));(D/'observer.c.txt').write_text(observer)
for name in ['proto_importer.h','proto_runtime.inc']:(D/name).write_bytes((OLD/name).read_bytes())
profile=json.loads((E/'proto_importer.profile.json').read_text());source_files={};consumed={}
for row in [*profile['sources'],*profile['descriptors']]:
 pth=Path(row['path']).resolve();assert sha(pth)==row['sha256'];relative=pth.relative_to(ROOT);dest=D/'source'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(pth.read_bytes());assert sha(dest)==row['sha256'];source_files[str(dest)]=sha(dest);consumed[str(pth)]=sha(pth)
source=D/'source/coax/lib/compiler/compiler.coax';assert source.is_file();assert sha(D/'source/coax/lib/compiler/checker.coax')=='2684a0434252f34b69aa7901767e6d6d975a1f0771172adc5ae0c7d90caedff1'
build=json.loads((OLD/'record.json').read_text());argvs=[[v.replace(str(OLD.resolve()),str(D))for v in row['argv']]for row in build['rows']]
inputs=[E/'record.json',E/'proto_importer.c',E/'proto_importer.profile.json',OLD/'record.json',OLD/'proto_importer.h',OLD/'proto_runtime.inc',prior,p,Path(__file__).resolve(),ROOT/'coax/tools/bounded_process.py',ROOT/'coax/tests/quiet_crash.py',*[q for q in (OLD/'native-source').rglob('*')if q.is_file()],*[Path(v[0]).resolve()for v in argvs]]
plan={'scope':'PRIVATE generated-C counter observer on frozen predecessor2684. Original CB_tick body unchanged and delegated once. No Coax semantic/capacity/work changes, qualification, seal or install. Successful-end diagnostic dump is the sole observer adaptation beyond prior lexical counter/phase insertions.','phases':{'0':'A1','1':'B1reset','2':'rootseed','3':'instanceseed','4':'rootsummary','5':'instancesummary'},'original_tick_sha256':hashlib.sha256(tick.encode()).hexdigest(),'original_aggregate_sha256':sha(E/'proto_importer.c'),'instrumented_aggregate_sha256':sha(D/'proto_importer.c'),'reconstruction_exact':True,'observer_dump_factor_only':True,'files':{str(q):sha(q)for q in inputs},'artifacts':{str(D/name):sha(D/name)for name in ['proto_importer.c','proto_importer.h','proto_runtime.inc','instrumentation.patch','observer.c.txt']},'consumed_original_sources':consumed,'source_files':source_files,'compile_argv':argvs[0],'link_argv':argvs[1],'cwd':str(OLD/'native-source'),'source':str(source),'out':str(D),'expected_work':1047917,'expected_queries':14561,'expected_origins':8251,'toolchain_limit':'Exact C/C++ argv and physical tool hashes, not complete SDK/transitive content lock.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan':str(D/'plan.json'),'sha256':sha(D/'plan.json'),'patch_sha256':sha(D/'instrumentation.patch'),'sources':len(source_files)}))
