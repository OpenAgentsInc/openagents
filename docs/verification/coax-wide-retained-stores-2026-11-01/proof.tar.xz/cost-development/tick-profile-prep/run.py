from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
BASE=Path('/tmp/coax-chapter30-full/cost-prerequisite');D=BASE/'tick-profile-v1';ROOT=Path('/Users/christopherdavid/.codex/worktrees/coax-book30-cost/openagents');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(D/'plan.json')=='e5fe7adf80f044fd4533cf70e7ff60e228ed75b841610b1fa08916607fc26918'
plan=json.loads((D/'plan.json').read_text());expected={**plan['files'],**plan['artifacts'],**plan['source_files'],**plan['consumed_original_sources'],str(D/'plan.json'):sha(D/'plan.json'),str(Path(__file__).resolve()):sha(__file__)}
for p,h in expected.items():assert sha(p)==h,p
original_inputs=dict(expected)
assert not any((D/n).exists()for n in ['coax','proto_importer.o','execution.json'])
sys.path[:0]=[str(ROOT/'coax/tools'),str(ROOT/'coax/tests')]
spec=importlib.util.spec_from_file_location('tick_profile_current_bp',ROOT/'coax/tools/bounded_process.py');bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
flags=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno')
record={'scope':'PRIVATE generated-C diagnostic only; unchanged predecessor2684 policy,1Mwork/other caps and exact compiler.coax consumed source bytes in private relative closure. Original CB_tick delegated once and unchanged. No qualification, tests, install, cache, normal or published-artifact claim.','plan_sha256':sha(D/'plan.json'),'inputs_before':dict(original_inputs),'rows':[],'outcome':'not-checked'};started=time.monotonic();deadline=started+180
def save():
 record['inputs_after']={p:sha(p)for p in original_inputs};record['inputs_unchanged']=all(sha(p)==h for p,h in expected.items());record['elapsed_s']=time.monotonic()-started
 (D/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for label,argv in [('compile',plan['compile_argv']),('link',plan['link_argv']),('profile',[str(D/'coax'),'c',plan['source'],'--library'])]:
  for p,h in expected.items():assert sha(p)==h,p
  r=bp.run(argv,cwd=plan['cwd'],env=dict(os.environ),timeout_s=min(60,deadline-time.monotonic()),max_output_bytes=16777216,deadline=deadline,quiet_faults=True)
  raw={}
  for k in ('stdout','stderr'):
   data=r.pop(k);p=D/(label+'.'+k);p.write_bytes(data);raw[k]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  record['rows'].append({'label':label,'argv':argv,'observation':r,'raw':raw});save()
  assert r['started']and r['stdout_eof']and r['stderr_eof']and not any(r[k]for k in flags),label
  assert r['returncode']==0,label
  if label in ('compile','link'):
   p=D/('proto_importer.o'if label=='compile'else'coax');expected[str(p)]=sha(p)
 counts=[];states=[];overflow=[]
 for line in (D/'profile.stderr').read_text().splitlines():
  for prefix,dest in [('COAX_TICK_COUNTS ',counts),('COAX_TICK_STATE ',states),('COAX_TICK_OVERFLOW ',overflow)]:
   if line.startswith(prefix):dest.append(json.loads(line[len(prefix):]))
 assert len(states)==1 and states[0]['work']==plan['expected_work'] and states[0]['queries']==plan['expected_queries'] and states[0]['origins']==plan['expected_origins'] and 'error['not in(D/'profile.stderr').read_text()
 assert sum(r['count']for r in counts)+sum(r['count']for r in overflow)==states[0]['work']
 record.update(counts=counts,state=states,overflow=overflow,artifacts={p:h for p,h in expected.items()if p not in original_inputs},image_sha256=sha(D/'coax'),outcome='observed-current-work-histogram')
except BaseException as e:record.update(outcome='failed-diagnostic',error=repr(e));raise
finally:save()
assert record['inputs_unchanged']
print(json.dumps({'state':states,'overflow':overflow,'largest':sorted(counts,key=lambda r:r['count'],reverse=True)[:24],'inputs_unchanged':record['inputs_unchanged'],'image_sha256':record['image_sha256'],'record_sha256':sha(D/'execution.json')},indent=2))
