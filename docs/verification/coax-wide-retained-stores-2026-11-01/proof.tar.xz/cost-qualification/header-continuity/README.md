# Exact header-layout continuity

`continuity.json` uses `coax.header-layout-continuity.v2`. `compose.py` performed only regular-file hash/byte/JSON validation; it invoked no compiler, probe, CDLL, model or gate. Do not rerun it over the retained receipt: it intentionally refuses overwrite.

The original B1 actual21-record/198-offset compile-only guard and its raw stdout/stderr remain at their original paths and hashes, attributed to sourcea073. The old live B source path is provenance only; the retained candidate-v2/source/checker.coax snapshot supplies the historical model bytes. Every other original guard dependency is rehashed live. New E source4fc and the fresh current-emitter record8f0c are separate identities. Both actual fresh headers are byte-identical to the exact headers that were compiled in the old guard. Five B→E Python transport/helper files are compared byte-for-byte.

The165 supporting pins cover the composing tool, original guard/guard sources/raws/emission artifacts/compiler, historical snapshot, current model/emitter producer/manifest/raws/C/H/profiles/actual consumed sources, current transport identities, and the prior B1 continuity/review history. Source-before/after equality is actual hash stability during this composition. The inherited guard's explicit toolchain limit remains: physical C compiler and explicit files are pinned; that old receipt is not a complete SDK dependency lock.

Outcome passed means this byte-identity composition passed, not new current-normal/native qualification. No old compile rows were copied or labelled new. No frozen B1 evidence was modified. Previous Root approval is linked as historical evidence only; it is not an endorsement of this new receipt. Root review remains required and root_approval is null.
