#!/usr/bin/env python3
"""Hash/byte evidence composition only. Never emits C or invokes a compiler/probe."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
B = Path('/Users/christopherdavid/.codex/worktrees/coax-current-audit/openagents')
E = Path('/Users/christopherdavid/.codex/worktrees/coax-book30-cost/openagents')
OLD = Path('/tmp/coax-retained-borrows-B1-finish/layout-988/qualification.json')
OLD_SHA = '5ae48003a55473e77359a6d25cde8e7455e1bd2c62b6cb61e1b81f95eae695a3'
OLD_MODEL = B/'coax/lib/compiler/checker.coax'
OLD_MODEL_SHA = 'a0733951fe73d6cb7e12eba8a04309db20f86e33bf71a3c0ccceb6f29a5a4a4e'
SNAPSHOT = Path('/tmp/coax-retained-borrows-B1-finish/candidate-v2/source/checker.coax')
NEW_MODEL = E/'coax/lib/compiler/checker.coax'
NEW_MODEL_SHA = '4fc4444c8d0c15c9642395b11fad56f37a9c4443b89f5fe5c3f9e0ae0de0f1e9'
EMISSION = Path('/tmp/coax-chapter30-full/cost-prerequisite/current-emitter-final/record.json')
EMISSION_SHA = '8f0c564b71366fbb3d961d2e5122510bf004633dedd0e8a8aa7921d0db28cdf8'
PRIOR = Path('/tmp/coax-retained-borrows-B1-finish/header-layout-984-continuity/continuity.json')
PRIOR_SHA = '0b6db1ce7c4a21bba26011d8a06fb290d1ec34455646bea3d9baa52f9d07b514'
PRIOR_REVIEW = PRIOR.parent/'root-review.json'
PRIOR_REVIEW_SHA = '2f9a136f96799c2fff4d4e2df43d46e8450c1a8a436bc5f71d2b81323549c5d6'
FLAGS = ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit',
         'group_killed','kill_errno','launch_errno','launch_error','read_errno')
pins = {}

def digest(path):
    p=Path(path)
    if not p.is_file() or p.is_symlink():
        raise RuntimeError('not a regular final file: '+str(path))
    return hashlib.sha256(p.read_bytes()).hexdigest()

def admit(path, expected=None):
    path=str(path); h=digest(path)
    if expected is not None and h != expected:
        raise RuntimeError('hash mismatch: '+path)
    if path in pins and pins[path] != h:
        raise RuntimeError('inconsistent pin: '+path)
    pins[path]=h
    return h

def load(path, expected):
    admit(path,expected)
    return json.loads(Path(path).read_text())

def clean(o):
    return (o['started'] is True and o['returncode']==0
            and o['stdout_eof'] is True and o['stderr_eof'] is True
            and all(not o[k] for k in FLAGS))

def raws(row):
    for fact in row['raw'].values():
        admit(fact['path'],fact['sha256'])
        if Path(fact['path']).stat().st_size != fact['bytes']:
            raise RuntimeError('raw length mismatch')

def main():
    if (OUT/'continuity.json').exists():
        raise RuntimeError('refuse overwrite of retained receipt')
    admit(__file__)
    old=load(OLD,OLD_SHA)
    emission=load(EMISSION,EMISSION_SHA)
    prior=load(PRIOR,PRIOR_SHA)
    prior_review=load(PRIOR_REVIEW,PRIOR_REVIEW_SHA)
    assert old['schema']=='coax.B1.header-only-layout.v1'
    assert old['outcome']=='passed' and old['inputs_unchanged'] is True
    assert old['source_before']==old['source_after']
    assert old['layout_record_count']==21 and old['field_offset_count']==198
    assert len(old['rows'])==2
    assert old['source_before'][str(OLD_MODEL)]==OLD_MODEL_SHA
    admit(SNAPSHOT,OLD_MODEL_SHA)
    admit(NEW_MODEL,NEW_MODEL_SHA)
    # Historical live model path is provenance ONLY. Rehash the retained snapshot
    # as a073; never demand that the final B model is the historical model.
    for path,h in old['source_before'].items():
        if path!=str(OLD_MODEL): admit(path,h)
    for path,h in old['generated_guard_sources'].items(): admit(path,h)
    for row in old['rows']:
        assert clean(row['observation']) and row['transport_clean'] is True
        assert row['matches_ctypes'] is True
        assert len(row['actual_layouts'])==21
        assert sum(len(v['offsets']) for v in row['actual_layouts'].values())==198
        assert '-fsyntax-only' in row['argv']
        raws(row)
    assert prior['original_layout']['sha256']==OLD_SHA
    assert prior_review['continuity_receipt']['sha256']==PRIOR_SHA
    assert prior_review['historical_model_snapshot']['sha256']==OLD_MODEL_SHA
    # Preserve old source inputs as old attribution; the NEW emitter receipt has
    # its own source/image identity and raw observations. No rows are copied as new.
    assert emission['schema']=='coax.chapter30.cost-current-emitter.v1'
    assert emission['outcome']=='passed' and emission['inputs_unchanged'] is True
    assert emission['source_before']==emission['source_after']
    assert len(emission['rows'])==2
    assert emission['source_before'][str(NEW_MODEL)]==NEW_MODEL_SHA
    for path,h in emission['source_before'].items(): admit(path,h)
    for path,h in emission['artifacts'].items(): admit(path,h)
    admit(emission['producer'],emission['producer_sha256'])
    labels={r['label']:r for r in emission['rows']}
    assert set(labels)=={'checker','proto_importer'}
    header_identity=[]
    for row in emission['rows']:
        assert clean(row['observation']) and row['transport_clean'] is True
        raws(row)
        profile=load(row['profile'],row['profile_sha256'])
        assert profile['command']=='c' and profile['backend']=='c11'
        assert profile['success'] is True and profile['exit_status']==0
        assert profile['sources']==row['actual_consumed_sources']
        assert profile['descriptors']==row['actual_consumed_descriptors']
        for fact in row['actual_consumed_sources']+row['actual_consumed_descriptors']:
            admit(fact['path'],fact['sha256'])
        c=EMISSION.parent/(row['label']+'.c')
        assert digest(c)==row['raw']['stdout']['sha256']==profile['artifact_sha256']
        oldrow=old['rows'][0 if row['label']=='checker' else 1]
        oldh=Path(oldrow['header']);newh=EMISSION.parent/(row['label']+'.h')
        h=admit(oldh,old['source_before'][str(oldh)])
        admit(newh,h)
        assert oldh.read_bytes()==newh.read_bytes()
        header_identity.append(dict(module=row['label'],original_header=str(oldh),
                                    current_header=str(newh),sha256=h,exact_bytes_equal=True))
    # Original Python transport/helper dependencies are byte-identical at E; the
    # old actual guard remains bound to B and is not re-executed or relabelled.
    mappings=[]
    for rel in ['coax/tests/checker.py','coax/tests/parser.py','coax/tests/lexer.py',
                'coax/tools/bounded_process.py','coax/tests/quiet_crash.py']:
        original=B/rel; current=E/rel; h=old['source_before'][str(original)]
        admit(original,h);admit(current,h)
        assert original.read_bytes()==current.read_bytes()
        mappings.append(dict(original_path=str(original),current_path=str(current),
                             sha256=h,exact_bytes_equal=True))
    before=dict(sorted(pins.items()))
    after={path:digest(path) for path in before}
    if before!=after: raise RuntimeError('supporting input changed during composition')
    result={
      'schema':'coax.header-layout-continuity.v2',
      'outcome':'passed',
      'scope':'Hash/byte continuity composition only: actual old compile-only21-record/198-offset observations remain historical; two fresh unqualified current-emitter headers equal their exact bytes. No compiler/probe/CDLL/gate rerun, native behavior or current-normal qualification is claimed.',
      'original_layout':{'path':str(OLD),'sha256':OLD_SHA,'schema':old['schema'],'model_sha256':OLD_MODEL_SHA},
      'historical_model':{'path':str(OLD_MODEL),'sha256':OLD_MODEL_SHA,
                          'snapshot':{'path':str(SNAPSHOT),'sha256':OLD_MODEL_SHA}},
      'historical_live_model_path_is_provenance_only':True,
      'current_model':{'path':str(NEW_MODEL),'sha256':NEW_MODEL_SHA},
      'current_emission':{'path':str(EMISSION),'sha256':EMISSION_SHA,
                          'producer_sha256':emission['producer_sha256']},
      'current_emission_producer_scope':emission['producer_scope'],
      'source_before':before,'source_after':after,'inputs_unchanged':True,
      'header_identity':header_identity,'current_ctypes_source_identity':mappings,
      'layout_record_count':21,'field_offset_count':198,
      'actual_compile_rows_reference':{'path':str(OLD),'sha256':OLD_SHA,'row_indices':[0,1],
                                      'rows_remain_original':True},
      'prior_continuity_history':{'path':str(PRIOR),'sha256':PRIOR_SHA},
      'prior_review_history_only':{'path':str(PRIOR_REVIEW),'sha256':PRIOR_REVIEW_SHA,
                                  'endorsement_of_this_new_receipt':False},
      'normal_qualification_claim':False,'compile_observations_repeated':False,
      'root_review_required':True,'root_approval':None,
      'toolchain_limit':old['toolchain_limit']}
    with (OUT/'continuity.json').open('x') as f:
        f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'receipt':str(OUT/'continuity.json'),
                      'sha256':digest(OUT/'continuity.json'),'supporting_pins':len(before),
                      'records':21,'offsets':198,'compiler_runs':0}))

if __name__=='__main__': main()
