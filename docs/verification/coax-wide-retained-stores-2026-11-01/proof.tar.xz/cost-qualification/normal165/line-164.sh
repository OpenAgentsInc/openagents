#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
cd /private/tmp/coax-chapter30-full/cost-qualification/normal165/snapshot/coax
root=/private/tmp/coax-chapter30-full/cost-qualification/normal165/snapshot
target=/Users/christopherdavid/.codex/worktrees/coax-book30-cost/openagents
input_identity=7d99f3e06df5efdf4175cb810a02bb7fc5b6905d291a22511829bbf402ccdece
work=bin/.bootstrap-bounded-normal
host_flags=(-std=c++20 -O1 -g -Wall -Wextra -Wno-missing-field-initializers)
if [[ -n "${COAX_HOST_TARGET:-}" ]]; then host_flags+=(-target "$COAX_HOST_TARGET"); fi
c_flags=(-std=c11 -O1 -g)
if [[ -n "${COAX_HOST_TARGET:-}" ]]; then c_flags+=(-target "$COAX_HOST_TARGET"); fi
export COAX_BUILD_FRESH=1 COAX_MUTATION_CHANGED=strict COAX_MUTATION_FULL=1
sha() { if command -v shasum > /dev/null 2>&1; then shasum -a 256 | awk '{print $1}'; else sha256sum | awk '{print $1}'; fi; }
gate_cache="${COAX_GATE_CACHE:-$HOME/.cache/coax-gates}"
[[ -z "${COAX_BUILD_FRESH:-}" ]] || gate_cache=""
stage0_identity() {
  local path
  {
    printf 'coax-stage0-v1\0'
    while IFS= read -r -d '' path; do printf '%s\0%s\0' "$path" "$(sha < "$path")"; done < <(find src bootstrap -type f -print0 | sort -z)
    printf 'proto_runtime\0%s\0' "$(sha < "$work/proto_runtime.inc")"
    printf 'flags\0%s\0%s\0' "${host_flags[*]}" "${c_flags[*]}"
    printf 'cc\0%s\0%s\0' "$(command -v "${CC:-cc}")" "$("${CC:-cc}" --version)"
    printf 'cxx\0%s\0%s\0' "$(command -v "${CXX:-c++}")" "$("${CXX:-c++}" --version)"
    printf 'host\0%s\0%s\0' "$(uname -s)" "$(uname -m)"
    if [[ "$(uname -s)" == Darwin ]]; then printf 'sdk\0%s\0%s\0' "$(xcrun --show-sdk-path)" "$(xcrun --show-sdk-version)"; fi
    for path in COAX_CC COAX_HOST_TARGET SDKROOT MACOSX_DEPLOYMENT_TARGET IPHONEOS_DEPLOYMENT_TARGET DEVELOPER_DIR CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH LIBRARY_PATH; do
      printf '%s\0%s\0' "$path" "${!path-}"
    done
  } | sha
}
# The key of a stage0 gate in $key, left empty when its sources can't be
# listed. Gates run in the main shell, so one file's closure is hashed once.
closure_file="" closure=""
gate_key() {
  local deps path list
  key=""
  if [[ "$closure_file" != "$3" ]]; then
    closure_file="$3" closure=""
    deps="$("$work/stage0" deps "$3" 2> /dev/null)" || return 0
    list="$(printf '%s' "$deps" | tr -d '\n' | sed -n 's/.*"sources":\[\(.*\)\],"descriptors":\[\(.*\)\]}$/\1,\2/p' | tr ',' '\n' | sed -e 's/^"//' -e 's/"$//')"
    [[ -n "$list" ]] || return 0
    while IFS= read -r path; do
      [[ -z "$path" || ( -f "$path" && ! -L "$path" ) ]] || return 0
    done <<< "$list"
    closure="$({
      printf '%s\0' "${deps//"$root"\//}"
      while IFS= read -r path; do
        [[ -n "$path" ]] && printf '%s\0%s\0' "${path#"$root"/}" "$(sha < "$path")"
      done <<< "$list"
    } | sha)"
  fi
  [[ -n "$closure" ]] || return 0
  key="$({ printf 'coax-gate-v1\0%s\0%s\0' "$stage0_id" "$closure"; printf '%s\0' "${@:2}"; } | sha)"
}
# A mutation gate that fails only on survivors is judged by mutation-gate.sh
# against COAX_MUTATION_CHANGED (the lines changed since a base, from
# coax/build.sh; unset or "strict": every survivor gates). A survivor gates on
# a changed line, or when the change removed a check from its file or from the
# gate's mutated file. Other survivors are listed in bin/mutation-survivors and
# do not stop the build. Their
# gate result is kept with its survivors, and judged again on reuse.
mutation_changed="${COAX_MUTATION_CHANGED:-strict}"
judge() {   # judge LABEL SURVIVORS: 0 when none of them gates
  local gating
  # Labelled, so a check removed from the mutated file gates its survivors.
  sed "s|^|$1: |" "$2" > "$work/survivors.labelled"
  if gating="$(./mutation-gate.sh verdict "$mutation_changed" "$work/survivors.labelled")"; then
    echo "coax bootstrap: $(wc -l < "$2" | tr -d ' ') survivor(s) the change did not cause, reported, not gating: $1"
    sed "s|^|$1: |" "$2" >> "$work/mutation-survivors"
    return 0
  fi
  if [[ "$mutation_changed" == strict ]]; then echo "coax bootstrap: surviving mutants stop the build, the full mutation check ($1):" >&2
  else echo "coax bootstrap: surviving mutants on changed lines stop the build ($1):" >&2; fi
  printf '%s\n' "$gating" | sed 's/^/  /' >&2
  return 1
}
gate() {
  local start=$SECONDS label="${*//"$work"\//}" key=""
  if [[ -n "$gate_cache" && "$1" == "$work/stage0" && ( "$2" == test || "$2" == mutate ) ]]; then
    gate_key "$@"
    if [[ -n "$key" && -f "$gate_cache/$key" ]]; then
      sed -n 's/^survivor //p' "$gate_cache/$key" > "$work/survivors"
      if [[ ! -s "$work/survivors" ]]; then echo "coax bootstrap: reused   $label"; return 0; fi
      echo "coax bootstrap: reused   $label (with survivors)"
      judge "$label" "$work/survivors"; return
    fi
  fi
  if "$@" > "$work/gate.log" 2>&1; then
    echo "coax bootstrap: $(printf '%5d' $((SECONDS - start))) s  $label"
    if [[ -n "$key" ]] && mkdir -p "$gate_cache" 2> /dev/null; then
      printf '%s\n' "$label" > "$gate_cache/.$key.$$" && mv "$gate_cache/.$key.$$" "$gate_cache/$key"
    fi
    return 0
  fi
  if [[ "$2" == mutate ]] && ./mutation-gate.sh survivors < "$work/gate.log" > "$work/survivors"; then
    echo "coax bootstrap: $(printf '%5d' $((SECONDS - start))) s  $label"
    if [[ -n "$key" ]] && mkdir -p "$gate_cache" 2> /dev/null; then
      { printf '%s\n' "$label"; sed 's/^/survivor /' "$work/survivors"; } > "$gate_cache/.$key.$$" && mv "$gate_cache/.$key.$$" "$gate_cache/$key"
    fi
    judge "$label" "$work/survivors" && return 0
  fi
  cat "$work/gate.log" >&2
  return 1
}
if [[ -f "$work/stage0.identity" ]]; then IFS= read -r stage0_id < "$work/stage0.identity"; else stage0_id=""; fi
[[ "$COAX_BUILD_FRESH" == 1 && -z "$gate_cache" && "$COAX_MUTATION_FULL" == 1 && "$COAX_MUTATION_CHANGED" == strict && "$mutation_changed" == strict ]]
gate "$work/stage0" mutate lib/compiler/check-domains.coax --root-only
