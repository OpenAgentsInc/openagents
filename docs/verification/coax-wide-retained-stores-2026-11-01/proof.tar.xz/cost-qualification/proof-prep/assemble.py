#!/usr/bin/env python3
"""Archive frozen analysis-cost completion proof files only; never infer qualification."""
import argparse
import lzma
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
import time

RESUME = Path('/tmp/coax-chapter30-full').resolve()
SCOPES = {
    'cost-development': RESUME/'cost-prerequisite',
    'cost-qualification': RESUME/'cost-qualification',
    'independent-source-review': RESUME/'cost-review',
    'prior-layout': Path('/tmp/coax-retained-borrows-B1-finish/layout-988').resolve(),
    'prior-layout-emission': Path('/tmp/coax-retained-borrows-B1-finish/trusted-988-emission').resolve(),
    'prior-layout-historical-source': Path('/tmp/coax-retained-borrows-B1-finish/candidate-v2/source').resolve(),
    'prior-layout-continuity': Path('/tmp/coax-retained-borrows-B1-finish/header-layout-984-continuity').resolve(),
    'canonical-v12': Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha').resolve(),
}
REQUIRED_CANONICAL = (
    'runner.py', 'plan.json', 'make-plan.py', 'bootstrap-build.original.sh',
    'build.original.sh', 'mutation-gate.original.sh', 'provenance.original.sh',
    'infrastructure/coax/tools/bounded_process.py',
    'infrastructure/coax/tests/quiet_crash.py',
)
TEXT_SUFFIXES = {'.py', '.c', '.h', '.cpp', '.hpp', '.coax', '.snippet', '.js', '.ts', '.proto',
                 '.patch', '.diff', '.rec', '.json', '.jsonl', '.md', '.sh',
                 '.stdout', '.stderr', '.log', '.inc', '.txt', '.out',
                 '.toml', '.yaml', '.yml', '.plist', '.record', '.identity', '.sha256'}
PACKAGE_EXECUTABLES = {'coax', 'provenance-check'}
PACKAGE_TEXT_SIDECARS = {'provenance.record', 'mutation-survivors'}
PRUNE = {'__pycache__', '.cache', 'cache', 'node_modules', '.git'}
PRIVATE = {'.env', 'credentials.json', 'application_default_credentials.json',
           'access-token', 'token', 'headers.txt'}
BIN_SUFFIXES = {'.o', '.a', '.so', '.dylib', '.wasm', '.exe', '.bc', '.pyc', '.pyo'}
MAGIC = (b'\x7fELF', b'MZ', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf',
         b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xce', b'\xca\xfe\xba\xbe',
         b'\xbe\xba\xfe\xca', b'!<arch>\n', b'\x00asm')


def digest(path, deadline):
    h = hashlib.sha256()
    with open(path, 'rb') as source:
        while True:
            assert time.monotonic() < deadline, 'archive deadline exhausted'
            block = source.read(1048576)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def stable_file(path, deadline):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode), 'only regular files: '+str(path)
    value = digest(path, deadline)
    last = path.lstat()
    assert (first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns) == (
        last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns), 'writer during read: '+str(path)
    return {'bytes': last.st_size, 'sha256': value}


def exclusion(path):
    if path.name in PRIVATE or path.name.startswith('.env.'):
        return 'private-environment/credential filename'
    if path.name in PACKAGE_EXECUTABLES:
        return 'normal-package executable body'
    if path.suffix in BIN_SUFFIXES:
        return 'compiled/object/cache artifact'
    with path.open('rb') as stream:
        prefix = stream.read(8)
    if any(prefix.startswith(magic) for magic in MAGIC):
        return 'executable/library/object binary magic'
    if path.suffix in {'.identity', '.sha256'}:
        with path.open('rb') as stream:
            payload = stream.read(65537)
        try:
            text = payload.decode('utf-8')
        except UnicodeError:
            return 'not a small UTF-8 text identity sidecar'
        if len(payload)>65536 or '\x00' in text:
            return 'not a small UTF-8 text identity sidecar'
    if path.suffix not in TEXT_SUFFIXES and path.name not in PACKAGE_TEXT_SIDECARS:
        return 'not an admitted proof-source/raw-log suffix'
    return None


def safe_member(name):
    value = PurePosixPath(name)
    assert not value.is_absolute() and '..' not in value.parts and value.parts
    assert str(value) == name and '\\' not in name


def inventory(deadline):
    members, excluded, directories = {}, {}, []
    for prefix, root in SCOPES.items():
        assert root.is_dir() and not root.is_symlink(), 'missing proof scope: '+str(root)
        for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
            assert time.monotonic() < deadline
            base = Path(base)
            for name in sorted(dirs.copy()):
                path = base/name
                if name in PRUNE or name.endswith('.dSYM') or path.is_symlink():
                    dirs.remove(name)
                    directories.append({'path':str(path), 'reason':'cache/debug-bundle/symlink directory excluded recursively'})
            dirs.sort()
            for name in sorted(files):
                path = base/name
                relative = path.relative_to(root).as_posix()
                archive_name = prefix+'/'+relative
                safe_member(archive_name)
                if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
                    excluded[str(path)] = {'reason':'nonregular/symlink member'}
                    continue
                reason = exclusion(path)
                if reason == 'private-environment/credential filename':
                    excluded[str(path)] = {'reason':reason}
                    continue
                value = stable_file(path, deadline)
                if reason:
                    excluded[str(path)] = {**value, 'reason':reason}
                else:
                    assert archive_name not in members
                    members[archive_name] = {'source_path':str(path), **value}
    return {'members':dict(sorted(members.items())),
            'excluded_regular_files':dict(sorted(excluded.items())),
            'pruned_directories':sorted(directories, key=lambda row:row['path'])}


def tar_info(name, size):
    safe_member(name)
    info = tarfile.TarInfo(name)
    info.size = size
    info.mode = 0o644
    info.uid = info.gid = info.mtime = 0
    info.uname = info.gname = ''
    info.type = tarfile.REGTYPE
    return info


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--freeze-note', required=True)
    p.add_argument('--freeze-note-sha256', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--budget-s', type=int, default=220)
    a = p.parse_args()
    started = time.monotonic()
    assert 1 <= a.budget_s <= 840
    deadline = started+a.budget_s
    note_path = Path(a.freeze_note).resolve(strict=True)
    assert stat.S_ISREG(note_path.lstat().st_mode)
    note_bytes = note_path.read_bytes()
    assert hashlib.sha256(note_bytes).hexdigest() == a.freeze_note_sha256
    note = json.loads(note_bytes)
    assert note['schema'] == 'coax.analysis-cost.proof-freeze.v1'
    assert note['all_writers_stopped'] is True
    assert note['root_authorized_archive'] is True
    assert note['qualification_claim_by_assembler'] is False
    status = note['qualification_status']
    assert status in ('FULLY_QUALIFIED', 'NOT_QUALIFIED')
    if status == 'FULLY_QUALIFIED':
        assert note['all_final_gates_finished'] is True
    else:
        unfinished = note['unfinished_gate_names']
        assert isinstance(unfinished, list) and unfinished
        assert all(isinstance(name, str) and name.strip() for name in unfinished)
        assert len(set(unfinished)) == len(unfinished)
        assert isinstance(note['owner_limit_reason'], str) and note['owner_limit_reason'].strip()
        assert note.get('all_final_gates_finished') is not True
    assert isinstance(note['actual_gate_receipts'], dict)
    for name, fact in note['actual_gate_receipts'].items():
        assert digest(Path(fact['path']), deadline) == fact['sha256'], 'frozen gate receipt differs: '+name
    for name in REQUIRED_CANONICAL:
        path = SCOPES['canonical-v12']/name
        assert path.is_file() and not path.is_symlink(), 'canonical script absent: '+name
    output = Path(a.output).resolve()
    assert not output.exists()
    assert all(not output.is_relative_to(root) and not root.is_relative_to(output)
               for root in SCOPES.values()), 'keep outputs outside all input scopes'
    output.mkdir(parents=True)
    record = {'schema':'coax.analysis-cost.proof-archive.v1',
              'outcome':'not-assembled', 'qualification_claim':False,
              'scope':'Frozen actual completion proof files and explicit supporting sources only. This archive performs no compiler/test/native/network/Git operation and does not decide analysis-cost qualification.',
              'freeze_note':{'path':str(note_path),'sha256':a.freeze_note_sha256},
              'supplied_freeze_qualification_status':status,
              'unfinished_gate_names':note.get('unfinished_gate_names', []),
              'owner_limit_reason':note.get('owner_limit_reason'),
              'scope_roots':{name:str(path) for name,path in SCOPES.items()},
              'old_history_reference':note.get('old_history_reference'),
              'old_history_nested_copy':False}

    def save():
        record['elapsed_s'] = time.monotonic()-started
        (output/'record.json').write_text(json.dumps(record, indent=2)+'\n')

    try:
        before = inventory(deadline)
        assert before['members'], 'empty archive'
        record['inventory_before'] = before
        for name, fact in note['actual_gate_receipts'].items():
            assert any(Path(row['source_path']).resolve() == Path(fact['path']).resolve()
                       and row['sha256'] == fact['sha256'] for row in before['members'].values()), 'actual current gate receipt outside archive: '+name
        manifest = {'schema':'coax.analysis-cost.proof-members.v1',
                    'qualification_claim':False,
                    'members':before['members'],
                    'auxiliary_members':{'FREEZE.json':{'bytes':len(note_bytes),
                        'sha256':hashlib.sha256(note_bytes).hexdigest()}},
                    'self_manifest':'MANIFEST.json is byte-identical to the external manifest.json; excluded from its own recursive member table.',
                    'exclusion_scope':'Pruned caches/debug bundles/credential-named files are not read. Other excluded regular artifacts have hash/size inventories but no archive body.'}
        manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2)+'\n').encode()
        (output/'manifest.json').write_bytes(manifest_bytes)
        expected = {name:{'bytes':row['bytes'],'sha256':row['sha256']}
                    for name,row in before['members'].items()}
        expected['FREEZE.json'] = manifest['auxiliary_members']['FREEZE.json']
        expected['MANIFEST.json'] = {'bytes':len(manifest_bytes),
            'sha256':hashlib.sha256(manifest_bytes).hexdigest()}
        archive = output/'proof.tar.xz'
        with archive.open('xb') as raw, lzma.LZMAFile(raw, mode='w',
                format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64,
                filters=[{'id':lzma.FILTER_LZMA2,'preset':6,'dict_size':67108864}]) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for name in sorted(expected):
                    assert time.monotonic() < deadline
                    if name in ('FREEZE.json','MANIFEST.json'):
                        data = note_bytes if name == 'FREEZE.json' else manifest_bytes
                        tar.addfile(tar_info(name,len(data)), io.BytesIO(data))
                    else:
                        fact = before['members'][name]
                        with open(fact['source_path'],'rb') as source:
                            tar.addfile(tar_info(name,fact['bytes']), source)
        assert archive.stat().st_size < 100*1024*1024, 'compressed proof exceeds100MiB'
        after = inventory(deadline)
        record['inventory_after'] = after
        assert after == before, 'proof inputs changed during assembly'
        assert note_path.read_bytes() == note_bytes, 'freeze note changed'
        verified = {}
        with tarfile.open(archive,'r:xz') as tar:
            for member in tar:
                assert time.monotonic() < deadline
                safe_member(member.name)
                assert member.isreg() and member.name in expected and member.name not in verified
                assert member.uid == member.gid == member.mtime == 0 and member.mode == 0o644
                h = hashlib.sha256()
                stream = tar.extractfile(member)
                assert stream is not None
                count = 0
                while True:
                    assert time.monotonic() < deadline
                    block = stream.read(1048576)
                    if not block:
                        break
                    count += len(block)
                    h.update(block)
                got = {'bytes':count,'sha256':h.hexdigest()}
                assert got == expected[member.name], 'archive member differs: '+member.name
                verified[member.name] = got
        assert set(verified) == set(expected)
        assert inventory(deadline) == before, 'proof changed during readback'
        record.update(outcome='assembled-integrity-verified',
            archive={'path':str(archive),'bytes':archive.stat().st_size,
                     'sha256':digest(archive,deadline)},
            manifest={'path':str(output/'manifest.json'),
                      'sha256':hashlib.sha256(manifest_bytes).hexdigest()},
            members_verified=len(verified), selected_proof_files=len(before['members']),
            uncompressed_member_bytes=sum(row['bytes'] for row in expected.values()),
            before_after_identity=True, every_member_readback_verified=True,
            deterministic_archive_headers=True, compression='XZ LZMA2 with64MiB dictionary andCRC64')
    except BaseException as error:
        record['outcome']='failed'
        record['error']=type(error).__name__+': '+str(error)
        raise
    finally:
        save()
    print(json.dumps({'outcome':record['outcome'],'qualification_claim':False,
        'archive':record['archive'],'members_verified':record['members_verified']}))


if __name__ == '__main__':
    main()
