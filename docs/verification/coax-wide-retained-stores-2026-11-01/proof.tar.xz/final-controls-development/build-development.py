#!/usr/bin/env python3
"""New-current-native final-style development build; never a normal qualification."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
B=Path('/Users/christopherdavid/.codex/worktrees/coax-book30-final-controls/openagents')
BASE=Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha')
sys.path[:0]=[str(BASE/'infrastructure/coax/tools'),str(BASE/'infrastructure/coax/tests')]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
def inventory(root):
 assert not any(p.is_symlink() for p in root.rglob('*'))
 return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def main():
 a=argparse.ArgumentParser();a.add_argument('--emission-directory',required=True);a.add_argument('--emission-record-sha256',required=True);a.add_argument('--source-revision',required=True);a.add_argument('--directory',required=True);args=a.parse_args()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==args.source_revision
 e=Path(args.emission_directory).resolve();d=Path(args.directory).resolve();assert not d.exists()
 assert sha(e/'record.json')==args.emission_record_sha256
 emission=json.loads((e/'record.json').read_text());assert emission['outcome']=='passed' and emission['inputs_unchanged']
 for p,v in emission['artifacts'].items():assert sha(p)==v
 assert sha(B/'coax/bootstrap-build.sh')=='3b27f7de82ad35fed14ce28cca27daedd8d83ff2028f9dd838206d56dae90f40'
 environment=dict(os.environ);aliases={};physical={}
 for key,default in [('CC','cc'),('CXX','c++')]:
  program=environment.get(key,default);search=os.pathsep.join(str(Path(p) if Path(p).is_absolute() else B/'coax'/p) for p in os.get_exec_path(environment))
  found=Path(program) if os.path.dirname(program) else Path(shutil.which(program,path=search) or '/missing')
  if not found.is_absolute():found=B/'coax'/found
  alias=Path(os.path.abspath(found));assert alias.is_file() and os.access(alias,os.X_OK)
  aliases[key]=str(alias);physical[key]=str(alias.resolve(strict=True))
 original=inventory(B/'coax/src');d.mkdir();s=d/'native-source';s.mkdir();shutil.copytree(B/'coax/src',s/'src')
 assert inventory(s/'src')==original and inventory(B/'coax/src')==original,'CPP snapshot changed during copy'
 runtime_parts=[('CORE',[B/'coax/lib/proto/wire.coax']),('MEMORY',[B/'coax/lib/proto/memory.coax']),('IMPORTER',[B/'coax/lib/proto/importer.coax']),('FINGERPRINT',[B/'coax/lib/crypto/sha256-kernel.coax',B/'coax/lib/proto/fingerprint.coax'])]
 runtime_inputs={str(p):sha(p) for _,paths in runtime_parts for p in paths};runtime=b''
 for name,paths in runtime_parts:
  tag='FP' if name=='FINGERPRINT' else name
  runtime+=('static constexpr char PROTO_'+name+'_SOURCE[] = R"COAX_'+tag+'(').encode()+b''.join(p.read_bytes() for p in paths)+(')COAX_'+tag+'";\n').encode()
 assert all(sha(p)==v for p,v in runtime_inputs.items());(d/'proto_runtime.inc').write_bytes(runtime)
 for name in ['proto_importer.c','proto_importer.h']:shutil.copy2(e/name,d/name)
 inputs=[Path(__file__).resolve(),e/'record.json',e/'proto_importer.c',e/'proto_importer.h',*[s/'src'/name for name in original],Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[Path(v) for v in physical.values()]]
 before={str(p):sha(p) for p in inputs};artifacts={str(d/n):sha(d/n) for n in ['proto_importer.c','proto_importer.h','proto_runtime.inc']}
 r={'schema':'coax.chapter30.cost-development-finalstyle.v1','scope':'Development final-style image with actual profiles from the fresh current native snapshot and actual historical qualified5c emission of frozen streamed retained-store source. No BOOTSTRAP_IMPORTER, object reuse, normal pass, seed fixedpoint, provenance, install or SDK-content lock claim.','source_revision_at_copy':args.source_revision,'native_source_original_at_copy':original,'native_source_snapshot':str(s/'src'),'runtime_inputs_at_copy':runtime_inputs,'compiler_aliases':aliases,'compiler_physical':physical,'emission':str(e/'record.json'),'emission_sha256':sha(e/'record.json'),'source_before':before,'artifacts':artifacts,'rows':[],'outcome':'not-checked','settings':{k:environment.get(k) for k in ['COAX_HOST_TARGET','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET']}}
 started=time.monotonic();deadline=started+840
 def save():
  r['source_after']={str(p):sha(p) for p in inputs};r['inputs_unchanged']=r['source_after']==before and inventory(s/'src')==original and all(str(Path(aliases[k]).resolve(strict=True))==physical[k] for k in physical);r['artifacts_unchanged']=all(sha(p)==v for p,v in artifacts.items());r['elapsed_s']=time.monotonic()-started;(d/'record.json').write_text(json.dumps(r,indent=2)+'\n')
 cflags=['-std=c11','-O1','-g'];cppflags=['-std=c++20','-O1','-g','-Wall','-Wextra','-Wno-missing-field-initializers']
 if environment.get('COAX_HOST_TARGET'):
  cflags+=['-target',environment['COAX_HOST_TARGET']];cppflags+=['-target',environment['COAX_HOST_TARGET']]
 commands=[('compile-aggregate',[aliases['CC'],*cflags,'-c',str(d/'proto_importer.c'),'-o',str(d/'proto_importer.o')],d/'proto_importer.o'),('link-finalstyle',[aliases['CXX'],*cppflags,'-I',str(d),'-o',str(d/'coax'),'src/main.cpp',str(d/'proto_importer.o')],d/'coax')]
 try:
  for name,argv,output in commands:
   save();assert r['inputs_unchanged'] and r['artifacts_unchanged']
   o=bounded_process.run(argv,cwd=s,env=environment,timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=8388608,deadline=deadline,quiet_faults=True)
   row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
   for stream in ['stdout','stderr']:
    data=row['observation'].pop(stream);p=d/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
   row['transport_clean']=clean(o);r['rows'].append(row);save();assert row['transport_clean'] and r['inputs_unchanged'] and r['artifacts_unchanged'],'candidate build failed'
   assert output.is_file();artifacts[str(output)]=sha(output);save();print(json.dumps({'step':name,'passed':True,'seconds':o['elapsed_s'],'output':str(output),'sha256':sha(output)}),flush=True)
  r['outcome']='passed';r['image']=str(d/'coax');r['image_sha256']=sha(d/'coax')
 except BaseException as error:r['outcome']='failed';r['error']=repr(error);raise
 finally:save()
 print(json.dumps({'record':str(d/'record.json'),'record_sha256':sha(d/'record.json'),'unqualified_image':str(d/'coax'),'image_sha256':sha(d/'coax')}),flush=True)
if __name__=='__main__':main()
