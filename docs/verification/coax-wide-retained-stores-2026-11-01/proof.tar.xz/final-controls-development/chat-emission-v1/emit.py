#!/usr/bin/env python3
"""Actual matching G development image emits unchanged retained Chat; no current qualification."""
from pathlib import Path
import hashlib,json,os,sys,time
S=Path('/private/var/folders/v2/0ls5nf1j509db69fk73k7ms40000gn/T/tmp.XZVPnA3Kbi/check').resolve()
W=Path('/tmp/coax-chapter30-full/final-controls/development-v1').resolve()
D=Path(__file__).resolve().parent
sys.path[:0]=[str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tools')),str(Path('/tmp/coax-return-borrows-A1/normal046-plan8-current309-184-v12-sha/infrastructure/coax/tests'))]
import bounded_process,quiet_crash
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
clean=lambda o:o['started'] and o['returncode']==0 and o['stdout_eof'] and o['stderr_eof'] and not any(o[k] for k in ('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','launch_errno','launch_error','kill_errno','read_errno'))
paths=[Path(__file__).resolve(),W/'coax',W/'proto_runtime.inc',Path(bounded_process.__file__).resolve(),Path(quiet_crash.__file__).resolve(),*[p for root in [S/'apps/openagents-web',S/'apps/shared',S/'coax/lib',S/'proto'] for p in root.rglob('*') if p.is_file()]]
before={str(p):sha(p) for p in paths}
assert before[str(W/'coax')]=='e89d29f728bed640c3c639ddbdafe736a5321d70fa21d20693ca4a0d6fc01274'
assert before[str(S/'coax/lib/compiler/checker.coax')]=='4fc4444c8d0c15c9642395b11fad56f37a9c4443b89f5fe5c3f9e0ae0de0f1e9'
build_record=W/'record.json';assert sha(build_record)=='577d708b4ac472fa22bf4088a2192b74d518783b36dae5227f80da0b6651db41';build=json.loads(build_record.read_text());assert build['outcome']=='passed' and build['image_sha256']==sha(W/'coax');before[str(build_record)]=sha(build_record);paths.append(build_record)
r={'schema':'coax.chapter30.stream-chat-emission.v1','scope':'Actual2b5523fc/e89d29f7 unqualified latest0.47 development image emits unchanged retained actual Chat source with supported observational profile. Broad input inventory is broader than consumed closure. Original generation flags c --library --header; profile-report observes consumed inputs/output only. No normal, native, seal, install, browser or page-completion claim.','producer':str(W/'coax'),'producer_sha256':sha(W/'coax'),'source_revision':'e84f7b02cbaefc60ba2cec03c3cb0db5c9aaac3f','producer_scope':'Actual2b5523fc/1011-check latest0.47 development compilere89d29f7, build record577d708b, emits Chat from retained E20d source tree. Development only; do not relabel E d8ee qualification.','source_before':before,'rows':[],'artifacts':{},'outcome':'not-checked'}
started=time.monotonic();deadline=started+840
def save():
 r['source_after']={str(p):sha(p) for p in paths};r['inputs_unchanged']=r['source_after']==before;r['elapsed_s']=time.monotonic()-started
 (D/'record.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name in ['chat']:
  save();assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
  module='apps/openagents-web/chat.coax'
  header=D/(name+'.h');assert not header.exists() and not (D/(name+'.c')).exists()
  profile=D/(name+'.profile.json')
  argv=[str(W/'coax'),'c',module,'--library','--header',str(header),'--profile-report',str(profile)]
  o=bounded_process.run(argv,cwd=S,env=dict(os.environ),timeout_s=min(600,deadline-time.monotonic()),max_output_bytes=33554432,deadline=deadline,quiet_faults=True)
  row={'label':name,'argv':argv,'observation':dict(o),'raw':{}}
  for stream in ['stdout','stderr']:
   data=row['observation'].pop(stream);p=D/(name+'.'+stream);p.write_bytes(data);row['raw'][stream]={'path':str(p),'sha256':sha(p),'bytes':len(data)}
  (D/(name+'.c')).write_bytes(o['stdout'])
  row['transport_clean']=clean(o);r['rows'].append(row);save()
  assert row['transport_clean'] and r['inputs_unchanged'],'actual emission failed'
  assert header.is_file() and header.stat().st_size>0
  manifest=json.loads(profile.read_text())
  assert manifest['schema_version']==1 and manifest['command']=='c' and manifest['backend']=='c11' and manifest['runtime_arithmetic']=='checked' and manifest['success'] and manifest['exit_status']==0
  assert manifest['emitted_sha256']==sha(D/(name+'.c')) and manifest['artifact_sha256']==sha(D/(name+'.c'))
  for consumed in [*manifest['sources'],*manifest['descriptors']]:assert sha(consumed['path'])==consumed['sha256']
  row['profile']=str(profile);row['profile_sha256']=sha(profile);row['actual_consumed_sources']=manifest['sources'];row['actual_consumed_descriptors']=manifest['descriptors']
  for p in [header,D/(name+'.c'),profile]:r['artifacts'][str(p)]=sha(p)
  save();print(json.dumps({'label':name,'passed':True,'elapsed_s':o['elapsed_s'],'artifacts':{str(p):sha(p) for p in [header,D/(name+'.c')]}}),flush=True)
 assert r['inputs_unchanged'] and all(sha(p)==v for p,v in r['artifacts'].items())
 r['outcome']='passed'
except BaseException as e:
 r['outcome']='failed';r['error']=repr(e);raise
finally:save()
print(json.dumps({'record':str(D/'record.json'),'sha256':sha(D/'record.json'),'outcome':r['outcome']}),flush=True)
