#!/usr/bin/env python3
"""One bounded private authored-check observation; never compiler qualification."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,time
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--compiler',required=True);p.add_argument('--source',required=True);p.add_argument('--only');p.add_argument('--record-dir',required=True);a=p.parse_args()
R=Path('/Users/christopherdavid/.codex/worktrees/coax-book30-final-controls/openagents');C=Path(a.compiler).resolve();S=Path(a.source).resolve();D=Path(a.record_dir).resolve();assert not D.exists();D.mkdir()
sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
H=R/'coax/tools/bounded_process.py';Q=R/'coax/tests/quiet_crash.py';spec=importlib.util.spec_from_file_location('cost_bp',H);bp=importlib.util.module_from_spec(spec);spec.loader.exec_module(bp)
paths=[Path(__file__).resolve(),C,H,Q,*sorted(S.parent.rglob('*.coax'))];before={str(q):sha(q)for q in paths};assert before[str(C)]=='5c37377a72fbba0a4e11a6ffdba2bfa37c223f8490b158aa23bc1a75488c53d9'
argv=[str(C),'test',str(S),'--library','--evidence',str(D/'evidence.json')]
if a.only:argv+=['--only',a.only]
started=time.monotonic();o=bp.run(argv,cwd=R,env=os.environ.copy(),timeout_s=120,deadline=started+125,max_output_bytes=4194304,quiet_faults=True);raw={}
for k in ('stdout','stderr'):
 data=o.pop(k);q=D/(k+'.log');q.write_bytes(data);raw[k]={'path':str(q),'sha256':sha(q),'bytes':len(data)}
after={str(q):sha(q)for q in paths};flags=('timeout','deadline_exhausted','stdout_limit','stderr_limit','output_limit','group_killed','kill_errno','launch_errno','launch_error','read_errno');transport=o['started']and o['stdout_eof']and o['stderr_eof']and not any(o.get(k)for k in flags)
r={'schema':'coax.chapter30.analysis-cost.authored-observation.v1','scope':('Selected private controls on historical qualified5c; authority coverage skipped.' if a.only else 'Whole authored current H source on historical qualified5c with authority coverage; no current producer or normal qualification claim.'),'argv':argv,'source_sha256':sha(S),'producer':str(C),'producer_sha256':sha(C),'observation':o,'raw':raw,'inputs_before':before,'inputs_after':after,'inputs_unchanged':before==after,'transport_clean':bool(transport),'semantic_e0406':b'error[E0406]'in(D/'stderr.log').read_bytes(),'outcome':'passed'if transport and before==after and o['returncode']==0 else 'nonpassing'}
(D/'process.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'record':str(D/'process.json'),'sha256':sha(D/'process.json'),'outcome':r['outcome'],'observation':o,'semantic_e0406':r['semantic_e0406'],'stdout_tail':(D/'stdout.log').read_text()[-2200:],'stderr':(D/'stderr.log').read_text()[-4000:]}))
assert transport and before==after
