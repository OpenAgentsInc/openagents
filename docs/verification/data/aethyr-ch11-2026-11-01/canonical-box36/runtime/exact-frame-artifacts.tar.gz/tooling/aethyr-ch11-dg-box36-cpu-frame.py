from pathlib import Path
import argparse,hashlib,json,subprocess,time,sys
ROOT=Path('/Users/christopherdavid/work/openagents-aethyr-book');sys.path.insert(0,str(ROOT/'aethyr/render/tests'))
from check_reference_frame import snapshot_frame_config
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--rounding',choices=['nearest-even','nearest-positive'],required=True);p.add_argument('--work',type=Path,required=True);a=p.parse_args();a.work.mkdir(exist_ok=True)
oldpath=Path('/tmp/aethyr-ch11-reference-deadgears-ring8-current-native/measurement.json');old=json.loads(oldpath.read_text());assert old['status']=='rendered' and not old['source_changes'] and not old['artifact_changes'] and not old['input_changes'] and not old['compiler_changed']
artifact={k:Path(old[k+'_path'])for k in ['generated_c','generated_header','executable']}
for kind,path in artifact.items():assert sha(path)==old[kind+'_sha256']
capture=Path('/tmp/aethyr-ch11-deadgears-box36-current-default/frame.config');package=Path('/tmp/aethyr-ch11-packages-box36/dead-gears/render.json');inputs=a.work/'inputs';inputs.mkdir(exist_ok=True);config=a.work/'frame.config'
files,pkg,trees,original,counts=snapshot_frame_config(capture,package,inputs,config)
before={str(x):sha(x)for x in set(files.values())|set(artifact.values())|{config,oldpath,capture,package,Path(__file__),ROOT/'aethyr/render/tests/check_reference_frame.py'}}
command=[str(artifact['executable']),str(config),str(a.work/'screen.rgba32f'),str(a.work/'frame.json'),a.rounding,'8','guard-band','65536','rgba16f','complex-world','analytic']
started=time.monotonic()
with(a.work/'render.log').open('wb')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=810)
assert r.returncode==0
changes=[p for p,h in before.items()if sha(p)!=h];assert not changes
result=json.loads((a.work/'frame.json').read_text());assert result['status']==0
provenance=Path('/tmp/aethyr-ch11-depth-left-native-analysis.json'if a.rounding=='nearest-even'else'/tmp/aethyr-ch11-depth-left-webgpu-analysis.json')
record={'schema':'aethyr.render.retained-backend-profile-measurement.v1','status':'rendered','qualification':False,'scope':'Exact qualified633-era normal-C/header/backend executable reused for a distinct authenticated winding-repair shader package and fresh actual producer input. The backend retains its recorded pre-water-spray Geometry epoch; changed current Everglade-specific admission is not attributed to this emission. No Coax compilation or live source closure rescan.',
 'backend_receipt':str(oldpath),'backend_receipt_sha256':sha(oldpath),'compiler_sha256':old['compiler_sha256'],'backend_source_sha256':old['source_sha256'],
 'profile':4,'width':320,'height':180,'result':result,'command':command,'elapsed_seconds':time.monotonic()-started,'raster_profile':{'rounding':a.rounding,'subpixel_bits':8,'xy_clipping':'guard-band','guard_pixels':65536,'provenance':str(provenance),'provenance_sha256':sha(provenance)},
 'input_artifact_sha256':before,'input_artifact_changes':changes,'image_sha256':sha(a.work/'screen.rgba32f')}
(a.work/'measurement.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['status','elapsed_seconds','result']}))
