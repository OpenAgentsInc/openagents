#include "Probe.h"
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
int main(int argc,char **argv){assert(argc==3);FILE *in=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");assert(in&&out);float u[4];for(int i=0;i<728;i++){assert(fread(u,4,4,in)==4);coax_t_V4 q=ring8_cpu_sample((coax_v_f32){u,4});float v[4]={q.x,q.y,q.z,q.w};assert(fwrite(v,4,4,out)==4);}assert(fgetc(in)==EOF&&!fclose(in)&&!fclose(out));coax_t_V4 a=ring8_cpu_refusal(false,UINT32_MAX),b=ring8_cpu_refusal(true,UINT32_MAX);assert(a.x==0&&a.y==0&&a.z==0&&a.w==0&&b.x==0&&b.y==0&&b.z==0&&b.w==0);return 0;}
