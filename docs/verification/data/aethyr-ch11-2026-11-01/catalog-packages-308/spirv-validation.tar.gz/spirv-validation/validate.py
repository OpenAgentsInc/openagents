import hashlib,json,shutil,subprocess
from pathlib import Path
tool=shutil.which('spirv-val');assert tool
source=json.loads(Path('inputs.json').read_text());observations=[]
for row in source:
 data=Path(row['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 r=subprocess.run([tool,'--target-env','vulkan1.1',row['file']],capture_output=True,timeout=30)
 observations.append(dict(row,exit_status=r.returncode,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace')))
positive=[r for r in observations if r['kind']=='program'];controls=[r for r in observations if r['kind']=='control']
ok=all(r['exit_status']==0 for r in positive) and len(controls)==2 and all(r['exit_status']!=0 and r['stderr'] for r in controls)
version=subprocess.run([tool,'--version'],capture_output=True,check=True,timeout=10).stdout.decode()
print(json.dumps(dict(status='pass' if ok else 'fail',validator=tool,validator_sha256=hashlib.sha256(Path(tool).read_bytes()).hexdigest(),version=version,observations=observations)))
