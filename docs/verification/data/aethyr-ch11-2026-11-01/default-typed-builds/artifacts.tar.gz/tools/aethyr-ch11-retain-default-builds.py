from pathlib import Path
import hashlib,json,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');source=Path('/tmp/aethyr-ch11-typed-hosts-one');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/default-typed-builds';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={};included=[]
for name in ['watchtower','waterlab','verse','fixture','droprealm','garden','myrealm','villa','deadgears']:
 p=source/(name+'.json');d=json.loads(p.read_text());assert d['status']=='pass'and not d['source_changes'];w=source/(name+'.wasm');assert sha(w)==d['wasm_sha256'];admitted=Path(d['environment']['COAXIAL_ADMITTED_DIR']);assert all(sha(admitted/f)==h for f,h in d['emitted'].items());receipts[name]={k:d[k]for k in ['elapsed_seconds','compiler_sha256','wasm_sha256','source_changes','emitted']};receipts[name]['receipt_sha256']=sha(p)
 for f in [p,source/(name+'.log'),w,*admitted.glob('*')]:included.append((f,name+'/'+str(f.relative_to(source))if f.is_relative_to(source)else name+'/'+f.name))
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 for p,label in included:tar.add(p,arcname=label)
 for p in [Path('/tmp/aethyr-ch11-build-one.py'),Path(__file__)]:tar.add(p,arcname='tools/'+p.name)
 for name in ['coax/web/wasm.sh','coax/web/toolchain.sh','coax/web/render-face.c','verse/native/build.sh']:tar.add(root/name,arcname='effects/'+name)
record={'schema':'aethyr.render.ordinary-typed-builds.v1','status':'pass_for_nine_current_owners','default_route':'COAXIAL_RENDER unset: auto','builds':receipts,'archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size},'scope':'Nine ordinary renderer-enabled wasm.sh builds retain exact qualified Coax-generated C/headers and linked Wasm with source fences. Other owners and earlier C-only relinks are separate; this is build/adoption evidence, not complete CPU/GPU image parity.'};(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n');print(record['archive']['bytes'])
