#include "/tmp/aethyr-ch11-typed-hosts-one/admitted/everglade/everglade.c"
static void *read_input(const char *p, int64_t *n) {FILE *f=fopen(p,"rb");if(!f){perror(p);exit(2);}fseek(f,0,SEEK_END);long z=ftell(f);rewind(f);void *b=calloc(z?z:1,1);if(fread(b,1,z,f)!=(size_t)z)exit(3);fclose(f);*n=z;return b;}
int main(void) {
 const char *base="/tmp/aethyr-ch11-everglade-full-input-refusal/";char name[2048];int64_t n;
 #define READ(S) (snprintf(name,sizeof name,"%s%s",base,S),read_input(name,&n))
 float *u=READ("uniforms.bin");int64_t un=n/4;uint32_t *draws=READ("draws.bin");int64_t dn=n/4;
 uint32_t *idx=read_input("/tmp/aethyr-ch11-everglade-current-startup/indices.bin",&n);int64_t in=n/4;
 coax_t_RenderGeometryBuffer b[6]={0};const char *files[]={"vertices.bin.bin","s0.bin.bin","s1.bin.bin","s2.bin.bin","s3.bin.bin","puffs.bin.bin"};
 for(int k=0;k<6;k++){b[k].words.data=READ(files[k]);b[k].words.count=n/4;b[k].binding_set=k==5?1:0;b[k].resource=k==5?1:k+1;if(k==1)b[k].words.count=88200/4;}
 coax_t_RenderDrawDomain domains[4096]={0};coax_t_FrameCounts c={.width=1280,.height=800,.draw_count=dn/4,.water_draws=1,.grass_instances=104576,.particle_instances=126,.vertex_stride=16};
 coax_t_RenderGeometryResult r=coax_p_render_geometry_admit(2,c,(coax_v_u32){draws,dn},(coax_v_u32){idx,in},(coax_v_f32){u,un},(coax_v_t_RenderGeometryBuffer){b,6},(coax_v_f32){0,0},(coax_v_t_RenderDrawDomain){domains,4096},16777216);
 printf("status %d bad_draw %lld bad_resource %lld work %lld\n",r.status,(long long)r.bad_draw,(long long)r.bad_resource,(long long)r.work);
 for(int k=0;k<dn/4;k++){coax_t_FrameCounts one=c;one.draw_count=1;one.water_draws=k==dn/4-1;coax_t_RenderGeometryResult t=coax_p_render_geometry_admit(2,one,(coax_v_u32){draws+4*k,4},(coax_v_u32){idx,in},(coax_v_f32){u,un},(coax_v_t_RenderGeometryBuffer){b,6},(coax_v_f32){0,0},(coax_v_t_RenderDrawDomain){domains,4096},16777216);if(t.status)printf("draw %d status %d words %u %u %u %u\n",k,t.status,draws[k*4],draws[k*4+1],draws[k*4+2],draws[k*4+3]);}
 return 0;
}
