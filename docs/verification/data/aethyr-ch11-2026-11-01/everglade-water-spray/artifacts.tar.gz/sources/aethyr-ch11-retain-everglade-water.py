from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/everglade-water-spray';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gate=json.loads(Path('/tmp/aethyr-ch11-everglade-water-geometry-mutate-final.json').read_text());assert gate['status']=='pass'and not gate['source_changed'];source=root/'aethyr/render/geometry.coax';assert sha(source)==gate['source_sha256'];native=json.loads(Path('/tmp/aethyr-ch11-everglade-water-native/qualification.json').read_text());assert native['status']=='pass'and native['geometry_sha256']==sha(source)
failed=json.loads(Path('/tmp/aethyr-ch11-everglade-current-full-startup/receipt.json').read_text());assert failed['status']['render']['refusal']['geometry']==5 and failed['status']['render']['refusal']['requested']['draws']==190 and not failed['source_changes']
paths={}
for label in ['aethyr-ch11-everglade-live-generic','aethyr-ch11-everglade-full-input-refusal','aethyr-ch11-everglade-water-native','aethyr-ch11-everglade-water-spray-build-stopped-after-mutation']:
 for p in sorted((Path('/tmp')/label).rglob('*')):
  if p.is_file():paths['evidence/'+label+'/'+str(p.relative_to(Path('/tmp')/label))]=p
for name in ['driver.ts','receipt.json','failure.json']:
 p=Path('/tmp/aethyr-ch11-everglade-current-full-startup')/name
 if p.exists():paths['fullsize-refusal/'+name]=p
for p in Path('/tmp').glob('aethyr-ch11-everglade-water-*.log'):paths['logs/'+p.name]=p
for p in Path('/tmp').glob('aethyr-ch11-everglade-water-*.json'):paths['logs/'+p.name]=p
for p in [source,root/'apps/openagents-web/everglade.coax',root/'verse/everglade/gpu.coax',root/'verse/everglade/river.coax',Path('/tmp/aethyr-ch11-everglade-current-startup/indices.bin'),Path(__file__)]:paths['sources/'+p.name]=p
before={name:sha(p)for name,p in paths.items()}
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 for name,p in paths.items():
  b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mtime=0;tar.addfile(i,io.BytesIO(b))
assert all(sha(p)==before[name]for name,p in paths.items())
r={'schema':'aethyr.render.everglade-water-spray.v1','status':'implementation_checks_and_native_regression_pass_browser_recheck_pending','geometry_gate':gate,'checks':98,'mutants':710,'killed':710,'survivors':0,'equivalent_marks':0,'native':native,'diagnosis':'The desktop producer reserves 3 spray slots, while the old domain retained only ceil(64/96)=1. Its final draw requested 120 instances against a derived 118. The shader clips the extra slots before reading a particle. The new bound retains max(3, ceil(64/per)) slots. It preserves the phone tier and every resource bound.','failure':'Actual full-size browser frame refused draw189, with no submitted frame. Independently compiled old Coax C isolates that exact draw. Small160x90 actual frame previously submitted and is not evidence for the desktop case.','native_replay':'The current Coax geometry admits the actual full desktop payload in debug, O2 and ASan/UBSan C. Instance121, index576 and a short water-node payload each refuse with no partial publication.','history':'Initial check syntax diagnostics and two red regression logs are retained. The first max expression had 2 mutation survivors; it was rewritten without adding equivalent marks. The in-progress first ordinary build was deliberately stopped after that mutation failure.','source_inputs':before,'source_changes':[],'scope':'This record qualifies the implementation and native admission boundary. A fresh ordinary Wasm build and full-size browser frame remain pending. It makes no GPU image, CPU raster or full-chapter completion claim.','archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size}}
(out/'qualification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['archive']))
