from pathlib import Path
import json,os,subprocess,signal,sys,time
root=Path('/Users/christopherdavid/work/openagents-aethyr-book'); route,names,out=sys.argv[1:]; folder=Path(out);folder.mkdir(exist_ok=True,parents=True)
start=time.monotonic(); server=subprocess.Popen(['bun','/tmp/aethyr-ch11-golden-server-grid-4m.ts',route,out],cwd=root,stdout=subprocess.PIPE,stderr=(folder/'server.log').open('w'),text=True,start_new_session=True)
child=None
try:
 base=json.loads(server.stdout.readline())['base'];command=['bun','coax/web/goldens.ts',base,'--only',names,'--report',str(folder/'report.json')]
 child=subprocess.Popen(command,cwd=root,env=dict(os.environ,GOLDENS_POOL='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 try:stdout,_=child.communicate(timeout=780)
 except subprocess.TimeoutExpired:
  os.killpg(child.pid,signal.SIGTERM)
  try:stdout,_=child.communicate(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);stdout,_=child.communicate()
  raise RuntimeError('stock golden slice stopped at780second deadline')
 (folder/'execution.log').write_text(stdout);record={'status':'pass'if child.returncode==0 else'fail','route':route,'command':command,'elapsed_seconds':round(time.monotonic()-start,3),'returncode':child.returncode,'scope':'Actual existing production golden walker and saved PNG baselines; HTML rewrites only local artifact/package addresses, routes recorded separately.'};(folder/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print(stdout[-5000:])
finally:
 if server.poll()is None:server.terminate()
 try:server.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
