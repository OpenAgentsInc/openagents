#include "stage.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char**argv){uint64_t cursor,bytes,limit;
 while(scanf("%"SCNu64" %"SCNu64" %"SCNu64,&cursor,&bytes,&limit)==3){
  coax_t_RenderHostStage r=stage_native(cursor,bytes,limit);
  if(argc==2){if(!strcmp(argv[1],"status"))r.status=COAX_RenderFrameStatus_bad_upload;
   if(!strcmp(argv[1],"address"))r.address=0;if(!strcmp(argv[1],"next"))r.next=0;if(!strcmp(argv[1],"pages"))r.pages=0;}
  printf("%u %"PRIu64" %"PRIu64" %"PRIu64"\n",(unsigned)r.status,r.address,r.next,r.pages);
 }return 0;}
