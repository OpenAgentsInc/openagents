#include "uploads.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char**argv){uint64_t prior,incoming,capacity;int submitted;
 while(scanf("%"SCNu64" %"SCNu64" %"SCNu64" %d",&prior,&incoming,&capacity,&submitted)==4){
  coax_t_RenderHostUploadState before={.pending=prior};
  coax_t_RenderHostUploadReceipt staged=uploads_stage_native(before,incoming,capacity);
  coax_t_RenderHostUploadState after=uploads_ack_native(staged.next,submitted);
  if(argc==2){if(!strcmp(argv[1],"status"))staged.status=COAX_RenderFrameStatus_bad_upload;
   if(!strcmp(argv[1],"pending"))staged.next.pending=0;if(!strcmp(argv[1],"grew"))staged.grew=0;if(!strcmp(argv[1],"ack"))after.pending=0;}
  printf("%u %"PRIu64" %d %"PRIu64"\n",(unsigned)staged.status,staged.next.pending,(int)staged.grew,after.pending);
 }return ferror(stdin)?2:0;}
