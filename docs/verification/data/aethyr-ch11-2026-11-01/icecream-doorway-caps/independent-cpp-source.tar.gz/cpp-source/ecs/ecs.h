// Aethyr's entity-component-system. See docs/ecs.md.
//
// Entities are 32-bit handles (index + generation). Each component type is a
// plain struct kept in its own sparse set: a dense array of values beside the
// dense array of owners, and a sparse index from entity index to dense slot.
// Component and resource type ids come from a template counter; there is no
// RTTI and no virtual dispatch. Systems are plain functions run in phases,
// single-threaded and deterministic. Events are typed queues drained after
// each phase, in phase order. Prefabs and save/load go through each
// component's registered fields.
//
// This header has no dependency on GL or Emscripten, so worlds and their
// rules build and test natively (./build.sh test).
#pragma once

#include <cassert>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

#include "json.h"

namespace ecs {

// ---------------------------------------------------------------- entities

struct Entity {
  static constexpr uint32_t kIndexBits = 20;  // up to 1,048,575 live entities
  static constexpr uint32_t kIndexMask = (1u << kIndexBits) - 1;
  static constexpr uint32_t kGenerationMask = (1u << (32 - kIndexBits)) - 1;
  static constexpr uint32_t kNullId = 0xFFFFFFFFu;

  uint32_t id = kNullId;

  constexpr uint32_t index() const { return id & kIndexMask; }
  constexpr uint32_t generation() const { return id >> kIndexBits; }
  constexpr explicit operator bool() const { return id != kNullId; }
  constexpr bool operator==(const Entity&) const = default;
  static constexpr Entity make(uint32_t index, uint32_t generation) {
    return Entity{(generation << kIndexBits) | (index & kIndexMask)};
  }
};
inline constexpr Entity kNull{};

// -------------------------------------------------------------- type ids

namespace detail {
template <class Family>
struct Counter {
  static uint32_t next() {
    static uint32_t n = 0;
    return n++;
  }
};
struct ComponentFamily;
struct ResourceFamily;
struct EventFamily;
}  // namespace detail

// A small, dense id per component type, shared by every world.
template <class T>
uint32_t componentId() {
  static const uint32_t id = detail::Counter<detail::ComponentFamily>::next();
  return id;
}
template <class T>
uint32_t resourceId() {
  static const uint32_t id = detail::Counter<detail::ResourceFamily>::next();
  return id;
}
template <class T>
uint32_t eventId() {
  static const uint32_t id = detail::Counter<detail::EventFamily>::next();
  return id;
}

// ------------------------------------------------------------- storage

// The type-erased part of a component pool. Type-specific operations are
// function pointers filled in by Pool<T>, not virtuals.
struct PoolBase;
struct PoolDeleter {
  void operator()(PoolBase* p) const;
};

enum class FieldKind : uint8_t { Unsupported, Bool, Signed, Unsigned, Number, Text, Vec3, Entity, Source };
struct SerializedField {std::string name;FieldKind kind=FieldKind::Unsupported;uint32_t bits=0;std::string sourceContract;std::function<bool(const json::Value&)> accept;};

struct PoolBase {
  static constexpr uint32_t kNone = 0xFFFFFFFFu;
  std::vector<Entity> dense;     // owners, parallel to Pool<T>::data
  std::vector<uint32_t> sparse;  // entity index -> dense slot, or kNone
  std::string name;              // registered name ("Transform"), for prefabs, saves and stats
  uint32_t version = 1;          // the registered schema version of its saved fields
  std::vector<SerializedField> serializedFields;
  int iterating = 0;             // > 0 while a view walks this pool

  void (*eraseFn)(PoolBase&, uint32_t slot) = nullptr;
  void* (*emplaceDefaultFn)(PoolBase&, Entity) = nullptr;
  void* (*slotFn)(PoolBase&, uint32_t slot) = nullptr;
  void (*clearFn)(PoolBase&) = nullptr;
  void (*deleteFn)(PoolBase*) = nullptr;
  // Registered serialization (empty when the type has none).
  std::function<void(const void*, json::Value&)> save;
  std::function<void(void*, const json::Value&)> load;

  size_t size() const { return dense.size(); }
  uint32_t slotOf(Entity e) const {
    uint32_t i = e.index();
    if (i >= sparse.size()) return kNone;
    uint32_t s = sparse[i];
    return s != kNone && dense[s] == e ? s : kNone;
  }
  bool contains(Entity e) const { return slotOf(e) != kNone; }
  void* get(Entity e) {
    uint32_t s = slotOf(e);
    return s == kNone ? nullptr : slotFn(*this, s);
  }
  bool erase(Entity e) {
    uint32_t s = slotOf(e);
    if (s == kNone) return false;
    eraseFn(*this, s);
    return true;
  }
};

inline void PoolDeleter::operator()(PoolBase* p) const { p->deleteFn(p); }

template <class T>
struct Pool : PoolBase {
  std::vector<T> data;

  Pool() {
    eraseFn = [](PoolBase& b, uint32_t slot) {
      auto& p = static_cast<Pool&>(b);
      assert(!p.iterating && "remove<T> while iterating T: use World::destroy or removeLater");
      uint32_t last = uint32_t(p.dense.size() - 1);
      p.sparse[p.dense[slot].index()] = kNone;
      if (slot != last) {
        p.dense[slot] = p.dense[last];
        p.data[slot] = std::move(p.data[last]);
        p.sparse[p.dense[slot].index()] = slot;
      }
      p.dense.pop_back();
      p.data.pop_back();
    };
    emplaceDefaultFn = [](PoolBase& b, Entity e) -> void* { return &static_cast<Pool&>(b).emplace(e); };
    slotFn = [](PoolBase& b, uint32_t slot) -> void* { return &static_cast<Pool&>(b).data[slot]; };
    clearFn = [](PoolBase& b) {
      auto& p = static_cast<Pool&>(b);
      p.dense.clear();
      p.data.clear();
      p.sparse.clear();
    };
    deleteFn = [](PoolBase* b) { delete static_cast<Pool*>(b); };
  }

  template <class... A>
  T& emplace(Entity e, A&&... args) {
    uint32_t s = slotOf(e);
    if (s != kNone) return data[s] = T{std::forward<A>(args)...};
    uint32_t i = e.index();
    if (i >= sparse.size()) sparse.resize(size_t(i) + 1 + sparse.size() / 2, kNone);
    sparse[i] = uint32_t(dense.size());
    dense.push_back(e);
    data.push_back(T{std::forward<A>(args)...});
    return data.back();
  }
  T* find(Entity e) {
    uint32_t s = slotOf(e);
    return s == kNone ? nullptr : &data[s];
  }
};

// ---------------------------------------------------------- serialization

namespace detail {
// While World::restore runs, saved entity ids map to the new handles (ids
// not in the save become kNull); otherwise ids load unchanged.
Entity loadEntity(uint32_t savedId);
}  // namespace detail

// One named field of a component for prefabs and saves: numbers, bools,
// enums, and anything with x/y/z (saved as [x, y, z]).
template <class T>
struct Field {
  std::string name;
  std::function<void(const T&, json::Value&)> save;
  std::function<void(T&, const json::Value&)> load;
  FieldKind kind=FieldKind::Unsupported;uint32_t bits=0;std::string sourceContract;
};

template <class T, class M>
Field<T> field(std::string name, M T::*member) {
  Field<T> f;
  f.name = std::move(name);
  if constexpr(std::is_same_v<M,bool>)f.kind=FieldKind::Bool;
  else if constexpr(std::is_enum_v<M>) {f.kind=std::is_signed_v<std::underlying_type_t<M>>?FieldKind::Signed:FieldKind::Unsigned;f.bits=sizeof(M)*8;}
  else if constexpr(std::is_integral_v<M>) {f.kind=std::is_signed_v<M>?FieldKind::Signed:FieldKind::Unsigned;f.bits=sizeof(M)*8;}
  else if constexpr(std::is_floating_point_v<M>){f.kind=FieldKind::Number;f.bits=sizeof(M)*8;}
  else if constexpr(std::is_same_v<M,Entity>){f.kind=FieldKind::Entity;f.bits=32;}
  else if constexpr(std::is_same_v<M,std::string>)f.kind=FieldKind::Text;
  else if constexpr(requires(M v){v.x;v.y;v.z;}){f.kind=FieldKind::Vec3;f.bits=32;}
  f.save = [member](const T& c, json::Value& out) {
    const M& v = c.*member;
    if constexpr (std::is_same_v<M, bool>) out = json::Value::boolean(v);
    else if constexpr (std::is_enum_v<M>) out = json::Value::number(double(static_cast<std::underlying_type_t<M>>(v)));
    else if constexpr (std::is_arithmetic_v<M>) out = json::Value::number(double(v));
    else if constexpr (std::is_same_v<M, Entity>) out = json::Value::number(double(v.id));
    else if constexpr (std::is_same_v<M, std::string>) out = json::Value::string(v);
    else if constexpr (requires { v.x; v.y; v.z; }) {
      out = json::Value::array();
      out.items = {json::Value::number(v.x), json::Value::number(v.y), json::Value::number(v.z)};
    } else static_assert(sizeof(M) == 0, "ecs::field: unsupported member type");
  };
  f.load = [member](T& c, const json::Value& in) {
    M& v = c.*member;
    if constexpr (std::is_same_v<M, bool>) v = in.num() != 0;
    else if constexpr (std::is_enum_v<M>) v = M(static_cast<std::underlying_type_t<M>>(in.num()));
    else if constexpr (std::is_arithmetic_v<M>) v = M(in.num());
    else if constexpr (std::is_same_v<M, Entity>) v = detail::loadEntity(uint32_t(in.num(double(Entity::kNullId))));
    else if constexpr (std::is_same_v<M, std::string>) { if (in.type == json::Value::String) v = in.s; }
    else if constexpr (requires { v.x; v.y; v.z; }) {
      if (in.isArray() && in.items.size() >= 3) {
        v.x = float(in.items[0].num()), v.y = float(in.items[1].num()), v.z = float(in.items[2].num());
      } else if (in.isNumber()) v.x = v.y = v.z = float(in.n);  // a uniform scale
    }
  };
  return f;
}

// --------------------------------------------------------------- phases

enum class Phase : uint8_t { PreUpdate, FixedUpdate, Update, PostUpdate, Render, Count };
constexpr int kPhaseCount = int(Phase::Count);
const char* phaseName(Phase p);

// The deterministic step, the same as player::Player's.
constexpr double kFixedStep = 1.0 / 60.0;

// Built-in resource: the clock as systems see it.
struct Time {
  float dt = 0;            // this frame (or, inside FixedUpdate, kFixedStep)
  float frameDt = 0;       // this frame, clamped by World::maxFrameDt
  double now = 0;          // seconds of frames run
  double fixedNow = 0;     // seconds of fixed steps run
  float alpha = 0;         // how far between fixed steps the frame is, 0..1
  uint64_t frame = 0;      // frames run
  uint64_t fixedSteps = 0; // fixed steps run
};

class World;
using SystemFn = std::function<void(World&, float dt)>;

template <class... X>
struct Exclude {};
template <class... X>
inline constexpr Exclude<X...> exclude{};

// ----------------------------------------------------------------- world

class World {
 public:
  World();
  ~World();
  World(const World&) = delete;
  World& operator=(const World&) = delete;

  // How long a frame may be at most (longer ones run slower than real time),
  // and how many fixed steps one frame may take.
  float maxFrameDt = 0.1f;
  int maxFixedSteps = 8;

  // ----- entities
  Entity create();
  // Destroys at the end of the current fixed step or frame (see flush), so
  // systems may destroy while iterating. Destroying twice is harmless.
  void destroy(Entity e);
  // Destroys immediately; never call while a view is iterating.
  void destroyNow(Entity e);
  bool alive(Entity e) const {
    uint32_t i = e.index();
    return e && i < generations_.size() && generations_[i] == e.generation() && live_[i];
  }
  bool pendingDestroy(Entity e) const;
  // Applies deferred destroys and removals.
  void flush();
  // Destroys every entity and clears every queue (keeps systems, resources,
  // registrations and prefabs).
  void clear();
  size_t entityCount() const { return liveCount_; }

  // ----- components
  template <class T, class... A>
  T& add(Entity e, A&&... args) {
    assert(alive(e));
    return pool<T>().emplace(e, std::forward<A>(args)...);
  }
  template <class T>
  T& set(Entity e, T value) {
    assert(alive(e));
    return pool<T>().emplace(e, std::move(value));
  }
  template <class T>
  bool remove(Entity e) {
    auto* p = findPool<T>();
    return p && p->erase(e);
  }
  // Removes at the next flush, like destroy.
  template <class T>
  void removeLater(Entity e) {
    deferredRemovals_.push_back({componentId<T>(), e});
  }
  template <class T>
  bool has(Entity e) const {
    auto* p = findPool<T>();
    return p && p->contains(e);
  }
  template <class T>
  T* get(Entity e) {
    auto* p = findPool<T>();
    return p ? p->find(e) : nullptr;
  }
  template <class T>
  T& at(Entity e) {
    T* c = get<T>(e);
    assert(c && "entity lacks component");
    return *c;
  }
  template <class T>
  size_t count() const {
    auto* p = findPool<T>();
    return p ? p->size() : 0;
  }
  template <class T>
  Pool<T>& pool() {
    uint32_t id = componentId<T>();
    if (id >= pools_.size()) pools_.resize(id + 1);
    if (!pools_[id]) {
      auto* p = new Pool<T>();
      pools_[id].reset(p);
    }
    return static_cast<Pool<T>&>(*pools_[id]);
  }
  // The first entity with T (in storage order), or kNull.
  template <class T>
  Entity first() {
    auto* p = findPool<T>();
    return p && p->size() ? p->dense[0] : kNull;
  }

  // ----- views
  // Calls f(Entity, A&, B&...) or f(A&, B&...) for every entity that has
  // all of the components. Walks the smallest pool and checks the others.
  // Adding components or creating entities inside f is fine (new ones are
  // not visited this pass); removing a visited type is not: use destroy or
  // removeLater.
  template <class... T, class F>
  void each(F&& f) {
    eachImpl<T...>(Exclude<>{}, std::forward<F>(f));
  }
  template <class... T, class... X, class F>
  void each(Exclude<X...> ex, F&& f) {
    eachImpl<T...>(ex, std::forward<F>(f));
  }
  // The same, in ascending entity index order regardless of how storage was
  // shuffled by removals: stable for networking, saving and replays.
  template <class... T, class F>
  void eachOrdered(F&& f) {
    std::vector<Entity> order;
    each<T...>([&](Entity e, T&...) { order.push_back(e); });
    sortByIndex(order);
    for (Entity e : order) {
      if constexpr (std::is_invocable_v<F&, Entity, T&...>) f(e, *get<T>(e)...);
      else f(*get<T>(e)...);
    }
  }

  // ----- resources: singletons the world owns
  template <class R, class... A>
  R& setResource(A&&... args) {
    uint32_t id = resourceId<R>();
    if (id >= resources_.size()) resources_.resize(id + 1);
    resources_[id] = Holder{new R{std::forward<A>(args)...}, [](void* p) { delete static_cast<R*>(p); }};
    return *static_cast<R*>(resources_[id].p);
  }
  template <class R>
  R* tryResource() {
    uint32_t id = resourceId<R>();
    return id < resources_.size() ? static_cast<R*>(resources_[id].p) : nullptr;
  }
  template <class R>
  R& resource() {
    R* r = tryResource<R>();
    if (!r) r = &setResource<R>();
    return *r;
  }
  Time& time() { return resource<Time>(); }

  // ----- events
  // Queues an event. Handlers run when the queue drains: after the phase
  // (or fixed step) it was sent in, in the order handlers were added.
  template <class E>
  void emit(E event) {
    auto& q = queue<E>();
    q.pending.push_back(event);
    q.frame.push_back(std::move(event));
  }
  template <class E>
  void on(std::function<void(World&, const E&)> handler) {
    queue<E>().handlers.push_back(std::move(handler));
  }
  // Events of type E not yet drained.
  template <class E>
  const std::vector<E>& pending() {
    return queue<E>().pending;
  }
  // Every event of type E sent since the frame began (for HUDs and render).
  template <class E>
  const std::vector<E>& thisFrame() {
    return queue<E>().frame;
  }
  // Runs handlers until every queue is empty (handlers may emit more).
  void drainEvents();

  // ----- systems
  void addSystem(Phase phase, std::string name, SystemFn fn);
  // Runs one phase's systems, then drains events.
  void runPhase(Phase phase, float dt);
  // A whole frame: PreUpdate, as many FixedUpdate steps as dt covers (each
  // followed by a flush), Update, PostUpdate, flush, Render.
  void frame(float dt);
  // The same frame with the steps the engine's clock already counted
  // (aethyr::Tick: dt capped, fixedSteps, alpha), so a world's systems step
  // with the engine rather than on a clock of their own.
  void frame(float dt, int fixedSteps, float alpha);

  // ----- registration, prefabs and saving
  // Names a component type and its fields, so prefabs can spawn it and
  // save/load can carry it. `version` is the schema version of the fields:
  // bump it when they change and add a migration from the old one.
  template <class T>
  void registerComponent(std::string name, std::vector<Field<T>> fields = {}, uint32_t version = 1) {
    auto& p = pool<T>();
    p.name = name;
    p.version = version;
    p.serializedFields.clear();for(auto& f:fields){SerializedField info{f.name,f.kind,f.bits,f.sourceContract,{}};
      if(f.kind==FieldKind::Source){auto write=f.save;auto read=f.load;info.accept=[write,read](const json::Value& input){try{T value{};read(value,input);json::Value out;write(value,out);return json::write(input)==json::write(out);}catch(...){return false;}};}
      p.serializedFields.push_back(std::move(info));}
    auto [save, load] = codec<T>(std::move(fields));
    p.save = std::move(save);
    p.load = std::move(load);
  }
  // A resource saved with snapshots, by name and fields like a component.
  template <class R>
  void registerResource(std::string name, std::vector<Field<R>> fields, uint32_t version = 1) {
    std::vector<SerializedField> metadata;for(auto& f:fields){SerializedField info{f.name,f.kind,f.bits,f.sourceContract,{}};
      if(f.kind==FieldKind::Source){auto write=f.save;auto read=f.load;info.accept=[write,read](const json::Value& input){try{R value{};read(value,input);json::Value out;write(value,out);return json::write(input)==json::write(out);}catch(...){return false;}};}
      metadata.push_back(std::move(info));}
    auto [save, load] = codec<R>(std::move(fields));
    SavedResource r;
    r.name = std::move(name);
    r.version = version;
    r.serializedFields=std::move(metadata);
    r.save = [this, save](json::Value& out) { save(&resource<R>(), out); };
    r.load = [this, load](const json::Value& in) { load(&resource<R>(), in); };
    for (auto& old : savedResources_)
      if (old.name == r.name) {
        old = std::move(r);
        return;
      }
    savedResources_.push_back(std::move(r));
  }
  // Upgrades a component's (or saved resource's) saved fields from version
  // `from` to from + 1. restore() runs them in order.
  void addMigration(std::string name, uint32_t from, std::function<void(json::Value& fields)> fn);
  // The world's own schema version (what entities exist and mean), and
  // whole-snapshot migrations from `from` to from + 1.
  uint32_t schemaVersion = 1;
  void addWorldMigration(uint32_t from, std::function<void(json::Value& snapshot)> fn);
  // Defines prefabs from {"name": {"Component": {fields...}, ...}, ...}, or
  // a document with that object under "prefabs". Returns false on bad JSON.
  bool loadPrefabs(std::string_view jsonText, std::string* error = nullptr);
  void definePrefab(std::string name, json::Value bundle);
  bool hasPrefab(std::string_view name) const;
  // Creates an entity from a prefab, then applies overrides (same shape).
  // Unknown component names are skipped. Returns kNull for an unknown prefab.
  Entity spawn(std::string_view prefab, const json::Value* overrides = nullptr);
  // Adds the components in a bundle to an existing entity.
  void apply(Entity e, const json::Value& bundle);
  // Every live entity with its registered components, in index order:
  // {"entities":[{"Transform":{...},...},...]}.
  json::Value save();
  // One entity's registered components, as a bundle apply() and spawn() read.
  json::Value saveEntity(Entity e);
  std::string saveText() { return json::write(save()); }
  // Clears the world and recreates the saved entities (new handles).
  bool load(const json::Value& doc);
  // A versioned snapshot: the world schema, every registered component's and
  // saved resource's version, the saved resources, and every live entity
  // with its saved id ("#") and registered components, in index order.
  json::Value snapshot();
  // Migrates a snapshot to the current versions and replaces the world with
  // it. Entity fields are remapped to the new handles. Checks everything
  // before touching the world: on false (bad shape, a newer version, a
  // missing migration) the world is unchanged and error says why.
  bool restore(const json::Value& snapshot, std::string* error = nullptr,bool strictFields=false);
  json::Value wireSchemas() const;
  bool wireSchemasCompatible(const json::Value&,uint32_t fromSchema,std::string* error=nullptr) const;

  // ----- debug
  struct SystemStat {
    std::string name;
    Phase phase;
    double ms = 0;     // smoothed
    double lastMs = 0;
  };
  const std::vector<SystemStat>& systemStats() const { return stats_; }
  // {"entities":N,"components":{"Name":n},"systems":[{"name","phase","ms"}]}
  std::string statsJson() const;

 private:
  struct Holder {
    void* p = nullptr;
    void (*del)(void*) = nullptr;
    Holder() = default;
    Holder(void* p_, void (*d)(void*)) : p(p_), del(d) {}
    Holder(Holder&& o) noexcept : p(o.p), del(o.del) { o.p = nullptr; }
    Holder& operator=(Holder&& o) noexcept {
      if (this != &o) {
        if (p) del(p);
        p = o.p, del = o.del, o.p = nullptr;
      }
      return *this;
    }
    ~Holder() {
      if (p) del(p);
    }
  };
  struct QueueBase {
    void (*drainFn)(QueueBase&, World&) = nullptr;
    void (*clearFrameFn)(QueueBase&) = nullptr;
    size_t (*pendingFn)(const QueueBase&) = nullptr;
  };
  template <class E>
  struct Queue : QueueBase {
    std::vector<E> pending, frame, draining;
    std::vector<std::function<void(World&, const E&)>> handlers;
    Queue() {
      drainFn = [](QueueBase& b, World& w) {
        auto& q = static_cast<Queue&>(b);
        q.draining.swap(q.pending);
        for (const E& e : q.draining)
          for (auto& h : q.handlers) h(w, e);
        q.draining.clear();
      };
      clearFrameFn = [](QueueBase& b) {
        auto& q = static_cast<Queue&>(b);
        q.frame.clear();
        q.pending.clear();
      };
      pendingFn = [](const QueueBase& b) { return static_cast<const Queue&>(b).pending.size(); };
    }
  };
  struct System {
    Phase phase;
    SystemFn fn;
    size_t stat;
  };

  template <class T>
  Pool<T>* findPool() const {
    uint32_t id = componentId<T>();
    return id < pools_.size() ? static_cast<Pool<T>*>(pools_[id].get()) : nullptr;
  }
  template <class E>
  Queue<E>& queue() {
    uint32_t id = eventId<E>();
    if (id >= queues_.size()) queues_.resize(id + 1);
    if (!queues_[id].p) queues_[id] = Holder{new Queue<E>(), [](void* p) { delete static_cast<Queue<E>*>(p); }};
    return *static_cast<Queue<E>*>(queues_[id].p);
  }
  static void sortByIndex(std::vector<Entity>& v);

  template <class F, class... T>
  static void invoke(F& f, Entity e, T&... c) {
    if constexpr (std::is_invocable_v<F&, Entity, T&...>) f(e, c...);
    else f(c...);
  }

  template <class... T, class... X, class F>
  void eachImpl(Exclude<X...>, F&& f) {
    static_assert(sizeof...(T) > 0, "each<> needs at least one component");
    std::tuple<Pool<T>*...> ps{findPool<T>()...};
    bool missing = false;
    std::apply([&](auto*... p) { missing = ((p == nullptr) || ...); }, ps);
    if (missing) return;
    std::tuple<Pool<X>*...> xs{findPool<X>()...};
    auto excluded = [&](Entity e) {
      bool out = false;
      std::apply([&](auto*... x) { out = ((x && x->contains(e)) || ...); }, xs);
      return out;
    };
    if constexpr (sizeof...(T) == 1) {
      // Single-component fast path: walk the dense arrays directly.
      auto* p = std::get<0>(ps);
      p->iterating++;
      size_t n = p->dense.size();
      for (size_t i = 0; i < n && i < p->dense.size(); i++) {
        Entity e = p->dense[i];
        if constexpr (sizeof...(X) > 0)
          if (excluded(e)) continue;
        invoke(f, e, p->data[i]);
      }
      p->iterating--;
    } else {
      PoolBase* lead = nullptr;
      std::apply([&](auto*... p) { ((lead = (!lead || p->size() < lead->size()) ? p : lead), ...); }, ps);
      std::apply([](auto*... p) { ((p->iterating++), ...); }, ps);
      size_t n = lead->dense.size();
      for (size_t i = 0; i < n && i < lead->dense.size(); i++) {
        Entity e = lead->dense[i];
        bool all = true;
        std::apply([&](auto*... p) { all = (p->contains(e) && ...); }, ps);
        if (!all) continue;
        if constexpr (sizeof...(X) > 0)
          if (excluded(e)) continue;
        std::apply([&](auto*... p) { invoke(f, e, p->data[p->sparse[e.index()]]...); }, ps);
      }
      std::apply([](auto*... p) { ((p->iterating--), ...); }, ps);
    }
  }

  std::vector<uint32_t> generations_;
  std::vector<uint8_t> live_;
  std::vector<uint32_t> freeList_;
  size_t liveCount_ = 0;
  std::vector<Entity> deferredDestroys_;
  struct Removal {
    uint32_t component;
    Entity e;
  };
  std::vector<Removal> deferredRemovals_;
  std::vector<std::unique_ptr<PoolBase, PoolDeleter>> pools_;
  std::vector<Holder> resources_;
  std::vector<Holder> queues_;
  std::vector<System> systems_;
  std::vector<SystemStat> stats_;
  std::vector<std::pair<std::string, json::Value>> prefabs_;
  struct SavedResource {
    std::vector<SerializedField> serializedFields;
    std::string name;
    uint32_t version = 1;
    std::function<void(json::Value&)> save;
    std::function<void(const json::Value&)> load;
  };
  std::vector<SavedResource> savedResources_;
  struct Migration {
    std::string name;  // empty: the whole snapshot
    uint32_t from;
    std::function<void(json::Value&)> fn;
  };
  std::vector<Migration> migrations_;
  const Migration* findMigration(std::string_view name, uint32_t from) const;
  template <class T>
  static std::pair<std::function<void(const void*, json::Value&)>, std::function<void(void*, const json::Value&)>>
  codec(std::vector<Field<T>> fields) {
    if (fields.empty())
      return {[](const void*, json::Value& out) { out = json::Value::object(); }, [](void*, const json::Value&) {}};
    auto shared = std::make_shared<std::vector<Field<T>>>(std::move(fields));
    return {[shared](const void* c, json::Value& out) {
              out = json::Value::object();
              for (auto& f : *shared) {
                json::Value v;
                f.save(*static_cast<const T*>(c), v);
                out.set(f.name, std::move(v));
              }
            },
            [shared](void* c, const json::Value& in) {
              for (auto& f : *shared)
                if (auto* v = in.find(f.name)) f.load(*static_cast<T*>(c), *v);
            }};
  }
  double fixedAccumulator_ = 0;
};

// The world shown by the debug overlay (web/aethyr.js); a scene sets it.
void setDebugWorld(World* w);
World* debugWorld();

}  // namespace ecs
