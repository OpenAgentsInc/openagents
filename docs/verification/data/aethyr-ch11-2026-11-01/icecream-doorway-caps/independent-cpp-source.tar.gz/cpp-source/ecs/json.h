// A small JSON value, parser and writer for prefabs and component
// serialization. Objects keep their key order so saved worlds diff cleanly.
#pragma once

#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace ecs::json {

struct Value {
  enum Type { Null, Bool, Number, String, Array, Object };
  Type type = Null;
  bool b = false;
  double n = 0;
  std::string s;
  std::vector<Value> items;                           // Array
  std::vector<std::pair<std::string, Value>> fields;  // Object, in order

  Value() = default;
  static Value number(double v) { Value r; r.type = Number; r.n = v; return r; }
  static Value boolean(bool v) { Value r; r.type = Bool; r.b = v; return r; }
  static Value string(std::string v) { Value r; r.type = String; r.s = std::move(v); return r; }
  static Value array() { Value r; r.type = Array; return r; }
  static Value object() { Value r; r.type = Object; return r; }

  bool isObject() const { return type == Object; }
  bool isArray() const { return type == Array; }
  bool isNumber() const { return type == Number; }
  // The member named key, or nullptr.
  const Value* find(std::string_view key) const;
  // Sets (or adds) a member of an object.
  Value& set(std::string key, Value v);
  double num(double fallback = 0) const { return type == Number ? n : type == Bool ? (b ? 1 : 0) : fallback; }
};

// Parses text; on failure returns false and says where in error.
bool parse(std::string_view text, Value& out, std::string* error = nullptr);
std::string write(const Value& v);

}  // namespace ecs::json
