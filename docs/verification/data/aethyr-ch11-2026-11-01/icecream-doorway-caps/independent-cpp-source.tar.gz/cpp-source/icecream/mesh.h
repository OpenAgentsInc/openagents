// Ice Cream Man's low-poly models, made in code (issue #13): a C++ port of
// OpenAgents' `toon-mesh` crate and the web build's scene.rs
// (third_party/icecream/crates). Each room of the house (pastel walls,
// waffle-cone trim, melting drips, sprinkle carpet, furniture), its ceiling
// lights, the tools, the Ice Cream Man and the little things (keys, fudge,
// sprinkles, clouds, the puzzle).
//
// A mesh is a plain triangle list. Each vertex carries its position, its
// face's normal, an outward "hull" direction shared by every face at that
// corner (the toon outline pushes along it, so corners have no gaps), a
// colour (0xRRGGBB, sRGB as the original) and an outline weight (0 for things
// that never get a line, such as markings on the floor). Nothing here draws:
// src/icecream/world.cpp uploads these in the engine's vertex layout.
//
// Models face +z in their own space; the floor is y = 0.
#pragma once

#include <cstdint>
#include <vector>

#include "../vec3.h"
#include "rules.h"

namespace icecream::toon {

// An affine transform: p' = m * p + t (m row-major).
struct Xf {
  float m[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  Vec3 t{0, 0, 0};
  Vec3 apply(Vec3 p) const;
  Vec3 linear(Vec3 d) const;
};
Xf operator*(const Xf& a, const Xf& b);
Xf translate(Vec3 t);
Xf scale(Vec3 s);
inline Xf scale(float s) { return scale({s, s, s}); }
Xf rotX(float a);
Xf rotY(float a);
Xf rotZ(float a);
Xf arc(Vec3 from, Vec3 to);  // the rotation taking unit `from` to unit `to`
// glam's from_scale_rotation_translation: translate * rotate * scale.
inline Xf srt(Vec3 s, const Xf& r, Vec3 t) { return translate(t) * r * scale(s); }
inline Xf srt(float s, const Xf& r, Vec3 t) { return srt(Vec3{s, s, s}, r, t); }

// A shape in its own unit space, centred on the origin.
struct Shape {
  enum Kind { Cube, Frustum, Sphere, Torus, Disc, Square } kind = Cube;
  uint32_t a = 0, b = 0;  // frustum and disc sides; sphere rings, segments; torus segments, sides
  float p = 0, q = 0;     // frustum bottom, top radius; torus radius, tube
  static Shape cube() { return {}; }
  static Shape frustum(uint32_t sides, float bottom, float top) { return {Frustum, sides, 0, bottom, top}; }
  static Shape sphere(uint32_t rings, uint32_t segments) { return {Sphere, rings, segments, 0, 0}; }
  static Shape torus(uint32_t segments, uint32_t sides, float radius, float tube) {
    return {Torus, segments, sides, radius, tube};
  }
  static Shape disc(uint32_t sides) { return {Disc, sides, 0, 0, 0}; }
  static Shape square() { return {Square, 0, 0, 0, 0}; }
};

struct Vtx {
  Vec3 p, n, hull;
  uint32_t colour;
  float weight;
};

struct Mesh {
  std::vector<Vtx> v;
  // Adds `shape` placed by `xf`, in `colour`, with an outline weight (1 the
  // normal line, 0 none).
  void add(Shape shape, const Xf& xf, uint32_t colour, float weight);
  // A box from lo to hi.
  void block(Vec3 lo, Vec3 hi, uint32_t colour, float weight);
  size_t vertices() const { return v.size(); }
};

// ---- the palette (scene.rs) ----
constexpr uint32_t kWaffle = 0xD9A05B, kWaffleDark = 0xB57B3A, kFudge = 0x5A2E12, kVanilla = 0xFFF3D9,
                   kForehead = 0xFFE4D0, kCeiling = 0xF6EFE4, kGold = 0xF7C52B, kWhite = 0xF7F7F4,
                   kInk = 0x2B1D16, kCloud = 0xBFD86A, kSkin = 0xF2C9A0, kShirt = 0x4F9DDE, kPants = 0x334E7A;
constexpr uint32_t kSprinkles[5] = {0xFF6FA8, 0x5EC8F2, 0xFFE15C, 0x7EDB7A, 0xFFFFFF};
constexpr uint32_t kBackWall = 0xD6C77C, kBackStripe = 0xC9B866, kBackCarpet = 0x9A8A4E, kBackDamp = 0x7A6C3A,
                   kBackTrim = 0xB8A35A, kBackCeiling = 0xE4DCB8, kCandyRed = 0xE8384F;
constexpr uint32_t kButtonColours[3] = {0xFF6FA8, 0x5EC8F2, 0xFFE15C};  // pink, blue, yellow

uint32_t mix(uint32_t a, uint32_t b, float t);
uint32_t wall(Flavor f);
uint32_t carpet(Flavor f);
bool cold(Module m);  // lit freezer blue rather than warm

// One room: floor, ceiling, its side of each wall with doorways, trim,
// drips, the carpet's sprinkles and its furniture; the front door in its
// room. `yellow` (0 to 1) turns it into the Backrooms.
Mesh room(const House& house, size_t index, float yellow);
// A room's ceiling light panels, drawn in their own light.
Mesh lights(const House& house, size_t index, float yellow);

// ---- the kid (the player) ----
// The blocky Roblox-style avatar's height (to the top of its hair) and the
// scale that draws it the kid's kPlayerHeight; its eye line before scaling.
constexpr float kAvatarModelHeight = 2.12f;
constexpr float kAvatarScale = kPlayerHeight / kAvatarModelHeight;
constexpr float kAvatarModelEyes = 1.89f;
struct Avatar {
  Mesh torso, head, arm, leg;
};
// Facing +z; the arm and leg hang from their joint at the origin.
Avatar avatar();

// ---- the Ice Cream Man ----
constexpr float kManModelHeight = 3.345f;
constexpr float kManScale = kManHeight / kManModelHeight;
constexpr float kManModelHip = 0.85f;
constexpr float kManDuck = 0.72f;  // radians he bends at a doorway
constexpr float kMinionScale = 0.8f / kManModelHeight;
float manTop(float duck);                 // his top, metres, bent `duck` (0-1)
float duck(const House& house, V2 at);    // how much he ducks at `at`

struct ManModel {
  Mesh body, leg, arm, head, forehead;
};
ManModel man();
Mesh tool(Tool t);  // in the hand, pointing along +z from the grip
Mesh key();
Mesh ball(uint32_t colour);      // radius 0.5
Mesh sprinkle(uint32_t colour);  // long along +z
Mesh splat(uint32_t colour);     // flat on the floor, radius 0.5
Mesh treat();                    // an edible cone on the floor
Mesh coneShot();                 // a cone in flight, point first along +z
Mesh button(uint32_t colour);
Mesh cabinet();
Mesh bigCone();                  // the cone you end up in, scooped

}  // namespace icecream::toon
