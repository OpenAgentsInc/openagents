// Ice Cream Man's rules: a step-for-step C++ port of the icecream-rules crate
// (see rules.h). Each function names the Rust it mirrors. Float operations
// follow Rust's exactly: f32::max/min are fmaxf/fminf (IEEE maxNum/minNum),
// clamp is Rust's two comparisons, and this file builds with
// -ffp-contract=off so no multiply-add is fused.
#include "rules.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <limits>

#include "../ecs/ecs.h"

namespace icecream {

namespace {

constexpr float kPi = 3.14159265358979323846f;
constexpr float kTau = 6.28318530717958647692f;
// f32::to_radians: the value times PI / 180, both in f32.
constexpr float kRadsPerDeg = kPi / 180.0f;
constexpr size_t kNone = std::numeric_limits<size_t>::max();

// Rust's f32::max / f32::min (maxNum / minNum) and f32::clamp.
inline float fmax(float a, float b) { return std::fmax(a, b); }
inline float fmin(float a, float b) { return std::fmin(a, b); }
inline float clampf(float x, float lo, float hi) {
  if (x < lo) x = lo;
  if (x > hi) x = hi;
  return x;
}

}  // namespace

// ---------------------------------------------------------------- geom.rs

float dot(V2 a, V2 b) { return a.x * b.x + a.z * b.z; }
float length(V2 a) { return std::sqrt(dot(a, a)); }
float distance(V2 a, V2 b) { return length(a - b); }
V2 normalized(V2 a) {
  float l = length(a);
  if (l < 1e-6f) return {0, 0};
  return a * (1.0f / l);
}
V2 clamped(V2 a, float max) {
  float l = length(a);
  return l > max ? a * (max / l) : a;
}
V2 rotated(V2 a, float c, float s) { return v(a.x * c - a.z * s, a.x * s + a.z * c); }

bool Block::contains(V2 p) const { return p.x >= min.x && p.x <= max.x && p.z >= min.z && p.z <= max.z; }
Block Block::grown(float r) const { return {min - v(r, r), max + v(r, r), height}; }
V2 Block::closest(V2 p) const { return v(clampf(p.x, min.x, max.x), clampf(p.z, min.z, max.z)); }
float Block::segment(V2 a, V2 b) const {
  V2 d = b - a;
  float low = 0.0f, high = 1.0f;
  const float starts[2] = {a.x, a.z}, deltas[2] = {d.x, d.z}, mins[2] = {min.x, min.z}, maxs[2] = {max.x, max.z};
  for (int k = 0; k < 2; ++k) {
    float start = starts[k], delta = deltas[k];
    if (std::fabs(delta) < 1e-9f) {
      if (start < mins[k] || start > maxs[k]) return -1;
    } else {
      float t0 = (mins[k] - start) / delta, t1 = (maxs[k] - start) / delta;
      if (t0 > t1) std::swap(t0, t1);
      low = fmax(low, t0);
      high = fmin(high, t1);
      if (low > high) return -1;
    }
  }
  return low;
}

V2 slide(const std::vector<Block>& blocks, V2 from, V2 delta, float radius, float feet) {
  V2 p = from + delta;
  for (int pass = 0; pass < 3; ++pass) {
    for (const Block& block : blocks) {
      if (!(block.height > feet)) continue;
      V2 c = block.closest(p);
      V2 d = p - c;
      float gap = dot(d, d);
      if (gap >= radius * radius) continue;
      if (gap > 1e-10f) {
        p = c + normalized(d) * radius;
      } else {
        // The centre is inside: leave by the nearest side.
        std::pair<float, V2> pushes[4] = {
            {p.x - block.min.x + radius, v(-1, 0)},
            {block.max.x - p.x + radius, v(1, 0)},
            {p.z - block.min.z + radius, v(0, -1)},
            {block.max.z - p.z + radius, v(0, 1)},
        };
        auto best = pushes[0];
        for (auto& push : pushes)
          if (push.first < best.first) best = push;
        p = p + best.second * best.first;
      }
    }
  }
  return p;
}

float firstHit(const std::vector<Block>& blocks, V2 a, V2 b, float radius, float minHeight) {
  bool any = false;
  float best = 0;
  for (const Block& block : blocks) {
    if (!(block.height >= minHeight)) continue;
    float t = block.grown(radius).segment(a, b);
    if (t < 0) continue;
    best = any ? fmin(best, t) : t;
    any = true;
  }
  return any ? best : -1;
}

float segmentDistance(V2 a, V2 b, V2 p) {
  V2 d = b - a;
  float len = dot(d, d);
  float t = len < 1e-12f ? 0.0f : clampf(dot(p - a, d) / len, 0.0f, 1.0f);
  return distance(a + d * t, p);
}

// ---------------------------------------------------------------- rng.rs

uint64_t Rng::nextU64() {
  state += 0x9E3779B97F4A7C15ull;
  uint64_t z = state;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
size_t Rng::below(size_t n) {
  if (n == 0) return 0;
  return (size_t)(nextU64() % (uint64_t)n);
}
float Rng::unit() { return (float)(nextU64() >> 40) / (float)(1ull << 24); }

// ---------------------------------------------------------------- tuning.rs

namespace {
struct Field {
  const char* name;
  double def, lo, hi;
  bool whole;
};
template <class T>
constexpr bool isWhole() { return std::is_same_v<T, uint32_t>; }
const Field kFields[] = {
#define ICECREAM_DESC(name, type, def, lo, hi) {#name, (double)(type)(def), (double)(lo), (double)(hi), isWhole<type>()},
    ICECREAM_TUNABLES(ICECREAM_DESC)
#undef ICECREAM_DESC
};
const Field* fieldOf(const std::string& name) {
  for (const Field& f : kFields)
    if (name == f.name) return &f;
  return nullptr;
}

using Changes = std::vector<std::pair<const char*, double>>;
const Changes kOriginal = {{"man_wander", 2.4}, {"man_investigate", 3.6}, {"man_search", 3.2}, {"man_chase", 5.6},
                           {"extra_closets", 0}, {"earned_weapons", 0}, {"minion_count", 0}, {"free_roam", 0},
                           {"backrooms", 0}, {"loops", 4}, {"yellow", 0}, {"fog_near", 9}, {"fog_far", 34},
                           {"flicker", 0.03}, {"buzz", 0}, {"sprint_noise", 8}, {"unlock", 2}, {"unlock_guard", 0},
                           {"puzzle_key", 0}, {"house_size", 4}, {"key_spread", 0}, {"patrol_keys", 0},
                           {"corners", 0}, {"minion_growth", 0}};
const Changes kV4 = {{"man_wander", 1.92}, {"man_investigate", 2.88}, {"man_search", 2.56}, {"man_chase", 4.48},
                     {"loops", 10}, {"sprint_noise", 8}, {"unlock", 2}, {"unlock_guard", 0}, {"puzzle_key", 0},
                     {"house_size", 4}, {"key_spread", 0}, {"patrol_keys", 0}, {"corners", 0}, {"minion_growth", 0}};
const Changes kHard = {{"house_size", 8}, {"man_wander", 2.7}, {"man_investigate", 4.0}, {"man_search", 3.6},
                       {"man_chase", 6.2}, {"sight", 26}, {"search_time", 10}, {"sniff_every", 18},
                       {"patrol_keys", 1}, {"sprint_noise", 18}, {"unlock", 7}, {"unlock_guard", 11},
                       {"minion_count", 4}, {"minion_growth", 40}, {"minion_speed", 3.8}, {"extra_closets", 1}};
Tuning withChanges(const Changes& changes) {
  Tuning t;
  for (auto& [name, value] : changes) t.set(name, value);
  return t;
}
}  // namespace

bool Tuning::set(const std::string& name, double value, std::string* why) {
  const Field* f = fieldOf(name);
  if (!f) {
    if (why) *why = "the game has no setting called " + name;
    return false;
  }
  if (!std::isfinite(value) || value < f->lo || value > f->hi) {
    if (why) *why = name + " is out of bounds";
    return false;
  }
  if (f->whole && value != std::floor(value)) {
    if (why) *why = name + " must be a whole number";
    return false;
  }
#define ICECREAM_SET(n, type, def, lo, hi) \
  if (name == #n) n = (type)value;
  ICECREAM_TUNABLES(ICECREAM_SET)
#undef ICECREAM_SET
  return true;
}

std::optional<double> Tuning::get(const std::string& name) const {
#define ICECREAM_GET(n, type, def, lo, hi) \
  if (name == #n) return (double)n;
  ICECREAM_TUNABLES(ICECREAM_GET)
#undef ICECREAM_GET
  return std::nullopt;
}

bool Tuning::operator==(const Tuning& o) const {
#define ICECREAM_EQ(n, type, def, lo, hi) \
  if (!(n == o.n)) return false;
  ICECREAM_TUNABLES(ICECREAM_EQ)
#undef ICECREAM_EQ
  return true;
}

float Tuning::sightCos() const { return std::cos(sight_angle * kRadsPerDeg); }
Tuning Tuning::original() { return withChanges(kOriginal); }

Tuning tuningFor(Difficulty d) {
  switch (d) {
    case Difficulty::Easy: return withChanges(kV4);
    case Difficulty::Hard: return withChanges(kHard);
    default: return Tuning{};
  }
}
const char* difficultyId(Difficulty d) {
  return d == Difficulty::Easy ? "easy" : d == Difficulty::Hard ? "hard" : "normal";
}
std::optional<Difficulty> difficultyFromId(const std::string& id) {
  for (Difficulty d : {Difficulty::Easy, Difficulty::Normal, Difficulty::Hard})
    if (id == difficultyId(d)) return d;
  return std::nullopt;
}

// ---------------------------------------------------------------- layout.rs

const char* moduleName(Module m) {
  switch (m) {
    case Module::Bedroom: return "Bedroom";
    case Module::Kitchen: return "Kitchen";
    case Module::LivingRoom: return "Living room";
    case Module::Bathroom: return "Bathroom";
    case Module::Laundry: return "Laundry";
    case Module::Hallway: return "Hallway";
    case Module::Stairwell: return "Stairwell";
    case Module::FreezerRoom: return "The freezer room";
    case Module::Backroom: return "The Backrooms";
  }
  return "";
}

namespace {
using K = PropKind;
constexpr float IN = 4.85f;
Prop prop(K kind, float x0, float z0, float x1, float z1, float h) { return {kind, v(x0, z0), v(x1, z1), h, false, {}}; }
Prop usable(K kind, float x0, float z0, float x1, float z1, float h, V2 at) {
  return {kind, v(x0, z0), v(x1, z1), h, true, at};
}
ModuleDef def(std::vector<Prop> props, std::vector<V2> slots) { return {std::move(props), std::move(slots), false, {}}; }
ModuleDef def(std::vector<Prop> props, std::vector<V2> slots, Prop spare) {
  return {std::move(props), std::move(slots), true, spare};
}
const ModuleDef kBedroom = def({prop(K::Bed, 2.0f, -IN, IN, -2.0f, 0.6f), usable(K::Closet, -IN, -IN, -3.4f, -2.4f, 2.4f, v(-2.6f, -3.6f)),
                                prop(K::Dresser, -IN, 2.6f, -2.4f, IN, 1.0f), prop(K::Plant, 3.6f, 3.6f, 4.4f, 4.4f, 1.2f)},
                               {v(3.6f, 0.0f), v(0.0f, 3.6f), v(-3.4f, 0.0f), v(3.0f, -1.6f)},
                               usable(K::Closet, 2.0f, 3.6f, 3.4f, IN, 2.4f, v(2.7f, 2.9f)));
const ModuleDef kKitchen = def({prop(K::Counter, 1.8f, -IN, IN, -4.0f, 1.0f), usable(K::Fridge, -IN, -IN, -3.6f, -3.6f, 2.0f, v(-2.9f, -2.9f)),
                                prop(K::Table, 2.2f, 2.2f, 4.0f, 4.0f, 0.8f), prop(K::Counter, -IN, 2.0f, -4.0f, IN, 1.0f)},
                               {v(0.0f, -3.8f), v(3.2f, -2.8f), v(-3.6f, 0.0f), v(0.0f, 3.6f)},
                               usable(K::Closet, -3.9f, 3.6f, -2.4f, IN, 2.4f, v(-3.1f, 2.9f)));
const ModuleDef kLivingRoom = def({prop(K::Sofa, 2.0f, -4.5f, 4.6f, -3.3f, 0.8f), prop(K::Table, 2.6f, -2.6f, 3.8f, -1.9f, 0.5f),
                                   usable(K::Closet, -IN, -IN, -3.4f, -2.6f, 2.4f, v(-2.7f, -3.7f)), prop(K::Tv, 3.8f, 2.0f, IN, 4.5f, 1.4f),
                                   prop(K::Plant, -4.4f, 3.6f, -3.6f, 4.4f, 1.2f)},
                                  {v(0.0f, -3.6f), v(2.6f, 3.0f), v(-3.6f, 0.0f), v(3.6f, 0.0f)});
const ModuleDef kBathroom = def({prop(K::Tub, 2.0f, -IN, IN, -3.2f, 0.7f), prop(K::Toilet, 3.8f, 3.4f, 4.6f, 4.6f, 0.8f),
                                 prop(K::Sink, -IN, 3.0f, -4.0f, 4.4f, 1.0f), usable(K::Closet, -IN, -4.6f, -3.6f, -2.4f, 2.2f, v(-2.9f, -3.5f))},
                                {v(3.2f, -2.4f), v(0.0f, 3.6f), v(-3.6f, 0.0f), v(2.4f, 2.6f)},
                                usable(K::Closet, 1.8f, 3.6f, 3.4f, IN, 2.2f, v(2.6f, 2.9f)));
const ModuleDef kLaundry = def({prop(K::Washer, 3.7f, -IN, IN, -3.7f, 1.0f), prop(K::Washer, 2.4f, -IN, 3.6f, -3.7f, 1.0f),
                                usable(K::Fridge, 3.6f, 3.6f, IN, IN, 2.0f, v(2.9f, 2.9f)), usable(K::Closet, -IN, 2.4f, -3.4f, IN, 2.4f, v(-2.7f, 3.6f)),
                                prop(K::Shelf, -IN, -IN, -2.0f, -4.2f, 1.8f)},
                               {v(3.0f, -2.6f), v(0.0f, -3.6f), v(3.6f, 0.0f), v(-3.0f, -2.8f)});
const ModuleDef kHallway = def({prop(K::Pillar, -IN, -IN, -1.7f, -1.7f, kWallHeight), prop(K::Pillar, 1.7f, -IN, IN, -1.7f, kWallHeight),
                                prop(K::Pillar, -IN, 1.7f, -1.7f, IN, kWallHeight), prop(K::Pillar, 1.7f, 1.7f, IN, IN, kWallHeight)},
                               {v(0.0f, -3.8f), v(3.8f, 0.0f), v(0.0f, 3.8f), v(-3.8f, 0.0f)});
const ModuleDef kStairwell = def({prop(K::Stairs, 1.8f, -IN, IN, -1.8f, kWallHeight), usable(K::Closet, -IN, 2.0f, -3.0f, IN, 2.4f, v(-2.3f, 3.4f)),
                                  prop(K::Plant, 3.6f, 3.6f, 4.4f, 4.4f, 1.2f)},
                                 {v(-3.0f, -3.0f), v(0.0f, 3.6f), v(3.6f, 0.0f), v(2.4f, 2.6f)});
const ModuleDef kFreezerRoom = def({prop(K::Freezer, 2.0f, -4.6f, 4.6f, -3.0f, 1.0f), prop(K::Freezer, -4.6f, 3.0f, -2.0f, 4.6f, 1.0f),
                                    usable(K::Fridge, -IN, -IN, -3.6f, -3.6f, 2.4f, v(-2.9f, -2.9f)), usable(K::Fridge, 3.6f, 3.6f, IN, IN, 2.4f, v(2.9f, 2.9f))},
                                   {v(3.0f, -2.2f), v(-3.0f, 2.2f), v(0.0f, -3.8f), v(3.8f, 0.0f)});
const ModuleDef kBackroom = def({prop(K::Partition, -3.6f, -3.6f, -1.9f, -3.3f, kWallHeight), prop(K::Partition, -3.6f, -3.3f, -3.3f, -1.9f, kWallHeight),
                                 prop(K::Partition, 1.9f, 3.3f, 3.6f, 3.6f, kWallHeight), prop(K::Partition, 3.3f, 1.9f, 3.6f, 3.3f, kWallHeight),
                                 prop(K::Partition, 2.4f, -IN, 2.7f, -2.6f, kWallHeight), prop(K::Partition, -IN, 2.4f, -2.6f, 2.7f, kWallHeight)},
                                {v(0.0f, -3.8f), v(3.8f, 0.0f), v(0.0f, 3.8f), v(-3.8f, 0.0f)});

const Module kAll[8] = {Module::Bedroom, Module::Kitchen, Module::LivingRoom, Module::Bathroom,
                        Module::Laundry, Module::Hallway, Module::Stairwell, Module::FreezerRoom};
const Flavor kFlavors[4] = {Flavor::Strawberry, Flavor::Mint, Flavor::Vanilla, Flavor::Chocolate};
const Side kSides[4] = {Side::North, Side::East, Side::South, Side::West};

std::pair<int, int> step(Side s) {
  switch (s) {
    case Side::North: return {0, -1};
    case Side::East: return {1, 0};
    case Side::South: return {0, 1};
    default: return {-1, 0};
  }
}
size_t sideIndex(Side s) { return (size_t)s; }
Side opposite(Side s) {
  switch (s) {
    case Side::North: return Side::South;
    case Side::East: return Side::West;
    case Side::South: return Side::North;
    default: return Side::East;
  }
}
std::optional<Cell> neighbourIn(Cell cell, Side side, size_t cols, size_t rows) {
  auto [dx, dz] = step(side);
  if (dx < 0 && cell.first == 0) return std::nullopt;
  if (dz < 0 && cell.second == 0) return std::nullopt;
  size_t col = cell.first + dx, row = cell.second + dz;
  if (col < cols && row < rows) return Cell{col, row};
  return std::nullopt;
}
// Iterator::max_by_key: the last of the largest.
template <class Items, class Key>
std::optional<size_t> lastMaxBy(const Items& items, Key key) {
  std::optional<size_t> best;
  size_t bestKey = 0;
  for (size_t i = 0; i < items.size(); ++i) {
    size_t k = key(items[i]);
    if (!best || k >= bestKey) best = i, bestKey = k;
  }
  return best;
}
}  // namespace

const ModuleDef& moduleDef(Module m) {
  switch (m) {
    case Module::Bedroom: return kBedroom;
    case Module::Kitchen: return kKitchen;
    case Module::LivingRoom: return kLivingRoom;
    case Module::Bathroom: return kBathroom;
    case Module::Laundry: return kLaundry;
    case Module::Hallway: return kHallway;
    case Module::Stairwell: return kStairwell;
    case Module::FreezerRoom: return kFreezerRoom;
    default: return kBackroom;
  }
}

V2 outward(Side s) {
  auto [x, z] = step(s);
  return v((float)x, (float)z);
}

Shape Shape::of(const Tuning& t) {
  return {std::clamp((size_t)t.house_size, (size_t)3, kMaxSize), (size_t)t.loops, t.backrooms == 1, t.key_spread == 1,
          t.puzzle_key == 1};
}

V2 centre(Cell cell) {
  return v((float)cell.first * kCell + kCell / 2.0f, (float)cell.second * kCell + kCell / 2.0f);
}
Cell cellOfAny(V2 p) {
  size_t col = (size_t)clampf(std::floor(p.x / kCell), 0.0f, (float)(kMaxSize - 1));
  size_t row = (size_t)clampf(std::floor(p.z / kCell), 0.0f, (float)(kMaxSize - 1));
  return {col, row};
}

Cell House::cellOf(V2 p) const {
  size_t col = (size_t)clampf(std::floor(p.x / kCell), 0.0f, (float)(cols - 1));
  size_t row = (size_t)clampf(std::floor(p.z / kCell), 0.0f, (float)(rows - 1));
  return {col, row};
}
std::optional<Cell> House::neighbour(Cell c, Side s) const { return neighbourIn(c, s, cols, rows); }

House House::of(uint64_t seed, const Tuning& t) { return withClosets(generate(seed, Shape::of(t)), (size_t)t.extra_closets); }
House House::tuned(uint64_t seed, size_t extra) { return withClosets(airbnb(seed), extra); }
House House::airbnb(uint64_t seed) { return build(seed, 4, false); }
House House::build(uint64_t seed, size_t loops, bool backrooms) {
  return generate(seed, Shape{4, loops, backrooms, false, false});
}

House House::withClosets(House house, size_t extra) {
  uint64_t seed = house.seed;
  if (extra == 0) return house;
  std::vector<size_t> rooms;
  for (size_t i = 0; i < house.rooms.size(); ++i)
    if (moduleDef(house.rooms[i].module).hasSpare) rooms.push_back(i);
  Rng rng(seed ^ 0x5eedc105e7c105e7ull);
  rng.shuffle(rooms);
  for (size_t k = 0; k < rooms.size() && k < extra; ++k) {
    size_t room = rooms[k];
    const ModuleDef& d = moduleDef(house.rooms[room].module);
    if (!d.hasSpare) continue;
    const Prop& p = d.spare;
    V2 c = centre(house.rooms[room].cell);
    Block block{c + p.min, c + p.max, p.height};
    house.blocks.push_back(block);
    if (p.usable) house.closets.push_back({c + p.useAt, block, room});
    house.extras.push_back({room, p});
  }
  return house;
}

std::vector<Prop> House::props(size_t room) const {
  std::vector<Prop> out = moduleDef(rooms[room].module).props;
  for (auto& [r, p] : extras)
    if (r == room) out.push_back(p);
  return out;
}

House House::generate(uint64_t seed, Shape shape) {
  size_t cols = shape.size, rows = shape.size;
  Rng rng(seed);
  size_t count = cols * rows;
  Cell corners[4] = {{0, 0}, {cols - 1, 0}, {0, rows - 1}, {cols - 1, rows - 1}};
  Cell spawnCell = corners[rng.below(4)];
  size_t spawnRoom = spawnCell.second * cols + spawnCell.first;

  std::vector<Module> kinds;
  if (shape.backrooms) {
    const Module own[6] = {Module::Bedroom, Module::Kitchen, Module::Bathroom, Module::FreezerRoom, Module::LivingRoom, Module::Laundry};
    for (size_t i = 0; i < std::max(count / 16, (size_t)1); ++i) kinds.insert(kinds.end(), own, own + 6);
    kinds.resize(count - 1, Module::Backroom);
  } else {
    kinds.assign(kAll, kAll + 8);
    while (kinds.size() < count - 1) {
      size_t pick = rng.below(8 + 3);
      kinds.push_back(pick < 8 ? kAll[pick] : Module::Hallway);
    }
  }
  rng.shuffle(kinds);
  size_t next = 0;
  House house;
  house.seed = seed;
  house.cols = cols;
  house.rows = rows;
  for (size_t i = 0; i < count; ++i) {
    Room room;
    room.cell = {i % cols, i / cols};
    room.module = i == spawnRoom ? Module::Bedroom : next < kinds.size() ? kinds[next++] : Module::Hallway;
    room.flavor = kFlavors[0];
    house.rooms.push_back(room);
  }
  for (Room& room : house.rooms) room.flavor = kFlavors[rng.below(4)];

  auto index = [&](Cell c) { return c.second * cols + c.first; };
  auto& rooms = house.rooms;

  // Doorways: a random tree from the bedroom, then a few loops.
  std::vector<bool> seen(count, false);
  std::vector<Cell> stack = {spawnCell};
  seen[spawnRoom] = true;
  while (!stack.empty()) {
    Cell cell = stack.back();
    std::vector<std::pair<Side, Cell>> open;
    for (Side side : kSides)
      if (auto n = neighbourIn(cell, side, cols, rows); n && !seen[index(*n)]) open.push_back({side, *n});
    if (open.empty()) {
      stack.pop_back();
      continue;
    }
    auto [side, nextCell] = open[rng.below(open.size())];
    rooms[index(cell)].doors[sideIndex(side)] = true;
    rooms[index(nextCell)].doors[sideIndex(opposite(side))] = true;
    seen[index(nextCell)] = true;
    stack.push_back(nextCell);
  }
  size_t added = 0, tries = 0;
  while (added < shape.loops && tries < std::max((size_t)100, shape.loops * 25)) {
    ++tries;
    Cell cell = rooms[rng.below(count)].cell;
    Side side = kSides[rng.below(4)];
    if (auto n = neighbourIn(cell, side, cols, rows); n && !rooms[index(cell)].doors[sideIndex(side)]) {
      rooms[index(cell)].doors[sideIndex(side)] = true;
      rooms[index(*n)].doors[sideIndex(opposite(side))] = true;
      ++added;
    }
  }

  house.spawn = centre(spawnCell) + v(0.0f, 1.0f);
  house.spawnRoom = spawnRoom;
  house.backrooms = shape.backrooms;
  std::vector<size_t> distance = house.distances(spawnCell);

  // The front door: the outer room farthest from the bedroom.
  size_t frontRoom = spawnRoom;
  for (size_t i = 0; i < rooms.size(); ++i) {
    bool outer = false;
    for (Side side : kSides) outer |= !house.neighbour(rooms[i].cell, side).has_value();
    if (outer && distance[i] > distance[frontRoom]) frontRoom = i;
  }
  std::vector<Side> outerSides;
  for (Side side : kSides)
    if (!house.neighbour(rooms[frontRoom].cell, side)) outerSides.push_back(side);
  Side side = outerSides[rng.below(outerSides.size())];
  V2 mid = centre(rooms[frontRoom].cell) + outward(side) * (kCell / 2.0f);
  house.front = {frontRoom, side, mid, mid - outward(side) * 1.1f};

  // Keys: three other rooms two or more doorways from the bedroom.
  size_t floorKeys = shape.puzzleKey ? kKeys - 1 : kKeys;
  std::vector<size_t> candidates;
  for (size_t i = 0; i < count; ++i)
    if (i != spawnRoom && i != frontRoom && distance[i] >= 2) candidates.push_back(i);
  if (candidates.size() < kKeys) {
    candidates.clear();
    for (size_t i = 0; i < count; ++i)
      if (i != spawnRoom && i != frontRoom) candidates.push_back(i);
  }
  rng.shuffle(candidates);
  std::vector<size_t> keyRooms;
  if (shape.spread) {
    std::vector<std::vector<size_t>> anchors = {distance, house.distances(rooms[frontRoom].cell)};
    std::vector<size_t> picked;
    for (size_t k = 0; k < floorKeys; ++k) {
      std::vector<size_t> pool;
      for (size_t r : candidates)
        if (std::find(picked.begin(), picked.end(), r) == picked.end()) pool.push_back(r);
      auto best = lastMaxBy(pool, [&](size_t r) {
        size_t m = kNone;
        for (auto& d : anchors) m = std::min(m, d[r]);
        return anchors.empty() ? (size_t)0 : m;
      });
      if (best) {
        size_t room = pool[*best];
        picked.push_back(room);
        anchors.push_back(house.distances(rooms[room].cell));
      }
    }
    keyRooms = picked;
  } else {
    for (size_t k = 0; k < candidates.size() && k < floorKeys; ++k) keyRooms.push_back(candidates[k]);
  }
  for (size_t room : keyRooms) {
    const auto& slots = moduleDef(rooms[room].module).keySlots;
    V2 slot = slots[rng.below(slots.size())];
    house.keys.push_back(centre(rooms[room].cell) + slot);
  }

  // The Ice Cream Man starts three or more rooms away.
  std::vector<size_t> far;
  for (size_t i = 0; i < count; ++i)
    if (distance[i] >= 3) far.push_back(i);
  size_t manRoom;
  if (far.empty()) {
    std::vector<size_t> all(count);
    for (size_t i = 0; i < count; ++i) all[i] = i;
    manRoom = lastMaxBy(all, [&](size_t i) { return distance[i]; }).value_or(0);
  } else {
    manRoom = far[rng.below(far.size())];
  }
  house.manStart = centre(rooms[manRoom].cell);

  house.buildBlocks(rng);
  house.placePuzzle(frontRoom, shape.spread);
  if (shape.puzzleKey) {
    house.cabinetKey = house.keys.size();
    house.keys.push_back(house.cabinet);
  }
  return house;
}

void House::placePuzzle(size_t frontRoom, bool spread) {
  Rng rng(seed ^ 0x5b0a7c0de5ea3001ull);
  std::vector<size_t> keyRooms;
  for (V2 k : keys) keyRooms.push_back(roomOf(k));
  std::vector<size_t> pool;
  for (size_t i = 0; i < rooms.size(); ++i) {
    if (i == spawnRoom || i == frontRoom) continue;
    if (spread && std::find(keyRooms.begin(), keyRooms.end(), i) != keyRooms.end()) continue;
    pool.push_back(i);
  }
  rng.shuffle(pool);
  if (spread) {
    std::vector<size_t> fromBed = distances(rooms[spawnRoom].cell), fromDoor = distances(rooms[frontRoom].cell);
    std::vector<std::vector<size_t>> anchors = {fromBed, fromDoor};
    for (size_t r : keyRooms) anchors.push_back(distances(rooms[r].cell));
    std::vector<size_t> picked;
    for (size_t k = 0; k <= kButtons; ++k) {
      std::vector<size_t> left;
      for (size_t r : pool)
        if (std::find(picked.begin(), picked.end(), r) == picked.end()) left.push_back(r);
      auto best = lastMaxBy(left, [&](size_t r) {
        size_t m = kNone;
        for (auto& d : anchors) m = std::min(m, d[r]);
        return m;
      });
      if (best) {
        size_t room = left[*best];
        picked.push_back(room);
        anchors.push_back(distances(rooms[room].cell));
      }
    }
    pool = picked;
    // The cabinet last: the farthest of them.
    std::vector<size_t> order(pool.size());
    for (size_t i = 0; i < pool.size(); ++i) order[i] = i;
    if (auto far = lastMaxBy(order, [&](size_t i) { return std::min(fromBed[pool[i]], fromDoor[pool[i]]); })) {
      size_t room = pool[*far];
      pool.erase(pool.begin() + *far);
      pool.push_back(room);
    }
  }
  std::vector<V2> spots;
  for (size_t k = 0; k < pool.size() && k < kButtons + 1; ++k) {
    size_t room = pool[k];
    V2 c = centre(rooms[room].cell);
    std::vector<V2> slots;
    for (V2 s : moduleDef(rooms[room].module).keySlots) {
      V2 at = c + s;
      bool clear = true;
      for (V2 key : keys) clear &= distance(key, at) > 1.0f;
      if (clear) slots.push_back(at);
    }
    spots.push_back(slots[rng.below(slots.size())]);
  }
  if (spots.empty()) {
    cabinet = spawn;
  } else {
    cabinet = spots.back();
    spots.pop_back();
  }
  buttons = spots;
}

void House::buildBlocks(Rng& rng) {
  const float half = kWall / 2.0f, gap = kDoor / 2.0f;
  auto wall = [](V2 min, V2 max) { return Block{min, max, kWallHeight}; };
  for (const Room& room : rooms) {
    auto [col, row] = room.cell;
    float x0 = (float)col * kCell, z0 = (float)row * kCell;
    std::vector<Side> sides = {Side::North, Side::West};
    if (col == cols - 1) sides.push_back(Side::East);
    if (row == rows - 1) sides.push_back(Side::South);
    for (Side side : sides) {
      bool open = room.doors[sideIndex(side)];
      bool horizontal = side == Side::North || side == Side::South;
      float line = side == Side::North ? z0 : side == Side::South ? z0 + kCell : side == Side::West ? x0 : x0 + kCell;
      float start = horizontal ? x0 - half : z0 - half, end = horizontal ? x0 + kCell + half : z0 + kCell + half;
      float mid = (start + end) / 2.0f;
      std::vector<std::pair<float, float>> pieces;
      if (open) pieces = {{start, mid - gap}, {mid + gap, end}};
      else pieces = {{start, end}};
      for (auto [a, b] : pieces)
        blocks.push_back(horizontal ? wall(v(a, line - half), v(b, line + half)) : wall(v(line - half, a), v(line + half, b)));
    }
  }
  for (size_t i = 0; i < rooms.size(); ++i) {
    V2 c = centre(rooms[i].cell);
    for (const Prop& p : moduleDef(rooms[i].module).props) {
      Block block{c + p.min, c + p.max, p.height};
      blocks.push_back(block);
      if (!p.usable) continue;
      Spot spot{c + p.useAt, block, i};
      if (p.kind == PropKind::Closet) {
        closets.push_back(spot);
      } else if (p.kind == PropKind::Fridge) {
        Pickup pickup = rng.below(3) == 0 ? Pickup::Fart : Pickup::Fudge;
        fridges.push_back({spot, pickup});
      }
    }
  }
}

std::vector<size_t> House::distances(Cell from) const {
  std::vector<size_t> distance(rooms.size(), kNone);
  std::deque<Cell> queue = {from};
  distance[index(from)] = 0;
  while (!queue.empty()) {
    Cell cell = queue.front();
    queue.pop_front();
    for (Side side : kSides) {
      if (!rooms[index(cell)].doors[sideIndex(side)]) continue;
      if (auto n = neighbour(cell, side); n && distance[index(*n)] == kNone) {
        distance[index(*n)] = distance[index(cell)] + 1;
        queue.push_back(*n);
      }
    }
  }
  return distance;
}

std::vector<Cell> House::cellPath(Cell from, Cell to) const {
  std::vector<size_t> distance = distances(to);
  std::vector<Cell> path = {from};
  Cell at = from;
  while (at != to) {
    size_t here = distance[index(at)];
    if (here == kNone) break;
    std::optional<Cell> next;
    for (Side side : kSides) {
      if (!rooms[index(at)].doors[sideIndex(side)]) continue;
      auto n = neighbour(at, side);
      if (n && distance[index(*n)] + 1 == here) {
        next = n;
        break;
      }
    }
    if (!next) break;
    path.push_back(*next);
    at = *next;
  }
  return path;
}

V2 House::doorway(Cell a, Cell b) { return (centre(a) + centre(b)) * 0.5f; }

std::vector<std::pair<V2, bool>> House::doorways() const {
  std::vector<std::pair<V2, bool>> all;
  for (const Room& room : rooms)
    for (Side side : {Side::South, Side::East})
      if (room.doors[sideIndex(side)])
        if (auto n = neighbour(room.cell, side)) all.push_back({doorway(room.cell, *n), side == Side::South});
  return all;
}

float House::headroom(V2 p, float radius) const {
  for (auto [mid, alongX] : doorways()) {
    float across = alongX ? std::fabs(p.z - mid.z) : std::fabs(p.x - mid.x);
    float along = alongX ? std::fabs(p.x - mid.x) : std::fabs(p.z - mid.z);
    if (across < kWall / 2.0f + radius && along < kDoor / 2.0f + radius) return kDoorHeight;
  }
  return kWallHeight;
}

std::vector<Cell> House::neighbours(Cell cell) const {
  std::vector<Cell> out;
  for (Side side : kSides)
    if (rooms[index(cell)].doors[sideIndex(side)])
      if (auto n = neighbour(cell, side)) out.push_back(*n);
  return out;
}

std::vector<V2> House::route(V2 from, V2 to, float radius) const {
  std::vector<Cell> cells = cellPath(cellOf(from), cellOf(to));
  std::vector<V2> points;
  V2 last = from;
  auto push = [&](V2 next, Cell room) {
    if (firstHit(blocks, last, next, radius, 0.0f) >= 0) {
      V2 c = centre(room);
      if (distance(c, last) > 0.2f) {
        points.push_back(c);
        last = c;
      }
    }
    points.push_back(next);
    last = next;
  };
  for (size_t i = 0; i + 1 < cells.size(); ++i) push(doorway(cells[i], cells[i + 1]), cells[i]);
  push(to, cellOf(to));
  return points;
}

bool House::open(V2 p, float radius) const {
  for (const Block& b : blocks)
    if (b.grown(radius).contains(p)) return false;
  return true;
}

// ---------------------------------------------------------------- man.rs

Man Man::tuned(V2 at, uint64_t seed, Tuning t) {
  Man m;
  m.pos = at;
  m.facing = v(0, 1);
  m.volleyWait = t.volley_wait;
  m.sniff = t.sniff_every;
  m.rng = Rng(seed * 31 + 17);
  m.health = t.man_health;
  m.tuning = t;
  return m;
}

bool Man::canSee(const House& house, V2 player) const {
  if (state == ManState::Frozen || state == ManState::Confused) return false;
  V2 to = player - pos;
  float d = length(to);
  if (d > tuning.sight) return false;
  bool ahead = d <= tuning.notice || state == ManState::Chase || dot(facing, normalized(to)) >= tuning.sightCos();
  return ahead && firstHit(house.blocks, pos, player, 0.0f, 1.5f) < 0;
}

bool Man::fudge() {
  if (state == ManState::Frozen) return false;
  fudgeHits += 1;
  fudgeMemory = tuning.fudge_memory;
  slow = tuning.fudge_slow;
  if (fudgeHits >= tuning.freeze_hits) {
    fudgeHits = 0;
    state = ManState::Frozen;
    timer = tuning.frozen;
    path.clear();
    shove = {0, 0};
    return true;
  }
  return false;
}

bool Man::hurt(float damage) {
  if (health <= 0.0f) return false;
  health = fmax(health - damage, 0.0f);
  return health <= 0.0f;
}

void Man::fart(V2 at) {
  V2 away = normalized(pos - at);
  if (away == V2{0, 0}) away = v(1, 0);
  shove = away * tuning.fart_shove;
  if (state != ManState::Frozen) {
    state = ManState::Confused;
    timer = tuning.confused;
  }
  lastSeen.reset();
  sawHide = false;
  path.clear();
  goal.reset();
  facing = away;
}

void Man::headTo(const House& house, V2 g) {
  goal = g;
  path = house.route(pos, g, kManRadius);
  replan = 0.5f;
}

bool Man::follow(const House& house, float speed) {
  while (!path.empty() && distance(pos, path.front()) < 0.3f) path.erase(path.begin());
  if (tuning.corners == 1 && state == ManState::Chase)
    while (path.size() > 1 && firstHit(house.blocks, pos, path[1], kManRadius, 0.0f) < 0) path.erase(path.begin());
  if (path.empty()) return true;
  walk(house, path.front(), speed);
  return false;
}

void Man::walk(const House& house, V2 toward, float speed) {
  V2 to = toward - pos;
  V2 dir = normalized(to);
  float stepLen = fmin(speed * kDt, length(to));
  V2 before = pos;
  pos = slide(house.blocks, pos, dir * stepLen, kManRadius, 0.0f);
  if (!(dir == V2{0, 0})) facing = dir;
  moving = true;
  if (distance(pos, before) < stepLen * 0.2f) ++stuck;
  else stuck = 0;
  if (stuck > 20) {
    stuck = 0;
    if (goal) {
      V2 c = centre(house.cellOf(pos));
      std::vector<V2> p = {c};
      auto rest = house.route(c, *goal, kManRadius);
      p.insert(p.end(), rest.begin(), rest.end());
      path = p;
    }
  }
}

float Man::speed(float base) const { return slow > 0.0f ? base * tuning.slowed : base; }

std::vector<Act> Man::step(const House& house, const Senses& senses) {
  std::vector<Act> acts;
  moving = false;
  for (float* t : {&volleyWait, &grabWait, &gloat, &slow, &replan}) *t = fmax(*t - kDt, 0.0f);
  if (fudgeMemory > 0.0f) {
    fudgeMemory -= kDt;
    if (fudgeMemory <= 0.0f) fudgeHits = 0;
  }
  if (length(shove) > 0.05f) {
    pos = slide(house.blocks, pos, shove * kDt, kManRadius, 0.0f);
    shove = shove * fmax(1.0f - kShoveFade * kDt, 0.0f);
  }

  if (state == ManState::Frozen) {
    timer -= kDt;
    if (timer <= 0.0f) {
      V2 g = lastSeen.value_or(senses.player);
      state = ManState::Search;
      timer = tuning.search_time;
      looking = false;
      headTo(house, g);
    }
    return acts;
  }
  if (state == ManState::Confused) {
    timer -= kDt;
    if (rng.below(30) == 0 || facing == V2{0, 0}) {
      float a = rng.unit() * kTau;
      facing = v(std::cos(a), std::sin(a));
    }
    V2 before = pos, f = facing;
    pos = slide(house.blocks, pos, f * tuning.man_wander * 0.6f * kDt, kManRadius, 0.0f);
    moving = true;
    if (distance(pos, before) < 0.01f) facing = rotated(f, 0.0f, 1.0f);
    if (timer <= 0.0f) {
      state = ManState::Wander;
      path.clear();
      goal.reset();
    }
    return acts;
  }

  bool sees = !senses.hidden && canSee(house, senses.player);
  if (sees) {
    if (state != ManState::Chase) {
      acts.push_back({ActKind::Spotted});
      state = ManState::Chase;
    }
    lastSeen = senses.player;
  } else if (state == ManState::Chase && !(senses.hidden && sawHide)) {
    acts.push_back({ActKind::Lost});
    V2 g = lastSeen.value_or(senses.player);
    state = ManState::Search;
    timer = tuning.search_time;
    looking = false;
    headTo(house, g);
  }

  if (state == ManState::Wander || state == ManState::Investigate || state == ManState::Search) {
    const auto& noises = *senses.noises;
    for (size_t k = noises.size(); k-- > 0;) {
      auto [at, radius] = noises[k];
      if (distance(at, pos) <= radius) {
        state = ManState::Investigate;
        if (!goal || distance(*goal, at) > 1.0f || replan <= 0.0f) headTo(house, at);
        break;
      }
    }
  }
  if (state == ManState::Wander) {
    sniff -= kDt;
    if (sniff <= 0.0f) {
      sniff = tuning.sniff_every;
      state = ManState::Investigate;
      headTo(house, centre(house.cellOf(senses.player)));
    }
  }

  switch (state) {
    case ManState::Chase: {
      if (gloat > 0.0f) return acts;
      V2 target = senses.hidden && sawHide && senses.closet ? *senses.closet : senses.player;
      float s = speed(tuning.man_chase);
      float t = firstHit(house.blocks, pos, target, kManRadius * 0.8f, 0.0f);
      bool direct = t < 0 || t >= 0.999f;
      if (direct && (sees || senses.hidden)) {
        path.clear();
        goal = target;
        walk(house, target, s);
      } else {
        if (replan <= 0.0f || path.empty()) headTo(house, target);
        follow(house, s);
      }
      float d = distance(pos, target);
      if (sees) {
        facing = normalized(senses.player - pos);
        if (d <= tuning.grab_reach && grabWait <= 0.0f) {
          acts.push_back({ActKind::Grab});
          grabWait = tuning.grab_wait;
          gloat = tuning.gloat;
        } else if (tuning.volley_min <= d && d <= tuning.volley_max && volleyWait <= 0.0f) {
          acts.push_back({ActKind::Volley, facing});
          volleyWait = tuning.volley_wait;
        }
      } else if (senses.hidden && sawHide && d <= tuning.grab_reach + 0.4f && grabWait <= 0.0f) {
        acts.push_back({ActKind::PullOut});
        sawHide = false;
        grabWait = tuning.grab_wait;
        gloat = tuning.gloat;
      }
      break;
    }
    case ManState::Investigate: {
      if (follow(house, speed(tuning.man_investigate))) {
        state = ManState::Search;
        timer = tuning.search_time;
        looking = true;
      }
      break;
    }
    case ManState::Search: {
      bool arrived = follow(house, speed(tuning.man_search));
      looking |= arrived;
      if (looking) timer -= kDt;
      if (arrived) {
        if (timer <= 0.0f) {
          state = ManState::Wander;
          lastSeen.reset();
          goal.reset();
        } else {
          V2 c = centre(house.cellOf(pos));
          const V2 spots[5] = {v(0, 0), v(3, 0), v(-3, 0), v(0, 3), v(0, -3)};
          V2 spot = c + spots[rng.below(5)];
          goal = spot;
          path = {c, spot};
        }
      }
      break;
    }
    case ManState::Wander: {
      if (follow(house, speed(tuning.man_wander))) {
        Cell here = house.cellOf(pos), door = house.cellOf(house.front.stand);
        bool patrol = tuning.patrol_keys > 0 && senses.keys >= tuning.patrol_keys && here != door;
        if (patrol && rng.below(2) == 0) {
          headTo(house, house.front.stand);
        } else {
          std::vector<Cell> next = house.neighbours(here);
          Cell pick = next.empty() ? here : next[rng.below(next.size())];
          headTo(house, centre(pick));
        }
      }
      break;
    }
    default: break;
  }
  return acts;
}

// ---------------------------------------------------------------- minion.rs

Minion::Minion(V2 at, float h, bool f, float l) : pos(at), facing(v(0, 1)), health(h), friendly(f), life(l) {}

void Minion::tick() {
  moving = false;
  flash = fmax(flash - kDt, 0.0f);
  biteWait = fmax(biteWait - kDt, 0.0f);
  replan = fmax(replan - kDt, 0.0f);
  if (friendly) life -= kDt;
}

void Minion::go(const House& house, V2 g, float speed, float near) {
  if (distance(pos, g) <= near) {
    facing = normalized(g - pos);
    return;
  }
  bool straight = firstHit(house.blocks, pos, g, kMinionRadius * 0.9f, 0.0f) < 0;
  if (straight) {
    path.clear();
    goal = g;
    stepToward(house, g, speed);
    return;
  }
  bool moved = !goal || distance(*goal, g) > 1.5f;
  if (path.empty() || replan <= 0.0f || moved) {
    path = house.route(pos, g, kMinionRadius);
    goal = g;
    replan = 1.0f;
  }
  while (!path.empty() && distance(pos, path.front()) < 0.3f) path.erase(path.begin());
  if (!path.empty()) stepToward(house, path.front(), speed);
}

void Minion::wander(const House& house, Rng& rng, float speed) {
  bool arrived = !goal || distance(*goal, pos) < 0.5f;
  if (arrived) {
    Cell here = house.cellOf(pos);
    std::vector<Cell> next = house.neighbours(here);
    Cell pick = next.empty() ? here : next[rng.below(next.size())];
    goal = centre(pick);
    path = house.route(pos, centre(pick), kMinionRadius);
  }
  if (goal) go(house, *goal, speed, 0.4f);
}

void Minion::stepToward(const House& house, V2 toward, float speed) {
  V2 to = toward - pos;
  V2 dir = normalized(to);
  if (dir == V2{0, 0}) return;
  float s = fmin(speed * kDt, length(to));
  pos = slide(house.blocks, pos, dir * s, kMinionRadius, 0.0f);
  facing = dir;
  moving = true;
}

// ---------------------------------------------------------------- game.rs

const char* toolName(Tool t) {
  static const char* names[kTools] = {"Fudge", "Fart", "Keys", "Sword", "Spear", "Pistol", "Sugar", "Staff"};
  return names[(int)t];
}

namespace {
const Tool kEarned[4] = {Tool::Sword, Tool::Spear, Tool::Pistol, Tool::Sugar};

std::array<std::pair<float, float>, kVolleyPellets> fan(float spread) {
  std::array<std::pair<float, float>, kVolleyPellets> turns;
  float middle = (float)(kVolleyPellets / 2);
  for (size_t i = 0; i < kVolleyPellets; ++i) {
    float degrees = ((float)i - middle) * spread;
    float radians = degrees * kRadsPerDeg;
    turns[i] = {std::cos(radians), std::sin(radians)};
  }
  return turns;
}

Event ev(EventKind k, uint32_t n = 0, V2 a = {}, V2 b = {}) { return {k, n, a, b}; }

uint32_t bits(float f) {
  uint32_t b;
  std::memcpy(&b, &f, 4);
  return b;
}
}  // namespace

Game::Game(uint64_t seed, Options o, Tuning t)
    : house(House::of(seed, t)), man(Man::tuned(house.manStart, seed, t)), options(o), tuning(t),
      rng_(seed ^ 0x3141592653589793ull) {
  player.pos = house.spawn;
  player.facing = v(0, -1);
  player.health = t.max_health;
  player.tool = Tool::Fudge;
  player.fudge = t.fudge_start;
  player.farts = t.farts_start;
  player.owned = {Tool::Fudge, Tool::Fart, Tool::Keys};
  player.sinceHit = t.regen_after;
  taken.assign(house.keys.size(), false);
  opened.assign(house.fridges.size(), false);
  minionWait_ = t.minion_first;
}

std::optional<size_t> Game::lockedKey() const {
  if (house.cabinetKey && !solved) return house.cabinetKey;
  return std::nullopt;
}

bool Game::doorGuarded() const {
  return tuning.unlock_guard > 0.0f && manHere() && !(man.state == ManState::Frozen || man.state == ManState::Confused) &&
         distance(man.pos, player.pos) < tuning.unlock_guard;
}

uint32_t Game::minionCap() const {
  uint32_t more = tuning.minion_growth > 0.0f ? (uint32_t)(seconds() / tuning.minion_growth) : 0;
  return std::min(tuning.minion_count + more, (uint32_t)12);
}

bool Game::has(Tool t) const { return std::find(player.owned.begin(), player.owned.end(), t) != player.owned.end(); }

float Game::maxHealth() const {
  float boost = player.boost > 0.0f ? tuning.cone_boost : 0.0f;
  return tuning.max_health * (1.0f + boost);
}

void Game::earn(Tool t) {
  if (has(t)) return;
  player.owned.push_back(t);
  std::stable_sort(player.owned.begin(), player.owned.end(), [](Tool a, Tool b) { return (int)a < (int)b; });
  if (t == Tool::Pistol) player.cones = tuning.pistol_ammo;
  if (t == Tool::Sugar) player.sugar = tuning.sugar_ammo;
  player.tool = t;
  events.push_back(ev(EventKind::Earned, (uint32_t)t));
}

void Game::arm() {
  for (Tool t : kEarned) earn(t);
  player.tool = Tool::Spear;
  events.clear();
}

bool Game::keepPlaying() {
  if (tuning.free_roam != 1 || !(status == Status::Escaped || status == Status::Melted)) return false;
  status = Status::Playing;
  freeRoam = true;
  player.unlock = 0.0f;
  player.health = maxHealth();
  events.clear();
  earn(Tool::Staff);
  events.push_back(ev(EventKind::FreeRoam));
  return true;
}

RunCard Game::runCard() const {
  RunCard c;
  c.escaped = won.value_or(status) == Status::Escaped;
  c.melted = manMelted;
  c.minionsMelted = stats.minionsMelted;
  c.seconds = (uint32_t)(tick / kHz);
  c.keys = player.keys;
  c.hitsTaken = stats.hitsTaken;
  if (stats.fudgeShots > 0) c.accuracy = stats.fudgeHits * 100 / stats.fudgeShots;
  return c;
}

std::optional<V2> Game::closetSpot() const {
  if (player.hidden) return house.closets[*player.hidden].at;
  return std::nullopt;
}

std::optional<Prompt> Game::prompt() const {
  if (auto t = target()) return t->first;
  return std::nullopt;
}

std::optional<std::pair<Prompt, size_t>> Game::target() const {
  if (player.hidden) return std::make_pair(Prompt::Leave, (size_t)0);
  V2 p = player.pos;
  if (!freeRoam && distance(p, house.front.stand) <= tuning.reach) {
    Prompt prompt = player.keys >= house.keys.size() ? (doorGuarded() ? Prompt::Guarded : Prompt::Unlock) : Prompt::Locked;
    return std::make_pair(prompt, (size_t)0);
  }
  std::optional<std::tuple<Prompt, size_t, float>> best;
  auto offer = [&](Prompt prompt, size_t i, float d) {
    if (d <= tuning.reach && (!best || d < std::get<2>(*best))) best = std::make_tuple(prompt, i, d);
  };
  if (puzzleOn() && !solved) {
    for (size_t i = 0; i < house.buttons.size(); ++i) offer(Prompt::Button, i, distance(p, house.buttons[i]));
    offer(Prompt::Cabinet, 0, distance(p, house.cabinet));
  }
  for (size_t i = 0; i < house.fridges.size(); ++i) {
    float d = distance(p, house.fridges[i].first.at);
    if (!opened[i]) offer(Prompt::Fridge, i, d);
  }
  for (size_t i = 0; i < house.closets.size(); ++i) offer(Prompt::Hide, i, distance(p, house.closets[i].at));
  if (best) return std::make_pair(std::get<0>(*best), std::get<1>(*best));
  return std::nullopt;
}

void Game::hurt(float damage) {
  float floor = freeRoam ? 1.0f : 0.0f;
  player.health = fmax(player.health - damage, floor);
  player.sinceHit = 0.0f;
  stats.hitsTaken += 1;
  if (player.health <= 0.0f && status == Status::Playing) {
    status = Status::Scooped;
    events.push_back(ev(EventKind::Scooped));
  }
}

void Game::step(const Input& input) {
  beginStep(input);
  movePlayer();
  fire();
  interact();
  pickUpKeys();
  pickUpDrops();
  fly();
  stepMan();
  stepMinions();
  reapStep();
  spawnMinions();
  ageClouds();
  endStep();
}

void Game::beginStep(const Input& input) {
  events.clear();
  stepping_ = status == Status::Playing;
  if (!stepping_) return;
  tick += 1;
  noises_.clear();
  in_ = input;
  pressed_ = input.interact && !wasInteract_;
  jumped_ = input.jump && !wasJump_;
  wasInteract_ = input.interact;
  wasJump_ = input.jump;
  if (input.select && has(*input.select)) player.tool = *input.select;
}

void Game::movePlayer() {
  if (!stepping_) return;
  Player& p = player;
  p.fireWait = fmax(p.fireWait - kDt, 0.0f);
  if (p.hidden) {
    p.moving = false;
    p.sprinting = false;
    return;
  }
  V2 walk = clamped(in_.walk, 1.0f);
  if (in_.body) {
    // The world moved the body (the shared controller): take it as it is.
    const Body& b = *in_.body;
    p.pos = b.pos;
    p.height = b.height;
    p.vy = 0;
    p.moving = b.moving;
    p.sprinting = b.sprinting;
    p.shove = p.shove * fmax(1.0f - kShoveFade * kDt, 0.0f);
    if (p.moving && length(walk) > 0.1f) p.facing = normalized(walk);
    if (p.sprinting) noises_.push_back({p.pos, tuning.sprint_noise});
    return;
  }
  p.moving = length(walk) > 0.1f;
  p.sprinting = p.moving && in_.sprint;
  float speed = p.sprinting ? tuning.sprint : tuning.walk;
  V2 delta = walk * (speed * kDt) + p.shove * kDt;
  p.pos = slide(house.blocks, p.pos, delta, kPlayerRadius, p.height);
  p.shove = p.shove * fmax(1.0f - kShoveFade * kDt, 0.0f);
  if (p.moving) p.facing = normalized(walk);
  if (p.sprinting) noises_.push_back({p.pos, tuning.sprint_noise});
  if (jumped_ && p.height <= 0.0f) {
    p.vy = tuning.jump_speed;
    events.push_back(ev(EventKind::Jumped));
  }
  p.height += p.vy * kDt;
  p.vy -= tuning.gravity * kDt;
  if (p.height <= 0.0f) {
    p.height = 0.0f;
    p.vy = 0.0f;
  }
  if (p.height > 0.0f) {
    float room = house.headroom(p.pos, kPlayerRadius) - kPlayerHeight - 0.05f;
    if (p.height > room) {
      p.height = fmax(room, 0.0f);
      p.vy = fmin(p.vy, 0.0f);
    }
  }
}

void Game::fire() {
  if (!stepping_) return;
  Player& p = player;
  if (!in_.fire || p.fireWait > 0.0f || p.hidden) return;
  V2 aim = normalized(in_.aim);
  if (aim == V2{0, 0}) aim = p.facing;
  switch (p.tool) {
    case Tool::Fudge:
      if (p.fudge > 0) {
        p.fudge -= 1;
        p.fireWait = 1.0f / tuning.fudge_rate;
        shots.push_back({ShotKind::Fudge, 0, p.pos + aim * 0.5f, 1.1f, aim * tuning.fudge_speed, tuning.fudge_range});
        stats.fudgeShots += 1;
        noises_.push_back({p.pos, tuning.fudge_noise});
        events.push_back(ev(EventKind::FudgeFired));
        return;
      }
      break;
    case Tool::Fart:
      if (p.farts > 0) {
        p.farts -= 1;
        p.fireWait = tuning.fart_wait;
        V2 from = p.pos, to = from + aim * tuning.fart_range;
        float t = firstHit(house.blocks, from, to, 0.3f, 1.0f);
        V2 at = t >= 0 ? from + (to - from) * (t * 0.9f) : to;
        clouds.push_back({at, 0.0f});
        stats.farts += 1;
        events.push_back(ev(EventKind::Fart, 0, at));
        if (manHere() && distance(man.pos, at) <= tuning.fart_radius) {
          man.fart(at);
          events.push_back(ev(EventKind::FartHit));
        }
        float radius = tuning.fart_radius, damage = tuning.fart_minion_damage;
        for (size_t i = 0; i < minions.size(); ++i) {
          Minion& m = minions[i];
          if (!m.friendly && distance(m.pos, at) <= radius) {
            V2 away = normalized(m.pos - at);
            m.pos = slide(house.blocks, m.pos, away * 1.2f, kMinionRadius, 0.0f);
            damageMinion(i, damage);
          }
        }
        return;
      }
      break;
    case Tool::Sword:
    case Tool::Spear: {
      bool sword = p.tool == Tool::Sword;
      float reach = sword ? tuning.sword_reach : tuning.spear_reach, wait = sword ? tuning.sword_wait : tuning.spear_wait;
      float damage = sword ? tuning.sword_damage : tuning.spear_damage, cos = sword ? 0.3f : 0.88f;
      p.fireWait = wait;
      events.push_back(ev(EventKind::Swing, (uint32_t)p.tool));
      melee(p.pos, aim, reach, cos, damage);
      return;
    }
    case Tool::Pistol:
      if (p.cones > 0) {
        p.cones -= 1;
        p.fireWait = 1.0f / tuning.pistol_rate;
        shots.push_back({ShotKind::Cone, 0, p.pos + aim * 0.5f, 1.1f, aim * tuning.pistol_speed, tuning.pistol_range});
        events.push_back(ev(EventKind::ConeFired));
        return;
      }
      break;
    case Tool::Sugar:
      if (p.sugar > 0) {
        p.sugar -= 1;
        p.fireWait = tuning.sugar_wait;
        shots.push_back({ShotKind::Sugar, 0, p.pos + aim * 0.5f, 1.2f, aim * tuning.sugar_speed, tuning.sugar_range});
        events.push_back(ev(EventKind::SugarFired));
        return;
      }
      break;
    case Tool::Staff:
      p.fireWait = tuning.staff_wait;
      staff(p.pos, aim);
      return;
    case Tool::Keys:
      p.fireWait = tuning.jingle_wait;
      noises_.push_back({p.pos, tuning.jingle_noise});
      events.push_back(ev(EventKind::Jingle));
      return;
  }
  p.fireWait = 0.4f;
  events.push_back(ev(EventKind::Empty, (uint32_t)p.tool));
}

void Game::interact() {
  if (!stepping_) return;
  auto t = target();
  bool unlockTarget = t && t->first == Prompt::Unlock;
  if (!unlockTarget || !in_.interact) {
    if (player.unlock > 0.0f && t && t->first == Prompt::Guarded) events.push_back(ev(EventKind::DoorGuarded));
    player.unlock = 0.0f;
  }
  if (!t) return;
  auto [prompt, i] = *t;
  switch (prompt) {
    case Prompt::Leave:
      if (pressed_) {
        player.hidden.reset();
        events.push_back(ev(EventKind::Unhid));
      }
      break;
    case Prompt::Hide:
      if (pressed_) {
        V2 spot = house.closets[i].at;
        man.sawHide = options.man && man.state == ManState::Chase && man.canSee(house, player.pos);
        player.hidden = i;
        player.pos = spot;
        player.height = 0.0f;
        events.push_back(ev(EventKind::Hid));
      }
      break;
    case Prompt::Fridge:
      if (pressed_) {
        opened[i] = true;
        Pickup pickup = house.fridges[i].second;
        if (pickup == Pickup::Fudge) player.fudge = std::min(player.fudge + tuning.fudge_pickup, tuning.fudge_max);
        else player.farts = std::min(player.farts + 1, tuning.farts_max);
        if (has(Tool::Pistol)) player.cones = std::min(player.cones + tuning.pistol_pickup, tuning.pistol_max);
        if (has(Tool::Sugar)) player.sugar = std::min(player.sugar + tuning.sugar_pickup, tuning.sugar_max);
        noises_.push_back({player.pos, tuning.fridge_noise});
        events.push_back(ev(EventKind::PickedUp, (uint32_t)pickup));
      }
      break;
    case Prompt::Button:
      if (pressed_) {
        if ((uint32_t)i == lit) {
          lit += 1;
          events.push_back(ev(EventKind::Button, lit));
          if (lit >= kButtons) {
            solved = true;
            if (weaponsOn()) drops.push_back({house.cabinet, DropKind::Weapon, Tool::Spear, 0.0f});
            events.push_back(ev(EventKind::PuzzleSolved));
          }
        } else if ((uint32_t)i > lit) {
          lit = 0;
          events.push_back(ev(EventKind::PuzzleWrong));
        }
      }
      break;
    case Prompt::Cabinet:
      if (pressed_) events.push_back(ev(EventKind::CabinetLocked));
      break;
    case Prompt::Locked:
      if (pressed_) {
        noises_.push_back({player.pos, tuning.door_noise});
        events.push_back(ev(EventKind::DoorLocked));
      }
      break;
    case Prompt::Guarded:
      if (in_.interact && (pressed_ || tick % kHz == 0)) events.push_back(ev(EventKind::DoorGuarded));
      break;
    case Prompt::Unlock:
      if (in_.interact) {
        player.unlock += kDt;
        if (tick % (kHz / 2) == 0) noises_.push_back({player.pos, tuning.door_noise});
        if (player.unlock >= tuning.unlock - 1e-4f) {
          status = Status::Escaped;
          won = Status::Escaped;
          events.push_back(ev(EventKind::Escaped));
        }
      }
      break;
  }
}

void Game::pickUpKeys() {
  if (!stepping_ || player.hidden) return;
  auto locked = lockedKey();
  for (size_t i = 0; i < house.keys.size(); ++i) {
    if (!taken[i] && !(locked && *locked == i) && distance(house.keys[i], player.pos) <= tuning.key_reach) {
      taken[i] = true;
      player.keys += 1;
      events.push_back(ev(EventKind::Key, player.keys));
    }
  }
}

void Game::fly() {
  if (!stepping_) return;
  std::vector<V2> bursts;
  std::vector<Shot> flying = std::move(shots);
  shots.clear();
  std::vector<Shot> kept;
  for (Shot& shot : flying) {
    V2 from = shot.pos, to = from + shot.vel * kDt;
    float travel = length(shot.vel) * kDt;
    float t = firstHit(house.blocks, from, to, 0.0f, shot.height);
    if (t >= 0) {
      V2 at = from + (to - from) * t;
      if (shot.kind == ShotKind::Fudge) events.push_back(ev(EventKind::FudgeSplat, 0, at));
      else if (shot.kind == ShotKind::Sugar) bursts.push_back(from + (to - from) * (t * 0.9f));
      continue;
    }
    bool playerShot = shot.kind != ShotKind::Sprinkle;
    if (playerShot) {
      std::optional<size_t> hit;
      for (size_t i = 0; i < minions.size(); ++i) {
        const Minion& m = minions[i];
        if (!m.friendly && m.health > 0.0f && segmentDistance(from, to, m.pos) <= kMinionRadius + 0.25f) {
          hit = i;
          break;
        }
      }
      if (hit) {
        if (shot.kind == ShotKind::Fudge) {
          stats.fudgeHits += 1;
          damageMinion(*hit, tuning.fudge_minion_damage);
        } else if (shot.kind == ShotKind::Cone) {
          damageMinion(*hit, tuning.pistol_damage);
        } else {
          bursts.push_back(minions[*hit].pos);
        }
        continue;
      }
    }
    bool gone = false;
    switch (shot.kind) {
      case ShotKind::Fudge:
        if (manHere() && segmentDistance(from, to, man.pos) <= kManRadius + 0.25f) {
          stats.fudgeHits += 1;
          events.push_back(ev(EventKind::FudgeHit));
          if (man.fudge()) {
            events.push_back(ev(EventKind::Frozen));
            stats.freezes += 1;
            if (weaponsOn() && stats.freezes >= tuning.pistol_task) earn(Tool::Pistol);
          }
          gone = true;
        }
        break;
      case ShotKind::Cone:
        if (manHere() && segmentDistance(from, to, man.pos) <= kManRadius + 0.25f) {
          damageMan(tuning.pistol_damage);
          gone = true;
        }
        break;
      case ShotKind::Sugar:
        if (manHere() && segmentDistance(from, to, man.pos) <= kManRadius + 0.3f) {
          bursts.push_back(man.pos);
          gone = true;
        } else if (shot.left - travel <= 0.0f) {
          bursts.push_back(to);
          gone = true;
        }
        break;
      case ShotKind::Sprinkle:
        if (!player.hidden && player.height < tuning.pellet_dodge &&
            segmentDistance(from, to, player.pos) <= kPlayerRadius + 0.1f) {
          events.push_back(ev(EventKind::SprinkleHit));
          hurt(tuning.sprinkle_damage);
          gone = true;
        }
        break;
    }
    if (gone) continue;
    shot.pos = to;
    shot.left -= travel;
    if (shot.left > 0.0f) kept.push_back(shot);
  }
  kept.insert(kept.end(), shots.begin(), shots.end());
  shots = std::move(kept);
  for (V2 at : bursts) burst(at);
}

void Game::stepMan() {
  if (!stepping_ || !manHere()) return;
  Senses senses{player.pos, player.hidden.has_value(), closetSpot(), &noises_, player.keys};
  auto acts = man.step(house, senses);
  for (const Act& act : acts) {
    switch (act.kind) {
      case ActKind::Volley: {
        for (auto [c, s] : fan(tuning.volley_spread)) {
          V2 vel = rotated(act.dir, c, s) * tuning.pellet_speed;
          sprinkle_ = (uint8_t)((sprinkle_ + 1) % 5);
          shots.push_back({ShotKind::Sprinkle, sprinkle_, man.pos + act.dir * (kManRadius + 0.2f), 1.2f, vel,
                           tuning.volley_max + 3.0f});
        }
        events.push_back(ev(EventKind::Volley));
        break;
      }
      case ActKind::Grab: {
        V2 away = normalized(player.pos - man.pos);
        player.shove = away * tuning.grab_shove;
        events.push_back(ev(EventKind::Grabbed));
        hurt(tuning.grab_damage);
        break;
      }
      case ActKind::PullOut: {
        player.hidden.reset();
        V2 away = normalized(player.pos - man.pos);
        player.shove = away * tuning.grab_shove;
        events.push_back(ev(EventKind::PulledOut));
        hurt(tuning.grab_damage);
        break;
      }
      case ActKind::Spotted: events.push_back(ev(EventKind::Spotted)); break;
      case ActKind::Lost: events.push_back(ev(EventKind::Lost)); break;
      case ActKind::Froze: events.push_back(ev(EventKind::Frozen)); break;
    }
  }
}

void Game::burst(V2 at) {
  events.push_back(ev(EventKind::SugarBurst, 0, at));
  float radius = tuning.sugar_radius, damage = tuning.sugar_damage;
  if (manHere() && distance(man.pos, at) <= radius + kManRadius) damageMan(damage);
  for (size_t i = 0; i < minions.size(); ++i)
    if (!minions[i].friendly && distance(minions[i].pos, at) <= radius + kMinionRadius) damageMinion(i, damage);
}

bool Game::clear(V2 a, V2 b) const { return firstHit(house.blocks, a, b, 0.0f, 1.0f) < 0; }

void Game::melee(V2 from, V2 aim, float reach, float cos, float damage) {
  auto inside = [&](V2 at, float body) {
    V2 to = at - from;
    float d = length(to);
    return d <= reach + body && (d < body + 0.4f || dot(aim, normalized(to)) >= cos);
  };
  if (manHere() && inside(man.pos, kManRadius) && clear(from, man.pos)) damageMan(damage);
  for (size_t i = 0; i < minions.size(); ++i) {
    const Minion& m = minions[i];
    if (!m.friendly && inside(m.pos, kMinionRadius) && clear(from, m.pos)) damageMinion(i, damage);
  }
}

void Game::staff(V2 from, V2 aim) {
  V2 end = from + aim * tuning.staff_length;
  float t = firstHit(house.blocks, from, end, 0.0f, 1.0f);
  if (t >= 0) end = from + (end - from) * t;
  float back = fmin(length(end - from), 0.7f);
  end = end - aim * back;
  events.push_back(ev(EventKind::Staff, 0, from, end));
  float damage = tuning.staff_damage;
  if (manHere() && segmentDistance(from, end, man.pos) <= kManRadius + 0.4f) damageMan(damage);
  for (size_t i = 0; i < minions.size(); ++i)
    if (!minions[i].friendly && segmentDistance(from, end, minions[i].pos) <= kMinionRadius + 0.4f) damageMinion(i, damage);
  V2 side = v(-aim.z, aim.x);
  uint32_t n = tuning.staff_minions;
  for (uint32_t k = 0; k < n; ++k) {
    float spread = ((float)k - ((float)n - 1.0f) / 2.0f) * 0.8f;
    V2 at = end + side * spread;
    if (!house.open(at, kMinionRadius) || !clear(end, at)) at = end;
    if (!house.open(at, kMinionRadius)) at = from;
    minions.emplace_back(at, tuning.minion_health, true, tuning.staff_minion_life);
  }
  size_t friends = 0;
  for (const Minion& m : minions) friends += m.friendly;
  if (friends > kMaxFriends) {
    size_t extra = friends - kMaxFriends;
    std::vector<Minion> keep;
    for (Minion& m : minions) {
      if (m.friendly && extra > 0) {
        --extra;
        continue;
      }
      keep.push_back(std::move(m));
    }
    minions = std::move(keep);
  }
  events.push_back(ev(EventKind::FriendsCame, n));
}

void Game::damageMan(float damage) {
  if (!manHere() || damage <= 0.0f) return;
  events.push_back(ev(EventKind::ManHit));
  stats.manDamage += (uint32_t)std::round(damage);
  if (man.hurt(damage)) {
    manMelted = true;
    events.push_back(ev(EventKind::Melted));
    if (status == Status::Playing && !freeRoam) {
      status = Status::Melted;
      won = Status::Melted;
    }
  }
}

void Game::damageMinion(size_t i, float damage) {
  if (i >= minions.size()) return;
  Minion& m = minions[i];
  if (m.health <= 0.0f || damage <= 0.0f) return;
  m.health -= damage;
  m.flash = 0.25f;
  events.push_back(ev(EventKind::MinionHit, 0, m.pos));
}

void Game::pickUpDrops() {
  if (!stepping_) return;
  for (Drop& d : drops) d.age += kDt;
  drops.erase(std::remove_if(drops.begin(), drops.end(), [](const Drop& d) { return d.kind == DropKind::Cone && !(d.age < kConeLife); }),
              drops.end());
  if (player.hidden) return;
  float reach = tuning.key_reach + 0.2f;
  std::vector<size_t> grabbed;
  for (size_t i = 0; i < drops.size(); ++i)
    if (distance(drops[i].at, player.pos) <= reach) grabbed.push_back(i);
  for (size_t k = grabbed.size(); k-- > 0;) {
    Drop d = drops[grabbed[k]];
    drops.erase(drops.begin() + grabbed[k]);
    if (d.kind == DropKind::Cone) {
      float base = tuning.max_health;
      player.boost = tuning.cone_time;
      player.health = fmin(player.health + base * tuning.cone_boost, maxHealth());
      stats.conesEaten += 1;
      events.push_back(ev(EventKind::ConeEaten));
    } else {
      earn(d.tool);
    }
  }
}

void Game::stepMinions() {
  if (!stepping_ || !options.man) return;
  const Tuning t = tuning;
  V2 me0 = player.pos;
  bool hidden = player.hidden.has_value();
  std::optional<V2> manAt;
  if (manHere()) manAt = man.pos;
  for (size_t i = 0; i < minions.size(); ++i) {
    minions[i].tick();
    if (minions[i].health <= 0.0f) continue;
    V2 me = minions[i].pos;
    if (minions[i].friendly) {
      std::optional<std::pair<size_t, V2>> foe;
      float foeD = 0;
      for (size_t j = 0; j < minions.size(); ++j) {
        const Minion& m = minions[j];
        if (m.friendly || !(m.health > 0.0f) || !(distance(m.pos, me) < 20.0f)) continue;
        float d = distance(m.pos, me);
        if (!foe || d < foeD) foe = std::make_pair(j, m.pos), foeD = d;
      }
      float speed = t.minion_speed * 1.25f;
      if (foe) {
        auto [j, at] = *foe;
        minions[i].go(house, at, speed, kMinionRadius * 2.0f + 0.1f);
        if (distance(minions[i].pos, at) <= kMinionRadius * 2.0f + 0.35f && minions[i].biteWait <= 0.0f) {
          minions[i].biteWait = t.minion_bite_wait;
          damageMinion(j, t.minion_damage);
        }
      } else if (manAt && distance(*manAt, me) < 25.0f) {
        V2 at = *manAt;
        minions[i].go(house, at, speed, kManRadius + kMinionRadius + 0.1f);
        if (distance(minions[i].pos, at) <= kManRadius + kMinionRadius + 0.4f && minions[i].biteWait <= 0.0f) {
          minions[i].biteWait = t.minion_bite_wait;
          damageMan(t.minion_damage);
        }
      } else {
        minions[i].go(house, me0, speed, 2.0f);
      }
    } else {
      bool near = distance(me, me0) <= t.minion_sight;
      if (near && !hidden) {
        minions[i].go(house, me0, t.minion_speed, kMinionRadius + kPlayerRadius);
        if (distance(minions[i].pos, me0) <= kMinionRadius + kPlayerRadius + 0.3f && minions[i].biteWait <= 0.0f) {
          minions[i].biteWait = t.minion_bite_wait;
          events.push_back(ev(EventKind::MinionBite));
          hurt(t.minion_damage);
        }
      } else {
        minions[i].wander(house, rng_, t.minion_speed * 0.6f);
      }
    }
  }
}

void Game::reapStep() {
  if (stepping_ && options.man) reap();
}

void Game::reap() {
  std::vector<V2> melted;
  std::vector<Minion> keep;
  for (Minion& m : minions) {
    if (m.health <= 0.0f) {
      if (!m.friendly) melted.push_back(m.pos);
      continue;
    }
    if (!(m.friendly && m.life <= 0.0f)) keep.push_back(std::move(m));
  }
  minions = std::move(keep);
  for (V2 at : melted) {
    stats.minionsMelted += 1;
    events.push_back(ev(EventKind::MinionMelted, 0, at));
    bool weapons = weaponsOn();
    if (weapons && !swordDropped && !has(Tool::Sword) && stats.minionsMelted >= tuning.sword_task) {
      swordDropped = true;
      drops.push_back({at, DropKind::Weapon, Tool::Sword, 0.0f});
      events.push_back(ev(EventKind::WeaponDropped, (uint32_t)Tool::Sword, at));
    } else if (rng_.unit() < tuning.cone_drop) {
      drops.push_back({at, DropKind::Cone, Tool::Sword, 0.0f});
      events.push_back(ev(EventKind::ConeDropped, 0, at));
    }
    if (weapons && stats.minionsMelted >= tuning.sugar_task) earn(Tool::Sugar);
  }
}

void Game::spawnMinions() {
  if (!stepping_ || !options.man) return;
  if (tuning.minion_count == 0) return;
  minionWait_ -= kDt;
  if (minionWait_ > 0.0f) return;
  minionWait_ = tuning.minion_every;
  size_t enemies = 0;
  for (const Minion& m : minions) enemies += !m.friendly;
  if (enemies >= minionCap()) return;
  V2 p = player.pos;
  V2 at;
  if (manHere() && distance(man.pos, p) >= 8.0f) {
    at = man.pos;
  } else {
    std::vector<size_t> steps = house.distances(house.cellOf(p));
    std::vector<size_t> far;
    for (size_t i = 0; i < house.rooms.size(); ++i)
      if (steps[i] >= 2 && steps[i] != kNone) far.push_back(i);
    if (far.empty()) return;
    size_t room = far[rng_.below(far.size())];
    at = centre(house.rooms[room].cell);
  }
  minions.emplace_back(at, tuning.minion_health, false, 0.0f);
  events.push_back(ev(EventKind::MinionCame, 0, at));
}

void Game::ageClouds() {
  if (!stepping_) return;
  for (Cloud& c : clouds) c.age += kDt;
  float life = tuning.cloud_life;
  clouds.erase(std::remove_if(clouds.begin(), clouds.end(), [&](const Cloud& c) { return !(c.age < life); }), clouds.end());
}

void Game::endStep() {
  if (!stepping_) return;
  if (player.boost > 0.0f) {
    player.boost -= kDt;
    if (player.boost <= 0.0f) {
      player.boost = 0.0f;
      player.health = fmin(player.health, tuning.max_health);
      events.push_back(ev(EventKind::BoostOver));
    }
  }
  float max = maxHealth();
  player.sinceHit += kDt;
  if (player.sinceHit >= tuning.regen_after) {
    player.health = fmin(player.health + tuning.regen_rate * kDt, fmax(max, player.health));
    player.health = fmin(player.health, max);
  }
  stepping_ = false;
}

uint64_t Game::fingerprint() const {
  uint64_t hash = 0xcbf29ce484222325ull;
  auto eat = [&](uint64_t b) {
    hash ^= b;
    hash *= 0x100000001b3ull;
  };
  for (float f : {player.pos.x, player.pos.z, player.height, player.health, man.pos.x, man.pos.z, man.timer})
    eat((uint64_t)bits(f));
  eat((uint64_t)player.fudge << 32 | (uint64_t)player.farts << 16 | (uint64_t)player.keys);
  eat(tick);
  eat((uint64_t)man.state);
  eat((uint64_t)status);
  eat((uint64_t)shots.size());
  eat((uint64_t)minions.size() | (uint64_t)drops.size() << 16);
  for (const Minion& m : minions) eat((uint64_t)bits(m.pos.x) << 32 | (uint64_t)bits(m.pos.z));
  eat((uint64_t)bits(man.health));
  for (const Shot& s : shots) eat((uint64_t)bits(s.pos.x));
  return hash;
}

std::string eventText(const Event& e) {
  static const char* names[] = {
      "FudgeFired", "FudgeHit", "FudgeSplat", "Frozen", "Fart", "FartHit", "Jingle", "Empty", "Volley",
      "SprinkleHit", "Grabbed", "PulledOut", "Spotted", "Lost", "Key", "Pickup", "Hid", "Unhid", "DoorLocked",
      "DoorGuarded", "Jumped", "Escaped", "Scooped", "Swing", "ConeFired", "SugarFired", "SugarBurst", "Staff",
      "FriendsCame", "ManHit", "Melted", "MinionCame", "MinionHit", "MinionMelted", "MinionBite", "Earned",
      "WeaponDropped", "ConeDropped", "ConeEaten", "BoostOver", "Button", "PuzzleWrong", "PuzzleSolved",
      "CabinetLocked", "FreeRoam"};
  std::string s = names[(int)e.kind];
  char buf[64];
  auto at = [&](V2 p) {
    std::snprintf(buf, sizeof buf, ":%08x,%08x", bits(p.x), bits(p.z));
    s += buf;
  };
  switch (e.kind) {
    case EventKind::FudgeSplat: case EventKind::Fart: case EventKind::SugarBurst: case EventKind::MinionCame:
    case EventKind::MinionHit: case EventKind::MinionMelted: case EventKind::ConeDropped:
      at(e.a);
      break;
    case EventKind::Staff: at(e.a); at(e.b); break;
    case EventKind::Empty: case EventKind::Swing: case EventKind::Earned:
      s += ":"; s += toolName((Tool)e.n);
      break;
    case EventKind::WeaponDropped: s += ":"; s += toolName((Tool)e.n); at(e.a); break;
    case EventKind::PickedUp: s += e.n == (uint32_t)Pickup::Fudge ? ":Fudge" : ":Fart"; break;
    case EventKind::Key: case EventKind::FriendsCame: case EventKind::Button:
      s += ":" + std::to_string(e.n);
      break;
    default: break;
  }
  return s;
}

// ---------------------------------------------------------------- bot.rs

namespace {
float routeLength(const Game& game, V2 to) {
  auto route = game.house.route(game.player.pos, to, kPlayerRadius);
  V2 last = game.player.pos;
  float sum = 0;
  for (V2 p : route) {
    sum = sum + distance(p, last);
    last = p;
  }
  return sum;
}
std::pair<V2, bool> botGoal(const Game& game) {
  const Player& p = game.player;
  bool hurt = p.health < game.tuning.max_health * 0.75f;
  const Drop* detour = nullptr;
  float detourD = 0;
  for (const Drop& d : game.drops) {
    float dd = distance(d.at, p.pos);
    bool want = d.kind == DropKind::Weapon ? dd < 14.0f : hurt && dd < 10.0f;
    if (want && (!detour || dd < detourD)) detour = &d, detourD = dd;
  }
  if (detour) return {detour->at, false};
  auto locked = game.lockedKey();
  std::optional<V2> best;
  float bestLen = 0;
  for (size_t i = 0; i < game.house.keys.size(); ++i) {
    if (game.taken[i] || (locked && *locked == i)) continue;
    float l = routeLength(game, game.house.keys[i]);
    if (!best || l < bestLen) best = game.house.keys[i], bestLen = l;
  }
  if (best) return {*best, false};
  if (locked || (game.weaponsOn() && !game.has(Tool::Spear))) {
    if (!game.solved) {
      if (game.lit < game.house.buttons.size()) return {game.house.buttons[game.lit], true};
    } else {
      for (const Drop& d : game.drops)
        if (d.kind == DropKind::Weapon && d.tool == Tool::Spear) return {d.at, false};
    }
  }
  return {game.house.front.stand, false};
}
}  // namespace

Input Bot::input(const Game& game) {
  const Player& player = game.player;
  Input in;
  if (player.hidden) {
    in.interact = game.tick % 2 == 0;
    return in;
  }
  auto [target, press] = botGoal(game);
  if (target_ != target || replan_ == 0 || path_.empty()) {
    path_ = game.house.route(player.pos, target, kPlayerRadius);
    target_ = target;
    replan_ = 15;
  }
  replan_ -= 1;
  while (path_.size() > 1 && distance(path_[0], player.pos) < 0.3f) path_.erase(path_.begin());
  bool allKeys = std::all_of(game.taken.begin(), game.taken.end(), [](bool t) { return t; });
  bool atDoor = allKeys && target == game.house.front.stand && distance(player.pos, target) < 0.5f;
  bool atButton = press && distance(player.pos, target) < 0.5f;
  if (atDoor) {
    in.interact = true;
  } else if (atButton) {
    in.interact = game.tick % 2 == 0;
  } else if (!path_.empty()) {
    in.walk = clamped((path_.front() - player.pos) * 4.0f, 1.0f);
  }
  const Tuning& t = game.tuning;
  auto sees = [&](V2 at, float range) {
    return distance(at, player.pos) < range && firstHit(game.house.blocks, player.pos, at, 0.0f, 1.0f) < 0;
  };
  std::optional<V2> minion;
  float minionD = 0;
  for (const Minion& m : game.minions) {
    if (m.friendly || !(m.health > 0.0f) || !sees(m.pos, 7.0f)) continue;
    float d = distance(m.pos, player.pos);
    if (!minion || d < minionD) minion = m.pos, minionD = d;
  }
  bool chased = game.manHere() && game.man.state == ManState::Chase;
  in.sprint = (chased || (minion && distance(*minion, player.pos) < 4.0f)) && !atDoor && !atButton;
  std::optional<V2> man;
  if (game.manHere()) man = game.man.pos;
  float manD = man ? distance(*man, player.pos) : std::numeric_limits<float>::max();
  bool minionFirst = minion && distance(*minion, player.pos) < manD;
  if (minion && (minionFirst || !man || !sees(*man, 12.0f))) {
    V2 at = *minion;
    float d = distance(at, player.pos);
    std::optional<Tool> pick;
    if (game.has(Tool::Sword) && d <= t.sword_reach + 0.2f) pick = Tool::Sword;
    else if (game.has(Tool::Spear) && d <= t.spear_reach) pick = Tool::Spear;
    else if (player.fudge > 0) pick = Tool::Fudge;
    else if (game.has(Tool::Pistol) && player.cones > 0) pick = Tool::Pistol;
    if (pick) {
      in.aim = normalized(at - player.pos);
      in.select = pick;
      in.fire = true;
    }
    return in;
  }
  if (man && sees(*man, 12.0f)) {
    V2 to = *man - player.pos;
    float d = length(to);
    bool dazed = game.man.state == ManState::Frozen || game.man.state == ManState::Confused;
    in.aim = normalized(to);
    std::optional<Tool> hitter;
    if (game.has(Tool::Spear) && d <= t.spear_reach) hitter = Tool::Spear;
    else if (game.has(Tool::Sword) && d <= t.sword_reach) hitter = Tool::Sword;
    else if (game.has(Tool::Sugar) && player.sugar > 0 && d > t.sugar_radius + 0.5f && d < t.sugar_range) hitter = Tool::Sugar;
    else if (game.has(Tool::Pistol) && player.cones > 0) hitter = Tool::Pistol;
    if (dazed) {
      if (hitter) in.select = hitter, in.fire = true;
    } else if (d < t.fart_radius - 0.8f && player.farts > 0) {
      in.select = Tool::Fart, in.fire = true;
    } else if (player.fudge > 0) {
      in.select = Tool::Fudge, in.fire = true;
    } else if (hitter) {
      in.select = hitter, in.fire = true;
    }
  }
  return in;
}

// ---------------------------------------------------------------- the ECS

namespace {
Game* stepping(ecs::World& w) {
  Run& r = w.resource<Run>();
  return r.game && !r.paused && !r.half ? &*r.game : nullptr;
}
template <void (Game::*part)()>
void system(ecs::World& w, float) {
  if (Game* g = stepping(w)) (g->*part)();
}
}  // namespace

void install(ecs::World& w) {
  w.resource<Run>();
  // One rules step for every two engine fixed steps (30 Hz of 60).
  w.addSystem(ecs::Phase::FixedUpdate, "ic.begin", [](ecs::World& w, float) {
    Run& r = w.resource<Run>();
    if (!r.game || r.paused) return;
    r.half = !r.half;
    if (!r.half) r.game->beginStep(r.input);
  });
  w.addSystem(ecs::Phase::FixedUpdate, "ic.move", system<&Game::movePlayer>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.fire", system<&Game::fire>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.interact", system<&Game::interact>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.keys", system<&Game::pickUpKeys>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.drops", system<&Game::pickUpDrops>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.shots", system<&Game::fly>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.man", system<&Game::stepMan>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.minions", system<&Game::stepMinions>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.reap", system<&Game::reapStep>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.spawn", system<&Game::spawnMinions>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.clouds", system<&Game::ageClouds>);
  w.addSystem(ecs::Phase::FixedUpdate, "ic.end", [](ecs::World& w, float) {
    Game* g = stepping(w);
    if (!g) return;
    g->endStep();
    Run& r = w.resource<Run>();
    r.stepped++;
    r.input.select.reset();  // a selection is used once
    if (r.onStep) r.onStep(w, *g);
  });
}

}  // namespace icecream
