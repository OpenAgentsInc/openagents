// Ice Cream Man's rules on the Aethyr engine (issue #13): a C++ port of
// OpenAgents' `icecream-rules` crate (third_party/icecream/crates/
// icecream-rules), step for step, so the same seed and the same inputs give
// the same run as the Rust build. tests/icecream-test.cpp replays input
// traces recorded from the Rust build (tools/icecream-trace) and checks every
// step's state fingerprint and events against it.
//
// A deterministic fixed-step simulation at kHz steps a second: the seeded
// house (House), the player and their tools, the Ice Cream Man's state
// machine (Man), his minions (Minion) and the run's status. Nothing here
// draws, reads a key or knows the time of day. No GL or Emscripten, so it
// builds natively; rules.cpp is compiled with -ffp-contract=off so float
// arithmetic rounds exactly as Rust's does.
//
// On the engine the run is one ecs::World resource (icecream::Run) stepped by
// FixedUpdate systems in the original order (install()). The world may drive
// the player's body itself (the shared controller, Input::body); the rules
// then read the body instead of moving it.
#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace ecs { class World; }

namespace icecream {

constexpr uint32_t kHz = 30;
constexpr float kDt = 1.0f / (float)kHz;

// ---- geometry on the floor plane (x right, z toward the viewer) ----

struct V2 {
  float x = 0, z = 0;
  bool operator==(const V2& o) const { return x == o.x && z == o.z; }
  bool operator!=(const V2& o) const { return !(*this == o); }
};
inline V2 v(float x, float z) { return {x, z}; }
inline V2 operator+(V2 a, V2 b) { return {a.x + b.x, a.z + b.z}; }
inline V2 operator-(V2 a, V2 b) { return {a.x - b.x, a.z - b.z}; }
inline V2 operator*(V2 a, float s) { return {a.x * s, a.z * s}; }
inline V2 operator-(V2 a) { return {-a.x, -a.z}; }
float dot(V2 a, V2 b);
float length(V2 a);
float distance(V2 a, V2 b);
V2 normalized(V2 a);       // zero for a tiny vector
V2 clamped(V2 a, float max);
V2 rotated(V2 a, float cos, float sin);

// A solid box on the floor, `height` tall.
struct Block {
  V2 min, max;
  float height = 0;
  bool contains(V2 p) const;
  Block grown(float r) const;
  V2 closest(V2 p) const;
  // Where along a to b (0 to 1) the segment first enters the box, or -1.
  float segment(V2 a, V2 b) const;
  bool operator==(const Block& o) const { return min == o.min && max == o.max && height == o.height; }
};
// Moves a circle of `radius` from `from` by `delta`, sliding along the blocks
// taller than `feet`.
V2 slide(const std::vector<Block>& blocks, V2 from, V2 delta, float radius, float feet);
// Where along a to b (0 to 1) the first block at least min_height tall,
// grown by radius, is hit; -1 for none.
float firstHit(const std::vector<Block>& blocks, V2 a, V2 b, float radius, float minHeight);
float segmentDistance(V2 a, V2 b, V2 p);

// ---- the seeded generator (SplitMix64) ----

struct Rng {
  uint64_t state = 0;
  explicit Rng(uint64_t seed = 0) : state(seed ^ 0x1CEC2EA30000000ull) {}
  uint64_t nextU64();
  size_t below(size_t n);
  float unit();
  template <class T>
  void shuffle(std::vector<T>& items) {
    for (size_t i = items.size(); i-- > 1;) {
      size_t j = below(i + 1);
      std::swap(items[i], items[j]);
    }
  }
  bool operator==(const Rng& o) const { return state == o.state; }
};

// ---- tuning: every number a run reads (tuning.rs) ----

#define ICECREAM_TUNABLES(X)                                                                     \
  X(walk, float, 4.5, 1, 12) X(sprint, float, 7.0, 1, 16) X(jump_speed, float, 5.5, 2, 10)       \
  X(gravity, float, 16.0, 4, 40) X(max_health, float, 100, 10, 1000)                              \
  X(regen_after, float, 10, 0, 120) X(regen_rate, float, 4, 0, 50)                                \
  X(man_wander, float, 2.4, 0.5, 12) X(man_investigate, float, 3.6, 0.5, 12)                      \
  X(man_search, float, 3.2, 0.5, 12) X(man_chase, float, 5.6, 0.5, 14) X(sight, float, 22, 2, 60) \
  X(sight_angle, float, 70, 10, 180) X(notice, float, 4, 0, 20) X(search_time, float, 7, 0, 60)   \
  X(sniff_every, float, 25, 3, 600) X(patrol_keys, uint32_t, 2, 0, 3) X(corners, uint32_t, 1, 0, 1) \
  X(sprinkle_damage, float, 5, 0, 100) X(grab_damage, float, 30, 0, 200)                          \
  X(grab_shove, float, 8, 0, 30) X(grab_reach, float, 1.25, 0.5, 4) X(grab_wait, float, 2, 0.2, 20) \
  X(gloat, float, 1, 0, 10) X(volley_min, float, 3, 0, 30) X(volley_max, float, 15, 1, 40)        \
  X(volley_spread, float, 6, 0, 30) X(pellet_speed, float, 11, 1, 40)                             \
  X(volley_wait, float, 2.4, 0.3, 30) X(pellet_dodge, float, 0.45, 0, 1)                          \
  X(fudge_start, uint32_t, 30, 0, 500) X(fudge_max, uint32_t, 60, 1, 999)                         \
  X(fudge_pickup, uint32_t, 15, 0, 500) X(fudge_rate, float, 6, 0.5, 20)                          \
  X(fudge_speed, float, 16, 2, 40) X(fudge_range, float, 13, 1, 40) X(fudge_slow, float, 2.5, 0, 20) \
  X(slowed, float, 0.5, 0.05, 1) X(freeze_hits, uint32_t, 6, 1, 50)                               \
  X(fudge_memory, float, 4, 0.5, 30) X(frozen, float, 3, 0, 60) X(farts_start, uint32_t, 3, 0, 50) \
  X(farts_max, uint32_t, 5, 1, 99) X(fart_range, float, 4.5, 1, 20) X(fart_radius, float, 3.5, 0.5, 15) \
  X(fart_shove, float, 10, 0, 40) X(confused, float, 4, 0, 60) X(fart_wait, float, 1, 0.1, 20)    \
  X(cloud_life, float, 3, 0.2, 20) X(jingle_noise, float, 30, 0, 80) X(jingle_wait, float, 1.5, 0.2, 20) \
  X(sprint_noise, float, 14, 0, 80) X(fudge_noise, float, 12, 0, 80) X(fridge_noise, float, 8, 0, 80) \
  X(door_noise, float, 25, 0, 80) X(extra_closets, uint32_t, 2, 0, 4) X(unlock, float, 6, 0, 600) \
  X(unlock_guard, float, 8, 0, 60) X(puzzle_key, uint32_t, 1, 0, 1) X(reach, float, 1.4, 0.5, 4)  \
  X(key_reach, float, 0.9, 0.3, 4) X(backrooms, uint32_t, 1, 0, 1) X(loops, uint32_t, 7, 0, 24)   \
  X(house_size, uint32_t, 7, 3, 10) X(key_spread, uint32_t, 1, 0, 1)                              \
  X(earned_weapons, uint32_t, 1, 0, 1) X(man_health, float, 400, 10, 10000)                       \
  X(sword_damage, float, 25, 0, 500) X(sword_reach, float, 1.9, 0.5, 6) X(sword_wait, float, 0.45, 0.1, 10) \
  X(sword_task, uint32_t, 1, 1, 50) X(spear_damage, float, 35, 0, 500) X(spear_reach, float, 3.4, 1, 10) \
  X(spear_wait, float, 0.8, 0.1, 10) X(pistol_damage, float, 15, 0, 500) X(pistol_rate, float, 3, 0.2, 20) \
  X(pistol_speed, float, 22, 2, 60) X(pistol_range, float, 18, 1, 60) X(pistol_ammo, uint32_t, 12, 0, 500) \
  X(pistol_max, uint32_t, 40, 1, 999) X(pistol_pickup, uint32_t, 8, 0, 500)                       \
  X(pistol_task, uint32_t, 1, 1, 50) X(sugar_damage, float, 60, 0, 1000) X(sugar_radius, float, 2.5, 0.5, 10) \
  X(sugar_speed, float, 12, 2, 60) X(sugar_range, float, 14, 1, 60) X(sugar_wait, float, 1.2, 0.1, 20) \
  X(sugar_ammo, uint32_t, 4, 0, 200) X(sugar_max, uint32_t, 10, 1, 999) X(sugar_pickup, uint32_t, 2, 0, 200) \
  X(sugar_task, uint32_t, 4, 1, 100) X(minion_count, uint32_t, 3, 0, 12)                          \
  X(minion_first, float, 25, 0, 600) X(minion_every, float, 15, 1, 600)                           \
  X(minion_growth, float, 60, 0, 600) X(minion_speed, float, 3.4, 0.5, 12)                        \
  X(minion_health, float, 30, 1, 1000) X(minion_damage, float, 6, 0, 100)                         \
  X(minion_bite_wait, float, 1, 0.1, 20) X(minion_sight, float, 14, 1, 80)                        \
  X(fudge_minion_damage, float, 10, 0, 500) X(fart_minion_damage, float, 40, 0, 500)              \
  X(cone_drop, float, 0.35, 0, 1) X(cone_boost, float, 0.5, 0, 3) X(cone_time, float, 10, 0, 120) \
  X(staff_length, float, 10, 1, 40) X(staff_damage, float, 30, 0, 1000) X(staff_wait, float, 2, 0.2, 30) \
  X(staff_minions, uint32_t, 3, 1, 12) X(staff_minion_life, float, 20, 1, 600)                    \
  X(free_roam, uint32_t, 1, 0, 1) X(yellow, float, 1, 0, 1) X(fog_near, float, 3, 0, 100)         \
  X(fog_far, float, 18, 1, 120) X(flicker, float, 0.35, 0, 1) X(buzz, float, 0.8, 0, 1)           \
  X(first_person, uint32_t, 0, 0, 1)

struct Tuning {
#define ICECREAM_FIELD(name, type, def, lo, hi) type name = (type)(def);
  ICECREAM_TUNABLES(ICECREAM_FIELD)
#undef ICECREAM_FIELD
  // Sets a value by name within its bounds; false (and why) otherwise.
  bool set(const std::string& name, double value, std::string* why = nullptr);
  std::optional<double> get(const std::string& name) const;
  float sightCos() const;
  static Tuning original();
  bool operator==(const Tuning& o) const;
};

enum class Difficulty { Easy, Normal, Hard };
Tuning tuningFor(Difficulty d);
const char* difficultyId(Difficulty d);
std::optional<Difficulty> difficultyFromId(const std::string& id);

// Fixed numbers (tuning.rs constants the rules use directly).
constexpr float kPlayerRadius = 0.35f, kManRadius = 0.5f, kMinionRadius = 0.3f, kShoveFade = 6.0f;
constexpr size_t kVolleyPellets = 5;

// ---- the house (layout.rs) ----

constexpr float kCell = 10.0f, kWall = 0.3f, kWallHeight = 2.6f, kDoor = 2.2f, kDoorHeight = 2.1f;
constexpr float kPlayerHeight = 1.35f, kEyeHeight = 1.2f, kManHeight = 2.35f, kLane = 1.5f;
constexpr size_t kMaxSize = 10, kKeys = 3, kButtons = 3;

enum class Module { Bedroom, Kitchen, LivingRoom, Bathroom, Laundry, Hallway, Stairwell, FreezerRoom, Backroom };
const char* moduleName(Module m);
enum class Flavor { Strawberry, Mint, Vanilla, Chocolate };
enum class PropKind {
  Bed, Closet, Dresser, Counter, Fridge, Table, Sofa, Tv, Tub, Toilet, Sink, Washer, Shelf, Stairs,
  Freezer, Pillar, Plant, Partition
};
struct Prop {
  PropKind kind;
  V2 min, max;
  float height;
  bool usable = false;
  V2 useAt{};
};
struct ModuleDef {
  std::vector<Prop> props;
  std::vector<V2> keySlots;
  bool hasSpare = false;
  Prop spare{};
};
const ModuleDef& moduleDef(Module m);

using Cell = std::pair<size_t, size_t>;  // column, row
enum class Side { North, East, South, West };
V2 outward(Side s);

struct Room {
  Cell cell;
  Module module;
  Flavor flavor;
  bool doors[4] = {false, false, false, false};  // by Side
};
enum class Pickup { Fudge, Fart };
struct Spot {
  V2 at;
  Block block;
  size_t room;
};
struct FrontDoor {
  size_t room = 0;
  Side side = Side::North;
  V2 at, stand;
};
struct Shape {
  size_t size;
  size_t loops;
  bool backrooms, spread, puzzleKey;
  static Shape of(const Tuning& t);
};

V2 centre(Cell cell);
Cell cellOfAny(V2 p);  // clamped to the biggest grid

struct House {
  uint64_t seed = 0;
  size_t cols = 0, rows = 0;
  std::vector<Room> rooms;
  std::vector<Block> blocks;
  std::vector<Spot> closets;
  std::vector<std::pair<Spot, Pickup>> fridges;
  std::vector<V2> keys;
  V2 spawn;
  size_t spawnRoom = 0;
  V2 manStart;
  FrontDoor front;
  std::vector<std::pair<size_t, Prop>> extras;
  std::vector<V2> buttons;
  V2 cabinet;
  bool backrooms = false;
  std::optional<size_t> cabinetKey;

  static House of(uint64_t seed, const Tuning& t);
  static House generate(uint64_t seed, Shape shape);
  static House build(uint64_t seed, size_t loops, bool backrooms);
  static House airbnb(uint64_t seed);  // House::new
  static House tuned(uint64_t seed, size_t extra);

  Cell cellOf(V2 p) const;
  size_t index(Cell c) const { return c.second * cols + c.first; }
  size_t roomOf(V2 p) const { return index(cellOf(p)); }
  std::optional<Cell> neighbour(Cell c, Side s) const;
  std::vector<Prop> props(size_t room) const;
  std::vector<size_t> distances(Cell from) const;  // SIZE_MAX where unreachable
  std::vector<Cell> cellPath(Cell from, Cell to) const;
  static V2 doorway(Cell a, Cell b);
  std::vector<std::pair<V2, bool>> doorways() const;  // middle, wall runs along x
  float headroom(V2 p, float radius) const;
  std::vector<Cell> neighbours(Cell c) const;
  std::vector<V2> route(V2 from, V2 to, float radius) const;
  bool open(V2 p, float radius) const;

 private:
  void buildBlocks(Rng& rng);
  void placePuzzle(size_t frontRoom, bool spread);
  static House withClosets(House house, size_t extra);
};

// ---- the run (game.rs, man.rs, minion.rs) ----

enum class Tool { Fudge, Fart, Keys, Sword, Spear, Pistol, Sugar, Staff };
constexpr int kTools = 8;
const char* toolName(Tool t);

enum class ManState { Wander, Investigate, Chase, Search, Frozen, Confused };
enum class Status { Playing, Escaped, Melted, Scooped };
enum class Prompt { Hide, Leave, Fridge, Unlock, Guarded, Locked, Button, Cabinet };

enum class EventKind {
  FudgeFired, FudgeHit, FudgeSplat, Frozen, Fart, FartHit, Jingle, Empty, Volley, SprinkleHit, Grabbed,
  PulledOut, Spotted, Lost, Key, PickedUp, Hid, Unhid, DoorLocked, DoorGuarded, Jumped, Escaped, Scooped,
  Swing, ConeFired, SugarFired, SugarBurst, Staff, FriendsCame, ManHit, Melted, MinionCame, MinionHit,
  MinionMelted, MinionBite, Earned, WeaponDropped, ConeDropped, ConeEaten, BoostOver, Button, PuzzleWrong,
  PuzzleSolved, CabinetLocked, FreeRoam
};
// Something that happened this step, for sounds and effects. n is a count,
// a Tool or a Pickup; a and b are places.
struct Event {
  EventKind kind;
  uint32_t n = 0;
  V2 a{}, b{};
  bool operator==(const Event& o) const { return kind == o.kind && n == o.n && a == o.a && b == o.b; }
};
// The event as the trace format writes it (tools/icecream-trace).
std::string eventText(const Event& e);

// The player's body when the world moves it (the shared controller).
struct Body {
  V2 pos;
  float height = 0;  // feet above the floor
  bool moving = false, sprinting = false;
};

struct Input {
  V2 walk;  // where to walk, up to length 1, world space
  bool sprint = false, jump = false, fire = false;
  V2 aim;
  bool interact = false;
  std::optional<Tool> select;
  std::optional<Body> body;  // set: the world moved the player this step
};

struct Options {
  bool man = true;  // whether the Ice Cream Man is in the house
};

enum class DropKind { Cone, Weapon };
struct Drop {
  V2 at;
  DropKind kind;
  Tool tool = Tool::Sword;  // a weapon's
  float age = 0;
};
constexpr float kConeLife = 45.0f;
constexpr size_t kMaxFriends = 24;

enum class ShotKind { Fudge, Cone, Sugar, Sprinkle };
struct Shot {
  ShotKind kind;
  uint8_t colour = 0;  // a sprinkle's, 0-4
  V2 pos;
  float height;
  V2 vel;
  float left;
};
struct Cloud {
  V2 at;
  float age = 0;
};

struct Player {
  V2 pos;
  float height = 0, vy = 0;
  V2 facing;
  float health = 0;
  Tool tool = Tool::Fudge;
  uint32_t fudge = 0, farts = 0, cones = 0, sugar = 0;
  std::vector<Tool> owned;
  float boost = 0;
  uint32_t keys = 0;
  std::optional<size_t> hidden;
  V2 shove;
  float sinceHit = 0, fireWait = 0, unlock = 0;
  bool moving = false, sprinting = false;
};

struct Stats {
  uint32_t hitsTaken = 0, fudgeShots = 0, fudgeHits = 0, farts = 0, freezes = 0, minionsMelted = 0,
           conesEaten = 0, manDamage = 0;
};
struct RunCard {
  bool escaped, melted;
  uint32_t minionsMelted, seconds, keys, hitsTaken;
  std::optional<uint32_t> accuracy;
};

enum class ActKind { Volley, Grab, PullOut, Spotted, Lost, Froze };
struct Act {
  ActKind kind;
  V2 dir{};
};
struct Senses {
  V2 player;
  bool hidden = false;
  std::optional<V2> closet;
  const std::vector<std::pair<V2, float>>* noises = nullptr;
  uint32_t keys = 0;
};

struct Man {
  V2 pos, facing;
  ManState state = ManState::Wander;
  std::vector<V2> path;
  std::optional<V2> goal, lastSeen;
  float timer = 0, slow = 0;
  uint32_t fudgeHits = 0;
  float fudgeMemory = 0;
  V2 shove;
  float volleyWait = 0, grabWait = 0, gloat = 0, sniff = 0;
  bool sawHide = false, moving = false;
  uint32_t stuck = 0;
  float replan = 0;
  bool looking = false;
  Rng rng;
  Tuning tuning;
  float health = 0;

  static Man tuned(V2 at, uint64_t seed, Tuning t);
  bool canSee(const House& house, V2 player) const;
  bool fudge();
  bool hurt(float damage);
  void fart(V2 at);
  std::vector<Act> step(const House& house, const Senses& senses);

 private:
  void headTo(const House& house, V2 goal);
  bool follow(const House& house, float speed);
  void walk(const House& house, V2 toward, float speed);
  float speed(float base) const;
};

struct Minion {
  V2 pos, facing;
  float health;
  bool friendly;
  float life;
  bool moving = false;
  float flash = 0, biteWait = 0.5f;
  std::vector<V2> path;
  std::optional<V2> goal;
  float replan = 0;

  Minion(V2 at, float health, bool friendly, float life);
  void tick();
  void go(const House& house, V2 goal, float speed, float near);
  void wander(const House& house, Rng& rng, float speed);

 private:
  void stepToward(const House& house, V2 toward, float speed);
};

class Game {
 public:
  House house;
  Player player;
  Man man;
  Options options;
  Tuning tuning;
  std::vector<Shot> shots;
  std::vector<Cloud> clouds;
  std::vector<bool> taken, opened;
  Status status = Status::Playing;
  uint64_t tick = 0;
  std::vector<Event> events;  // this step's
  Stats stats;
  std::vector<Minion> minions;
  std::vector<Drop> drops;
  uint32_t lit = 0;
  bool solved = false, manMelted = false, freeRoam = false;
  std::optional<Status> won;

  Game(uint64_t seed, Options options, Tuning tuning = {});

  bool weaponsOn() const { return tuning.earned_weapons == 1; }
  std::optional<size_t> lockedKey() const;
  bool puzzleOn() const { return weaponsOn() || house.cabinetKey.has_value(); }
  bool doorGuarded() const;
  uint32_t minionCap() const;
  bool has(Tool t) const;
  float maxHealth() const;
  void arm();
  bool keepPlaying();
  float seconds() const { return (float)tick / (float)kHz; }
  RunCard runCard() const;
  bool manHere() const { return options.man && !manMelted; }
  std::optional<V2> closetSpot() const;
  std::optional<Prompt> prompt() const;
  void step(const Input& input);
  uint64_t fingerprint() const;

  // Exposed for tests (game.rs's own tests reach these).
  void hurt(float damage);
  void damageMinion(size_t i, float damage);
  void reap();
  void burst(V2 at);
  bool clear(V2 a, V2 b) const;
  bool swordDropped = false;

  // The step's parts, in order, for the ECS systems (install()).
  void beginStep(const Input& input);
  void movePlayer();
  void fire();
  void interact();
  void pickUpKeys();
  void pickUpDrops();
  void fly();
  void stepMan();
  void stepMinions();
  void reapStep();
  void spawnMinions();
  void ageClouds();
  void endStep();

 private:
  std::vector<std::pair<V2, float>> noises_;
  bool wasInteract_ = false, wasJump_ = false;
  uint8_t sprinkle_ = 0;
  float minionWait_ = 0;
  Rng rng_;
  // This step's input and its edges.
  Input in_;
  bool pressed_ = false, jumped_ = false, stepping_ = false;

  void earn(Tool t);
  std::optional<std::pair<Prompt, size_t>> target() const;
  void melee(V2 from, V2 aim, float reach, float cos, float damage);
  void staff(V2 from, V2 aim);
  void damageMan(float damage);
};

// The bot (bot.rs's Bot): walks to the nearest key, solves the puzzle, holds
// E at the front door, fights on the way. For tests and the attract camera.
class Bot {
 public:
  Input input(const Game& game);

 private:
  std::vector<V2> path_;
  std::optional<V2> target_;
  uint32_t replan_ = 0;
};
constexpr uint64_t kEscapeSeed = 7;

// ---- on the engine ----

// The run as an ECS resource. The world sets `input` before the step; the
// FixedUpdate systems step the game every other fixed step (30 Hz from the
// engine's 60 Hz), and `stepped` counts the steps (each step's events are in
// game->events until the next).
struct Run {
  std::optional<Game> game;
  Input input;
  bool paused = false;
  uint64_t stepped = 0;
  bool half = false;  // the fixed step between two rules steps
  // Called after every rules step, with its events (sounds, effects, HUD).
  void (*onStep)(ecs::World&, const Game&) = nullptr;
};
// Adds the rules' systems to a world (FixedUpdate, in game.rs's step order).
void install(ecs::World& w);

}  // namespace icecream
