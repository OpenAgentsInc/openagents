// Independent contracts around the actual Coax producer. Numeric vertex parity
// with the separately repaired C++ oracle is checked by mesh-check.c.
#include "IceCream.h"
#include <inttypes.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define REQUIRE(q) do {if(!(q)){fprintf(stderr,"band check failed at%d: %s\n",__LINE__,#q);return 1;}}while(0)
static uint32_t bits(float x){uint32_t n;memcpy(&n,&x,4);return n;}
static int same(coax_t_Vtx a,coax_t_Vtx b){return !memcmp(&a,&b,sizeof a);}
int main(void){
 _Static_assert(sizeof(coax_t_Vtx)==44,"eleven recorded four-byte vertex words");
 const coax_t_Vtx marker={.p={91,92,93},.n={94,95,96},.hull={97,98,99},.colour=0xabcdef,.weight=100};
 uint64_t cases=0,words=0;
 for(int orientation=0;orientation<4;orientation++)for(int base=0;base<8;base++){
  coax_t_Vtx full[128],short_view[128],trim[72],middle[36];
  for(int j=0;j<128;j++)full[j]=marker;
  REQUIRE(icecream_band_native((coax_v_t_Vtx){full,128},base,orientation,-2.25f,4.75f)==base+108);
  REQUIRE(icecream_piece_native((coax_v_t_Vtx){trim,72},0,orientation,-2.25f,4.75f,0,.28f,0x445566,.05f)==36);
  REQUIRE(icecream_piece_native((coax_v_t_Vtx){trim,72},36,orientation,-2.25f,4.75f,2.6f-.22f,2.6f,0x445566,.05f)==72);
  REQUIRE(icecream_piece_native((coax_v_t_Vtx){middle,36},0,orientation,-2.25f,4.75f,.28f,2.6f-.22f,0x112233,0)==36);
  float bottom=-INFINITY,top=INFINITY;
  for(int j=0;j<36;j++){bottom=fmaxf(bottom,trim[j].p.y);top=fminf(top,trim[j+36].p.y);}
  REQUIRE(bottom>.27f&&bottom<.29f&&top>2.37f&&top<2.39f);
  for(int j=0;j<36;j++){
   REQUIRE(bits(full[base+j].p.y)==bits(bottom)||bits(full[base+j].p.y)==bits(top));
   middle[j].p.y=full[base+j].p.y;REQUIRE(same(full[base+j],middle[j]));
   REQUIRE(same(full[base+36+j],trim[j]));REQUIRE(same(full[base+72+j],trim[36+j]));
  }
  for(int cap=0;cap<=base+111;cap++){
   for(int j=0;j<128;j++)short_view[j]=marker;
   REQUIRE(icecream_band_native((coax_v_t_Vtx){short_view,cap},base,orientation,-2.25f,4.75f)==base+108);
   for(int j=0;j<128;j++){
    int written=j>=base&&j<base+108&&base+((j-base)/3)*3+3<=cap;
    REQUIRE(same(short_view[j],written?full[j]:marker));words+=11;
   }
   cases++;
  }
 }
 printf("bands: %" PRIu64 " short-view cases, %" PRIu64 " vertex words, exact seams/unchanged trims/canaries pass\n",cases,words);
 return 0;
}
