from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/belt-stair';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={
'belt-base':Path('/tmp/aethyr-ch11-golden-belt-current'),
'belt-integer':Path('/tmp/aethyr-ch11-belt-current-shaders-old-executor'),
'belt-incomplete-sine-control':Path('/tmp/aethyr-ch11-belt-old-shader-controls'),
'belt-complete-sine-control':Path('/tmp/aethyr-ch11-belt-all-old-shader-controls'),
'stair-base':Path('/tmp/aethyr-ch11-golden-stair-current'),
'stair-integer':Path('/tmp/aethyr-ch11-stair-current-shaders-old-executor'),
'stair-sine-control':Path('/tmp/aethyr-ch11-stair-old-shader-controls')}
controls={n:json.loads((d/'comparison.json').read_text())for n,d in paths.items()}
for r in controls.values():assert r['same_producer_wasm']and r['same_inputs']and not r['source_changes']
for app in ['belt','stair']:
 assert controls[app+'-integer']['identical'];assert controls[app+'-integer']['legacy_sha256']==controls[app+'-base']['generic_sha256']
assert controls['belt-complete-sine-control']['legacy_sha256']==controls['belt-base']['legacy_sha256']
assert controls['belt-incomplete-sine-control']['legacy_sha256']!=controls['belt-base']['legacy_sha256']
assert controls['stair-sine-control']['legacy_sha256']==controls['stair-base']['legacy_sha256']
stocks={n:Path('/tmp/'+d)for n,d in {'original-mixed-failure':'aethyr-ch11-stock-final-three-generic','original-legacy':'aethyr-ch11-stock-belt-stair-legacy','migrated-generic':'aethyr-ch11-stock-belt-stair-migrated-generic','migrated-integer':'aethyr-ch11-stock-belt-stair-migrated-integer'}.items()}
stock={}
for n,d in stocks.items():
 e=json.loads((d/'execution.json').read_text());s=json.loads((d/'server-receipt.json').read_text());assert not s['source_changes'];report=json.loads((d/'report.json').read_text());stock[n]={'execution':e,'report':report,'log':(d/'execution.log').read_text()}
 if n!='original-mixed-failure':assert e['status']=='pass'
 if n.startswith('migrated'):
  assert all((case+': matches its golden (0 blocks changed, '+str(limit)+' allowed')in stock[n]['log']for case,limit in [('belt-2200',8),('hold-the-stair',6)])
observed={};pool={}
for d in paths.values():
 for route in ['legacy','generic']:
  r=json.loads((d/route/'receipt.json').read_text());assert not r['source_changes']and not r['exceptions']and not r['errors']
  for f,h in {**r['source_inputs'],**r['served']}.items():
   p=Path(f);assert p.is_file()and sha(p)==h,(p,h);observed[f]=h;pool.setdefault(h,p)
review=Path('/tmp/aethyr-ch11-belt-stair-visible-review');observations=json.loads((review/'observations.json').read_text())
for name,r in observations['cases'].items():assert r['baseline_updated']and sha(root/'coax/web/goldens'/(name+'.png'))==r['after_sha256']
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 def add(p,n):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;tar.addfile(i,io.BytesIO(b))
 for label,d in paths.items():
  for p in sorted(d.rglob('*')):
   if p.is_file():add(p,'controls/'+label+'/'+str(p.relative_to(d)))
 for label,d in stocks.items():
  for p in sorted(d.glob('*')):
   if p.is_file():add(p,'stock/'+label+'/'+p.name)
 for p in sorted(review.iterdir()):
  if p.is_file():add(p,'before-after/'+p.name)
 for label in ['belt','stair']:
  for p in sorted(Path('/tmp/aethyr-ch11-'+label+'-noise-controls').iterdir()):
   if p.is_file():add(p,'variants/'+label+'/'+p.name)
 for h,p in sorted(pool.items()):add(p,'consumed/'+h+'/'+p.name)
 for p in [Path(__file__),Path('/tmp/aethyr-ch11-golden-server-belt-stair-migrated.ts'),Path('/tmp/aethyr-ch11-run-stock-golden-belt-stair-migrated.py'),root/'coax/web/goldens.ts',root/'coax/web/golden-policy.ts',root/'coax/web/golden-pages.ts',root/'coax/web/realms.ts',root/'apps/openagents-web/realms.json']:add(p,'tools/'+p.name)
assert all(sha(Path(p))==h for p,h in observed.items())
r={'schema':'aethyr.render.belt-stair-visible-migration.v1','status':'pass_for_two_explicit_visible_migrations','cases':['belt-2200','hold-the-stair'],'exact_controls':controls,'stock_gates':stock,'baseline_migration':observations,'source_inputs':observed,'source_changes':[],'scope':'Belt8block andStair6block allowances unchanged; both migratedexecutor routes report0changedblocks. Firststockbatch retainsEverglade refusal asfailure. Two independentvisual reviews precedePNGupdates. Consumedbytes from exact rawcomparisons retained, includingproducerWasms; source/headerbuild evidence lives indefaultbuild records. CPU/GPU numerical acceptance is separate.','archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size}}
(out/'qualification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['archive']))
