from pathlib import Path
import hashlib,json,re,tarfile,shutil
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/fairy';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=Path('/tmp/aethyr-ch11-golden-fairy');source=(base/'observed-host.js').read_text();source=source[:source.rindex('\nglobalThis.coaxial.goldenStatus =')]
source=source.replace('const readback = probe && probeArmed && ++frames >= 1 && !gpu.probed ? readBack(encoder, texture) : null;','const readback = probe && ++frames >= 1 && !gpu.probed ? readBack(encoder, texture) : null;')
a='''if (readback) report({ ...readback, rendererSnapshot: {
  admitted_hud: n, admitted_draws: draws, vertex_stride: arena.floats,
  uniform_bytes: Array.from(new Uint8Array(memory.buffer, arena.uniforms, arena.uniformFloats * 4)),
  vertex_bytes: Array.from(new Uint8Array(memory.buffer, arena.vertices, n * arena.floats * 4)),
  draw_bytes: draws ? Array.from(new Uint8Array(memory.buffer, x.coaxial_draws(arena.state), draws * 16)) : [],
} }, texture);''';assert source.count(a)==1;source=source.replace(a,'if (readback) report(readback, texture);')
a='''  const tight = new Uint8Array(w * h * pixelBytes);
  for (let y = 0; y < h; y++) tight.set(px.subarray(y * row, y * row + w * pixelBytes), y * w * pixelBytes);
  globalThis.coaxial.renderCapture = { schema: "aethyr.render.legacy-readback.v1", width: w, height: h,
    format: texture.format, row_bytes: w * pixelBytes, bytes: Array.from(tight), ...rendererSnapshot };
  buffer.unmap();buffer.destroy();return;
  const x0 = Math.floor(w * 0.3)''';assert source.count(a)==1;source=source.replace(a,'  const x0 = Math.floor(w * 0.3)');recovered=base/'retained-host.js';recovered.write_text(source)
expected=next(v for k,v in json.loads((base/'legacy/receipt.json').read_text())['served'].items()if k.endswith('/coax/web/host.js'));assert sha(recovered)==expected

paths={'base':base,'integer':Path('/tmp/aethyr-ch11-fairy-visible-isolation/integer-capture'),'sin':Path('/tmp/aethyr-ch11-fairy-visible-isolation/sin-capture')}
controls={n:json.loads((d/'comparison.json').read_text())for n,d in paths.items()};assert controls['integer']['identical'];assert controls['base']['legacy_sha256']==controls['sin']['legacy_sha256'];assert controls['base']['generic_sha256']==controls['integer']['legacy_sha256'];assert all(not x['source_changes']and x['same_inputs']and x['same_producer_wasm']for x in controls.values())
stocks={n:Path('/tmp/aethyr-ch11-stock-fairy-'+n)for n in ['generic','sin','migrated-generic','migrated-integer']}
stock={}
for n,d in stocks.items():
 r=json.loads((d/'execution.json').read_text());f=json.loads((d/'server-receipt.json').read_text());assert not f['source_changes'];stock[n]={'execution':r,'source_changes':f['source_changes'],'log':(d/'execution.log').read_text()}
assert all(stock[n]['execution']['status']=='pass'for n in ['sin','migrated-generic','migrated-integer'])
alternate=Path('/tmp/aethyr-ch11-fairy-visible-isolation/sin-capture');host_recovery=Path('/tmp/aethyr-ch11-recover-fairy-intermediate.py')
prefix=Path(__file__).read_text().split('paths={')[0].replace("base=Path('/tmp/aethyr-ch11-golden-fairy')", "base=Path('/tmp/aethyr-ch11-fairy-visible-isolation/sin-capture')")
# Reverse precisely the same readback instrumentation from that later source epoch.
exec(compile(prefix,str(host_recovery),'exec'),{})
alternate_host=alternate/'retained-host.js'
pool={};missing=[]
def observe(filename,digest):
 p=Path(filename)
 if not p.is_file()or sha(p)!=digest:
  if filename.endswith('/coax/web/host.js')and sha(recovered)==digest:p=recovered
  elif filename.endswith('/coax/web/host.js')and sha(alternate_host)==digest:p=alternate_host
  elif filename.endswith('/coax/web/render.js')and sha(root/'docs/verification/data/aethyr-ch11-2026-11-01/browser-effects/media-retirement-sources/render.js')==digest:p=root/'docs/verification/data/aethyr-ch11-2026-11-01/browser-effects/media-retirement-sources/render.js'
  elif filename.endswith('/coax/web/render.js')and sha(root/'docs/verification/data/aethyr-ch11-2026-11-01/browser-effects/render-a3d9ce-source.js')==digest:p=root/'docs/verification/data/aethyr-ch11-2026-11-01/browser-effects/render-a3d9ce-source.js'
  else:missing.append({'path':filename,'sha256':digest});return
 pool.setdefault(digest,p)
for directory in paths.values():
 for route in ['legacy','generic']:
  r=json.loads((directory/route/'receipt.json').read_text())
  for f,h in r['served'].items():observe(f,h)
for directory in stocks.values():
 for f,h in json.loads((directory/'server-receipt.json').read_text())['served'].items():observe(f,h)
assert not missing,missing
obsdir=Path('/tmp/aethyr-ch11-fairy-before-after');observations=json.loads((obsdir/'observations.json').read_text());assert observations['baseline_updated']
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 for label,directory in paths.items():
  for p in directory.rglob('*'):
   if p.is_file():tar.add(p,arcname='controls/'+label+'/'+str(p.relative_to(directory)))
 for label,directory in stocks.items():
  for p in directory.glob('*'):
   if p.is_file():tar.add(p,arcname='stock/'+label+'/'+p.name)
 for p in obsdir.glob('*'):
  if p.is_file():tar.add(p,arcname='before-after/'+p.name)
 for p in Path('/tmp/aethyr-ch11-fairy-visible-isolation').glob('*'):
  if p.is_file():tar.add(p,arcname='variants/'+p.name)
 for h,p in pool.items():tar.add(p,arcname='served/'+h+'/'+p.name)
 for p in Path('/tmp/aethyr-ch11-typed-hosts-one/admitted/fairy').glob('*'):tar.add(p,arcname='admitted/'+p.name)
 for rel in ['coax/web/goldens.ts','coax/web/golden-pages.ts','coax/web/golden-policy.ts','coax/web/realms.ts','apps/openagents-web/realms.json']:
  tar.add(root/rel,arcname='walk-sources/'+rel)
 for p in [Path('/tmp/aethyr-ch11-golden-server-current.ts'),Path('/tmp/aethyr-ch11-run-stock-golden-current.py'),Path(__file__)]:tar.add(p,arcname='tools/'+p.name)
record={'schema':'aethyr.render.fairy-noise-migration.v1','status':'pass_for_explicit_visible_noise_migration','scope':'Existing production Fairy Forest screenshot, unchanged six-block allowance. Exact matching producer controls isolate portable integer noise from host/pass changes; numerical CPU/GPU parity remains separate.','compiler_sha256':sha(root/'coax/bin/coax'),'exact_controls':controls,'stock_gates':stock,'baseline_migration':observations,'retention':{'archive':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size,'missing':missing,'source_epoch':'Exact served files retained by observed digest. Original host recovered by reversing only retained readback instrumentation and verified against original served SHA. Earlier render.js retained from its original browser-effects snapshot.'}}
(out/'noise-migration.json').write_text(json.dumps(record,indent=2)+'\n');print(record['retention']['bytes'])
