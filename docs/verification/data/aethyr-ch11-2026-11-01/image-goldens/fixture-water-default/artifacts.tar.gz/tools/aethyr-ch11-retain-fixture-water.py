from pathlib import Path
import hashlib,json,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/fixture-water-default';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={'fixture-base':Path('/tmp/aethyr-ch11-golden-fixture-current'),'fixture-integer':Path('/tmp/aethyr-ch11-noise-fixture-lowpoly-integer-capture'),'fixture-sin':Path('/tmp/aethyr-ch11-noise-fixture-lowpoly-sin-capture'),'fixture-sin-hardware':Path('/tmp/aethyr-ch11-noise-fixture-lowpoly-sin-hardware-capture'),'waterlab-base':Path('/tmp/aethyr-ch11-golden-waterlab-current'),'waterlab-integer':Path('/tmp/aethyr-ch11-noise-waterlab-integer-capture'),'waterlab-sin':Path('/tmp/aethyr-ch11-noise-waterlab-sin-capture')}
controls={n:json.loads((d/'comparison.json').read_text())for n,d in paths.items()};assert all(d['same_inputs']and d['same_producer_wasm']and not d['source_changes']for d in controls.values());assert controls['fixture-integer']['identical']and controls['waterlab-integer']['identical'];assert controls['fixture-sin-hardware']['legacy_sha256']==controls['fixture-base']['legacy_sha256'];assert controls['waterlab-sin']['legacy_sha256']==controls['waterlab-base']['legacy_sha256']
stocks={'initial-generic':Path('/tmp/aethyr-ch11-stock-current-four'),'original-legacy':Path('/tmp/aethyr-ch11-stock-fixture-water-legacy'),'restored-sine':Path('/tmp/aethyr-ch11-stock-fixture-water-sin'),'migrated-generic':Path('/tmp/aethyr-ch11-stock-fixture-water-migrated-generic'),'migrated-integer':Path('/tmp/aethyr-ch11-stock-fixture-water-migrated-integer')};stock={};pool={}
def observe(f,h):
 p=Path(f);assert p.is_file()and sha(p)==h,(f,h);pool.setdefault(h,p)
for name,d in stocks.items():
 e=json.loads((d/'execution.json').read_text());s=json.loads((d/'server-receipt.json').read_text());assert not s['source_changes'];stock[name]={'status':e['status'],'seconds':e['elapsed_seconds'],'log':(d/'execution.log').read_text()}
 for f,h in s['served'].items():observe(f,h)
assert all(stock[n]['status']=='pass'for n in ['original-legacy','restored-sine','migrated-generic','migrated-integer'])
for d in paths.values():
 for route in ['legacy','generic']:
  r=json.loads((d/route/'receipt.json').read_text())
  for f,h in r['served'].items():observe(f,h)
obsdir=Path('/tmp/aethyr-ch11-fixture-water-before-after');observations=json.loads((obsdir/'observations.json').read_text());assert all(v['baseline_updated']for v in observations['cases'].values())
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 for label,d in paths.items():
  for p in d.rglob('*'):
   if p.is_file():tar.add(p,arcname='controls/'+label+'/'+str(p.relative_to(d)))
 for label,d in stocks.items():
  for p in d.glob('*'):
   if p.is_file():tar.add(p,arcname='stock/'+label+'/'+p.name)
 for p in obsdir.rglob('*'):
  if p.is_file():tar.add(p,arcname='before-after/'+str(p.relative_to(obsdir)))
 for app in ['fixture','waterlab']:
  d=Path('/tmp/aethyr-ch11-'+app+'-noise-controls')
  for p in d.glob('*'):
   if p.is_file():tar.add(p,arcname='variants/'+app+'/'+p.name)
 for h,p in pool.items():tar.add(p,arcname='served/'+h+'/'+p.name)
 for p in [Path(__file__),Path('/tmp/aethyr-ch11-noise-controls.py'),Path('/tmp/aethyr-ch11-sampling-controls.py'),Path('/tmp/aethyr-ch11-golden-server-current.ts'),Path('/tmp/aethyr-ch11-run-stock-golden-current.py')]:tar.add(p,arcname='tools/'+p.name)
 for rel in ['coax/web/goldens.ts','coax/web/golden-pages.ts','coax/web/golden-policy.ts','coax/web/realms.ts','apps/openagents-web/realms.json']:tar.add(root/rel,arcname='walk-sources/'+rel)
record={'schema':'aethyr.render.default-fixture-water-visible-migration.v1','status':'pass_for_two_explicit_visible_migrations','exact_controls':controls,'stock_gates':stock,'baseline_migration':observations,'source_epoch':'All consumed served bytes retained by digest, current host214003ec and render824e1128. Old-executor and shared-renderer producer bytes match; decoded physical texture equivalence is established separately by texture qualification.','fixture_sampling_isolation':'Noise-only restoration leaves145pixels/207channels different from oldraw inside textured object bounds x90..230,y39..88. Restoring the old implicit texture-array call as well closes the old image exactly. A coarse-derivative diagnostic emits byte-identical WGSL to sine-only and supplies no distinct GPU evidence.','scope':'Two existing production golden scenarios, original six-block allowance unchanged. Fixture stars/noise and explicit eight-tap object filtering are recorded separately; Waterlab visible differences isolate to noise. Both reviewers inspect original and current screenshots before PNG changes. Numerical CPU/GPU acceptance is separate.','archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size}};(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n');print(record['archive']['bytes'])
