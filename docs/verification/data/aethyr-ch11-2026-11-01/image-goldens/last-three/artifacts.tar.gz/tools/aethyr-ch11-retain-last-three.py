from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');out=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/last-three';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={
'haunt-base':Path('/tmp/aethyr-ch11-golden-haunt-current-scoped-readback'),
'sandbox-base':Path('/tmp/aethyr-ch11-golden-sandbox-current-scoped-readback'),
'villa-base':Path('/tmp/aethyr-ch11-golden-villa-empty-service')}
for label in ['haunt','sandbox','villa']:
 paths[label+'-current-shaders']=Path('/tmp/aethyr-ch11-'+label+'-current-shaders-old-executor');paths[label+'-old-shaders']=Path('/tmp/aethyr-ch11-'+label+'-old-shader-controls')
controls={n:json.loads((d/'comparison.json').read_text())for n,d in paths.items()}
for r in controls.values():assert r['same_producer_wasm']and r['same_inputs']and not r['source_changes']
for name in ['haunt','sandbox','villa']:
 assert controls[name+'-current-shaders']['identical'];assert controls[name+'-current-shaders']['legacy_sha256']==controls[name+'-base']['generic_sha256'];assert controls[name+'-old-shaders']['legacy_sha256']==controls[name+'-base']['legacy_sha256']
stocks={n:Path('/tmp/'+d)for n,d in {'original-seven-mixed':'aethyr-ch11-stock-current-seven','original-haunt':'aethyr-ch11-stock-current-journey','original-haunt-legacy':'aethyr-ch11-stock-current-journey-legacy','hecate-ch9-producer':'aethyr-ch11-stock-hecate-ch9-producer','migrated-generic':'aethyr-ch11-stock-last-three-migrated-generic','migrated-integer':'aethyr-ch11-stock-last-three-migrated-integer','command-refused-generic':'aethyr-ch11-stock-last-three-migrated-generic-command-refused','command-refused-integer':'aethyr-ch11-stock-last-three-migrated-integer-command-refused'}.items()}
stock={}
for n,d in stocks.items():
 e=json.loads((d/'execution.json').read_text());s=json.loads((d/'server-receipt.json').read_text());assert not s['source_changes'];report=json.loads((d/'report.json').read_text())if(d/'report.json').exists()else None;stock[n]={'execution':e,'report':report,'log':(d/'execution.log').read_text()}
 if n.startswith('migrated'):
  assert e['status']=='pass';assert all(case+': matches its golden (0 blocks changed, 6 allowed'in stock[n]['log']for case in ['haunted-house','sandbox','hecates-cemetery'])
observed={};pool={}; historical_observers={sha(p):p for p in Path("/tmp").glob("aethyr-ch11-*/driver.ts")}
for d in paths.values():
 for route in ['legacy','generic']:
  r=json.loads((d/route/'receipt.json').read_text());assert not r['source_changes']and not r['exceptions']and not r['errors']
  for f,h in {**r['source_inputs'],**r['served']}.items():
   p=Path(f); retained=p
   if not p.is_file() or sha(p)!=h:
    assert p==root/'aethyr/tests/check_render_goldens.ts' and h in historical_observers,(p,h)
    retained=historical_observers[h]
   assert sha(retained)==h;observed[f+'@'+h]={'original_path':f,'sha256':h,'retained_from':str(retained),'current_path_matches':p.is_file()and sha(p)==h};pool.setdefault(h,retained)
review=Path('/tmp/aethyr-ch11-last-three-visible-review');observations=json.loads((review/'observations.json').read_text())
for name,r in observations['cases'].items():assert r['baseline_updated']and sha(root/'coax/web/goldens'/(name+'.png'))==r['after_sha256']
ch9=Path('/tmp/aethyr-ch9-consumers/villa.wasm');assert sha(ch9)=='1fd2a42d2892b8a7e2097e24b9d0efdf066ceb2da608098c18f5a77c3d08cd9e'
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 def add(p,n):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;tar.addfile(i,io.BytesIO(b))
 for label,d in paths.items():
  for p in sorted(d.rglob('*')):
   if p.is_file():add(p,'controls/'+label+'/'+str(p.relative_to(d)))
 for label,d in stocks.items():
  for p in sorted(d.glob('*')):
   if p.is_file():add(p,'stock/'+label+'/'+p.name)
 for p in sorted(review.rglob('*')):
  if p.is_file():add(p,'before-after/'+str(p.relative_to(review)))
 for label in ['realm','villa']:
  for p in sorted(Path('/tmp/aethyr-ch11-'+label+'-noise-controls').iterdir()):
   if p.is_file():add(p,'variants/'+label+'/'+p.name)
 for p in sorted(Path('/tmp/aethyr-ch11-particle-controls').iterdir()):
  if p.is_file():add(p,'variants/particles/'+p.name)
 add(Path('/tmp/aethyr-ch11-particles-current.wgsl'),'variants/particles/current.wgsl');add(ch9,'pre-chapter11/villa-ch9.wasm')
 diagnostic=Path('/tmp/aethyr-ch11-six-visible-before-after/hecate-diagnostic.png')
 if diagnostic.exists():add(diagnostic,'before-after/hecate-diagnostic.png')
 for h,p in sorted(pool.items()):add(p,'consumed/'+h+'/'+p.name)
 for p in [Path(__file__),Path('/tmp/aethyr-ch11-golden-server-last-three-migrated.ts'),Path('/tmp/aethyr-ch11-run-stock-golden-last-three-migrated.py'),root/'coax/web/goldens.ts',root/'coax/web/golden-policy.ts',root/'coax/web/golden-pages.ts',root/'coax/web/realms.ts',root/'apps/openagents-web/realms.json']:add(p,'tools/'+p.name)
assert all(sha(Path(r['retained_from']))==r['sha256'] for r in observed.values())
r={'schema':'aethyr.render.last-three-visible-migration.v1','status':'pass_for_three_explicit_visible_migrations','cases':['haunted-house','sandbox','hecates-cemetery'],'exact_controls':controls,'stock_gates':stock,'baseline_migration':observations,'source_inputs':observed,'observer_epochs':'Reused positive legacy captures retain their contemporaneous observer receipts. Four historical observer bytes are independently recovered by exact SHA from preserved driver.ts copies, retained alongside current tool; no capture is reclassified as having used a later observer.','source_changes':[],'scope':'Both migratedexecutor routes report0changedblocks underunchanged6block allowances. Hauntmovingblocks and Hecatemovingblocks remainvisible inunmodifiedstockpolicy logs. Fixed90step rawcontrols compareallRGBAbytes withidenticalproducerbytes andnoimageexclusions. Pre11Hecateproducer difference and existingHauntUIcaption/prompt explicitlyseparatefromnoise/filter changes. Consumedbytes from exact rawcomparisons retained. CPU/GPU numerical acceptance is separate.','archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size}}
(out/'qualification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['archive']))
