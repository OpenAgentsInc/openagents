import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,extname} from 'node:path';
import {createHash} from 'node:crypto';
const root='/Users/christopherdavid/work/openagents-aethyr-book', app=resolve(root,'apps/openagents-web');
const [route,out]=process.argv.slice(2); if(!['generic','legacy','legacy-sin','legacy-integer'].includes(route)||!out)throw Error('route/out');mkdirSync(out,{recursive:true});
const files:Record<string,string>={'fixture':'/tmp/aethyr-ch11-typed-hosts-one/fixture.wasm','ice-cream-man':'/tmp/aethyr-ch11-typed-hosts-one/icecream.wasm','watchtower':'/tmp/aethyr-ch11-typed-hosts-one/watchtower.wasm','garden':'/tmp/aethyr-ch11-garden-raw-bool.wasm','fairy-forest':'/tmp/aethyr-ch11-typed-hosts-relinked/fairy.wasm','waterlab':'/tmp/aethyr-ch11-typed-hosts-one/waterlab.wasm','drop':'/tmp/aethyr-ch11-typed-hosts-one/droprealm.wasm','orbit-league':'/tmp/aethyr-ch11-typed-hosts-relinked/orbitleague.wasm'};
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex'); const served=new Map<string,string>(),htmls:any={},requests:string[]=[];
const server=Bun.serve({hostname:'127.0.0.1',port:0,websocket:{message(){}},fetch(req,s){const u=new URL(req.url),p=u.pathname; requests.push(p);
 if(p==='/coaxial/live'&&s.upgrade(req))return;
 if(p==='/api/auth/viewer')return new Response('');
 if(p.startsWith('/api/playtest/'))return Response.json({});
 if(p==='/api/analytics/events')return new Response(null,{status:204});
 if(p==='/favicon.ico')return new Response(null,{status:204});
 let file:string|undefined;let slug=p.match(/^\/realms\/([^/]+)\/?$/)?.[1];
 if(slug&&files[slug])file=resolve(app,'realms',slug,'index.html');
 else if(p==='/waterlab.wgsl'&&route==='legacy-sin')file='/tmp/aethyr-ch11-waterlab-noise-controls/sin.wgsl';
 else if(p==='/waterlab.wgsl'&&route==='legacy-integer')file='/tmp/aethyr-ch11-waterlab-noise-controls/integer.wgsl';
 else if(p==='/fairy.wgsl'&&route==='legacy-sin')file='/tmp/aethyr-ch11-fairy-visible-isolation/sin.wgsl';
 else if(p==='/fairy.wgsl'&&route==='legacy-integer')file='/tmp/aethyr-ch11-fairy-visible-isolation/integer.wgsl';
 else if(p==='/fixture.wgsl'&&route==='legacy-sin')file='/tmp/aethyr-ch11-fixture-noise-isolation/sin.wgsl';
 else if(p==='/fixture.wgsl'&&route==='legacy-integer')file='/tmp/aethyr-ch11-fixture-noise-isolation/integer.wgsl';
 else if(p.startsWith('/coaxial/'))file=resolve(root,'coax/web',p.slice(9));
 else if(p.startsWith('/test-wasm/'))file=files[p.slice(11)];
 else if(p.startsWith('/packages/'))file=resolve('/tmp/aethyr-ch11-packages-current',p.slice(10));
 else file=resolve(app,p.slice(1));
 try{if(!file)throw Error('missing');let b=readFileSync(file);let h=sha(b);if(served.has(file)&&served.get(file)!==h)throw Error('source changed');served.set(file,h);
 if(slug&&files[slug]){let html=b.toString();html=route.startsWith('legacy')?html.replace(/\sdata-render(?:-profile)?="[^"]*"/g,''):html.replace(/data-render="[^"]*"/,`data-render="/packages/${slug}/render.json"`);html=/data-wasm="/.test(html)?html.replace(/data-wasm="[^"]*"/,`data-wasm="/test-wasm/${slug}"`):html.replace(/data-app="[^"]*"/,'$& '+`data-wasm="/test-wasm/${slug}"`);htmls[p]={original_sha256:h,served_sha256:sha(html),rewrites:'data-wasm artifact path; data-render route only'};b=Buffer.from(html);}
 const type=extname(file)==='.js'?'text/javascript':extname(file)==='.wasm'?'application/wasm':extname(file)==='.json'?'application/json':extname(file)==='.html'?'text/html':'application/octet-stream';return new Response(b,{headers:{'content-type':type}});
 }catch{return new Response('not found',{status:404});}
}});
function finish(){const changes=[...served].filter(([p,h])=>sha(readFileSync(p))!==h).map(([p])=>p);writeFileSync(`${out}/server-receipt.json`,JSON.stringify({route,served:Object.fromEntries(served),source_changes:changes,htmls,requests},null,2)+'\n');server.stop(true);process.exit(changes.length?1:0);}
process.on('SIGTERM',finish);process.on('SIGINT',finish);setTimeout(finish,810000);console.log(JSON.stringify({base:`http://127.0.0.1:${server.port}`}));
