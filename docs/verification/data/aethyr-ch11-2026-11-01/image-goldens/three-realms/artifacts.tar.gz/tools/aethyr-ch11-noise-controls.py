from pathlib import Path
import hashlib,json,re,shlex,subprocess,sys
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');app=sys.argv[1];work=Path('/tmp/aethyr-ch11-'+app+'-noise-controls');work.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=root/'apps/openagents-web/gpu'/(app+'.coax');style=root/'verse/style.coax';old_commit='a1a35280cd'
def absolute(text,path):return re.sub(r'#load "([^"]+)"',lambda m:'#load "'+str((path.parent/m[1]).resolve())+'"',text)
def old_function(name,original):
 old=subprocess.check_output(['git','show',old_commit+':'+str(original.relative_to(root))],cwd=root,text=True)
 pattern=re.compile(r'(?m)^'+re.escape(name)+r'\s*::[^\n]*\{');m=pattern.search(old);assert m,name;start=m.start();i=m.end();level=1
 while level:
  if old[i]=='{':level+=1
  elif old[i]=='}':level-=1
  i+=1
 return old[start:i]
def restore(text,original):
 changed=[]
 for m in list(re.finditer(r'(?m)^([A-Za-z_][A-Za-z_0-9]*)\s*::[^\n]*\{\s*\n?\s*return render_noise[23]\([^\n]*?;\s*\n?\}',text)):
  name=m[1];text=text.replace(m[0],old_function(name,original));changed.append(name)
 text=re.sub(r'#test "[^"\n]*portable integer noise profile"\s*\{\s*#assert[^\n]*\n\}\n','',text)
 return text,changed
for mode in ['integer','sin']:
 fs=original.read_text();ss=style.read_text();changes=[]
 if mode=='sin':fs,fc=restore(fs,original);ss,sc=restore(ss,style);changes=fc+sc;assert 'verse_style_hash'in changes
 sp=work/(mode+'-style.coax');sp.write_text(absolute(ss,style));fp=work/(mode+'-'+app+'.coax');fp.write_text(absolute(fs,original).replace(str(style),str(sp)))
 command=['coax/bin/coax','wgsl',str(fp),*shlex.split((root/'apps/openagents-web/gpu'/(app+'.module')).read_text()),'-o',str(work/(mode+'.wgsl'))]
 p=subprocess.run(command,cwd=root,capture_output=True,timeout=120);(work/(mode+'.log')).write_bytes(p.stdout+p.stderr);record={'app':app,'mode':mode,'status':'pass'if p.returncode==0 else'fail','command':command,'compiler_sha256':sha(root/'coax/bin/coax'),'original_shader_sha256':sha(original),'original_style_sha256':sha(style),'old_function_source_commit':old_commit,'restored_functions':changes,'variant_shader_sha256':sha(fp),'variant_style_sha256':sha(sp),'wgsl_sha256':sha(work/(mode+'.wgsl'))if p.returncode==0 else None,'scope':'Diagnostic source variants compiled by Coax. Sin restores only procedures whose current body directly returns portable render_noise and removes only incompatible integer-profile assertions. All other current shader semantics remain; no generated WGSL arithmetic edited.'};(work/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(app,mode,record['status'],changes,flush=True)
 if p.returncode:print(p.stderr.decode());raise SystemExit(1)
