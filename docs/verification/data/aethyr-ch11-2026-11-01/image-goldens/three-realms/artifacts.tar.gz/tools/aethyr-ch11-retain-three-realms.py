from pathlib import Path
import hashlib,io,json,tarfile,re
root=Path('/Users/christopherdavid/work/openagents-aethyr-book')
out=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/three-realms';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={
 'built-base':Path('/tmp/aethyr-ch11-golden-built-current'),
 'garden-base':Path('/tmp/aethyr-ch11-golden-garden-current'),
 'deadgears-base':Path('/tmp/aethyr-ch11-golden-deadgears-current'),
 'built-integer':Path('/tmp/aethyr-ch11-noise-built-integer-capture'),
 'built-sin':Path('/tmp/aethyr-ch11-noise-built-sin-capture'),
 'built-sin-hardware':Path('/tmp/aethyr-ch11-noise-built-sin-hardware-capture'),
 'deadgears-integer':Path('/tmp/aethyr-ch11-noise-deadgears-integer-capture'),
 'deadgears-sin':Path('/tmp/aethyr-ch11-noise-deadgears-sin-capture')}
controls={n:json.loads((d/'comparison.json').read_text())for n,d in paths.items()}
assert all(d['same_inputs']and d['same_producer_wasm']and not d['source_changes']for d in controls.values())
for name in ['built','deadgears']:
 assert controls[name+'-integer']['identical']
 assert controls[name+'-integer']['legacy_sha256']==controls[name+'-base']['generic_sha256']
assert controls['built-sin-hardware']['legacy_sha256']==controls['built-base']['legacy_sha256']
assert controls['built-sin']['legacy_sha256']!=controls['built-base']['legacy_sha256']
assert controls['deadgears-sin']['legacy_sha256']==controls['deadgears-base']['legacy_sha256']
garden_dir=root/'docs/verification/data/aethyr-ch11-2026-11-01/image-goldens/garden'
garden=json.loads((garden_dir/'isolation.json').read_text())
assert controls['garden-base']['legacy_sha256']==garden['controls']['sin']['legacy_sha256']
assert controls['garden-base']['generic_sha256']==garden['controls']['integer']['legacy_sha256']==garden['controls']['integer']['generic_sha256']
for mode in ['integer','sin']:
 assert sha(Path('/tmp/aethyr-ch11-garden-noise-controls')/(mode+'.wgsl'))==sha(Path('/tmp/aethyr-ch11-garden-noise-isolation')/(mode+'.wgsl'))
stocks={
 'initial-generic':Path('/tmp/aethyr-ch11-stock-current-seven'),
 'original-legacy-mixed-batch':Path('/tmp/aethyr-ch11-stock-current-five-legacy'),
 'restored-sine':Path('/tmp/aethyr-ch11-stock-current-four-controls'),
 'migrated-generic':Path('/tmp/aethyr-ch11-stock-three-migrated-generic'),
 'migrated-integer':Path('/tmp/aethyr-ch11-stock-three-migrated-integer')}
stock={};pool={};observed={}
def observe(f,h):
 p=Path(f);assert p.is_file()and sha(p)==h,(f,h)
 pool.setdefault(h,p);observed[str(p)]=h
selected=['built','garden','dead-gears']
for name,d in stocks.items():
 e=json.loads((d/'execution.json').read_text());s=json.loads((d/'server-receipt.json').read_text());assert not s['source_changes']
 log=(d/'execution.log').read_text();report=json.loads((d/'report.json').read_text())
 matches={case:[line.strip()for line in log.splitlines()if re.search(r'\bok\s+'+re.escape(case)+r': matches its golden \(0 blocks changed, 6 allowed',line)]for case in selected}
 if name!='initial-generic':assert all(matches.values()),(name,matches)
 stock[name]={'batch_status':e['status'],'seconds':e['elapsed_seconds'],'selected_zero_block_checks':matches,'report':report,'log':log}
 for f,h in s['served'].items():observe(f,h)
for n in ['restored-sine','migrated-generic','migrated-integer']:assert stock[n]['batch_status']=='pass'
assert stock['original-legacy-mixed-batch']['batch_status']=='fail'
assert all(line.startswith('hecates-cemetery:')for line in stock['original-legacy-mixed-batch']['report']['failed'])
for d in paths.values():
 for route in ['legacy','generic']:
  r=json.loads((d/route/'receipt.json').read_text())
  for f,h in r['served'].items():observe(f,h)
obsdir=Path('/tmp/aethyr-ch11-six-visible-before-after');observations=json.loads((obsdir/'observations.json').read_text())
for case in selected:
 row=observations['cases'][case];assert row['baseline_updated']
 assert sha(root/'coax/web/goldens'/(case+'.png'))==row['new_baseline_sha256']
 for name,h in row['images'].items():assert sha(obsdir/case/name)==h
walk=[root/rel for rel in ['coax/web/goldens.ts','coax/web/golden-pages.ts','coax/web/golden-policy.ts','coax/web/realms.ts','apps/openagents-web/realms.json']]
walk_hashes={str(p):sha(p)for p in walk}
with tarfile.open(out/'artifacts.tar.gz','w:gz',compresslevel=9)as tar:
 def add(p,name):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 for label,d in paths.items():
  for p in sorted(d.rglob('*')):
   if p.is_file():add(p,'controls/'+label+'/'+str(p.relative_to(d)))
 for label,d in stocks.items():
  for p in sorted(d.glob('*')):
   if p.is_file():add(p,'stock/'+label+'/'+p.name)
 add(obsdir/'observations.json','before-after/original-six-case-observations.json')
 for case in selected:
  for p in sorted((obsdir/case).glob('*.png')):add(p,'before-after/'+case+'/'+p.name)
 for p in sorted(garden_dir.glob('*')):
  if p.is_file():add(p,'garden-historical/'+p.name)
 for app in ['myrealm','garden','deadgears']:
  d=Path('/tmp/aethyr-ch11-'+app+'-noise-controls')
  for p in sorted(d.glob('*')):
   if p.is_file():add(p,'variants/'+app+'/'+p.name)
 for h,p in sorted(pool.items()):add(p,'served/'+h+'/'+p.name)
 for p in [Path(__file__),Path('/tmp/aethyr-ch11-noise-controls.py'),Path('/tmp/aethyr-ch11-sampling-controls.py'),Path('/tmp/aethyr-ch11-golden-server-current.ts'),Path('/tmp/aethyr-ch11-run-stock-golden-current.py')]:add(p,'tools/'+p.name)
 for p in walk:add(p,'walk-sources/'+str(p.relative_to(root)))
assert all(sha(Path(p))==h for p,h in observed.items())
assert all(sha(Path(p))==h for p,h in walk_hashes.items())
record={
 'schema':'aethyr.render.three-realm-visible-migration.v1',
 'status':'pass_for_three_explicit_visible_migrations',
 'cases':selected,'exact_controls':controls,'garden_historical_isolation':garden,
 'garden_epoch_bridge':'Fresh current-producer legacy and generic raw images match the earlier05f22989/7c03bfb1 pair exactly. Historical causal variants use different host-ABI Wasms with exact matching producer payloads, not identical binaries. Both historical WGSL variants are byte-identical to the current control emissions. Their original metadata remains unmodified in garden-historical/.',
 'stock_gates':stock,
 'baseline_migration':{'cases':{k:observations['cases'][k]for k in selected},'visual_reviews':observations['visual_reviews']},
 'source_epoch':'All74 unique consumed served path/hash observations match and are retained in the digest pool. Current host214003ec/render824e1128; old Garden isolation is separately retained with its historical ABI correction. No new GPU run was performed for retention.',
 'served_inputs':observed,'walk_sources':walk_hashes,
 'built_sampling_isolation':'Noise-only sine restoration does not restore the original Built raw image. Restoring the old implicit hardware sampling call as well reproduces the exact original raw image; portable noise and explicit eight-tap filtering are separate visible migrations.',
 'scope':'Only Built, Garden and Dead Gears production PNG baselines are covered. Original six-block allowance is unchanged; selected3 original, restored-sine, migrated-generic and migrated-integer checks each report0changed blocks. The original-legacy five-case batch still fails unrelated Hecate and is retained as mixed, not globally passing. Both reviewers approved these3 before PNG updates. CPU/GPU numerical acceptance and decoded-texture equality remain separate.',
 'source_changes':[],
 'archive':{'file':'artifacts.tar.gz','sha256':sha(out/'artifacts.tar.gz'),'bytes':(out/'artifacts.tar.gz').stat().st_size}}
(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'archive':record['archive'],'served_path_hash_observations':len(observed),'unique_content_hashes':len(pool),'cases':selected}))
