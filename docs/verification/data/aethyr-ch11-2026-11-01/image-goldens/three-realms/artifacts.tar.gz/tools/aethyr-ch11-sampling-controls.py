from pathlib import Path
import json,hashlib,subprocess,sys
r=Path('/Users/christopherdavid/work/openagents-aethyr-book');app=sys.argv[1];w=Path('/tmp/aethyr-ch11-'+app+'-noise-controls');s=(w/('sin-'+app+'.coax')).read_text();changed=[]
for new,old in [('render_sample_layer8(', 'gpu_sample_layer('),('render_sample8(', 'gpu_sample(')]:
 count=s.count(new)
 if count:s=s.replace(new,old);changed.append({'new':new,'old':old,'count':count})
assert changed;f=w/('sin-hardware-'+app+'.coax');f.write_text(s);d=json.loads((w/'sin.json').read_text());cmd=d['command'][:];cmd[2]=str(f);cmd[-1]=str(w/'sin-hardware.wgsl');p=subprocess.run(cmd,cwd=r,capture_output=True,timeout=120);(w/'sin-hardware.log').write_bytes(p.stdout+p.stderr);assert not p.returncode,p.stderr.decode();d={'variant':'sin-hardware','app':app,'status':'pass','command':cmd,'sampler_call_controls':changed,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'wgsl_sha256':hashlib.sha256((w/'sin-hardware.wgsl').read_bytes()).hexdigest(),'scope':'Explicit Coax diagnostic restores old implicit GPU sampler at named calls, plus the prior isolated sine hashes. Demotion and all other current semantics remain. No generated WGSL arithmetic edited.'};(w/'sin-hardware.json').write_text(json.dumps(d,indent=2)+'\n');print(app,d['wgsl_sha256'])
