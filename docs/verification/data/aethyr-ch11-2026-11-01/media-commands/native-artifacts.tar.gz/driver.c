#include "media.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint64_t dbits(double d){uint64_t b;memcpy(&b,&d,8);return b;}
static uint32_t fbits(float f){uint32_t b;memcpy(&b,&f,4);return b;}
static double dvalue(uint64_t b){double d;memcpy(&d,&b,8);return d;}
int main(int argc,char **argv){char op;const char *fault=argc>1?argv[1]:"";
 while(scanf(" %c",&op)==1){
  if(op=='P'){
   size_t n;int cap;if(scanf("%zu %d",&n,&cap)!=2||getchar()!='\n'||cap<0||cap>112)return 2;
   char *text=calloc(n+1,1);if(!text||fread(text,1,n,stdin)!=n||getchar()!='\n')return 2;
   coax_t_RenderMediaRequest rows[114];memset(rows,0xa5,sizeof rows);
   coax_t_RenderMediaParse r=media_native_parse((coax_string){text,(int64_t)n},(coax_v_t_RenderMediaRequest){rows+1,cap});
   int guards=1;unsigned char *raw=(unsigned char*)rows;
   for(size_t i=0;i<sizeof rows;i++)if((i<sizeof rows[0]||i>=sizeof rows[0]*(size_t)(r.status?1:r.count+1))&&raw[i]!=0xa5)guards=0;
   if(!strcmp(fault,"parse-count"))r.count=0;
   printf("P %u %"PRId64" %"PRId64" %d %d",(unsigned)r.status,r.count,r.lines,(int)r.truncated,guards);
   for(int64_t i=0;i<r.count;i++){
    coax_t_RenderMediaRequest q=rows[i+1];
    if(!strcmp(fault,"parse-line"))q.line=-1;if(!strcmp(fault,"parse-url"))q.url.count=0;if(!strcmp(fault,"parse-box"))q.box.e[2]=0;
    int borrowed=q.url.data>=text&&q.url.data+q.url.count<=text+n;
    printf(" %u %"PRId64" %d %d %"PRId64" ",(unsigned)q.kind,q.line,(int)q.over,borrowed,q.url.count);
    for(int64_t k=0;k<q.url.count;k++)printf("%02x",(unsigned char)q.url.data[k]);
    if(!q.url.count)printf("-");for(int k=0;k<4;k++)printf(" %016"PRIx64,dbits(q.box.e[k]));
   }puts("");free(text);
  }else if(op=='R'){
   int kind,over;int64_t line,w,h,iw,ih;uint64_t b[4];
   if(scanf("%d %"SCNd64" %d %"SCNd64" %"SCNd64" %"SCNd64" %"SCNd64" %"SCNx64" %"SCNx64" %"SCNx64" %"SCNx64,&kind,&line,&over,&w,&h,&iw,&ih,b,b+1,b+2,b+3)!=11)return 2;
   coax_t_RenderMediaRequest q={0};q.kind=(coax_t_RenderMediaKind)kind;q.line=line;q.over=over;for(int i=0;i<4;i++)q.box.e[i]=dvalue(b[i]);
   coax_t_RenderMediaRect r=media_native_rect(q,w,h,iw,ih);
   if(!strcmp(fault,"rect-line"))r.line=-1;if(!strcmp(fault,"rect-over"))r.over=0;if(!strcmp(fault,"rect-draw"))r.draw=0;
   if(!strncmp(fault,"uniform-",8)){int k=atoi(fault+8);if(k>=0&&k<8)r.uniforms.e[k]=9;}
   printf("R %d %d %"PRId64" %d",(int)r.ok,(int)r.draw,r.line,(int)r.over);for(int i=0;i<8;i++)printf(" %08"PRIx32,fbits(r.uniforms.e[i]));puts("");
  }else if(op=='E'){
   int kind;int64_t w,h;if(scanf("%d %"SCNd64" %"SCNd64,&kind,&w,&h)!=3)return 2;
   coax_t_RenderMediaExtent r=media_native_extent((coax_t_RenderMediaKind)kind,w,h);
   if(!strcmp(fault,"extent-width"))r.width=0;if(!strcmp(fault,"extent-height"))r.height=0;
   printf("E %d %"PRId64" %"PRId64"\n",(int)r.ok,r.width,r.height);
  }else return 2;
 }return ferror(stdin)?2:0;}
