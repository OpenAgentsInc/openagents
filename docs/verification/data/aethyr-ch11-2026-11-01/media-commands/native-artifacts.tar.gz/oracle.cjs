const fs=require('node:fs');const c=JSON.parse(fs.readFileSync(0,'utf8'));
const dbits=x=>{const b=Buffer.alloc(8);b.writeDoubleLE(x);return b.readBigUInt64LE().toString(16).padStart(16,'0')};
const fbits=x=>{const b=Buffer.alloc(4);b.writeFloatLE(x);return b.readUInt32LE().toString(16).padStart(8,'0')};
const out=[];
for(const p of c.parse){
 if(Buffer.byteLength(p.text)>65536){out.push('P 1 0 0 0 1');continue}
 const lines=p.text.split('\n'), rows=[];
 for(const [i,line] of lines.slice(0,112).entries()){
  const [named,url,...b]=line.split(' '), box=b.map(Number),kind=named==='over'?'image':named;
  if((kind!=='image'&&kind!=='video')||!url?.startsWith('/')||url.startsWith('//')||box.length!==4||box.some(v=>!Number.isFinite(v)))continue;
  rows.push([kind==='image'?1:2,i,+(named==='over'),1,Buffer.byteLength(url),Buffer.from(url).toString('hex'),...box.map(dbits)].join(' '));
 }
 const status=+(rows.length>p.capacity), count=status?0:rows.length;
 out.push(['P',status,count,Math.min(lines.length,112),+(lines.length>112),1,...(status?[]:rows)].join(' '));
}
for(const r of c.rect){
 const [kind,line,over,w,h,iw,ih,...box]=r, [x0,y0,x1,y1]=box,bw=x1-x0,bh=y1-y0;
 let ok=(kind===1||kind===2)&&line>=0&&line<112&&w>=1&&h>=1&&Number.isFinite(bw)&&Number.isFinite(bh),draw=false,u=Array(8).fill(0);
 if(ok&&!(iw===0&&ih===0)){
  if(iw<1||ih<1)ok=false;
  else if(bw>1&&bh>1){const f=Math.min(bw/iw,bh/ih),dw=iw*f,dh=ih*f,cx=x0+(bw-dw)/2,cy=y0+(bh-dh)/2;
   const v=[cx/w*2-1,1-cy/h*2,(cx+dw)/w*2-1,1-(cy+dh)/h*2];
   ok=v.every(x=>Number.isFinite(x)&&Math.abs(x)<=3.4028234663852886e38);if(ok){draw=true;u=[...v,1,0,0,0]}
  }
 }
 out.push(['R',+ok,+draw,ok?line:-1,ok?+over:0,...u.map(fbits)].join(' '));
}
for(const [kind,w,h] of c.extent){let ok=(kind===1||kind===2)&&w>0&&h>0,x=0,y=0;
 if(ok){const f=kind===2?1:Math.min(1,2048/Math.max(w,h));x=Math.max(1,Math.round(w*f));y=Math.max(1,Math.round(h*f))}
 out.push(['E',+ok,x,y].join(' '));}
process.stdout.write(out.join('\n')+'\n');
