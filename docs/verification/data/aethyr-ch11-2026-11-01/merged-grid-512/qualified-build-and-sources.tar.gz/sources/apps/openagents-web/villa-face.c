// Hecate's Cemetery's C face for the browser (coax/web/host.js): villa.coax
// is the page, verse/player.coax walks you, verse/grid.coax reads a phone's
// thumbs and villafig.coax poses the figures (each its own library). Once
// a frame it passes values between them in order: the page's controls, the
// player's step among the garden's walls, the page's step (the flight, the
// camera, the dog), the figures posed where the page put them, then the
// page's drawing. It decides nothing. Every pointer is an offset into the
// host's WebAssembly.Memory; the page's state is the host's.
#include "villa.h"
#include "Player.h"
#include "Grid.h"
// villafig.coax's library, declared here by hand: its header and villa.h each
// define the same small array types. The face holds its Figs as bytes.
typedef struct { void *data; int64_t count; } figs_view;
void vf_start(figs_view f);
void vf_set(figs_view f, int64_t i, _Bool dog, coax_v_f32 numbers, int64_t pattern, float cr, float cg, float cb, float mr, float mg, float mb);
void vf_dress(figs_view f, int64_t i, int64_t tail, float ruff);
void vf_tick(figs_view f, float dt);
void vf_step(figs_view f, int64_t i, float speed, float dt);
int64_t vf_place(figs_view f, int64_t i, float x, float y, float z, float yaw, coax_v_f32 out, coax_v_f32 bound);
_Bool vf_still(figs_view f, int64_t i);
int64_t vf_bone_floats(void);
int64_t vf_max_bones(void);
int64_t vf_size(void);
int64_t vf_pet_emote(figs_view f, int64_t n);
_Bool vf_emote(figs_view f, int64_t i, int64_t motion);
void vf_stop(figs_view f, int64_t i);
int64_t vf_motion_add(figs_view f, coax_string text);
coax_string vf_error(figs_view f);
int64_t vf_motion_named(figs_view f, coax_string name);
#include "analytics-face.h"
#include <stdbool.h>
#include <stddef.h>
#include <math.h>
#include <string.h>

#define EXPORT(name) __attribute__((export_name(name)))
#define IMPORT(name) __attribute__((import_module("env"), import_name(name)))
IMPORT("coaxial_http") int32_t coaxial_http(uint32_t url, uint32_t url_len, uint32_t body, uint32_t body_len, int32_t flags);
#include "edit-face.h"
#define PLAYER_URL "/api/playtest/player"
#define RIG_WHY "rig must be animal: this is for a dog"

static coax_t_Player player;
static coax_t_Sticks sticks;
static _Alignas(16) uint8_t figs[512 * 1024];
static bool placed;
static double now;
static float width, height, dpr;
static uint8_t inbox[16384];
static coax_t_Track track_state;
static bool golden;
static bool reduced;
static bool flight_told;
static bool entered;   // world-enter and load-engine sent (the analytics contract, analytics-contract.json)
// Your pet's requests (villapet.coax), one at a time; a player key minted first if the browser has none.
static int32_t pet_ask = -1; static int64_t pet_kind;
static int32_t slow_ask = -1; static int64_t slow_kind; static double slow_asked_at;
static double pet_asked_at;
static char pet_url_buf[160];
static uint8_t pet_body_buf[12288];
static bool facts_seen, has_player, minted;
static int32_t mint_ask = -1;
static char mint_record[200]; static uint32_t mint_n;
static uint8_t action_out[256]; static uint32_t action_n; static int32_t action_kind;
// Who else is here, and the chat (villaroom.coax, room.coax): where you are posted about every second.
static int32_t room_ask = -1, say_ask = -1;
static double room_at = -10, room_asked_at;
static char room_url_buf[120], say_url_buf[120];
static uint8_t room_body[256], say_body[1400];
EXPORT("coaxial_golden") void coaxial_golden(uint32_t on) { golden = on != 0; }
static coax_v_t_Track tr(void) { return (coax_v_t_Track){&track_state, 1}; }
static figs_view fv(void) { return (figs_view){figs, 1}; }
#include "place-face.h"

static coax_t_Villa *villa(uint32_t state) { return (coax_t_Villa *)(uintptr_t)state; }
static coax_v_t_Villa at(uint32_t state) { return (coax_v_t_Villa){villa(state), 1}; }
static coax_v_t_RealmEdit ed(uint32_t state) { return (coax_v_t_RealmEdit){villa(state)->ed.e, 1}; }

// You: a slight shadow of a person. The dog: a dog of the usual build, its
// coat pale so it glows white (villa.coax draws it so).
static void cast(void) {
  if (vf_size() > (int64_t)sizeof figs) __builtin_trap();
  vf_start(fv());
  float you[10] = {1.0f, 1.0f, 1.0f, 0.88f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 1.0f};
  vf_set(fv(), 0, false, (coax_v_f32){you, 10}, 0, 0.02f, 0.02f, 0.03f, 0, 0, 0);
  float dog[10] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.8f, 1.1f, 1.0f, 1.2f};
  vf_set(fv(), 1, true, (coax_v_f32){dog, 10}, 0, 0.92f, 0.94f, 1.0f, 0.86f, 0.9f, 1.0f);
}

static void start(uint32_t state) {
  if (!track_state.page_n) track_init(tr(), track_cstr("hecates-cemetery"));
  if (placed) return;
  coax_t_Point spawn = villa_spawn(at(state));
  player = verse_player_place(spawn.x, spawn.y, spawn.z, 0);
  sticks = verse_sticks_reset();
  cast();
  placed = true;
  verse_place_golden(place_k(), golden);
  villa_walls(at(state));   // the page started: its orbit is where you start
  villa_on_realm_clock(at(state));
  place_seen(state);
}

// Where you are, kept so a reload puts you back (place-face.h).
static coax_t_Place place_here(uint32_t state) {
  if (!placed) return (coax_t_Place){0};
  return verse_place_of(player.pos.x, player.pos.y, player.pos.z, verse_player_face(player), villa(state)->orbit, -1);
}
static void place_put(uint32_t state, coax_t_Place p) {
  coax_t_Place q = villa_place_fix(at(state), p);
  player = verse_player_place(q.x, 0, q.z, q.face);
  villa_place_camera(at(state), q);
}

EXPORT("coaxial_layout") uint32_t coaxial_layout(void) {
  return (uint32_t)(sizeof(coax_t_Villa) * 1000003u + offsetof(coax_t_Villa, objects) * 7u + offsetof(coax_t_Villa, draws) * 13u + 0x56494c4cu);
}
EXPORT("coaxial_state_size") uint32_t coaxial_state_size(void) { return (uint32_t)sizeof(coax_t_Villa); }
// A new state's declared defaults (coax_default_T, from the compiler). The host calls this first.
EXPORT("coaxial_state_init") void coaxial_state_init(uint32_t state) { coax_default_t_Villa((coax_t_Villa *)(uintptr_t)state); }
EXPORT("coaxial_max_vertices") uint32_t coaxial_max_vertices(void) { return (uint32_t)coaxial_villa_max_vertices(); }
EXPORT("coaxial_vertex_floats") uint32_t coaxial_vertex_floats(void) { return (uint32_t)coaxial_villa_vertex_floats(); }
EXPORT("coaxial_uniform_floats") uint32_t coaxial_uniform_floats(void) { return (uint32_t)coaxial_villa_uniform_floats(); }

// The dog's look from your pet's avatar (villapet.coax), when it changes.
static void pet_look(uint32_t state) {
  coax_t_PetUi *p = &villa(state)->pet.e[0];
  if (!p->look_new) return;
  p->look_new = false;
  vf_set(fv(), 1, true, (coax_v_f32){p->avatar.e, 10}, p->pattern, p->coat.e[0], p->coat.e[1], p->coat.e[2], p->marks.e[0], p->marks.e[1], p->marks.e[2]);
  vf_dress(fv(), 1, p->tail_shape, p->chest);
}

// An action the panel asked for, handed to the host (in the press, for the file picker).
static void pet_action(uint32_t state) {
  coax_t_PetUi *p = &villa(state)->pet.e[0];
  if (!p->action || action_kind) return;
  memcpy(action_out, p->outbox.e, (size_t)p->out_n); action_n = (uint32_t)p->out_n; action_kind = (int32_t)p->action;
  p->action = 0; p->out_n = 0;
}

// The pet's requests: the next one wanted goes when none is waiting.
static void pet_requests(uint32_t state) {
  coax_t_PetUi *p = &villa(state)->pet.e[0];
  coax_t_Play *q = &villa(state)->play.e[0];
  // 0..5 the stock emotes, 6 digging; a come (or a throw) ends a still one
  if (p->emote >= 100) {   // one the agent made: into the library (by its name), then played
    int64_t slot = vf_motion_add(fv(), villa_my_emote_text(at(state), p->emote - 100));
    if (slot >= 0) vf_emote(fv(), 1, slot);
  }
  else if (p->emote == 6) vf_emote(fv(), 1, vf_motion_named(fv(), (coax_string){"dig", 3}));
  else if (p->emote >= 0) vf_emote(fv(), 1, vf_pet_emote(fv(), p->emote));
  p->emote = -1;
  // the agent's new motion: read by the engine; it plays, or the reason goes back to the agent
  if (villa_emote_check(at(state))) {
    int64_t slot = vf_motion_add(fv(), villa_emote_text(at(state)));
    if (slot >= 0 && vf_emote(fv(), 1, slot)) villa_emote_checked(at(state), true, (coax_string){"", 0});
    else if (slot >= 0) villa_emote_checked(at(state), false, (coax_string){RIG_WHY, sizeof RIG_WHY - 1});
    else villa_emote_checked(at(state), false, vf_error(fv()));
  }
  coax_t_Follower dog = villa_dog(at(state));
  float dx = dog.pos.x - villa(state)->feet.x, dz = dog.pos.z - villa(state)->feet.z;
  if (q->stop_ask || (!q->stay && q->dig_t <= 0 && dx * dx + dz * dz > 9.0f && vf_still(fv(), 1))) { vf_stop(fv(), 1); q->stop_ask = false; }
  pet_action(state);
  // A new player's key goes to the host as action 5, which keeps it after this frame: the pets and
  // presence wait a frame (and presence its second), or they go without the key, get 403 and mint again.
  if (mint_n && !action_kind) { memcpy(action_out, mint_record, mint_n); action_n = mint_n; action_kind = 5; mint_n = 0; has_player = true; room_at = now; return; }
  if (!facts_seen) return;
  if (!has_player) {
    if (!minted) { minted = true; mint_ask = coaxial_http((uint32_t)(uintptr_t)PLAYER_URL, sizeof PLAYER_URL - 1, (uint32_t)(uintptr_t)"{}", 2, 1 | 4); }
    return;
  }
  // two channels: the agent's emote (a model writes it, slowly) on its own, everything else on the other
  for (int slow = 1; slow >= 0; slow--) {
    int32_t *ask = slow ? &slow_ask : &pet_ask; int64_t *ask_kind = slow ? &slow_kind : &pet_kind; double *asked_at = slow ? &slow_asked_at : &pet_asked_at;
    if (*ask >= 0 && now - *asked_at < 200) continue;
    int64_t kind = villa_pet_next_in(at(state), slow);
    if (!kind) continue;
    int64_t un = villa_pet_url(at(state), kind, (coax_v_u8){(uint8_t *)pet_url_buf, sizeof pet_url_buf});
    int64_t bn = villa_pet_post(kind) ? villa_pet_body(at(state), kind, (coax_v_u8){pet_body_buf, sizeof pet_body_buf}) : 0;
    if (un <= 0 || bn < 0) { villa_pet_answer(at(state), kind, 0, (coax_string){"", 0}); continue; }
    int32_t id = coaxial_http((uint32_t)(uintptr_t)pet_url_buf, (uint32_t)un, (uint32_t)(uintptr_t)pet_body_buf, (uint32_t)bn,
                              (villa_pet_post(kind) ? 1 : 0) | 4 | 8);
    if (id < 0) continue;
    *ask = id; *ask_kind = kind; *asked_at = now;
  }
}

static void room_requests(uint32_t state, float dt) {
  coax_t_Villa *v = villa(state);
  coax_v_t_RoomState rs = {&v->room.e[0], 1};
  room_ease(rs, dt);
  if (!facts_seen || !has_player) return;
  coax_t_Chat *c = &v->chat.e[0];
  if (c->send && say_ask < 0) {
    c->send = false;
    int64_t un = room_url(villa_room_name(), true, (coax_v_u8){(uint8_t *)say_url_buf, sizeof say_url_buf});
    coax_string sid = {(const char *)track_state.sid.e, track_state.sid_n};
    int64_t bn = room_chat_body(villa_chat_line(at(state)), sid, (coax_v_u8){say_body, sizeof say_body});
    if (un > 0 && bn > 0) say_ask = coaxial_http((uint32_t)(uintptr_t)say_url_buf, (uint32_t)un, (uint32_t)(uintptr_t)say_body, (uint32_t)bn, 1 | 4 | 8);
  }
  if (room_ask >= 0 && now - room_asked_at < 10) return;
  if (now - room_at < 1.0) return;
  room_at = now;
  int64_t un = room_url(villa_room_name(), false, (coax_v_u8){(uint8_t *)room_url_buf, sizeof room_url_buf});
  coax_t_Point feet = v->feet;
  int64_t bn = room_presence_body(feet.x, feet.y, feet.z, v->face, v->room.e[0].last, (coax_v_u8){room_body, sizeof room_body});
  if (un <= 0 || bn <= 0) return;
  room_ask = coaxial_http((uint32_t)(uintptr_t)room_url_buf, (uint32_t)un, (uint32_t)(uintptr_t)room_body, (uint32_t)bn, 1 | 4 | 8);
  room_asked_at = now;
}

// The figures where the page left them: you (0) on your feet, the dog (1) where it walks.
static void pose(uint32_t state, float dt) {
  coax_t_Villa *v = villa(state);
  vf_tick(fv(), dt);
  int64_t per = vf_max_bones() * vf_bone_floats();
  coax_t_Point feet = v->feet;
  vf_step(fv(), 0, villa_you_speed(at(state)), dt);
  int64_t n = vf_place(fv(), 0, feet.x, feet.y, feet.z, v->face, (coax_v_f32){v->bones.e, per}, (coax_v_f32){v->bound.e, 4});
  villa_set_bones(at(state), 0, n);
  coax_t_Follower dog = villa_draw_dog(at(state));
  float speed = sqrtf(dog.vel.x * dog.vel.x + dog.vel.z * dog.vel.z);
  vf_step(fv(), 1, speed, dt);
  n = vf_place(fv(), 1, dog.pos.x, dog.pos.y, dog.pos.z, dog.face, (coax_v_f32){v->bones.e + per, per}, (coax_v_f32){v->bound.e + 4, 4});
  villa_set_bones(at(state), 1, n);
  villa_set_pet_still(at(state), vf_still(fv(), 1));
}

EXPORT("coaxial_frame")
uint32_t coaxial_frame(uint32_t state, uint32_t vertices, uint32_t uniforms, float w, float h, float scale, float dt, uint32_t still) {
  start(state);
  coax_t_Villa *v = villa(state);
  width = w; height = h; dpr = scale;
  float frame = dt;   /* the player's clock (aethyr/loop.coax) steps it; the rest moves by what it counts */
  dt = verse_player_counts(player, frame);
  now += dt;
  v->golden = golden;
  if (!v->started || v->time == 0) v->still = still != 0;
  v->wall_ms = track_state.epoch + track_state.t * 1000.0;
  villa_controls(at(state), dt, sticks.dyaw, sticks.dpitch);
  bool busy = villa_busy(at(state));
  if (busy) sticks = verse_sticks_reset();
  player = verse_player_input(player, v->key_x, v->key_y, sticks.pad_x, sticks.pad_y, verse_runs(v->run, sticks.run, sticks.pad_x, sticks.pad_y), v->jump || sticks.jump, 0, 0);
  player.theta = villa_player_theta(at(state));
  if (sticks.zoom != 0) villa_wheel(at(state), sticks.zoom);   /* a pinch zooms as the wheel does (verse/grid.coax) */
  sticks = verse_sticks_used(sticks);
  int64_t walls = villa_walls(at(state));
  coax_t_AdvanceTrace walked = verse_player_advance_in_realm_traced(player, frame, (coax_v_f32){0, 0}, (coax_v_f32){v->walls.e, walls * 6},
                                         (coax_v_f32){0, 0}, (coax_string){"hecates-cemetery", sizeof "hecates-cemetery" - 1});
  player = walked.player;
  coax_t_Vec3 feet = verse_player_feet(player);
  villa_step_on_clock(at(state), player.clock, (coax_v_t_StepTarget){walked.targets.e, walked.count},
                      feet.x, feet.y, feet.z, verse_player_face(player), verse_player_act(player), player.vel.x, player.vel.z);
  {   // metres walked and each 20 m square of the cemetery visited once (analytics.coax track_walk, track_area)
    static float last_x, last_z; static bool placed;
    if (placed) { float dx = feet.x - last_x, dz = feet.z - last_z; track_walk(tr(), __builtin_sqrt((double)(dx * dx + dz * dz))); }
    placed = true; last_x = feet.x; last_z = feet.z;
    char sq[8]; int cx = (int)((feet.x + 2000.0f) / 20.0f), cz = (int)((feet.z + 2000.0f) / 20.0f);   /* 100 is 0 m */
    sq[0] = 'x'; sq[1] = (char)('0' + cx / 100 % 10); sq[2] = (char)('0' + cx / 10 % 10); sq[3] = (char)('0' + cx % 10);
    sq[4] = 'z'; sq[5] = (char)('0' + cz / 100 % 10); sq[6] = (char)('0' + cz / 10 % 10); sq[7] = (char)('0' + cz % 10);
    track_area(tr(), (coax_string){sq, 8});
  }
  pet_look(state);
  pose(state, dt);
  pet_requests(state);
  room_requests(state, dt);
  coax_v_f32 out = {(float *)(uintptr_t)vertices, coaxial_villa_max_vertices() * coaxial_villa_vertex_floats()};
  coax_v_f32 u = {(float *)(uintptr_t)uniforms, coaxial_villa_uniform_floats()};
  int64_t n = villa_draw(at(state), out, u, w, h, scale, sticks.move_on, sticks.ox, sticks.oy, sticks.pad_x, sticks.pad_y);
  place_frame(state);
  track_frame(tr(), dt, w, h, scale);
  // world-enter and load-engine, as every realm sends them, so a visit counts as loaded and in a world
  if (n > 0 && !entered) { entered = true; track_world(tr(), track_cstr("hecates-cemetery")); track_loaded(tr(), track_cstr("load-engine")); }
  // The flight, once: that it played to its end or was skipped.
  if (!flight_told && v->time > 0.2 && !villa_busy(at(state))) {
    flight_told = true;
    if (villa_fly_wanted(at(state)) && track_begin(tr(), track_cstr("villa-flight"))) {
      track_bool(tr(), track_cstr("skipped"), v->fl_t < 8.5f);
      track_end(tr());
    }
  }
  // the steps you took this frame (villapet.coax EV_*), for the analytics dashboard
  for (int64_t i = 0, e = villa_ev_count(at(state)); i < e; i++) {
    coax_string name = villa_ev_name(at(state), i);
    if (name.count && track_begin(tr(), name)) { track_int(tr(), track_cstr("n"), villa_ev_arg(at(state), i)); track_end(tr()); }
  }
  villa_ev_clear(at(state));
  edit_face_drain(ed(state));
  track_drain(&track_state);
  return n < 0 ? 0u : (uint32_t)n;
}

EXPORT("coaxial_draws") uint32_t coaxial_draws(uint32_t state) { return (uint32_t)(uintptr_t)villa(state)->draws.e; }
EXPORT("coaxial_draw_count") uint32_t coaxial_draw_count(uint32_t state) { return villa(state)->started ? (uint32_t)villa_draws(at(state)) : 0u; }
EXPORT("coaxial_stores") uint32_t coaxial_stores(void) { return 2; }
EXPORT("coaxial_store_cap") uint32_t coaxial_store_cap(int32_t k) { return (uint32_t)villa_store_cap(k); }
EXPORT("coaxial_store") uint32_t coaxial_store(uint32_t state, int32_t k) {
  return (uint32_t)(uintptr_t)(k == 0 ? (void *)villa(state)->heights.e : (void *)villa(state)->objects.e);
}
EXPORT("coaxial_store_bytes") uint32_t coaxial_store_bytes(uint32_t state, int32_t k) { (void)state; return (uint32_t)villa_store_cap(k); }

// ---- the particles the host draws after the scene (particles.wgsl)
EXPORT("coaxial_particle_cap") uint32_t coaxial_particle_cap(void) { return (uint32_t)sizeof(((coax_t_Villa *)0)->emitters); }
EXPORT("coaxial_particles") uint32_t coaxial_particles(uint32_t state) { return (uint32_t)(uintptr_t)villa(state)->emitters.e; }
EXPORT("coaxial_particle_bytes") uint32_t coaxial_particle_bytes(uint32_t state) {
  return (uint32_t)(villa_emitter_count(at(state)) * 16 * sizeof(float));
}
EXPORT("coaxial_particle_instances") uint32_t coaxial_particle_instances(uint32_t state) {
  return (uint32_t)(villa_emitter_count(at(state)) * villa_particles_per());
}

EXPORT("coaxial_key") uint32_t coaxial_key(uint32_t state, int32_t key, int32_t mods) {
  start(state);
  track_key(tr(), key, villa_wants_text(at(state)));
  bool used = villa_key(at(state), key, mods);
  track_drain(&track_state);
  return used ? 1u : 0u;
}
EXPORT("coaxial_key_up") uint32_t coaxial_key_up(uint32_t state, int32_t key, int32_t mods) {
  track_key_up(tr(), key);
  return villa_key_up(at(state), key, mods) ? 1u : 0u;
}
EXPORT("coaxial_blur") void coaxial_blur(uint32_t state) { villa_blur(at(state)); sticks = verse_sticks_reset(); track_blur(tr()); }
EXPORT("coaxial_pointer") uint32_t coaxial_pointer(uint32_t state, float x, float y, int32_t phase, int32_t kind, int32_t id) {
  start(state);
  track_pointer(tr(), x, y, phase, kind, (coax_string){"", 0});
  track_drain(&track_state);
  if (villa_pointer(at(state), x, y, phase, kind, id)) { pet_action(state); return 1u; }
  if (kind != 0) sticks = verse_sticks_world_touch(sticks, id, phase, x, y, width, height, dpr, now);
  return kind != 0 ? 1u : 0u;
}
EXPORT("coaxial_wheel") void coaxial_wheel(uint32_t state, float dy) { villa_wheel(at(state), dy); }

EXPORT("coaxial_inbox") uint32_t coaxial_inbox(uint32_t state) { (void)state; return (uint32_t)(uintptr_t)inbox; }
EXPORT("coaxial_inbox_cap") uint32_t coaxial_inbox_cap(void) { return sizeof inbox; }
static int http_status(uint32_t length, uint32_t *body) {
  int status = 0; uint32_t i = 0;
  while (i < length && inbox[i] >= '0' && inbox[i] <= '9') { status = status * 10 + (inbox[i] - '0'); i++; }
  while (i < length && inbox[i] != '\n') i++;
  *body = i < length ? i + 1 : length;
  return status;
}
EXPORT("coaxial_message") void coaxial_message(uint32_t state, int32_t kind, uint32_t length) {
  if (length > sizeof inbox) return;
  start(state);
  if (place_message(state, kind, inbox, length)) return;
  if (kind != 600 && edit_face_message(ed(state), kind, (coax_string){(const char *)inbox, length})) { edit_face_drain(ed(state)); return; }
  if (kind == 600) {   // the page facts: whether the browser has a player key
    facts_seen = true;
    for (uint32_t i = 0; i + 7 < length; i++)
      if ((i == 0 || inbox[i - 1] == '\n') && !memcmp(inbox + i, "player=", 7) && i + 7 < length && inbox[i + 7] != '\n') has_player = true;
  }
  if (kind == 4) { villa_kept(at(state), (coax_string){(const char *)inbox, length}); return; }
  if (kind == 1) { villa_typed(at(state), (coax_string){(const char *)inbox, length}); return; }
  if (kind == 52) { villa_pet_files(at(state), (coax_string){(const char *)inbox, length}); return; }
  if (kind == 53) { villa_pet_scanned(at(state), (coax_string){(const char *)inbox, length}); return; }
  if (mint_ask >= 0 && kind == 512 + mint_ask) {
    mint_ask = -1;
    uint32_t b; int st = http_status(length, &b);
    if (st == 200 && length - b > 0 && length - b <= sizeof mint_record) { memcpy(mint_record, inbox + b, length - b); mint_n = length - b; }
    return;
  }
  if (pet_ask >= 0 && kind == 512 + pet_ask) {
    pet_ask = -1;
    uint32_t b; int st = http_status(length, &b);
    villa_pet_answer(at(state), pet_kind, st, (coax_string){(const char *)inbox + b, length - b});
    return;
  }
  if (slow_ask >= 0 && kind == 512 + slow_ask) {
    slow_ask = -1;
    uint32_t b; int st = http_status(length, &b);
    villa_pet_answer(at(state), slow_kind, st, (coax_string){(const char *)inbox + b, length - b});
    return;
  }
  if (room_ask >= 0 && kind == 512 + room_ask) {
    room_ask = -1;
    int64_t st = room_take((coax_v_t_RoomState){&villa(state)->room.e[0], 1}, (coax_string){(const char *)inbox, length});
    if (st == 403) has_player = false, minted = false;
    return;
  }
  if (say_ask >= 0 && kind == 512 + say_ask) {
    say_ask = -1;
    uint32_t b; villa_chat_said(at(state), http_status(length, &b));
    room_at = -10;
    return;
  }
  if (kind >= 512 && kind < 520) return;
  if (track_message(tr(), kind, (coax_string){(const char *)inbox, length})) track_drain(&track_state);
}

// The page's actions: copy a link (2), keep the player key (5), pick files to upload (30, uploads.js).
EXPORT("coaxial_action") int32_t coaxial_action(uint32_t state) { (void)state; return action_kind ? action_kind : place_action(); }
EXPORT("coaxial_outbox") uint32_t coaxial_outbox(uint32_t state) { (void)state; return place_out_now ? place_outbox() : (uint32_t)(uintptr_t)action_out; }
EXPORT("coaxial_outbox_len") uint32_t coaxial_outbox_len(uint32_t state) { (void)state; return place_out_now ? place_outbox_len() : action_n; }
EXPORT("coaxial_action_done") void coaxial_action_done(uint32_t state) { (void)state; if (place_out_now) place_done(); else { action_kind = 0; action_n = 0; } }
// Typing in the pet's panel or a memorial's note: the keyboard field over the box drawn.
EXPORT("coaxial_wants_text") int32_t coaxial_wants_text(uint32_t state) { return villa_wants_text(at(state)) ? 1 : 0; }
// The memorial's photos and videos for the host to draw (coax/web/host.js, coaxial_media): villapet.coax's media_text.
EXPORT("coaxial_media") uint32_t coaxial_media(uint32_t state) { return (uint32_t)(uintptr_t)villa(state)->pet.e[0].media_text.e; }
EXPORT("coaxial_media_len") uint32_t coaxial_media_len(uint32_t state) { return (uint32_t)villa(state)->pet.e[0].media_n; }
EXPORT("coaxial_field") uint32_t coaxial_field(uint32_t state) { return (uint32_t)(uintptr_t)&villa(state)->pet.e[0].field_box; }
// A memorial's link: #m/<slug>.
EXPORT("coaxial_hash") void coaxial_hash(uint32_t state, uint32_t length) {
  if (length > sizeof inbox) return;
  start(state);
  villa_hash(at(state), (coax_string){(const char *)inbox, length});
}

// The globals' declared defaults (coax_default_T, from the compiler), before any call:
// _initialize runs this in the browser, the loader natively.
__attribute__((constructor)) static void coaxial_face_defaults(void) {
  coax_default_t_Player(&player);
  coax_default_t_Sticks(&sticks);
}
