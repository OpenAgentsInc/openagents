set -euo pipefail
export VK_DRIVER_FILES=/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json
timeout 600 nix-shell -p gcc pkg-config libdrm vulkan-headers vulkan-loader vulkan-validation-layers spirv-tools --run '
set -e
for p in render/*.spv;do spirv-val --target-env vulkan1.1 "$p";done
read -r -a sources <sources
gcc -std=gnu11 -O2 -no-pie -ffp-contract=off -fno-fast-math -w -I. -Irender-native -Ikms $(pkg-config --cflags libdrm) vk-realm.c realm-host.c "${sources[@]}" render-native/render-host.c render-native/render-realm.c render-native/render-textures.c render-native/render-media.c render-native/RenderTexture.c vks.c vkc.c vkp.c vkd.c $(pkg-config --libs libdrm) -lvulkan -lm -o vk-realm >compile.log 2>&1
export VK_ADD_LAYER_PATH=$(dirname $(find /nix/store -maxdepth 6 -name VkLayer_khronos_validation.json -path "*validation-layers*" | head -1))
export VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation
VERSE_NATIVE_CLOCK_MS=0 ./vk-realm . wrong.pack --facts host.facts --golden --size 320x180 --headless 90 --keys 2:13:1,3:13:0 --raw-out screen.raw >native.log 2>&1
'
