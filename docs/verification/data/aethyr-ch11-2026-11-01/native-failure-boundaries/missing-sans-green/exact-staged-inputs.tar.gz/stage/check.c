#include "render-realm.c"
static float observed_uniforms[112],observed_hud[96];
int main(void){
 Vkc v;vkc_open(&v);RealmHost producer={.floats=12,.max_vertices=8,.uniform_floats=112,.vertices=(uint32_t)(uintptr_t)observed_hud,.uniforms=(uint32_t)(uintptr_t)observed_uniforms};char error[256];
 RhgRealm *r=rhgr_open(&v,&producer,1,"render/render.json",error,sizeof error);if(!r){fprintf(stderr,"open:%s\n",error);return 1;}
 for(size_t i=0;i<r->buffer_count;i++){memset(r->buffers[i].gpu.map,0xa5,r->buffers[i].gpu.size);r->named[i].observed.zero_initialized=false;}
 memset(r->hud.map,0xa5,r->hud.size);
 int result=rhgr_frame(r,1,80,120,0,COAX_RenderTextureFormat_rgba16f,error,sizeof error);if(result)return 2;
 for(size_t i=0;i<r->buffer_count;i++)for(size_t b=0;b<r->buffers[i].gpu.size;b++)if(((uint8_t*)r->buffers[i].gpu.map)[b]!=0xa5){fprintf(stderr,"missing Sans changed buffer payload before refusal:%s\n",error);return 3;}
 for(size_t b=0;b<r->hud.size;b++)if(((uint8_t*)r->hud.map)[b]!=0xa5)return 4;
 printf("missing Sans refused before all producer GPU payload writes:%s\n",error);
 rhgr_close(r);vkc_close(&v);return vkc_validation_errors||vkc_validation_warnings?5:0;
}
