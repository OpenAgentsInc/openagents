#include "render-realm.c"
static int inject_warning=1;
void test_submit(Vkc *v,void(*record)(VkCommandBuffer,void*),void *user){vks_submit(v,record,user);if(inject_warning){vkc_validation_warnings++;inject_warning=0;}}
int main(void){
 RealmHost h;rh_open(&h,1);rh_page(&h,0);char error[256];if(!rhgr_deliver(&h,7,error,sizeof error)){fprintf(stderr,"delivery: %s\n",error);return 1;}
 for(int i=0;i<3;i++){if(i==1)coaxial_key(h.state,13,0);if(i==2)coaxial_key_up(h.state,13,0);coaxial_frame(h.state,h.vertices,h.uniforms,320,180,1,1.0f/60,1);}
 Vkc v;vkc_open(&v);RhgRealm *r=rhgr_open(&v,&h,7,"render/render.json",error,sizeof error);if(!r){fprintf(stderr,"open: %s\n",error);return 1;}
 uint32_t hud=coaxial_frame(h.state,h.vertices,h.uniforms,320,180,1,1.0f/60,1);
 int first=rhgr_frame(r,hud,320,180,0,COAX_RenderTextureFormat_rgba16f,error,sizeof error);uint64_t pending=0;for(size_t i=0;i<r->buffer_count;i++)pending+=r->buffers[i].upload.pending;
 if(first||!pending||vkc_validation_warnings!=1||!strstr(error,"validation")){fprintf(stderr,"postsubmit result%d pending%llu warning%d diagnostic%s\n",first,(unsigned long long)pending,vkc_validation_warnings,error);return 2;}
 if(!rhgr_frame(r,hud,320,180,0,COAX_RenderTextureFormat_rgba16f,error,sizeof error)){fprintf(stderr,"retry: %s\n",error);return 3;}
 for(size_t i=0;i<r->buffer_count;i++)if(r->buffers[i].upload.pending)return 4;
 if(vkc_validation_errors||vkc_validation_warnings!=1)return 5;
 printf("postsubmit warning refused; retained%llu bytes; successful retry acknowledged all prefixes\n",(unsigned long long)pending);
 rhgr_close(r);vkc_close(&v);rh_close(&h);return 0;
}
