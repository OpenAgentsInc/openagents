set -e
export VK_DRIVER_FILES=/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json
timeout 500 nix-shell -p gcc vulkan-headers vulkan-loader vulkan-validation-layers --run '
set -e
flags="-std=gnu11 -O2 -no-pie -ffp-contract=off -fno-fast-math -w -I. -Irender-native"
gcc $flags -Dvks_submit=test_submit -c render-native/render-host.c -o instrumented-host.o >compile.log 2>&1
read -r -a sources <sources
gcc $flags check.c "${sources[@]}" realm-host.c instrumented-host.o render-native/render-textures.c render-native/render-media.c render-native/RenderTexture.c vks.c vkc.c -lvulkan -lm -o check >>compile.log 2>&1
export VK_ADD_LAYER_PATH=$(dirname $(find /nix/store -maxdepth 6 -name VkLayer_khronos_validation.json -path "*validation-layers*" | head -1))
export VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation
VERSE_NATIVE_CLOCK_MS=0 ./check >native.log 2>&1
'
