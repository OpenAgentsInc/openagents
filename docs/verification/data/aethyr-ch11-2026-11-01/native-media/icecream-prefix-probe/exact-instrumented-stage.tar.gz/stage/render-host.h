// Vulkan effects for a package and frame admitted by the shared Coax renderer.
// RenderHost.h is generated from aethyr/render/native-host.coax by the build.
#ifndef AETHYR_NATIVE_RENDER_HOST_H
#define AETHYR_NATIVE_RENDER_HOST_H
#include "RenderHost.h"
#include "vks.h"

typedef struct {const unsigned char *data;size_t bytes;} RhgBytes;
typedef RhgBytes (*RhgRead)(void *user,coax_string file);
typedef struct RhgRenderer RhgRenderer;
// The callback supplies actual handles and Coax-admitted byte views. Kind,
// slot and stage visibility come from use, never from host names or WGSL.
typedef int (*RhgBinding)(void *user,coax_t_RenderHostUse use,coax_t_RenderOp op,VksBinding *out);
typedef void (*RhgMedia)(void *user,VkCommandBuffer cmd,coax_t_RenderOpKind phase);
typedef struct {
  const VkcBuffer *hud,*index;
  coax_v_u32 draw_words;
  RhgBinding binding;RhgMedia media;void *user;
} RhgFrame;

RhgRenderer *rhg_open(Vkc *device,int64_t expected_profile,coax_string json,RhgRead read,void *user,char *error,size_t error_bytes);
// The receipt must be the unmodified result of aethyr_render_frame for these
// exact resources. Refusal makes no Vulkan writes or command submissions.
int rhg_execute(RhgRenderer *renderer,const coax_t_RenderRuntimeFrame *receipt,const RhgFrame *frame,
  int coarse,coax_t_RenderTextureFormat screen_format,char *error,size_t error_bytes);
VksImage *rhg_screen(RhgRenderer *renderer);
VksImage *rhg_target_image(RhgRenderer *renderer,coax_t_RenderTarget target);
uint64_t rhg_draw_commands(const RhgRenderer *renderer);
void rhg_close(RhgRenderer *renderer);
#endif
