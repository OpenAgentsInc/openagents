set -euo pipefail
export VK_DRIVER_FILES=/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json
timeout 600 nix-shell -p gcc vulkan-headers vulkan-loader vulkan-validation-layers spirv-tools --run '
set -e
for p in package/*.spv;do spirv-val --target-env vulkan1.1 "$p";done
gcc -std=c11 -O2 -ffunction-sections -fdata-sections -Wl,--gc-sections -ffp-contract=off -fno-fast-math -Wno-unknown-pragmas -I. native-frame.c render-host.c render-textures.c render-media.c RenderHost.c RenderTexture.c vks.c vkc.c -lvulkan -lm -o native-frame >compile.log 2>&1
export VK_ADD_LAYER_PATH=$(dirname $(find /nix/store -maxdepth 6 -name VkLayer_khronos_validation.json -path "*validation-layers*" | head -1))
export VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation
for case in full:-1 bg:0 scene:5 particle:9 post:11 media:-3 hud:12;do name=${case%:*};cut=${case#*:};RHG_STOP=$cut ./native-frame frame.config package/render.json $name.raw $name.json rgba16f >$name.log 2>&1;done
cp full.raw screen.raw;cp full.json frame.json;cp full.log native.log
'
