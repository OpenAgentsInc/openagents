set -e
export VK_DRIVER_FILES=/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json
timeout 400 nix-shell -p gcc vulkan-headers vulkan-loader vulkan-validation-layers --run '
set -e
gcc -std=c11 -O2 -no-pie -ffunction-sections -fdata-sections -Wl,--gc-sections -ffp-contract=off -fno-fast-math -w -I. check.c render-host.c render-textures.c render-media.c realm-host.c RenderHost.c RenderTexture.c vks.c vkc.c -lvulkan -lm -o check >compile.log 2>&1
export VK_ADD_LAYER_PATH=$(dirname $(find /nix/store -maxdepth 6 -name VkLayer_khronos_validation.json -path "*validation-layers*" | head -1))
export VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation
./check >native.log 2>&1
'
