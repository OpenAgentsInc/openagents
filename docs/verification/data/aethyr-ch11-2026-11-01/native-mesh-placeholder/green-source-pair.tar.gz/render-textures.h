// Exact observed mip bytes. The Coax codec and shared texture-origin policy
// admit them; this effect layer only allocates, row-packs and uploads pixels.
#ifndef AETHYR_RENDER_TEXTURES_H
#define AETHYR_RENDER_TEXTURES_H
#include "render-host.h"
#include "RenderTexture.h"
#include "frame-input.h"
typedef struct RhgTextures RhgTextures;
RhgTextures *rhgt_open(Vkc *device,const RfiFrame *raw,char *error,size_t error_bytes);
coax_v_t_RenderHostNamedTexture rhgt_names(RhgTextures *textures);
const VksImage *rhgt_image(RhgTextures *textures,coax_t_RenderHostTextureReceipt receipt,char *error,size_t error_bytes);
void rhgt_close(RhgTextures *textures);
#endif
