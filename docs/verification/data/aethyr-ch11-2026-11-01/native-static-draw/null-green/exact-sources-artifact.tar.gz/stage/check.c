#include "face.h"
static uint32_t null_draws(uint32_t state){(void)state;return 0;}
static uint32_t measured_draws(uint32_t state){(void)state;return 16;}
#define coaxial_draws null_draws
#define coaxial_draw_capacity measured_draws
#include "render-realm.c"
int main(void){
 RealmHost h={0};coax_t_RenderHostWordView result=rr_draw_words(&h,16);
 if(result.status==COAX_RenderFrameStatus_ok){fprintf(stderr,"nonempty null draw pointer incorrectly admitted\n");return 22;}
 if(result.words||result.address)return 23;
 printf("nonempty null draw pointer refused by existing Core span policy\n");return 0;
}
