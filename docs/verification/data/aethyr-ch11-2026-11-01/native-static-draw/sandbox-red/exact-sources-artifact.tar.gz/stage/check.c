#include "render-realm.c"
int main(int argc,char **argv){
 if(argc!=2)return 10;RealmHost h;rh_open(&h,1);rh_page(&h,0);
 if(rh_pack(&h,argv[1]))return 11;uint32_t particle_bytes=12605;rh_deliver(&h,1,&particle_bytes);
 uint32_t hud=0;for(int i=0;i<90;i++){if(i==2)coaxial_key(h.state,13,0);if(i==3)coaxial_key_up(h.state,13,0);hud=coaxial_frame(h.state,h.vertices,h.uniforms,320,180,1,1.0f/60,1);}
 uint32_t count=coaxial_draw_count(h.state),address=coaxial_draws(h.state);if(!count||!hud){fprintf(stderr,"producer not ready: count%u hud%u\n",count,hud);return 12;}
 if((uint64_t)address>=(uint64_t)(uintptr_t)h.arena&&(uint64_t)address<(uint64_t)(uintptr_t)h.arena+h.arena_size)return 13;
 coax_t_RenderHostWordView view=rr_draw_words(&h,(uint64_t)count*16);
 if(view.status!=COAX_RenderFrameStatus_ok||view.address!=address||view.words!=(int64_t)count*4){fprintf(stderr,"actual static draw view refused: status%u count%u words%lld address%u arena%p\n",view.status,count,(long long)view.words,address,(void*)h.arena);return 14;}
 // The original independently measured arena route remains valid.
 uint32_t value[4]={0};RealmHost local={.arena=(unsigned char*)value,.arena_size=sizeof value};
 coax_t_RenderHostWordView arena=aethyr_render_words((uint64_t)(uintptr_t)value,(uint64_t)(uintptr_t)local.arena,local.arena_size,sizeof value);if(arena.status!=COAX_RenderFrameStatus_ok||arena.words!=4)return 15;
 printf("actual static draw allocation admitted: %u records, %lld words, %u HUD vertices\n",count,(long long)view.words,hud);rh_close(&h);return 0;
}
