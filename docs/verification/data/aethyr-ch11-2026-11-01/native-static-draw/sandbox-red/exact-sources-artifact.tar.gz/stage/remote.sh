set -euo pipefail
timeout 500 nix-shell -p gcc vulkan-headers --run '
set -e
read -r -a sources <sources
gcc -std=gnu11 -O2 -no-pie -ffunction-sections -fdata-sections -Wl,--gc-sections -ffp-contract=off -fno-fast-math -w -I. check.c "${sources[@]}" realm-host.c RenderHost.c -lm -o check >compile.log 2>&1

./check sandbox.pack >sandbox.log 2>&1
'
