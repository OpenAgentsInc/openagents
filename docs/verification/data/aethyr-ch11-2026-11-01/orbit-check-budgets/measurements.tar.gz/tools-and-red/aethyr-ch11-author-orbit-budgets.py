from pathlib import Path
import json,hashlib,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');work=Path('/tmp/aethyr-ch11-orbit-check-profiles');originals={};texts={};rows=[]
for i in range(35):
 record=json.loads((work/f'{i}.json').read_text());e=json.loads((work/f'{i}.evidence.json').read_text());assert record['status']=='pass'and not record['source_changes'];claims=[r for r in e['claims']if r['outcome']=='passed'];assert len(claims)==1;check=claims[0];assert check['name']==record['name'];rel=check['at']['file'];app=root/rel
 if rel not in originals:originals[rel]=app.read_text();texts[rel]=originals[rel]
 source=next(r for r in e['sources']if r['path']==str(app));assert source['sha256']==hashlib.sha256(originals[rel].encode()).hexdigest();steps=check['steps'];limit=((steps*5+39999999)//40000000)*10000000
 old='#test '+json.dumps(check['name'])+' {';new='#test '+json.dumps(check['name'])+' #steps '+str(limit)+' {';assert texts[rel].count(old)==1,(rel,check['name']);texts[rel]=texts[rel].replace(old,new);rows.append({'source':rel,'name':check['name'],'measured_steps':steps,'authored_limit':limit,'profile_index':i})
rel='apps/openagents-web/orbitleague.coax';texts[rel]=texts[rel].replace('//   coax/bin/coax test apps/openagents-web/orbitleague.coax --steps 2000000000','//   coax/bin/coax test apps/openagents-web/orbitleague.coax   (long simulations declare measured #steps)')
for rel,text in texts.items():assert originals[rel].count('\n')==text.count('\n')
for rel,text in texts.items():
 p=root/rel;(work/(p.stem+'-original.coax')).write_text(originals[rel]);(work/(p.stem+'-authored.coax')).write_text(text);p.write_text(text)
out=root/'docs/verification/data/aethyr-ch11-2026-11-01/orbit-check-budgets';out.mkdir(exist_ok=True)
with tarfile.open(out/'measurements.tar.gz','w:gz',compresslevel=9)as tar:
 for p in work.glob('*'):
  if p.is_file():tar.add(p,arcname=p.name)
 for p in [Path('/tmp/aethyr-ch11-profile-orbit-check.py'),Path('/tmp/aethyr-ch11-orbit-long-checks.json'),Path(__file__),Path('/tmp/aethyr-ch11-typed-hosts-one/orbitleague.log'),Path('/tmp/aethyr-ch11-typed-hosts-one/orbitleague.json')]:tar.add(p,arcname='tools-and-red/'+p.name)
q={'schema':'aethyr.render.orbit-authored-check-budgets.v1','status':'individual measurements pass; authored fullcarrier build pending','compiler_sha256':e['compiler']['sha256'],'original_source_sha256':{k:hashlib.sha256(v.encode()).hexdigest()for k,v in originals.items()},'authored_source_sha256':{k:hashlib.sha256(v.encode()).hexdigest()for k,v in texts.items()},'source_bodies_unchanged':True,'source_line_count_unchanged':True,'global_check_limit_unchanged':20000000,'original_documented_caller_budget':2000000000,'measured_sum':sum(r['measured_steps']for r in rows),'measured_max':max(r['measured_steps']for r in rows),'authored_max':max(r['authored_limit']for r in rows),'rule':'125percent of measured work rounded upward to10million; only35 concrete existing default-budget failures,34appchecks andone importeddrumcheck. No test body, expectation or production arithmetic changed.','checks':rows,'archive':'measurements.tar.gz','archive_sha256':hashlib.sha256((out/'measurements.tar.gz').read_bytes()).hexdigest()};(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print('assigned',len(rows),'authored max',q['authored_max'])
