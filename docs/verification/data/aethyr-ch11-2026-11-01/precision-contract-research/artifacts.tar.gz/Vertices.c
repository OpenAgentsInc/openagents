#include "Vertices.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static void *load(const char *p,size_t *n){FILE*f=fopen(p,"rb");assert(f&&!fseek(f,0,SEEK_END));long z=ftell(f);assert(z>=0&&!fseek(f,0,SEEK_SET));void*b=malloc((size_t)z+1);assert(b&&fread(b,1,(size_t)z,f)==(size_t)z&&!fclose(f));*n=(size_t)z;return b;}
int main(int argc,char**argv){assert(argc==5);size_t un,on;float*u=load(argv[1],&un);coax_t_DeadgearsObj*o=load(argv[2],&on);assert(un%4==0&&on%sizeof(*o)==0);FILE*in=fopen(argv[3],"rb"),*out=fopen(argv[4],"wb");assert(in&&out);uint32_t pair[2];while(fread(pair,8,1,in)==1){coax_t_DeadgearsS s=dg_precision_vertex(pair[0],pair[1],(coax_v_f32){u,(int64_t)(un/4)},(coax_v_t_DeadgearsObj){o,(int64_t)(on/sizeof(*o))});float packet[14]={s.pos.x,s.pos.y,s.pos.z,s.pos.w,s.world.x,s.world.y,s.world.z,s.normal.x,s.normal.y,s.normal.z,s.tint.x,s.tint.y,s.tint.z,s.glow};assert(fwrite(packet,4,14,out)==14);}assert(feof(in)&&!fclose(in)&&!fclose(out));free(u);free(o);return 0;}
