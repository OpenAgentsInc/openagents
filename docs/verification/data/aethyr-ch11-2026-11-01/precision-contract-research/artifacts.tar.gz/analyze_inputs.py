from pathlib import Path
import json,struct,math,hashlib
W=Path(__file__).parent;source=Path('/tmp/aethyr-ch11-deadgears-box36-current-default')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=list(struct.iter_unpack('<2I',(W/'cases.bin').read_bytes()));vertices=list(struct.iter_unpack('<14f',(W/'vertices.bin').read_bytes()));assert len(cases)==len(vertices)==20628
u=struct.unpack('<684f',(source/'u.bin').read_bytes());objects=list(struct.iter_unpack('<16f',(source/'s0.bin').read_bytes()))
g4=4*2**-23/(1-4*2**-23);g8=8*2**-23/(1-8*2**-23)
corners=[(-.5,-.5,-.5),(.5,-.5,-.5),(.5,.5,-.5),(-.5,.5,-.5),(-.5,-.5,.5),(.5,-.5,.5),(.5,.5,.5),(-.5,.5,.5)]
ids=[1,2,6,1,6,5,0,4,7,0,7,3,3,7,6,3,6,2,0,1,5,0,5,4,4,5,6,4,6,7,0,3,2,0,2,1]
box_delta=[0]*4;box_world_delta=[0]*3;positive_w_certified=0;box_vertices=0;delta_records=[]
for (id,instance),v in zip(cases,vertices):
 if instance<96:continue
 box_vertices+=1;p=(*corners[ids[id]],1);m=objects[instance]
 dw=[g8*sum(abs(m[j*4+k]*p[k])for k in range(4))for j in range(3)]
 dc=[g8*sum(abs(u[8+j*4+k]*(*v[4:7],1)[k])for k in range(4))+(1+g4)*sum(abs(u[8+j*4+k])*dw[k]for k in range(3))for j in range(4)]
 box_world_delta=[max(x,y)for x,y in zip(box_world_delta,dw)];box_delta=[max(x,y)for x,y in zip(box_delta,dc)]
 positive_w_certified+=v[3]-dc[3]>0
 delta_records.append({'id':id,'instance':instance,'clip':v[:4],'cpu_gpu_clip_absolute_envelope':dc})
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
sub=lambda a,b:tuple(x-y for x,y in zip(a,b))
cross=lambda a,b:(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
triangles=[vertices[i:i+3]for i in range(0,len(vertices),3)]
degenerate=sum(dot(cross(sub(t[1][4:7],t[0][4:7]),sub(t[2][4:7],t[0][4:7])),cross(sub(t[1][4:7],t[0][4:7]),sub(t[2][4:7],t[0][4:7])))==0 for t in triangles)
mixed_w=sum(min(v[3]for v in t)<=0<max(v[3]for v in t)for t in triangles)
near_cross=sum(min(v[2]for v in t)<0<max(v[2]for v in t)for t in triangles)
axis_magnitude=[math.sqrt(sum((row[4+i]-row[i]+(.00001 if i==1 else 0))**2 for i in range(3)))for row in objects[:42]]
q={'schema':'aethyr.render.deadgears-input-precision-preflight.v1','status':'input-only; no candidate acceptance decision','scope':'All20628actual indexed productionVS invocations, using unchanged observedrawU/objects/draws/index and currentwinding shader. No GPUcolour/depth readback or failed-pixel list consumed. Bounds below are only shaderlinear-form bounds; they deliberately do not assert a fixed-function depth model.',
 'draws':json.loads((W/'draws.json').read_text())['draws'],'vertices':len(vertices),'triangles':len(triangles),'nominal_world_degenerate_triangles':degenerate,
 'nominal_output_nonfinite_scalars':sum(not math.isfinite(x)for v in vertices for x in v),'nominal_world_min':[min(v[4+i]for v in vertices)for i in range(3)],'nominal_world_max':[max(v[4+i]for v in vertices)for i in range(3)],
 'nominal_clip_w_min':min(v[3]for v in vertices),'nominal_clip_w_max':max(v[3]for v in vertices),'nominal_triangles_crossing_w_zero':mixed_w,'nominal_triangles_crossing_near_plane':near_cross,
 'raw_bone_axis_magnitude_with_authored_epsilon_min':min(axis_magnitude),'raw_bone_axis_magnitude_with_authored_epsilon_max':max(axis_magnitude),
 'linear_box_vertices':box_vertices,'linear_box_cpu_gpu_world_envelope_max':box_world_delta,'linear_box_cpu_gpu_clip_envelope_max':box_delta,'linear_box_vertices_provably_positive_w_before_unknown_ff_division':positive_w_certified,
 'linear_form_assumptions':'Finite normal/no-overflow four-term dot4, rounded eachoperationatmostoneULP in eitherdirection, contraction/reassociation restrictedto the same four-term linear form. Two evaluations differ by<=2gamma4*S<=gamma8*S; composedworld uncertainty propagated into each cliprow. Outward rational endpoints are required for a productionimplementation; this report uses binary64 for magnitude census only.',
 'not_yet_established':['All capsule normalize/cross/branch interval bounds','Fixed-function perspective/clipping/coverage/depth operation DAG and numericerrorbound','Full-frame possible-winner counts','FS branch-stability and wholeRGBA certificates'],
 'candidate_counts':None,'sources':{str(p):sha(p)for p in [source/'u.bin',source/'s0.bin',source/'draws.bin',source/'indices.bin',W/'vertices.coax',W/'Kernel.c',W/'Vertices.h',W/'driver.c',W/'cases.bin',W/'vertices.bin',Path(__file__)]},
 'compiler_sha256':sha('/tmp/aethyr-authority-budget-qualified-1fac/coax'),'tooling_failures_preserved':['Initial generator correctlyrefused its own incorrect assumption that draws werenonindexed; fixedbyreadingactualindexpayload','Case-insensitive filename collisionoverwrotetemporarygeneratedVertices.c withvertices.c driver; originalfailedlink retained, separatedKernel.c/driver.c andregeneratedlosttemporaryC once. No productsourceor passingGPUprobe repeated.']}
(W/'input-preflight.json').write_text(json.dumps(q,indent=2)+'\n');(W/'box-linear-envelopes.json').write_text(json.dumps(delta_records)+'\n');print(json.dumps({k:q[k]for k in q if k not in ['sources','linear_form_assumptions','tooling_failures_preserved']},indent=2))
