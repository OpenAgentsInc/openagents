"""Research-only exact homogeneous geometry; never consumes GPU colour.

The legality of the global internal-depth representation models is an
explicit proof obligation. This file does not issue an admitted mask.
"""
from pathlib import Path
from fractions import Fraction as Q
import math,struct,json,time,hashlib
W=Path(__file__).parent
bits=lambda f:struct.unpack('<I',struct.pack('<f',f))[0]
value=lambda b:struct.unpack('<f',struct.pack('<I',b))[0]

def rounded(n,d):
    assert 0<=n<=d and d>0
    b=bits(n/d);f=value(b);fn,fd=f.as_integer_ratio();delta=n*fd-fn*d
    if delta==0:return b,b,b
    if delta>0:lo,hi=b,b+1
    else:lo,hi=b-1,b
    ln,ld=value(lo).as_integer_ratio();hn,hd=value(hi).as_integer_ratio()
    assert n*ld>=ln*d and n*hd<=hn*d
    side=2*n*ld*hd-d*(ln*hd+hn*ld)
    nearest=lo if side<0 or(side==0 and lo%2==0)else hi
    return nearest,lo,hi

assert rounded(1,2)==(bits(.5),)*3
u=Q(1,2**24);back=Q(1,2)+3*u/4;front=Q(1,2)+u/4
assert rounded(back.numerator,back.denominator)==(bits(.5)+1,bits(.5),bits(.5)+1)
assert rounded(front.numerator,front.denominator)==(bits(.5),bits(.5),bits(.5)+1)
def choose(depths,mode):
    best=bits(1.);winner=-1
    for i,z in enumerate(depths):
        key=rounded(z.numerator,z.denominator)[mode]
        if key<best:best=key;winner=i
    return winner
assert [choose([back,front],m)for m in range(3)]==[1,0,0]
assert [choose([Q(3,4),Q(1,4)],m)for m in range(3)]==[1,1,1]
assert [choose([Q(1,2),Q(1,2)],m)for m in range(3)]==[0,0,0]

def setup(clip,width,height):
    ratios=[float(x).as_integer_ratio()for v in clip for x in v]
    scale=max(d for n,d in ratios);v=[tuple(n*(scale//d)for n,d in ratios[i:i+4])for i in range(0,12,4)]
    edges=[]
    for j,k in [(1,2),(2,0),(0,1)]:
        x,y,z,w=v[j];xx,yy,zz,ww=v[k]
        edges.append((y*ww-w*yy,w*xx-x*ww,x*yy-y*xx))
    determinant=sum(v[i][3]*edges[i][2]for i in range(3))
    if determinant==0:return None
    sign=1 if determinant>0 else-1
    coeff=[(2*a*height*sign,-2*b*width*sign,(a*height*(1-width)+b*width*(height-1)+c*width*height)*sign)for a,b,c in edges]
    zcoeff=tuple(sum(v[i][2]*coeff[i][j]for i in range(3))for j in range(3));den=abs(determinant)*width*height
    if all(p[3]<=0 for p in v):return None
    if all(p[3]>0 for p in v):
        xs=[Q((p[0]+p[3])*width,2*p[3])for p in v];ys=[Q((p[3]-p[1])*height,2*p[3])for p in v]
        ceil=lambda q:-((-q.numerator)//q.denominator)
        x0=max(0,ceil(min(xs)-Q(1,2)));x1=min(width-1,(max(xs)-Q(1,2)).numerator//(max(xs)-Q(1,2)).denominator)
        y0=max(0,ceil(min(ys)-Q(1,2)));y1=min(height-1,(max(ys)-Q(1,2)).numerator//(max(ys)-Q(1,2)).denominator)
    else:x0,x1,y0,y1=0,width-1,0,height-1
    return coeff,zcoeff,den,(x0,x1,y0,y1)

# An independent 2x2 projection fixture has exact barycentrics(.5,.25,.25).
t=[(-1.,-1.,float(Q(1,2)+u),1.),(1.,-1.,float(Q(1,2)+u),1.),(-1.,1.,.5,1.)]
c,z,d,bbox=setup(t,2,2);x,y=0,1
assert all(a*x+b*y+c0>0 for a,b,c0 in c)
assert Q(z[0]*x+z[1]*y+z[2],d)==back

def main():
    start=time.monotonic();width,height=320,180;raw=(W/'vertices.bin').read_bytes();vertices=list(struct.iter_unpack('<14f',raw));assert len(vertices)%3==0
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [W/'vertices.bin',W/'cases.bin',Path(__file__)]}
    best=[[bits(1.)]*(width*height)for m in range(3)];winners=[[-1]*(width*height)for m in range(3)];coverage=[0]*(width*height);iterations=fragments=0;setups=0;refused=[]
    for primitive,at in enumerate(range(0,len(vertices),3)):
        if time.monotonic()-start>810:raise TimeoutError('bounded input preflight')
        clip=[v[:4]for v in vertices[at:at+3]]
        if any(not math.isfinite(v)for p in clip for v in p):raise ValueError('nonfinite clip')
        s=setup(clip,width,height)
        if s is None:continue
        c,z,d,(x0,x1,y0,y1)=s;setups+=1
        include=[a>0 or(a==0 and b>0)for a,b,_ in c]
        for y in range(y0,y1+1):
            for x in range(x0,x1+1):
                iterations+=1;e=[a*x+b*y+c0 for a,b,c0 in c]
                if any(t<0 or(t==0 and not allowed)for t,allowed in zip(e,include)):continue
                n=z[0]*x+z[1]*y+z[2]
                if n<0 or n>d:continue
                offset=y*width+x;coverage[offset]+=1;fragments+=1
                for m,key in enumerate(rounded(n,d)):
                    if key<best[m][offset]:best[m][offset]=key;winners[m][offset]=primitive
    mask=bytes(int(len({winners[m][i]for m in range(3)})>1)for i in range(width*height))
    (W/'provisional-witness-mask.bin').write_bytes(mask)
    for m,name in enumerate(['nearest','down','up']):(W/('winner-'+name+'.bin')).write_bytes(struct.pack('<'+str(width*height)+'i',*winners[m]))
    changes=[p for p,h in before.items()if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not changes
    count=sum(mask);report={'schema':'aethyr.render.depth-witness-preflight.v1','status':'research-only; model legality and source eligibility not yet admitted','scope':'All source-derived actualVS clip packets. Exact integer homogeneous point coverage and exact rational linear depth, then one of three GLOBAL internalf32 sample-depth rounding models (nearest-even/down/up). LESS comparison and D32storage both use that typed internalvalue. This is a positive ambiguity witness family, NOT a universal actualhardwareerrorbound. No GPU colour/depthfile read.',
        'models':['exact-linear-depth-to-internal-f32-nearest-even','exact-linear-depth-to-internal-f32-down','exact-linear-depth-to-internal-f32-up'],'width':width,'height':height,'triangles':len(vertices)//3,'nondegenerate_positive_projective_setups':setups,'pixel_visits':iterations,'covered_fragments':fragments,'max_covered_fragments_per_pixel':max(coverage),'ambiguity_pixels':count,'ambiguity_channels':count*4,'ordinary_strict_checked_channels_if_admitted':(width*height-count)*4,'mask_sha256':hashlib.sha256(mask).hexdigest(),'input_sha256':before,'input_changes':changes,'elapsed_seconds':time.monotonic()-start,'independent_exact_controls':5,'remaining_proof_obligations':['Eachcomplete arithmetic model isconforming for actualbackendtarget, including internalf32 sampledepthconversion semantics','NativeRNE VS packet values are permittedby all actualshaderops','Exact coverage witness vs independentlyqualifieddevice coverage profile needs explicitcontract scope','Bounded mask allowance chosenbefore GPUreadback and whole prior occluderhistoryproof','Independent plantedbadinterior/depth/topology/cap controls before productionadmission']}
    (W/'witness-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
