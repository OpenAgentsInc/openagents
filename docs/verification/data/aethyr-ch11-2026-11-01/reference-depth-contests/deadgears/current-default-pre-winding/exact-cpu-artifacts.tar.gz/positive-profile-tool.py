from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/tmp/aethyr-ch11-reference-deadgears-ring8-current-native')
work=Path('/tmp/aethyr-ch11-reference-deadgears-ring8-current-browser');work.mkdir(exist_ok=True)
old=json.loads((root/'measurement.json').read_text());assert old['status']=='rendered' and not old['source_changes'] and not old['input_changes'] and not old['artifact_changes'] and not old['compiler_changed']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
artifacts={kind:Path(old[kind+'_path'])for kind in ['generated_c','generated_header','executable']}
for kind,path in artifacts.items():assert sha(path)==old[kind+'_sha256']
before=dict(old['input_sha256']);before.update({str(p):sha(p)for p in artifacts.values()});before[str(root/'measurement.json')]=sha(root/'measurement.json')
for p,h in before.items():assert sha(p)==h
command=[str(artifacts['executable']),str(root/'frame.config'),str(work/'screen.rgba32f'),str(work/'frame.json'),'nearest-positive','8','guard-band','65536','rgba16f','complex-world','analytic']
started=time.monotonic()
with (work/'render.log').open('wb')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=830)
assert r.returncode==0
changes=[p for p,h in before.items()if sha(p)!=h];assert not changes
result=json.loads((work/'frame.json').read_text());assert result['status']==0
receipt={'schema':'aethyr.render.retained-backend-profile-measurement.v1','status':'rendered','qualification':False,'scope':'Exact prior admitted normal-C/backend/header executable and exact fresh producer/package snapshots reused. Only declared raster rounding profile switches nearest-even to independently device-qualified nearest-positive. No Coax emission or assertion about later mutable product sources.',
 'backend_receipt':str(root/'measurement.json'),'backend_receipt_sha256':sha(root/'measurement.json'),'compiler_sha256':old['compiler_sha256'],'profile':4,'width':320,'height':180,'result':result,'command':command,'elapsed_seconds':time.monotonic()-started,'raster_profile':{'rounding':'nearest-positive','subpixel_bits':8,'xy_clipping':'guard-band','guard_pixels':65536,'provenance':'/tmp/aethyr-ch11-depth-left-webgpu-analysis.json'},'inputs_artifacts_sha256':before,'input_artifact_changes':changes,'image_sha256':sha(work/'screen.rgba32f')}
(work/'measurement.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['status','elapsed_seconds','result']}))
