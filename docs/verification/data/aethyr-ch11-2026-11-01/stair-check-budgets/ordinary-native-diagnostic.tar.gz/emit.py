from pathlib import Path
import hashlib,json,os,signal,subprocess,time
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');work=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads(Path('/tmp/aethyr-ch11-stair-check-profiles/0.evidence.json').read_text());paths=[Path(x['path'])for x in e['sources']]+[work/'stair-candidate.coax',work/'stair-coop-candidate.coax'];before={str(p):sha(p)for p in paths}
command=[str(root/'coax/bin/coax'),'c',str(work/'stair-candidate.coax'),'--library','--header',str(work/'Stair.h')];start=time.monotonic();timed=False
with (work/'Stair.c').open('wb')as out,(work/'emission.log').open('wb')as err:
 p=subprocess.Popen(command,cwd=root,stdout=out,stderr=err,start_new_session=True)
 try:p.wait(timeout=810)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
changes=[s for s,h in before.items()if sha(Path(s))!=h];q={'command':command,'status':'pass'if p.returncode==0 and not timed and not changes else'fail','returncode':p.returncode,'deadline_exceeded':timed,'elapsed_seconds':time.monotonic()-start,'compiler_sha256':sha(root/'coax/bin/coax'),'sources':before,'source_changes':changes,'artifacts':{n:sha(work/n)for n in ['Stair.c','Stair.h']if(work/n).exists()},'scope':'Ordinary checked C from the temporary candidate. All mandatory imported authority checks execute; no checks skipped. Not an official native-check ABI qualification.'};(work/'emission.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['status','returncode','elapsed_seconds','source_changes']}))
