#include "Stair.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
 int64_t vertices=coaxial_stair_max_vertices(),stride=coaxial_stair_vertex_floats(),uniforms=coaxial_stair_uniform_floats();
 float *out=calloc((size_t)vertices*(size_t)stride,sizeof(float)),*u=calloc((size_t)uniforms,sizeof(float));if(!out||!u)return 2;
 puts("[");
 for(int stage=0;stage<2;stage++)for(int screen=0;screen<3;screen++){
  coax_t_StairBudgetObservation q=stair_budget_native_observe(stage,screen,(coax_v_f32){out,vertices*stride},(coax_v_f32){u,uniforms});
  printf("{\"stage\":%d,\"screen\":%d,\"frames\":%" PRId64 ",\"refused\":%" PRId64 ",\"bytes\":%" PRId64 ",\"peak\":[",stage,screen,q.meter.frames,q.meter.refused,q.bytes);
  for(size_t k=0;k<sizeof q.meter.peak.e/sizeof q.meter.peak.e[0];k++)printf("%s%" PRId64,k?",":"",q.meter.peak.e[k]);
  fputs("],\"counts\":[",stdout);for(size_t k=0;k<sizeof q.counts.e/sizeof q.counts.e[0];k++)printf("%s%" PRId64,k?",":"",q.counts.e[k]);
  printf("]}%s\n",stage==1&&screen==2?"":",");
 }
 puts("]");free(out);free(u);return 0;
}
