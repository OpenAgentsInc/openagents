from pathlib import Path
import hashlib,json,re
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');work=Path(__file__).parent
manifest=json.loads(Path('/tmp/aethyr-ch11-stair-long-checks.json').read_text());texts={};originals={}
for item in manifest:
 rel=item['source'];p=root/rel
 if rel not in texts:originals[rel]=p.read_text();texts[rel]=originals[rel]
 evidence=json.loads(Path(f"/tmp/aethyr-ch11-stair-check-profiles/{item['index']}.evidence.json").read_text());claim=next(c for c in evidence['claims']if c['name']==item['name']);steps=claim['steps'];limit=((steps*5+39999999)//40000000)*10000000
 assert limit<=3000000000
 old='#test '+json.dumps(item['name'])+' {';new='#test '+json.dumps(item['name'])+' #steps '+str(limit)+' {';assert texts[rel].count(old)==1;texts[rel]=texts[rel].replace(old,new)
for rel,original in originals.items():(work/(Path(rel).stem+'-original.coax')).write_text(original)
stair=texts['apps/openagents-web/stair.coax'];stair=stair.replace('m[0].peak[BUDGET_VERTICES] == 39318','m[0].peak[BUDGET_VERTICES] == 39354')
def absolute_load(match):
 rel=match.group(1);path=(root/'apps/openagents-web'/rel).resolve()
 if path.name=='stair-coop.coax':path=work/'stair-coop-candidate.coax'
 return '#load "'+str(path)+'";'
stair=re.sub(r'#load "([^"]+)";',absolute_load,stair)
witness='''
#test "REALMS has six more Filament strokes than the old GALAXY exit label" {
 out:[256*VERTEX_FLOATS]f32;k:=Ink.{core=1,light=1,glow=0,red=1,green=1,blue=1,mode=0};
 #assert draw_text(out[..],0,"GALAXY",0,20,12,0.1,0.5,k,false,false)==192;
 #assert draw_text(out[..],0,"REALMS",0,20,12,0.1,0.5,k,false,false)==228;
 s:[1]Stair;stair_start(s[..]);label:[16]u8;n:=button_label(s[..],B_GALAXY,label[..]);
 #assert (cast(string)label[0..<n])=="REALMS";
}
'''
helper='''
StairBudgetObservation :: struct {meter:BudgetMeter;counts:[10]int;bytes:int;}
stair_budget_native_observe :: (stage:int,screen:int,out:[]f32,u:[]f32)->StairBudgetObservation #export_c {
 q:StairBudgetObservation;m:=[1]BudgetMeter.[budget_meter(STAIR_BUDGET)];s:[1]Stair;stair_start(s[..]);
 if stage==1 {stair_message(s[..],HOST_PAGE,"url=https://openagents.com/realms/hold-the-stair?stage=swarm");}
 sc:=budget_screen(screen);q.bytes=budget_arena_bytes(size_of(Stair),MAX_VERTICES,VERTEX_FLOATS,UNIFORM_FLOATS);
 for f:0..<10 {n:=stair_frame(s[..],out,u,sc.width,sc.height,sc.dpr,0.05,false);q.counts[f]=n;budget_measure(m[..],n,0,q.bytes);}
 q.meter=m[0];return q;
}
'''
(work/'stair-candidate.coax').write_text(stair+witness+helper);(work/'stair-coop-candidate.coax').write_text(texts['apps/openagents-web/stair-coop.coax']);(work/'witness.coax').write_text(witness)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q={'schema':'aethyr.stair.provisional-diagnostic-candidate.v1','purpose':'Temporary ordinary checked-C diagnostic: unchanged production logic; measured test budgets and provisional historical vertex-pin repair only. Canonical source remains unchanged until native observation.','compiler_sha256':sha(root/'coax/bin/coax'),'originals':{rel:hashlib.sha256(s.encode()).hexdigest()for rel,s in originals.items()},'candidate':{p.name:sha(p)for p in [work/'stair-candidate.coax',work/'stair-coop-candidate.coax']},'glyph_oracle':'glyph-oracle.json'};(work/'candidate.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
