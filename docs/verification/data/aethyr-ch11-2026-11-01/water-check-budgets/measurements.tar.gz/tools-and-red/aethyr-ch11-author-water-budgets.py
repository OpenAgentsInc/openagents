from pathlib import Path
import json,hashlib,tarfile
root=Path('/Users/christopherdavid/work/openagents-aethyr-book');work=Path('/tmp/aethyr-ch11-water-check-profiles');originals={};texts={};rows=[]
manifest=json.loads(Path('/tmp/aethyr-ch11-water-long-checks.json').read_text())
for item in manifest:
 i=item['index'];r=json.loads((work/f'{i}.json').read_text());e=json.loads((work/f'{i}.evidence.json').read_text());assert r['status']=='pass'and not r['source_changes'];claims=[c for c in e['claims']if c['outcome']=='passed'];assert len(claims)==1;claim=claims[0];assert claim['name']==item['name'];rel=claim['at']['file'];assert rel==item['source'],(rel,item)
 p=root/rel
 if rel not in originals:originals[rel]=p.read_text();texts[rel]=originals[rel]
 source=next(s for s in e['sources']if s['path']==str(p));assert source['sha256']==hashlib.sha256(originals[rel].encode()).hexdigest();steps=claim['steps'];limit=((steps*5+39999999)//40000000)*10000000;assert limit<=item['caller_budget'];old='#test '+json.dumps(claim['name'])+' {';new='#test '+json.dumps(claim['name'])+' #steps '+str(limit)+' {';assert texts[rel].count(old)==1;texts[rel]=texts[rel].replace(old,new);rows.append({'source':rel,'name':claim['name'],'measured_steps':steps,'authored_limit':limit,'documented_measurement_caller_limit':item['caller_budget'],'measurement_index':i})
for rel,text in texts.items():
 assert originals[rel].count('\n')==text.count('\n');restored=text
 for row in rows:
  if row['source']==rel:restored=restored.replace('#test '+json.dumps(row['name'])+' #steps '+str(row['authored_limit'])+' {','#test '+json.dumps(row['name'])+' {')
 assert restored==originals[rel]
for rel,text in texts.items():
 p=root/rel;(work/(p.stem+'-original.coax')).write_text(originals[rel]);(work/(p.stem+'-authored.coax')).write_text(text);p.write_text(text)
out=root/'docs/verification/data/aethyr-ch11-2026-11-01/water-check-budgets';out.mkdir(exist_ok=True)
with tarfile.open(out/'measurements.tar.gz','w:gz')as t:
 for p in work.glob('*'):
  if p.is_file():t.add(p,arcname=p.name)
 for p in [Path('/tmp/aethyr-ch11-profile-water-check.py'),Path('/tmp/aethyr-ch11-water-long-checks.json'),Path(__file__),Path('/tmp/aethyr-ch11-typed-hosts-one/waterlab.log'),Path('/tmp/aethyr-ch11-typed-hosts-one/waterlab.json')]:t.add(p,arcname='tools-and-red/'+p.name)
q={'schema':'aethyr.render.water-authored-check-budgets.v1','status':'individual measurements pass; authored full-carrier build pending','compiler_sha256':e['compiler']['sha256'],'original_source_sha256':{k:hashlib.sha256(v.encode()).hexdigest()for k,v in originals.items()},'authored_source_sha256':{k:hashlib.sha256(v.encode()).hexdigest()for k,v in texts.items()},'source_bodies_unchanged':True,'source_line_count_unchanged':True,'global_check_limit_unchanged':20000000,'measured_sum':sum(r['measured_steps']for r in rows),'measured_max':max(r['measured_steps']for r in rows),'authored_max':max(r['authored_limit']for r in rows),'measurement_max_seconds':max(json.loads((work/f"{row['measurement_index']}.json").read_text())['elapsed_seconds']for row in rows),'rule':'125% of measured work rounded upward to 10 million. Only the 20 concrete default-budget failures changed: 1 ocean, 10 spectrum, 9 water. Exact owning files come from compiler evidence. No app-owned check failed in that log.','scope':'Selected unchanged checks under their existing documented 2B (spectrum/ocean) or 500M (water) caller limits. No authority-coverage or whole-carrier success is inferred.','checks':rows,'archive':'measurements.tar.gz','archive_sha256':hashlib.sha256((out/'measurements.tar.gz').read_bytes()).hexdigest()};(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['measured_sum','measured_max','authored_max','measurement_max_seconds']},indent=2))
