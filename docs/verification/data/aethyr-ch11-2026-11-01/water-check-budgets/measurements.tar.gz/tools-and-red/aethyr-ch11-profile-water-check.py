from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
root=Path('/Users/christopherdavid/work/openagents-aethyr-book'); index=int(sys.argv[1]);row=json.loads(Path('/tmp/aethyr-ch11-water-long-checks.json').read_text())[index];name=row['name'];work=Path('/tmp/aethyr-ch11-water-check-profiles');work.mkdir(exist_ok=True)
command=['coax/bin/coax','test',row['source'],'--library','--only',name,'--steps',str(row['caller_budget']),'--profile','steps','--evidence',str(work/f'{index}.evidence.json')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=list(root.rglob('*.coax')); before={str(p.relative_to(root)):sha(p)for p in files};compiler=sha(root/'coax/bin/coax');start=time.monotonic()
p=subprocess.Popen(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);timed=False
try:out,_=p.communicate(timeout=810)
except subprocess.TimeoutExpired:
 timed=True;os.killpg(p.pid,signal.SIGTERM)
 try:out,_=p.communicate(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,_=p.communicate()
(work/f'{index}.log').write_bytes(out);evidence=json.loads((work/f'{index}.evidence.json').read_text())if(work/f'{index}.evidence.json').exists()else{}; used={str(Path(row['path']).relative_to(root)):row['sha256']for row in evidence.get('sources',[])}; changes=[k for k,h in used.items()if before.get(k)!=h or sha(root/k)!=h]; before={k:before.get(k)for k in used}
r={'index':index,'name':name,'command':command,'compiler_sha256':compiler,'source_sha256':before,'source_changes':changes,'returncode':p.returncode,'deadline_exceeded':timed,'elapsed_seconds':round(time.monotonic()-start,3),'status':'pass'if p.returncode==0 and not timed and not changes else'fail','scope':'Unchanged existing water check under its source-documented caller budget; selected check only, no authority-coverage claim.'};(work/f'{index}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['index','name','returncode','deadline_exceeded','elapsed_seconds','status']}));print(out.decode()[-1800:])
