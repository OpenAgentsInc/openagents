# Firm reason: 2 (independent Python struct/math image oracle compared with the newly ported Coax policy and native command).
from pathlib import Path
import importlib.util, hashlib, json, math, random, struct, subprocess, sys, time
ROOT=Path('/Users/christopherdavid/work/openagents-aethyr-book-main')
OUT=Path('/tmp/aethyr-compare-port-20261102')
BINARY=ROOT/'coax/web/build/tools/compare-frames-1fac3750bcffbb735ef26f4a065d16414b911068fd7d68bc3ca112565d2432aa'
spec=importlib.util.spec_from_file_location('legacy_image_oracle',OUT/'legacy-compare_frames.py');legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source_paths=[ROOT/p for p in ['aethyr/render/tests/compare-frames.coax','aethyr/render/tests/compare-frames-policy.coax','aethyr/render/tests/compare-frames-checks.coax','coax/lib/sys/fs.coax','coax/platform/store-file-native.c','coax/platform/store-file-native.h']]
fences={str(p):sha(p) for p in source_paths+[BINARY,Path(__file__),OUT/'legacy-compare_frames.py']}
rows=[]
def run(name,cpu,gpu,fmt,w,h):
 part=OUT/name;part.mkdir();cp=part/'cpu.bin';gp=part/'gpu.bin';rp=part/'receipt.json';cp.write_bytes(cpu);gp.write_bytes(gpu)
 start=time.monotonic()
 try:expected=legacy.compare_buffers(cpu,gpu,fmt,w,h);status=0 if expected['status']=='pass' else 1
 except ValueError:expected=None;status=2
 argv=[str(BINARY),'--cpu',str(cp),'--gpu',str(gp),'--gpu-format',fmt,'--width',str(w),'--height',str(h),'--receipt',str(rp)]
 r=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=60);(part/'stdout').write_bytes(r.stdout);(part/'stderr').write_bytes(r.stderr)
 assert r.returncode==status,(name,r.returncode,status,r.stderr.decode())
 if expected is not None:
  got=json.loads(rp.read_text());actual=got['comparison'];assert actual==expected,(name,actual,expected)
  assert got['inputs']['cpu']['sha256']==sha(cp) and got['inputs']['gpu']['sha256']==sha(gp)
  assert got['schema']=='aethyr.render.image-comparison.v1' and json.loads(r.stdout)==expected
 else:assert not rp.exists()
 (part/'expected.json').write_text(json.dumps(expected,indent=2,allow_nan=False)+'\n')
 rows.append(dict(name=name,width=w,height=h,format=fmt,exit_status=status,comparison=expected,cpu_sha256=sha(cp),gpu_sha256=sha(gp),seconds=time.monotonic()-start,argv=argv))
 print(name,status,flush=True)
f32=lambda *p:b''.join(struct.pack('<4f',*x)for x in p)
base=(1,.5,.25,.75);cpu=f32(base)
for fmt,gpu in [('rgba32f',cpu),('rgba16f',struct.pack('<4e',*base)),('rgba8',bytes([255,128,64,191])),('bgra8',bytes([64,128,255,191]))]:run('basic-'+fmt,cpu,gpu,fmt,1,1)
run('relative-exact-floor',f32((500,-500,0,1)),f32((501,-501,1/512,1)),'rgba32f',1,1)
run('relative-first-outside',f32((500,-500,0,1)),f32((501+1/32768,-501-1/32768,1/256,1)),'rgba32f',1,1)
run('all80channels-fail',f32(*([(0,0,0,0)]*20)),f32(*([(1,1,1,1)]*20)),'rgba32f',5,4)
run('matching-nonfinite',f32((float('nan'),float('inf'),-float('inf'),0)),f32((float('nan'),float('inf'),-float('inf'),0)),'rgba32f',1,1)
raw=b''.join(struct.pack('<4H',word,0x3c00,0xc000,0x3800)for word in range(65536));decoded=b''.join(struct.pack('<4f',*struct.unpack_from('<4e',raw,k))for k in range(0,len(raw),8));run('all65536halfwords',decoded,raw,'rgba16f',256,256)
rng=random.Random(0xCF20261102);cpu=b''.join(struct.pack('<I',rng.getrandbits(32))for _ in range(1024*4));gpu=b''.join(struct.pack('<I',rng.getrandbits(32))for _ in range(1024*4));run('random-binary32-all-channels',cpu,gpu,'rgba32f',32,32)
raw=bytes(c for code in range(256)for c in [code,255-code,code^165,code]);cpu=b''.join(struct.pack('<f',c/255)for c in raw);run('all256bytecodes',cpu,raw,'rgba8',16,16)
for name,w,h,fmt,c,g in [('zero',0,1,'rgba32f',cpu,cpu),('negative',1,-1,'rgba32f',cpu,cpu),('wide',16385,1,'rgba32f',cpu,cpu),('unknown',1,1,'unknown',bytes(16),bytes(16)),('short-cpu',1,1,'rgba32f',bytes(15),bytes(16)),('extra-gpu',1,1,'rgba8',bytes(16),bytes(5)),('short-half',1,1,'rgba16f',bytes(16),bytes(7))]:run('refuse-'+name,c,g,fmt,w,h)
for old in ['/tmp/aethyr-ch11-grid-4m-webgpu-comparison.json','/tmp/aethyr-ch11-grid-4m-native-comparison.json','/tmp/aethyr-ch11-deadgears-box36-browser-comparison.json','/tmp/aethyr-ch11-deadgears-box36-native-comparison.json']:
 p=Path(old);record=json.loads(p.read_text());inputs=record['inputs'];cp=Path(inputs['cpu']['path']);gp=Path(inputs['gpu']['path']);assert sha(cp)==inputs['cpu']['sha256'] and sha(gp)==inputs['gpu']['sha256'];run('retained-'+p.stem,cp.read_bytes(),gp.read_bytes(),inputs['gpu']['format'],record['width'],record['height'])
assert fences=={str(p):sha(p) for p in source_paths+[BINARY,Path(__file__),OUT/'legacy-compare_frames.py']}
record=dict(schema='aethyr.render.comparator-port-parity.v1',status='pass',scope='Independent old Python struct/math computations and complete new Coax native CLI match on every parsed comparison field, sample and input hash. This reuses retained renderer bytes and starts no renderer/GPU gate.',fences=fences,cases=rows)
(OUT/'qualification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'pass','cases':len(rows)}))
