struct coax_t9 {
  x: array<vec2f, 6>,
}
struct coax_t12 {
  x: vec4f,
  y: vec2f,
}
struct coax_io_12 {
  @builtin(position) x: vec4f,
  @location(0) y: vec2f,
}
@group(0) @binding(0) var<uniform> u: array<vec4f, 2>;
fn coax_at_u(i: i32) -> f32 {
  return u[i / 4][i % 4];
}
@group(0) @binding(1) var media_image: texture_2d<f32>;
@group(0) @binding(2) var media_sampler: sampler;
fn coax_p_vs(p_vertex: u32, p_instance: u32) -> coax_t12 {
  var l_vertex: u32 = p_vertex;
  var l_instance: u32 = p_instance;
  var l_packet: coax_t9;
  var l_c: vec2f;
  l_packet = coax_p_render_media_quad();
  l_c = l_packet.x[i32(l_vertex)];
  return coax_t12(coax_p_v4(coax_p_mix(coax_at_u(i32(0i)), coax_at_u(i32(2i)), l_c.x), coax_p_mix(coax_at_u(i32(1i)), coax_at_u(i32(3i)), l_c.y), 0.0f, 0x1.000000p0f), coax_p_v2(l_c.x, l_c.y));
}
fn coax_p_fs(p_v: coax_t12) -> vec4f {
  var l_v: coax_t12 = p_v;
  var l_c: vec4f;
  l_c = textureSample(media_image, media_sampler, l_v.y);
  return coax_p_v4((l_c.x * coax_at_u(i32(4i))), (l_c.y * coax_at_u(i32(4i))), (l_c.z * coax_at_u(i32(4i))), 0x1.000000p0f);
}
fn coax_p_render_media_quad() -> coax_t9 {
  return coax_t9(array<vec2f, 6>(vec2f(0.0f, 0.0f), vec2f(0x1.000000p0f, 0.0f), vec2f(0.0f, 0x1.000000p0f), vec2f(0.0f, 0x1.000000p0f), vec2f(0x1.000000p0f, 0.0f), vec2f(0x1.000000p0f, 0x1.000000p0f)));
}
fn coax_p_mix(p_a: f32, p_b: f32, p_t: f32) -> f32 {
  var l_a: f32 = p_a;
  var l_b: f32 = p_b;
  var l_t: f32 = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
fn coax_p_v4(p_x: f32, p_y: f32, p_z: f32, p_w: f32) -> vec4f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  var l_w: f32 = p_w;
  return vec4f(l_x, l_y, l_z, l_w);
}
fn coax_p_v2(p_x: f32, p_y: f32) -> vec2f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  return vec2f(l_x, l_y);
}
@vertex
fn vs(@builtin(vertex_index) coax_vid: u32, @builtin(instance_index) coax_iid: u32) -> coax_io_12 {
  let coax_r = coax_p_vs(coax_vid, coax_iid);
  return coax_io_12(coax_r.x, coax_r.y);
}
@fragment
fn fs(coax_in: coax_io_12) -> @location(0) vec4f {
  let coax_r = coax_p_fs(coax_t12(coax_in.x, coax_in.y));
  return coax_r;
}
