#include "frame-input.h"
int main(int argc,char **argv){RfiFrame f={0};char error[256];
int ok=argc==3?rfi_load_textures(argv[1],&f,error,sizeof error):rfi_load(argv[1],&f,error,sizeof error);
if(!ok){fprintf(stderr,"%s\n",error);return 2;}
printf("%lld %zu %zu %zu %zu %llu %zu %s\n",(long long)f.counts[0],f.uniforms.size,f.shader_count,f.buffer_count,f.texture_count,(unsigned long long)(f.texture_count?f.textures[0].levels[0].row_bytes:0),f.texture_count?f.textures[0].bytes.size:0,f.buffer_count?f.buffers[0].name:"");
if(f.media_text.size&&fwrite(f.media_text.data,1,f.media_text.size,stdout)!=f.media_text.size)return 4;
for(size_t i=0;i<f.media_image_count;i++){RfiMediaImage m=f.media_images[i];printf("%lld %s %lld %lld %lld\n",(long long)m.kind,m.url,(long long)m.ready,(long long)m.width,(long long)m.height);}
rfi_close(&f);return argc==2||argc==3?0:3;}