changed independent oracle bytes
