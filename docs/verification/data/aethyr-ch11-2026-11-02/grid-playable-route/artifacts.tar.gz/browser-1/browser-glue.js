// Firm reason: 1 (browser glue: controlled clock, offline browser effects and read-only page observations for the Coax journey)
// Decisions, schedule and acceptance live in grid-journey.coax. This file only
// adapts the browser's effects and carries measurements back to that tool.
(() => {
  globalThis.coaxialClip = true;
  const fixed = 1793577600000, NativeDate = Date, fetchActual = fetch, SocketActual = WebSocket;
  globalThis.Date = class extends NativeDate {
    constructor(...args) { super(...(args.length ? args : [fixed])); }
    static now() { return fixed; }
  };
  const record = globalThis.gridJourneyEffects = { requests: [], sockets: [], exceptions: [], faults: [] };
  addEventListener('error', event => record.exceptions.push(String(event.message)));
  addEventListener('unhandledrejection', event => record.exceptions.push(String(event.reason)));
  globalThis.fetch = (...args) => {
    const url = new URL(typeof args[0] === 'string' ? args[0] : args[0].url, location.href);
    record.requests.push(url.href);
    // The offline profile leaves external/API effects pending. It never
    // supplies invented server answers, authorizes a player or alters inputs.
    if (url.origin !== location.origin || url.pathname.startsWith('/api/')) return new Promise(() => {});
    return fetchActual(...args);
  };
  globalThis.WebSocket = class extends SocketActual {
    constructor(url, ...args) {
      record.sockets.push(String(url));
      if (new URL(url, location.href).host !== location.host) throw Error('offline Grid journey');
      super(url, ...args);
    }
  };
  globalThis.gridJourneyRead = () => ({
    url: location.pathname + location.search,
    golden: new URLSearchParams(location.search).has('golden') || globalThis.coaxialGolden === true,
    probe: Array.from({ length: 10 }, (_, field) => coaxial.gridProbe(field)),
    pose: Array.from({ length: 10 }, (_, field) => coaxial.gridPose(field)),
    status: coaxial.renderStatus, ready: coaxial.ready, sceneReady: coaxial.sceneReady,
  });
  import('/coaxial/render.js').then(({ RenderHost }) => {
    const frame = RenderHost.prototype.frame;
    RenderHost.prototype.frame = function (...args) {
      if (!globalThis.gridJourneyMissingSans) return frame.apply(this, args);
      const saved = this.sansTexture, queue = this.device.queue;
      const writeBuffer = queue.writeBuffer, submit = queue.submit;
      const calls = { writeBuffer: 0, submit: 0 };
      queue.writeBuffer = function (...values) { calls.writeBuffer++; return writeBuffer.apply(this, values); };
      queue.submit = function (...values) { calls.submit++; return submit.apply(this, values); };
      this.sansTexture = null;
      try { return frame.apply(this, args); }
      finally {
        this.sansTexture = saved; queue.writeBuffer = writeBuffer; queue.submit = submit;
        record.faults.push({ ...calls, refusal: this.lastRefusal });
      }
    };
    globalThis.gridJourneyGlueReady = true;
  });
})();
