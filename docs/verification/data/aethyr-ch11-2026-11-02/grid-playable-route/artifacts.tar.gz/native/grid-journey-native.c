/* Existing native host effects and byte-preserving Grid-face observation.
   Schedule, acceptance, replay and output decisions live in Coax. */
#include "realm-host.h"
#include "face.h"
#include <stdint.h>
#include <string.h>

extern void page(uint32_t,uint32_t);
extern int64_t grid_probe(int64_t),grid_mark(int64_t);
extern float grid_pose(int64_t);
extern uint32_t grid_replay(void);
static RealmHost journey_host;

int64_t gj_native_open(void) {
  rh_open(&journey_host,0);
  page(journey_host.state,1);
  const char facts[]="url=http://127.0.0.1:8817/realms/the-grid?from=home\nclip=1\nrealm=the-grid\nslot=the-grid\n";
  rh_send(&journey_host,RH_PAGE_KIND,facts,sizeof facts-1);
  return 0;
}
int64_t gj_native_frame(float dt) {
  /* Call the raw production export: never silently cap a count in rh_frame. */
  uint32_t vertices=coaxial_frame(journey_host.state,journey_host.vertices,journey_host.uniforms,960,540,1,dt,0);
  rh_after(&journey_host,0);
  return vertices;
}
void gj_native_key(int64_t key,int64_t down) {
  if(down)coaxial_key(journey_host.state,(int32_t)key,0);
  else coaxial_key_up(journey_host.state,(int32_t)key,0);
  rh_after(&journey_host,0);
}
int64_t gj_native_probe(int64_t field) {return grid_probe(field);}
float gj_native_pose(int64_t field) {return grid_pose(field);}
int64_t gj_native_mark(int64_t step) {return grid_mark(step);}
int64_t gj_native_replay(void) {return grid_replay();}
void gj_native_close(void) {rh_close(&journey_host);}
