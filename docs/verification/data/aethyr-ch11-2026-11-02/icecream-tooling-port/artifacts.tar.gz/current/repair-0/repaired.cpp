prefix
    std::vector<std::pair<size_t, size_t>> capBands;
    std::vector<std::pair<float, float>> spans;
      const size_t bandBegin = mesh.v.size();
      piece(s0, s1, 0.28f, kWallHeight - 0.22f, colour, 0);
      const size_t lowerBegin = mesh.v.size();
      piece(s0, s1, 0, 0.28f, trim, 0.05f);
      const size_t upperBegin = mesh.v.size();
      piece(s0, s1, kWallHeight - 0.22f, kWallHeight, trim, 0.05f);
      // Independent oracle: observe existing trim geometry, not Coax seam math.
      float bottomSeam = mesh.v[lowerBegin].p.y;
      float topSeam = mesh.v[upperBegin].p.y;
      for (size_t j=lowerBegin;j<upperBegin;++j) bottomSeam=std::max(bottomSeam,mesh.v[j].p.y);
      for (size_t j=upperBegin;j<mesh.v.size();++j) topSeam=std::min(topSeam,mesh.v[j].p.y);
      for (size_t j=bandBegin;j<lowerBegin;++j)
        mesh.v[j].p.y = mesh.v[j].p.y < kWallHeight/2 ? bottomSeam : topSeam;
      capBands.emplace_back(bandBegin,mesh.v.size());
      piece(mid - gap, mid + gap, kDoorHeight, kWallHeight, colour, 0);
      const size_t leftPostBegin = mesh.v.size();
      piece(mid - gap - 0.12f, mid - gap, 0, kDoorHeight, frame, 0.06f);
      const size_t rightPostBegin = mesh.v.size();
      piece(mid + gap, mid + gap + 0.12f, 0, kDoorHeight, frame, 0.06f);
      const size_t postsEnd = mesh.v.size();
      piece(mid - gap - 0.12f, mid + gap + 0.12f, kDoorHeight - 0.12f, kDoorHeight, frame, 0.06f);
      // Independent oracle: the original boxed primitive is a closed solid.
      // Read its actual bounds after emission, then remove only contained caps.
      auto trimCovered = [&](std::pair<size_t,size_t> band, size_t post0, size_t post1, bool atEnd) {
        Vec3 pl=mesh.v[post0].p, ph=pl;
        auto bound = [](Vec3& lo, Vec3& hi, Vec3 p) {
          lo={std::min(lo.x,p.x),std::min(lo.y,p.y),std::min(lo.z,p.z)};
          hi={std::max(hi.x,p.x),std::max(hi.y,p.y),std::max(hi.z,p.z)};
        };
        for(size_t j=post0;j<post1;++j) bound(pl,ph,mesh.v[j].p);
        auto span=[&](Vec3 p){return horizontal?p.x:p.z;};
        auto across=[&](Vec3 p){return horizontal?p.z:p.x;};
        for(size_t face=band.first;face<band.second;face+=6) {
          if(span(mesh.v[face].n)*(atEnd?1.0f:-1.0f)<=.5f) continue;
          Vec3 lo=mesh.v[face].p,hi=lo;
          for(size_t j=face;j<face+6;++j) bound(lo,hi,mesh.v[j].p);
          if(span(lo)<span(pl)||span(hi)>span(ph)||across(lo)<across(pl)||across(hi)>across(ph)||lo.y<pl.y)continue;
          if(hi.y<=ph.y){Vec3 point=mesh.v[face].p;for(size_t j=face;j<face+6;++j)mesh.v[j].p=point;}
          else if(lo.y<ph.y)for(size_t j=face;j<face+6;++j)mesh.v[j].p.y=std::max(mesh.v[j].p.y,ph.y);
        }
      };
      trimCovered(capBands[0],leftPostBegin,rightPostBegin,true);
      trimCovered(capBands[1],rightPostBegin,postsEnd,false);
suffix