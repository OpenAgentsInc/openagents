prefix
    std::vector<std::pair<float, float>> spans;

      piece(mid - gap, mid + gap, kDoorHeight, kWallHeight, colour, 0);
      piece(mid - gap - 0.12f, mid - gap, 0, kDoorHeight, frame, 0.06f);
      piece(mid + gap, mid + gap + 0.12f, 0, kDoorHeight, frame, 0.06f);
      piece(mid - gap - 0.12f, mid + gap + 0.12f, kDoorHeight - 0.12f, kDoorHeight, frame, 0.06f);
suffix