prefix
    std::vector<std::pair<float, float>> spans;
      piece(s0, s1, 0, kWallHeight, colour, 0);
      piece(s0, s1, 0, 0.28f, trim, 0.05f);
      piece(s0, s1, kWallHeight - 0.22f, kWallHeight, trim, 0.05f);
      piece(mid - gap, mid + gap, kDoorHeight, kWallHeight, colour, 0);
      piece(mid - gap - 0.12f, mid - gap, 0, kDoorHeight, frame, 0.06f);
      piece(mid + gap, mid + gap + 0.12f, 0, kDoorHeight, frame, 0.06f);
      piece(mid - gap - 0.12f, mid + gap + 0.12f, kDoorHeight - 0.12f, kDoorHeight, frame, 0.06f);
suffix
      piece(s0, s1, 0, kWallHeight, colour, 0);
      piece(s0, s1, 0, 0.28f, trim, 0.05f);
      piece(s0, s1, kWallHeight - 0.22f, kWallHeight, trim, 0.05f);