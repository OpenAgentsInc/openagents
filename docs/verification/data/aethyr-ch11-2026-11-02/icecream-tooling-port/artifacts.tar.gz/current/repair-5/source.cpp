prefix
    std::vector<std::pair<float, float>> spans;
      piece(s0, s1, 0, kWallHeight, colour, 0);
      piece(s0, s1, 0, 0.28f, trim, 0.05f);
      piece(s0, s1, kWallHeight - 0.22f, kWallHeight, trim, 0.05f);

suffix