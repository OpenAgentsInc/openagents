struct coax_t11 {
  x: vec4f,
  y: vec3f,
  z: vec3f,
  w: vec4f,
}
struct coax_io_11 {
  @builtin(position) x: vec4f,
  @location(0) @interpolate(flat) y: vec3f,
  @location(1) @interpolate(flat) z: vec3f,
  @location(2) @interpolate(flat) w: vec4f,
}
struct coax_t12 {
  x: bool,
  y: vec2f,
}
struct coax_t13 {
  x: vec4f,
  y: vec4f,
  z: vec4f,
  w: vec4f,
}
struct coax_t14 {
  x: vec3f,
  y: vec3f,
}
@group(0) @binding(0) var<uniform> u: array<vec4f, 1>;
fn coax_at_u(i: i32) -> f32 {
  return u[i / 4][i % 4];
}
fn coax_p_render_ring8_probe_vs(p_vertex: u32, p_instance: u32) -> coax_t11 {
  var l_vertex: u32 = p_vertex;
  var l_instance: u32 = p_instance;
  var l_ring8_probe_points: array<vec2f, 3>;
  var l_ring8_probe_p: vec2f;
  var l_ring8_probe_out: coax_t11;
  var l_ring8_probe_id: u32;
  var l_ring8_probe_mode: i32;
  var l_ring8_probe_d: coax_t12;
  var l_ring8_probe_m: coax_t13;
  var l_ring8_probe_v: coax_t14;
  var l_ring8_probe_q: u32;
  var l_ring8_probe_corner: vec2f;
  var l_ring8_probe_a: coax_t12;
  var l_ring8_probe_b: coax_t12;
  l_ring8_probe_points = array<vec2f, 3>(coax_p_v2((-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(0x1.800000p1f, 0x1.000000p0f), coax_p_v2((-0x1.000000p0f), (-0x1.800000p1f)));
  l_ring8_probe_p = l_ring8_probe_points[i32(l_vertex)];
  l_ring8_probe_out = coax_t11(coax_p_v4(l_ring8_probe_p.x, l_ring8_probe_p.y, 0x1.000000p-1f, 0x1.000000p0f), vec3f(), vec3f(), vec4f());
  l_ring8_probe_id = u32(coax_at_u(i32(0i)));
  l_ring8_probe_mode = i32(coax_at_u(i32(1i)));
  if ((l_ring8_probe_mode >= 3i))
  {
    l_ring8_probe_d = coax_t12();
    if ((l_ring8_probe_mode == 3i))
    {
      l_ring8_probe_d = coax_p_render_ring8_direction(l_ring8_probe_id);
    }
    else
    {
      l_ring8_probe_d = coax_p_render_capsule2_polar(l_ring8_probe_id);
    }
    l_ring8_probe_out.w = coax_p_v4(select(0.0f, 0x1.000000p0f, l_ring8_probe_d.x), l_ring8_probe_d.y.x, l_ring8_probe_d.y.y, 0.0f);
  }
  else
  {
    l_ring8_probe_m = coax_t13(coax_p_v4(0.0f, 0.0f, 0.0f, 0x1.000000p0f), coax_p_v4(0.0f, 0x1.fffeb0p-1f, 0.0f, 0x1.000000p0f), vec4f(), vec4f());
    l_ring8_probe_v = coax_p_deadgears_round_vertex(l_ring8_probe_m, l_ring8_probe_id);
    l_ring8_probe_q = (l_ring8_probe_id / 6u);
    l_ring8_probe_corner = coax_p_deadgears_quad((l_ring8_probe_id % 6u));
    l_ring8_probe_a = coax_p_render_ring8_direction(((l_ring8_probe_q % 8u) + coax_p_wg_u32_f(l_ring8_probe_corner.x)));
    l_ring8_probe_b = coax_p_render_capsule2_polar(((l_ring8_probe_q / 8u) + coax_p_wg_u32_f(l_ring8_probe_corner.y)));
    l_ring8_probe_out.y = l_ring8_probe_v.x;
    l_ring8_probe_out.z = l_ring8_probe_v.y;
    l_ring8_probe_out.w = coax_p_v4(l_ring8_probe_a.y.x, l_ring8_probe_a.y.y, l_ring8_probe_b.y.x, l_ring8_probe_b.y.y);
  }
  return l_ring8_probe_out;
}
fn coax_p_render_ring8_probe_fs(p_v: coax_t11) -> vec4f {
  var l_v: coax_t11 = p_v;
  var l_ring8_probe_mode: i32;
  l_ring8_probe_mode = i32(coax_at_u(i32(1i)));
  if ((l_ring8_probe_mode == 0i))
  {
    return coax_p_v4(l_v.y.x, l_v.y.y, l_v.y.z, 0x1.000000p0f);
  }
  if ((l_ring8_probe_mode == 1i))
  {
    return coax_p_v4(l_v.z.x, l_v.z.y, l_v.z.z, 0x1.000000p0f);
  }
  return l_v.w;
}
fn coax_p_v2(p_x: f32, p_y: f32) -> vec2f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  return vec2f(l_x, l_y);
}
fn coax_p_v4(p_x: f32, p_y: f32, p_z: f32, p_w: f32) -> vec4f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  var l_w: f32 = p_w;
  return vec4f(l_x, l_y, l_z, l_w);
}
fn coax_p_render_ring8_direction(p_sample: u32) -> coax_t12 {
  var l_sample: u32 = p_sample;
  var l_ring8_h: f32;
  var l_ring8_entries: array<vec2f, 9>;
  if ((l_sample > 8u))
  {
    return coax_t12(false, vec2f());
  }
  l_ring8_h = 0x1.6a09e6p-1f;
  l_ring8_entries = array<vec2f, 9>(coax_p_v2(0x1.000000p0f, 0.0f), coax_p_v2(l_ring8_h, l_ring8_h), coax_p_v2(0.0f, 0x1.000000p0f), coax_p_v2((-l_ring8_h), l_ring8_h), coax_p_v2((-0x1.000000p0f), 0.0f), coax_p_v2((-l_ring8_h), (-l_ring8_h)), coax_p_v2(0.0f, (-0x1.000000p0f)), coax_p_v2(l_ring8_h, (-l_ring8_h)), coax_p_v2(0x1.000000p0f, 0.0f));
  return coax_t12(true, l_ring8_entries[i32(l_sample)]);
}
fn coax_p_render_capsule2_polar(p_row: u32) -> coax_t12 {
  var l_row: u32 = p_row;
  var l_ring8_h: f32;
  var l_ring8_entries: array<vec2f, 6>;
  if ((l_row > 5u))
  {
    return coax_t12(false, vec2f());
  }
  l_ring8_h = 0x1.6a09e6p-1f;
  l_ring8_entries = array<vec2f, 6>(coax_p_v2(0.0f, (-0x1.000000p0f)), coax_p_v2(l_ring8_h, (-l_ring8_h)), coax_p_v2(0x1.000000p0f, 0.0f), coax_p_v2(0x1.000000p0f, 0.0f), coax_p_v2(l_ring8_h, l_ring8_h), coax_p_v2(0.0f, 0x1.000000p0f));
  return coax_t12(true, l_ring8_entries[i32(l_row)]);
}
fn coax_p_deadgears_round_vertex(p_m: coax_t13, p_id: u32) -> coax_t14 {
  var l_m: coax_t13 = p_m;
  var l_id: u32 = p_id;
  var l_q: u32;
  var l_c: vec2f;
  var l_row: u32;
  var l_azimuth: coax_t12;
  var l_polar: coax_t12;
  var l_a: vec3f;
  var l_b: vec3f;
  var l_axis: vec3f;
  var l_side: vec3f;
  var l_other: vec3f;
  var l_out: vec3f;
  var l_top: bool;
  var l_n: vec3f;
  var l_r: f32;
  l_q = (l_id / 6u);
  l_c = coax_p_deadgears_quad((l_id % 6u));
  l_row = ((l_q / 8u) + coax_p_wg_u32_f(l_c.y));
  l_azimuth = coax_p_render_ring8_direction(((l_q % 8u) + coax_p_wg_u32_f(l_c.x)));
  l_polar = coax_p_render_capsule2_polar(l_row);
  l_a = coax_p_v3(l_m.x.x, l_m.x.y, l_m.x.z);
  l_b = coax_p_v3(l_m.y.x, l_m.y.y, l_m.y.z);
  l_axis = coax_p_wg_normalize3(coax_p_wg_add_f3f3(coax_p_wg_sub_f3f3(l_b, l_a), coax_p_v3(0.0f, 0x1.4f8b58p-17f, 0.0f)));
  l_side = coax_p_wg_normalize3(coax_p_wg_cross3(l_axis, select(coax_p_v3(0x1.000000p0f, 0.0f, 0.0f), coax_p_v3(0.0f, 0x1.000000p0f, 0.0f), (abs(l_axis.y) < 0x1.ccccccp-1f))));
  l_other = coax_p_wg_cross3(l_axis, l_side);
  l_out = coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(l_side, l_azimuth.y.x), coax_p_wg_mul_f3f(l_other, l_azimuth.y.y));
  l_top = (l_row > 2u);
  l_n = coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(l_out, l_polar.y.x), coax_p_wg_mul_f3f(l_axis, l_polar.y.y));
  l_r = select(l_m.x.w, l_m.y.w, l_top);
  return coax_t14(coax_p_wg_add_f3f3(select(l_a, l_b, l_top), coax_p_wg_mul_f3f(l_n, l_r)), l_n);
}
fn coax_p_deadgears_quad(p_v: u32) -> vec2f {
  var l_v: u32 = p_v;
  var l_q: array<vec2f, 6>;
  l_q = array<vec2f, 6>(coax_p_v2(0.0f, 0.0f), coax_p_v2(0x1.000000p0f, 0.0f), coax_p_v2(0x1.000000p0f, 0x1.000000p0f), coax_p_v2(0.0f, 0.0f), coax_p_v2(0x1.000000p0f, 0x1.000000p0f), coax_p_v2(0.0f, 0x1.000000p0f));
  return l_q[i32(l_v)];
}
fn coax_p_wg_u32_f(p_x: f32) -> u32 {
  var l_x: f32 = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return u32(l_x);
}
fn coax_p_v3(p_x: f32, p_y: f32, p_z: f32) -> vec3f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  return vec3f(l_x, l_y, l_z);
}
fn coax_p_wg_sub_f3f3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_v3((l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
fn coax_p_wg_add_f3f3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_v3((l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
fn coax_p_wg_normalize3(p_a: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  return coax_p_normalize3(l_a);
}
fn coax_p_wg_cross3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_cross3(l_a, l_b);
}
fn coax_p_wg_mul_f3f(p_a: vec3f, p_b: f32) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: f32 = p_b;
  return coax_p_v3((l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
fn coax_p_normalize3(p_a: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  return coax_p_scale3(l_a, (0x1.000000p0f / coax_p_length3(l_a)));
}
fn coax_p_cross3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return vec3f(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
fn coax_p_length3(p_a: vec3f) -> f32 {
  var l_a: vec3f = p_a;
  return sqrt(dot(l_a, l_a));
}
fn coax_p_scale3(p_a: vec3f, p_k: f32) -> vec3f {
  var l_a: vec3f = p_a;
  var l_k: f32 = p_k;
  return vec3f((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
@vertex
fn render_ring8_probe_vs(@builtin(vertex_index) coax_vid: u32, @builtin(instance_index) coax_iid: u32) -> coax_io_11 {
  let coax_r = coax_p_render_ring8_probe_vs(coax_vid, coax_iid);
  return coax_io_11(coax_r.x, coax_r.y, coax_r.z, coax_r.w);
}
@fragment
fn render_ring8_probe_fs(coax_in: coax_io_11) -> @location(0) vec4f {
  let coax_r = coax_p_render_ring8_probe_fs(coax_t11(coax_in.x, coax_in.y, coax_in.z, coax_in.w));
  return coax_r;
}
