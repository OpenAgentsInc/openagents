#!/usr/bin/env bash
# Firm reason: 5 (thin working-directory and exec wrapper for the Coax recipe check).
cd "$(dirname "$0")/../.." || exit
exec coax/web/tool.sh psionic/tests/check-deepseek-recipe.coax "$@"
