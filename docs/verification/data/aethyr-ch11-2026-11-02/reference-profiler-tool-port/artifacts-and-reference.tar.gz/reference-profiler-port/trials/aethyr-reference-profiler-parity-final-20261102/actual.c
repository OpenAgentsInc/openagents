static coax_t_RRVertices coax_p_rr_vertices(int x);
static coax_t_RRShaded coax_p_rr_shade(int x);
static coax_t_RRVertices rfc_original_rr_vertices(int x) {return v;}
static coax_t_RRShaded rfc_original_rr_shade(int x) {return f;}
static coax_t_RFResult rfc_original_rf_execute_draw(int x) {return f;}
static coax_t_RRStored coax_p_rr_store(int x) {return f;}
static coax_t_RRTriangle rfc_original_rr_triangle_profile(int x) {return f;}

#include <assert.h>
#include <stdio.h>
static int rfc_extent_seen;static double rfc_minx,rfc_maxx,rfc_miny,rfc_maxy,rfc_excess;static long long rfc_setups;
static void rfc_extent(coax_t_RRTriangle q){if(q.status!=COAX_RQStatus_ok)return;rfc_setups++;for(int k=0;k<3;k++){double x=q.vertices.e[k].x,y=q.vertices.e[k].y;if(!rfc_extent_seen){rfc_minx=rfc_maxx=x;rfc_miny=rfc_maxy=y;rfc_extent_seen=1;}if(x<rfc_minx)rfc_minx=x;if(x>rfc_maxx)rfc_maxx=x;if(y<rfc_miny)rfc_miny=y;if(y>rfc_maxy)rfc_maxy=y;double e[4]={-x,x-q.width,-y,y-q.height};for(int j=0;j<4;j++)if(e[j]>rfc_excess)rfc_excess=e[j];}}

static const uint32_t *rfc_trees[14];
static int64_t rfc_indices[14],rfc_count,rfc_steps[14][2],rfc_calls[14][2];
void rfc_register(const uint32_t *tree,int64_t index){assert(rfc_count<14);rfc_trees[rfc_count]=tree;rfc_indices[rfc_count++]=index;}
static void rfc_note(const uint32_t *tree,int kind,int64_t steps){for(int64_t k=0;k<rfc_count;k++)if(tree==rfc_trees[k]){assert(steps>=0);rfc_steps[k][kind]+=steps;rfc_calls[k][kind]++;return;}abort();}
void rfc_report(void){for(int64_t k=0;k<rfc_count;k++)fprintf(stderr,"RF_COST {\"entry\":%lld,\"vertex_steps\":%lld,\"fragment_steps\":%lld,\"vertex_groups\":%lld,\"fragment_groups\":%lld}\n",(long long)rfc_indices[k],(long long)rfc_steps[k][0],(long long)rfc_steps[k][1],(long long)rfc_calls[k][0],(long long)rfc_calls[k][1]);fprintf(stderr,"RF_EXTENT {\"min_x\":%.17g,\"max_x\":%.17g,\"min_y\":%.17g,\"max_y\":%.17g,\"max_excess\":%.17g,\"setups\":%lld}\n",rfc_minx,rfc_maxx,rfc_miny,rfc_maxy,rfc_excess,rfc_setups);}
static const int64_t rfc_points[2][2]={{0,0},{1,1}};
static void rfc_pixels(int64_t entry,coax_t_RFRequirements req,coax_t_RFWorking work){for(int target=1;target<=4;target++){coax_t_RFCanvasLayout c=req.images.e[target];if(!c.present)continue;for(unsigned k=0;k<sizeof(rfc_points)/sizeof(rfc_points[0]);k++){int64_t x=rfc_points[k][0],y=rfc_points[k][1];if(x>=c.descriptor.width||y>=c.descriptor.height)continue;coax_t_RQColor v=work.images.data[c.offset+y*c.descriptor.width+x];fprintf(stderr,"RF_PIXEL {\"entry\":%lld,\"target\":%d,\"x\":%lld,\"y\":%lld,\"rgba\":[%.9g,%.9g,%.9g,%.9g]}\n",(long long)entry,target,(long long)x,(long long)y,(double)v.r,(double)v.g,(double)v.b,(double)v.a);}}}

static coax_t_RRVertices coax_p_rr_vertices(int x) {coax_t_RRVertices q=rfc_original_rr_vertices(x);rfc_note(l_tree.data,0,q.steps);if(q.status!=COAX_RQStatus_ok)fprintf(stderr,"RF_ERROR {\"stage\":0,\"status\":%u,\"steps\":%lld}\n",(unsigned)q.status,(long long)q.steps);return q;}
static coax_t_RRShaded coax_p_rr_shade(int x) {coax_t_RRShaded q=rfc_original_rr_shade(x);rfc_note(l_tree.data,1,q.steps);if(q.status!=COAX_RQStatus_ok)fprintf(stderr,"RF_ERROR {\"stage\":1,\"status\":%u,\"steps\":%lld}\n",(unsigned)q.status,(long long)q.steps);return q;}
static coax_t_RFResult coax_p_rf_execute_draw(int x) {coax_t_RFResult q=rfc_original_rf_execute_draw(x);rfc_pixels(l_index,l_req,l_work);return q;}
static coax_t_RRTriangle coax_p_rr_triangle_profile(int x) {coax_t_RRTriangle q=rfc_original_rr_triangle_profile(x);rfc_extent(q);if(q.status!=COAX_RQStatus_ok){fprintf(stderr,"RF_TRIANGLE_ERROR {\"status\":%u,\"width\":%lld,\"height\":%lld,\"clip\":[",(unsigned)q.status,(long long)l_width,(long long)l_height);for(int k=0;k<3;k++)fprintf(stderr,"%s[%.9g,%.9g,%.9g,%.9g]",k?",":"",(double)l_triangle.e[k].clip.e[0],(double)l_triangle.e[k].clip.e[1],(double)l_triangle.e[k].clip.e[2],(double)l_triangle.e[k].clip.e[3]);fputs("]}\n",stderr);}return q;}
