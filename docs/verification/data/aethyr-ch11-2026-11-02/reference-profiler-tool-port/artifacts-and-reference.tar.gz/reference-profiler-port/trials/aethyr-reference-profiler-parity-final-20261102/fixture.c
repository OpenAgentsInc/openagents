static coax_t_RRVertices coax_p_rr_vertices(int x);
static coax_t_RRShaded coax_p_rr_shade(int x);
static coax_t_RRVertices coax_p_rr_vertices(int x) {return v;}
static coax_t_RRShaded coax_p_rr_shade(int x) {return f;}
static coax_t_RFResult coax_p_rf_execute_draw(int x) {return f;}
static coax_t_RRStored coax_p_rr_store(int x) {return f;}
static coax_t_RRTriangle coax_p_rr_triangle_profile(int x) {return f;}
