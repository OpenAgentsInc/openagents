static coax_t_RRShaded coax_p_rr_shade(int x) {return f;}
