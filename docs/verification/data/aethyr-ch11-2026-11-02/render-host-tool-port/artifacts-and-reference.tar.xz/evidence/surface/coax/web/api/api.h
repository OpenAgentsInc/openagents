// The openagents.com API service (api.c): what its route files share.
#pragma once
#include <libpq-fe.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct {
  int fd;
  char method[8];
  char target[2048];   // the path and query as sent
  char path[2048];     // without the query
  const char *query;   // after '?', or ""
  const char *head;    // the request line and headers ("\r\n" separated)
  const char *body;    // Content-Length bytes (not terminated)
  size_t body_len;
} request;

double api_now_ms(void);
void api_log(const char *fmt, ...);
void api_respond(int fd, int status, const char *type, const char *extra_headers, const void *body, size_t n);
void api_json(int fd, int status, const char *json);
PGconn *api_db(void);
PGconn *api_db_new(void);   // a connection of its own (a child process's)
// A header's value (first one), or NULL with out "".
const char *api_header(const request *q, const char *name, char *out, size_t cap);
// A query parameter, percent-decoded, or NULL with out "".
const char *api_query(const request *q, const char *name, char *out, size_t cap);

// Route files: true when they answered.
bool analytics_route(const request *q);   // analytics.c
void analytics_team_init(PGconn *db);     // the team (OA_TEAM, OA_ADMIN_PUBKEYS) into analytics.team, and its backfill
#define TEAM_COOKIE "Set-Cookie: oa_team=1; Path=/; Max-Age=63072000; HttpOnly; Secure; SameSite=Lax\r\n"   // this browser is the team's
void admin_init(void);                    // admin.c
bool admin_route(const request *q);
bool admin_is(const char *pubkey);        // a site admin: a root (OA_ADMIN_PUBKEYS) or a database admin (0100)
bool admin_is_root(const char *pubkey);   // a pubkey in OA_ADMIN_PUBKEYS (admins.conf)
void admin_roots(char *out, size_t cap);  // the roots as a Postgres text array literal
int admin_who(const request *q, PGconn *db, char who[65]);   // 0 an admin (cookie or NIP-98), else 401/403
bool chat_route(const request *q);        // chat.c
void chat_key(const request *q, const char *pubkey, bool member);   // KEY for a signed-in admin, or a project member (private.c)
bool player_route(const request *q);      // player.c
bool npc_route(const request *q);         // npc.c
bool piece_route(const request *q);       // npc.c: the Sandbox's set pieces
bool voice_edit_route(const request *q);  // npc.c: an admin's spoken edit to a realm (eg-voice-edit)
bool private_route(const request *q);     // private.c
bool room_route(const request *q);        // room.c
bool drops_route(const request *q);       // drops.c
bool drops_token(char *out, size_t cap);   // the bucket's part, shared with villa.c
bool drops_open_upload(const char *object, const char *type, const char *bytes, const char *from, char *out, size_t cap);
void drops_inspect(const char *object, long long *size, char **head_hex);
void drops_delete_object(const char *object);
bool villa_route(const request *q);       // villa.c
bool realms_route(const request *q);      // realms.c: build your own realm
bool makers_route(const request *q);      // makers.c: a realm's maker and their claim
bool upgrades_route(const request *q);    // makers.c: listed fairy upgrades, bought with sats or credit
bool mesh_route(const request *q);         // mesh.c: authenticated native SystemOne mesh
bool site_identity(const request *q, PGconn *db, char who[65], bool *signed_req, bool *payload, bool *unseen);
bool inference_route(const request *q);   // inference.c: POST /api/v1/inference, our models for the Mac app
// Our Spark wallet (inference.c, OA_SPARK_URL): POST path with json (GET with none); its status (0 unreached), its body into *out.
long api_spark(const char *path, const char *json, long timeout_s, char **out);
// The model (npc.c): its generateContent answer into *body (malloc'd, or NULL), the HTTP status (0 unreached).
long npc_ask_model(const char *url_env, const char *model, const char *request, char **body);
long npc_ask_model_twice(const char *url_env, const char *model, const char *request, long timeout_ms, char **body);
// A page, list or file written into the site's bucket (drops.c, OA_SITE_BUCKET), no-cache.
bool drops_site_write(const char *name, const char *type, const char *data);
bool drops_site_delete(const char *name);   // gone already counts as done
char *drops_site_read(const char *name);   // a text object from the site's bucket, malloc'd, or NULL
bool drops_site_write_bytes(const char *name, const char *type, const unsigned char *data, size_t n);
void realms_refresh_pages(void);   // realms.c: on start, made realms' pages written with an older template
bool realms_jpeg_card(const unsigned char *b, size_t n);   // realms.c: a 1200x630 JPEG's frame header
bool jobs_route(const request *q);        // jobs.c: POST /api/jobs/<job>, Cloud Scheduler (OIDC) or an admin
bool email_route(const request *q);       // email.c: POST /api/admin/email, through Resend
// Mail through Resend (email.c): 0 sent, 1 sent before under the same key, else an HTTP status with err.
int email_send(PGconn *db, const char *message, char id[128], char *err, size_t errcap);
bool replies_route(const request *q);     // replies.c: reply with a realm (ev-reply-realm)
bool access_route(const request *q);      // access.c: realm invites, the waitlist, auth v2 (flags off by default)
// realms.c, before a realm is planned or made: true when access.c answered 403 invite only (realm_invites on).
// signer: a NIP-98 caller's pubkey (access_signed), or NULL.
bool access_refused(const request *q, PGconn *db, const char *key, const char *signer);
// A NIP-98 caller (access.c, caller-policy.coax): 0 not signed; 1 good, its pubkey in pk; -1 refused and answered 401.
int access_signed(const request *q, PGconn *db, char pk[65]);
// The player key a signer's account acts with on realm routes (auth.caller_key): false on a database error.
bool access_caller_key(PGconn *db, const char *pk, char key[160]);
