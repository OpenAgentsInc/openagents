#!/usr/bin/env bash
# coax deploy, for now. An app's files live in a storage bucket that its
# Cloud Run service mounts, so a deploy is a release build and an upload:
# no image build and no new revision.
#
#   deploy.sh APP_DIR SERVICE           # build in release, upload (seconds)
#   deploy.sh --server APP_DIR SERVICE  # also (re)build the server image and
#                                       # (re)create the service and its bucket
#
# COAXIAL_UNLOCKS adds hidden presentations to index.html (unlock/README.md).
# COAXIAL_STAGE_TO=DIR builds and stages into DIR (assets/, site/) and stops
# there, uploading nothing: pin.sh ships a pinned demo from it.
#
# The first deploy of a service needs --server, then a domain mapping:
#   gcloud beta run domain-mappings create --service SERVICE --domain HOST --region us-central1
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
server=false
if [[ "${1:-}" == --server ]]; then server=true; shift; fi
app="$(cd "$1" && pwd)"; service="$2"
project=openagentsgemini region=us-central1
bucket="$project-$service"
export CLOUDSDK_CONFIG="${CLOUDSDK_CONFIG:-$HOME/work/.secrets/gcloud-sa-config}"
now() { [[ -n "${EPOCHREALTIME:-}" ]] && echo "${EPOCHREALTIME//[.,]/}" || echo $(( $(date +%s) * 1000000 )); }   # microseconds
lap() { local d=$(( $(now) - $2 )); printf '  %-8s %4s s\n' "$1" "$(( d / 1000000 )).$(( d % 1000000 / 100000 ))"; }

"$here/check-visuals.sh" "$app"   # INVARIANTS.md: everything visible is Coax
t=$(now); COAXIAL_MODE=release "$app/build.sh"; lap build "$t"

stage="$(mktemp -d)"; trap 'rm -rf "$stage"' EXIT
# Bundle host modules before content naming; deployed pages need one immutable
# script, while coax serve can load the source modules from /coaxial/ directly.
bun build "$here/host.js" --target browser --format esm --outfile "$stage/host.js" > /dev/null
# The page, index.html at the bucket's root as the CDN serves it. The wasm,
# shaders and host script are named by their content (cached for good); the
# page names them (data-wasm, data-wgsl) and is checked on every visit.
python3 - "$app" "$stage/host.js" "$stage" "$here" <<'PY'
import hashlib, json, os, re, shutil, subprocess, sys
app, host, stage, tools = sys.argv[1:]
from pathlib import Path
sys.path.insert(0, tools)
def stage_package(app, url, stage):
    return subprocess.check_output([os.path.join(tools, "tool.sh"), "render-stage", str(app), url, str(stage)], text=True).strip()
assets, site = os.path.join(stage, "assets"), os.path.join(stage, "site")
def put(src, rel):
    h = hashlib.sha256(open(src, "rb").read()).hexdigest()[:12]
    stem, ext = os.path.splitext(rel)
    named = f"{stem}.{h}{ext}"
    for root in (assets, site):
        os.makedirs(os.path.dirname(os.path.join(root, named)), exist_ok=True)
        shutil.copy(src, os.path.join(root, named))
    return "/" + named
host_url = put(host, "coaxial/host.js")
os.makedirs(site, exist_ok=True)
# Pages at any depth (projects/coax/index.html is /projects/coax): pages, their
# Markdown twins, icons and link-preview cards (.jpg). Work files, builds and sources stay behind.
pages = []
for root, dirs, files in os.walk(app):
    # A directory holding a DEV-ONLY file is a page for development only: never released.
    dirs[:] = sorted(d for d in dirs if d not in ("build", "work", "node_modules") and not d.startswith(".")
                     and not os.path.exists(os.path.join(root, d, "DEV-ONLY")))
    for f in sorted(files):
        rel = os.path.relpath(os.path.join(root, f), app)
        agent = rel in ("llms.txt", "robots.txt", "pylon" + os.sep + "join.sh") or (rel.startswith("cli" + os.sep) and f.endswith((".sh", ".ps1"))) or rel == "docs/connect-a-pylon/confidential-round.json"
        if f == "README.md" or not (agent or f.endswith((".html", ".md", ".svg", ".jpg"))): continue
        pages.append(rel)
for f in pages:
    path = os.path.join(app, f)
    os.makedirs(os.path.dirname(os.path.join(site, f)) or site, exist_ok=True)
    text = open(path, encoding="utf-8").read() if f.endswith(".html") else None
    if text is None: shutil.copy(path, os.path.join(site, f)); continue
    def tag(m):
        name = re.search(r'data-app="([^"]+)"', m.group(0)).group(1)
        wasm = put(os.path.join(app, "build", name + ".wasm"), f"build/{name}.wasm")
        wgsl = put(os.path.join(app, name + ".wgsl"), f"build/{name}.wgsl")
        rest = m.group(1)
        rest = re.sub(r'data-render="([^"]+)"', lambda r: 'data-render="' + stage_package(Path(app), r.group(1), Path(stage)) + '"', rest)
        # A scene's assets (data-assets): each URL named by its content too,
        # under /build/ (the page's directory's assets/ in development).
        def asset(u):
            stem = u.group(2)[1:]
            return u.group(1) + put(os.path.join(app, stem), "build/" + stem)
        rest = re.sub(r'data-assets="[^"]*"', lambda a: re.sub(r'([:|=])(/[^\s|"]+)', asset, a.group(0)), rest)
        # A page that talks (data-voice): the voice engine (coax/web/voice/build.sh), named by its content too.
        if "data-voice=" in rest: rest += f' data-voice-wasm="{put(os.path.join(app, "build", "voice.wasm"), "build/voice.wasm")}"'
        # The engine is the page's biggest file and host.js asks for it only once it has run:
        # preloaded, it downloads beside the script (crossorigin: the same request host.js's fetch makes).
        return f'<link rel="preload" href="{wasm}" as="fetch" crossorigin><script type="module" src="{host_url}" data-app="{name}"{rest} data-wasm="{wasm}" data-wgsl="{wgsl}">'
    text = re.sub(r'<script type="module" src="/coaxial/host.js" data-app="[^"]+"([^>]*)>', tag, text)
    open(os.path.join(site, f), "w", encoding="utf-8").write(text)
    # A directory's page also answers at the bare path (/projects/coax), which
    # the bucket can't map to index.html on its own; upload.py serves it as HTML.
    if os.path.basename(f) == "index.html" and os.path.dirname(f):
        shutil.copy(os.path.join(site, f), os.path.join(site, os.path.dirname(f) + ".page"))
# The homepage's seed (`openagents project landing`): this build's captured, admitted events, which the
# page reads itself (build/home-seed/<capture>-<part>.txt, named in its Wasm), so a first visit asks
# the relay only for what is newer.
seed = os.path.join(app, "build", "home-seed")
for f in sorted(os.listdir(seed)) if os.path.isdir(seed) else []:
    os.makedirs(os.path.join(site, "build", "home-seed"), exist_ok=True)
    shutil.copy(os.path.join(seed, f), os.path.join(site, "build", "home-seed", f))
# well-known/apple-app-site-association.json is served without its extension, as JSON (upload.py's
# .wellknown): the phone app's universal links (docs/phone-sign-in.md). Others keep their name (nostr.json, NIP-05).
for f in sorted(os.listdir(os.path.join(app, "well-known"))) if os.path.isdir(os.path.join(app, "well-known")) else []:
    os.makedirs(os.path.join(site, ".well-known"), exist_ok=True)
    shutil.copy(os.path.join(app, "well-known", f), os.path.join(site, ".well-known", f[:-5] + ".wellknown" if f == "apple-app-site-association.json" else f))
# For agents: llms-full.txt is every public page's Markdown twin in one file, and sitemap.xml lists those pages.
def unlisted(f):
    j = os.path.join(app, os.path.dirname(f), "project.json")
    return f.startswith("projects" + os.sep) and os.path.exists(j) and json.load(open(j, encoding="utf-8")).get("visibility") in ("unlisted", "private")
public = sorted(f for f in pages if f.endswith("index.md") and not f.startswith(("admin", "chat", "login", "og" + os.sep, "projects" + os.sep + "private")) and not unlisted(f))
def url(f): return "https://openagents.com/" + os.path.dirname(f).replace(os.sep, "/")
with open(os.path.join(site, "llms-full.txt"), "w", encoding="utf-8") as out:
    out.write(open(os.path.join(app, "llms.txt"), encoding="utf-8").read())
    for f in public: out.write(f"\n\n---\n\nSource: {url(f)}\n\n" + open(os.path.join(app, f), encoding="utf-8").read())
with open(os.path.join(site, "sitemap.xml"), "w", encoding="utf-8") as out:
    out.write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n')
    out.write("".join(f"<url><loc>{url(f)}</loc></url>\n" for f in public) + "</urlset>\n")
PY

# Link previews (docs/web/og-tags.md): every page gets the Open Graph and Twitter tags it lacks, and
# og/pages.txt lists them for /og. A page without a title or description, a broken or wrong-size
# image, or a realm or project without its own card refuses the release (COAXIAL_OG_DRAFT=1 stages anyway).
bun "$here/og.ts" "$stage/site" "$app"

# Hidden presentations (unlock/), when COAXIAL_UNLOCKS names any: from the
# environment, or this machine's secrets file. The phrases stay here.
secrets="${COAXIAL_UNLOCKS_FILE:-$HOME/work/.secrets/coaxial-unlocks.env}"
if [[ -z "${COAXIAL_UNLOCKS:-}" && -f "$secrets" ]]; then set -a; source "$secrets"; set +a; fi
if [[ -n "${COAXIAL_UNLOCKS:-}" ]]; then
  [[ -d "$here/unlock/node_modules" ]] || (cd "$here/unlock" && bun install --silent)
  bun "$here/unlock/inject.ts" "$stage"
fi

# No comments reach a browser: the staged pages, scripts and shaders lose them
# here, after the hidden presentations are in.
bun "$here/strip.ts" "$stage"
if [[ -n "${COAXIAL_STAGE_TO:-}" ]]; then mkdir -p "$COAXIAL_STAGE_TO" && cp -R "$stage/assets" "$stage/site" "$COAXIAL_STAGE_TO/"; exit 0; fi

if $server; then
  t=$(now)
  gcloud storage buckets describe "gs://$bucket" --project "$project" > /dev/null 2>&1 ||
    gcloud storage buckets create "gs://$bucket" --project "$project" --location "$region" --uniform-bucket-level-access --quiet
  runtime="$(gcloud projects describe "$project" --format='value(projectNumber)')-compute@developer.gserviceaccount.com"
  gcloud storage buckets add-iam-policy-binding "gs://$bucket" --member "serviceAccount:$runtime" --role roles/storage.objectViewer --quiet > /dev/null
  lap bucket "$t"
fi

t=$(now)
python3 -I "$here/upload.py" "$stage" "$bucket" "$(gcloud auth print-access-token)"
lap upload "$t"

if $server; then
  t=$(now)
  mkdir -p "$stage/image/server"
  cp "$here/serve.c" "$here/../../verse/voice-host/ws.c" "$here/../../verse/voice-host/ws.h" "$stage/image/server/"
  sed -i.bak 's#"../../verse/voice-host/ws.h"#"ws.h"#' "$stage/image/server/serve.c" && rm -f "$stage/image/server/serve.c.bak"
  cp "$here/Dockerfile" "$stage/image/"
  image="$region-docker.pkg.dev/$project/cloud-run-source-deploy/coaxial-serve:$(date +%Y%m%d-%H%M%S)"
  gcloud builds submit "$stage/image" --project "$project" --region "$region" --tag "$image" --quiet \
    --service-account "projects/$project/serviceAccounts/oa-mvp-automation@$project.iam.gserviceaccount.com" \
    --default-buckets-behavior REGIONAL_USER_OWNED_BUCKET > /dev/null
  lap image "$t"
  t=$(now)
  gcloud run deploy "$service" --image "$image" --project "$project" --region "$region" \
    --allow-unauthenticated --port 8080 --cpu 1 --memory 512Mi --min-instances 0 --max-instances 3 \
    --concurrency 200 --execution-environment gen2 \
    --clear-volumes --clear-volume-mounts \
    --add-volume "name=site,type=cloud-storage,bucket=$bucket,readonly=true,mount-options=implicit-dirs;metadata-cache-ttl-secs=0" \
    --add-volume-mount "volume=site,mount-path=/site" --quiet 2>&1 | grep -E "Service URL|ERROR" || true
  lap service "$t"
fi
