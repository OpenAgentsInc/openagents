#!/usr/bin/env bash
# Smoke checks for a deployed Coaxial site, run by release.sh after each
# stage. Fails (exit 1) on the first broken promise and says which.
#   smoke.sh https://staging.openagents.com
#   smoke.sh https://openagents.com --via 136.69.24.60   # before DNS points there
#   smoke.sh https://openagents.com --coder              # also: coder's routes still answer
# Checks: the page and every file it names (status, type, caching, wasm
# magic, no comments shipped), the hidden text agents read, HTTP to HTTPS, an unknown path, an unknown
# private project (the locked page; its API says only not found), and
# with --coder, the routes the old service keeps until it is retired
# (docs/2026-10-28-coder-service-deprecation.md).
set -euo pipefail
base="${1%/}"; shift
via="" coder=false
while (($#)); do
  case "$1" in
    --via) via="$2"; shift 2 ;;
    --coder) coder=true; shift ;;
    *) echo "smoke: unknown option $1" >&2; exit 2 ;;
  esac
done
host="${base#https://}"
# every project page this checkout has (projects/<slug>/project.json beside an index.html)
site="$(cd "$(dirname "$0")/../../apps/openagents-web/projects" && pwd)"
projects=""
for d in "$site"/*/; do d="${d%/}"; [[ -f "$d/project.json" && -f "$d/index.html" ]] && projects+="${d##*/} "; done
exec python3 -I - "$base" "$host" "$via" "$coder" "$projects" "$site/../../../docs/connect-a-pylon.md" "$site/../../../coax/CHANGELOG.md" <<'PY'
import re, ssl, sys, socket, threading, http.client, uuid
from concurrent.futures import ThreadPoolExecutor
base, host, via, coder = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] == "true"
failed = []
ctx = ssl.create_default_context()
local = threading.local()   # one kept-alive connection per thread and scheme
def connect(scheme):
    if scheme == "http":
        return http.client.HTTPConnection(via or host, 80, timeout=15)
    c = http.client.HTTPSConnection(host, 443, timeout=15, context=ctx)
    if via:   # connect to the IP, but check the certificate for the host
        c.sock = ctx.wrap_socket(socket.create_connection((via, 443), timeout=15), server_hostname=host)
    return c
def get(path, method="GET", scheme="https"):
    for attempt in (0, 1):
        c = getattr(local, scheme, None) or connect(scheme)
        setattr(local, scheme, c)
        try:
            c.request(method, path, headers={"Host": host, "User-Agent": "coaxial-smoke"})
            r = c.getresponse(); body = r.read()
            if r.getheader("connection", "").lower() == "close": c.close(); setattr(local, scheme, None)
            return r.status, {k.lower(): v for k, v in r.getheaders()}, body
        except (http.client.HTTPException, OSError):
            c.close(); setattr(local, scheme, None)
            if attempt: raise
pool = ThreadPoolExecutor(16)
def fetch(reqs):   # every request at once; answers in the order asked
    return list(pool.map(lambda q: get(*q) if isinstance(q, tuple) else get(q), reqs))
def check(ok, what):
    print(("  ok    " if ok else "  FAIL  ") + what)
    if not ok: failed.append(what)

pages = ["/projects", "/projects/index.md", "/projects/coax/demo"] + [p for slug in sys.argv[5].split() for p in (f"/projects/{slug}", f"/projects/{slug}/index.md")]
check(all(f"/projects/{slug}" in pages for slug in ("coax", "verse", "planetary-villa")), f"the project pages: {sys.argv[5].strip()}")
moved = ["/project/coax", "/project/coax/index.md", "/project/verse/index.md",   # the old addresses: 301 to /projects/* and /realms/*
         "/realm/haunted-house", "/realm/everglade?from=playtest", "/realm/haunted-house/index.md", "/realm/everglade/og.jpg", "/realm/hecates-cemetery/card.jpg"]
extra = [("/llms.txt", {200}), ("/index.md", {200}), ("/v1/projects", {401, 403}), ("/docs", {200, 301, 302, 308})] if coder else [("/" + uuid.uuid4().hex, {404})]
verse = ["/verse", "/verse/index.md"]   # the playtest's landing
retired = ["/verse/galaxy", "/verse/galaxy/", "/verse/galaxy/index.md", "/verse/galaxy?realms=all"]   # the galaxy: 301 to /realms (lb.sh)
first = fetch(["/", ("/", "GET", "http"), "/realms/haunted-house", "/realms/haunted-house/index.md"] + pages + moved + [p for p, _ in extra] + verse + retired)
(s, h, page), redirect, house, house_md = first[:4]
s_pages = first[4:4 + len(pages)]
s_moved = first[4 + len(pages):4 + len(pages) + len(moved)]
s_extra = first[4 + len(pages) + len(moved):4 + len(pages) + len(moved) + len(extra)]
s_verse = first[4 + len(pages) + len(moved) + len(extra):4 + len(pages) + len(moved) + len(extra) + len(verse)]
s_retired = first[4 + len(pages) + len(moved) + len(extra) + len(verse):]

check(s == 200 and h.get("content-type", "").startswith("text/html"), f"/ is a page ({s})")
check("no-cache" in h.get("cache-control", ""), "/ is checked on every visit (no-cache)")
html = page.decode("utf-8", "replace")
check('data-app="newland"' in html, "/ runs the live network homepage")
check("<!--" not in html and "/*" not in html, "/ ships no comments")
check(re.search(r"<main[^>]*>\s*\S[\s\S]*?</main>", html) is not None and "<title>" in html, "/ keeps its title and the hidden text for agents")
files = sorted(set(re.findall(r'(?:src|data-wasm|data-wgsl)="(/[^"]+)"', html)))
check(len(files) >= 3, f"/ names its host, wasm and shader ({len(files)} files)")
body = house[2]
named = re.search(r'data-assets="([^"]*)"', body.decode("utf-8", "replace"))
urls = re.findall(r'(/build/[^\s|"]+)', named.group(1)) if named else []
got = fetch(files + [(u, "HEAD") for u in urls])
kinds = {".wasm": "application/wasm", ".js": "javascript", ".wgsl": ""}
for f, (s, h, body) in zip(files, got):
    ext = "." + f.rsplit(".", 1)[-1]
    typ = h.get("content-type", "")
    check(s == 200 and kinds.get(ext, "") in typ, f"{f} ({s}, {typ or 'no type'})")
    if re.search(r"\.[0-9a-f]{12}\.", f):
        check("immutable" in h.get("cache-control", ""), f"{f} is cached for good")
    if ext == ".js":
        check(b"/*" not in body and not re.search(rb"(^|[;{}\n])\s*//", body), f"{f} ships no comments")
    if ext == ".wgsl":
        check(b"//" not in body and b"/*" not in body, f"{f} ships no comments")
    if ext == ".wasm":
        check(body[:4] == b"\0asm", f"{f} is a wasm module ({len(body)} bytes)")
# Engines, shaders and the host go gzipped to a browser that takes gzip (upload.py), unzipped to one that doesn't.
for f in [f for f in files if f.endswith((".wasm", ".js"))][:2]:
    c = connect("https"); c.request("GET", f, headers={"Host": host, "User-Agent": "coaxial-smoke", "Accept-Encoding": "gzip"})
    r = c.getresponse(); r.read(); c.close()
    # A copy the CDN cached before it was stored gzipped (Age, same content name) is still the right bytes.
    gz, cached = r.getheader("content-encoding", "") == "gzip", r.getheader("age") is not None
    check(r.status == 200 and (gz or cached), f"{f} is sent gzipped ({r.getheader('content-length')} bytes)" if gz else f"{f}: the CDN's copy from before it was stored gzipped")
s, h, _ = redirect
check(s in (301, 308) and h.get("location", "").startswith("https://"), f"http:// redirects to https:// ({s})")
for path, (s, h, body) in zip(pages, s_pages):
    app = b'data-app="projects"' if path == "/projects" else b'data-app="project"'
    ok = s == 200 and (path.endswith(".md") or (app in body and b"<!--" not in body))
    check(ok, f"{path} ({s})")
    # a real project page names its project (key and d) for the page's own line to the relay
    if path.count("/") == 2 and not path.endswith(".md"):
        slug = path.rsplit("/", 1)[1]
        check(re.search(rb'data-text="[0-9a-f]{64} ' + slug.encode() + rb'"', body) is not None, f"{path} names its project")
# The old /project/* and /realm/* addresses move for good to /projects/* and /realms/*, path and query kept.
for path, (s, h, _) in zip(moved, s_moved):
    want = re.sub(r"^/(project|realm)/", lambda m: f"/{m.group(1)}s/", path)
    where = h.get("location", "")
    check(s == 301 and where in (want, f"https://{host}{want}"), f"{path} moves to {want} ({s} {where})")
# The Haunted House: its page, its Markdown, and every asset it names (the
# house's document, geometry and sheets; sounds and their loop).
check(house[0] == 200 and b'data-app="realm"' in house[2], f"/realms/haunted-house ({house[0]})")
check(house_md[0] == 200, f"/realms/haunted-house/index.md ({house_md[0]})")
check(len(urls) >= 16, f"/realms/haunted-house names its assets ({len(urls)})")
for u, (s, h, _) in zip(urls, got[len(files):]):
    check(s == 200 and "immutable" in h.get("cache-control", ""), f"{u} ({s})")
for (path, want), (s, _, body) in zip(extra, s_extra):
    if coder:
        check(s in want, f"coder still answers {path} ({s})")
    else:
        check(s in want and b'data-page="1"' in body, f"an unknown path gets the Coax 404 ({s})")
# The galaxy is retired: every address of it moves for good to /realms, its query dropped.
for path, (s, h, _) in zip(retired, s_retired):
    where = h.get("location", "")
    check(s == 301 and where in ("/realms", f"https://{host}/realms"), f"{path} moves to /realms ({s} {where})")
# The Verse's way in: the landing (the verse app's page 0) and its Markdown.
for path, (s, h, body) in zip(verse, s_verse):
    if path.endswith(".md"):
        check(s == 200 and body.startswith(b"# "), f"{path} ({s})")
    else:
        ok = s == 200 and b'data-app="verse"' in body and b'data-page="0"' in body and b"<!--" not in body
        check(ok, f"{path} runs the verse app ({s})")
        if ok:
            for f in sorted(set(re.findall(rb'(?:data-wasm|data-wgsl)="(/[^"]+)"', body))):
                fs, fh, fb = get(f.decode())
                check(fs == 200 and (not f.endswith(b".wasm") or fb[:4] == b"\0asm"), f"{path}: {f.decode()} ({fs})")
        cards = re.findall(rb'<meta (?:property="og:image"|name="twitter:image") content="https://openagents\.com(/[^"]+)">', body)
        check(len(cards) == 2 and b'name="twitter:card" content="summary_large_image"' in body, f"{path} names its link-preview card")
# The link-preview card those tags name: a JPEG, served without a script.
cs, ch, cb = get("/verse/og-verse.jpg")
check(cs == 200 and ch.get("content-type", "").startswith("image/jpeg") and cb[:3] == b"\xff\xd8\xff", f"/verse/og-verse.jpg is the card ({cs}, {ch.get('content-type')})")
# Link previews (docs/web/og-tags.md, coax/web/og.ts): a page of each kind names a whole preview,
# and its card is a JPEG on the site.
if not coder:
    for path in ["/", "/projects/coax", "/realms/dead-gears", "/pylon"]:
        ps, _, pb = get(path)
        head = pb.split(b"</head>", 1)[0]
        named = {k: v for k, v in re.findall(rb'<meta (?:property|name)="((?:og|twitter):[a-z:]+)" content="([^"]*)">', head)}
        whole = all(named.get(k) for k in (b"og:title", b"og:description", b"og:url", b"og:image", b"og:image:alt", b"twitter:card", b"twitter:image"))
        card = named.get(b"og:image", b"").decode()
        ok = ps == 200 and whole and named.get(b"twitter:card") == b"summary_large_image" and card.startswith("https://openagents.com/")
        if ok:
            cs, ch, cb = get(card[len("https://openagents.com"):])
            ok = cs == 200 and cb[:3] == b"\xff\xd8\xff" and len(cb) < 300 * 1024
        check(ok, f"{path} has a whole link preview with a JPEG card ({card or 'none'})")
# Private projects (docs/private-projects.md): the generic locked page, and
# a slug nobody made answers like one nobody may see: 404, no name, no data.
if not coder:
    nobody = uuid.uuid4().hex[:20]
    (s1, h1, b1), (s2, h2, b2), (s3, h3, b3) = fetch(["/projects/private", f"/projects/{nobody}", f"/api/private/{nobody}/state"])
    check(s1 == 200 and b'data-app="private"' in b1 and b'data-page="1"' in b1, f"/projects/private is the locked page ({s1})")
    # 404 naming nothing; the locked page itself once the load balancer's error policy serves it (lb.sh private-pages)
    check(s2 == 404 and b'data-page="1"' in b2 and nobody.encode() not in b2.split(b"<script", 1)[0], f"an unknown private slug is a 404 that names nothing ({s2})")
    check(s3 == 404 and b3 == b'{"error": "not found"}' and "no-store" in h3.get("cache-control", ""), f"an unknown private slug's API says only not found ({s3})")
# For agents: llms.txt and llms-full.txt, robots.txt, the sitemap, NIP-05 and security.txt, from the site.
agent = [("/llms.txt", "text/plain", b"# OpenAgents"), ("/llms-full.txt", "text/plain", b"# OpenAgents"),
         ("/robots.txt", "text/plain", b"User-agent"), ("/sitemap.xml", "application/xml", b"<urlset"),
         ("/.well-known/nostr.json", "application/json", b'"coax"'), ("/.well-known/security.txt", "text/plain", b"Contact:"),
         ("/cli/install.sh", "text/plain", b"#!/"),
         ("/pylon/index.md", "text/markdown", b"# Pylon"), ("/pylon/join.sh", "text/plain", b"#!/")]
for (path, kind, start), (s, h, body) in zip(agent, fetch([p for p, _, _ in agent])):
    check(s == 200 and h.get("content-type", "").startswith(kind) and start in body[:4000], f"{path} ({s}, {h.get('content-type')})")
# The canonical Pylon guide: GPU human page and exact agent-readable source.
guide = "/docs/connect-a-pylon"
(gs, gh, gb), (ms, mh, mb) = fetch([guide, guide + "/index.md"])
check(gs == 200 and gh.get("content-type", "").startswith("text/html") and b'data-app="connect-pylon"' in gb, f"{guide} is the Coax quickstart ({gs})")
check(b'type="text/markdown"' in gb and b'/docs/connect-a-pylon/index.md' in gb and b"<main>" in gb, "the Pylon guide exposes its Markdown twin and accessible text")
check(ms == 200 and mh.get("content-type", "").startswith("text/markdown") and mb == open(sys.argv[6], "rb").read(), "the Pylon Markdown is byte-identical to its canonical source")
guide_files = sorted(set(re.findall(rb'(?:src|data-wasm|data-wgsl)="(/[^"]+)"', gb)))
check(len(guide_files) >= 3, "the Pylon guide names its host, Wasm and shared Grid shader")
for path, (fs, fh, fb) in zip(guide_files, fetch([f.decode() for f in guide_files])):
    check(fs == 200 and (not path.endswith(b".wasm") or fb[:4] == b"\0asm"), f"Pylon guide file {path.decode()} ({fs})")
(ls, _, lb), (fs, _, fb), (ss, _, sb) = fetch(["/llms.txt", "/llms-full.txt", "/sitemap.xml"])
check(ls == 200 and b"/docs/connect-a-pylon/index.md" in lb and fs == 200 and mb in fb and ss == 200 and b"https://openagents.com/docs/connect-a-pylon" in sb, "agents discover the complete Pylon guide from llms and the sitemap")
# Coax's public release history is generated from the compiler's source, never
# a separately edited copy. Check its page, complete data and named GPU assets.
history = "/coax/changelog"
(hs, hh, hb), (hms, hmh, hmb) = fetch([history, history + "/index.md"])
check(hs == 200 and hh.get("content-type", "").startswith("text/html") and b'data-app="changelog"' in hb, "the Coax changelog is a Coax page")
check(b'type="text/markdown"' in hb and b'/coax/changelog/index.md' in hb and b'<main>' in hb, "the Coax changelog exposes accessible text and its Markdown twin")
check(hms == 200 and hmh.get("content-type", "").startswith("text/markdown") and hmb == open(sys.argv[7], "rb").read(), "the public Coax changelog is byte-identical to the canonical source")
history_files = sorted(set(re.findall(rb'(?:src|data-wasm|data-wgsl)="(/[^"]+)"', hb)))
check(len(history_files) >= 3, "the Coax changelog names its host, Wasm and shader")
for path, (status, headers, body) in zip(history_files, fetch([f.decode() for f in history_files])):
    check(status == 200 and (not path.endswith(b".wasm") or body[:4] == b"\0asm"), f"Coax changelog file {path.decode()} ({status})")
check(ls == 200 and b'/coax/changelog/index.md' in lb and fs == 200 and hmb in fb and ss == 200 and b'https://openagents.com/coax/changelog' in sb, "agents discover the complete Coax changelog from llms and the sitemap")
coax_status, _, coax_body = get('/projects/coax')
check(coax_status == 200 and b'href="/coax/changelog"' in coax_body, "the Coax project links to its changelog")
ps, ph, pb = get(guide + "/confidential-round.json")
import json
try:
    public_round = json.loads(pb)
    proof_steps = public_round.get("steps", [])
    proof_receipt = next((r for r in proof_steps if r.get("step") == "receipt"), None)
    proof_measure = next((r.get("measured", {}) for r in proof_steps if r.get("step") == "measure"), {})
except (ValueError, TypeError):
    proof_receipt, proof_measure = None, {}
check(ps == 200 and ph.get("content-type", "").startswith("application/json") and proof_receipt is not None and proof_measure.get("hwmodel") == "GCP_INTEL_TDX" and proof_measure.get("gpu") is None, "the dated confidential CPU report is public JSON (not a GPU/live-counter claim)")
# Signing in with the phone (docs/phone-sign-in.md): the page, the app's universal links, the API.
(s1, h1, b1), (s2, h2, b2), (s3, h3, b3) = fetch(["/login", "/.well-known/apple-app-site-association", "/api/auth/me"])
check(s1 == 200 and b'data-app="private"' in b1 and b'data-page="2"' in b1, f"/login is the login page ({s1})")
check(s2 == 200 and "json" in h2.get("content-type", "") and b"HQWSG26L43.com.openagents.app" in b2, f"the app's universal links are served as JSON ({s2}, {h2.get('content-type')})")
check(s3 == 401 and "no-store" in h3.get("cache-control", ""), f"/api/auth/me signed out is 401 ({s3})")
# /download: the iPhone app's TestFlight link, drawn by the login page's app (page 3).
(s5, h5, b5), = fetch(["/download"])
check(s5 == 200 and b'data-app="private"' in b5 and b'data-page="3"' in b5 and b"https://testflight.apple.com/join/dvQdns5B" in b5, f"/download is the download page ({s5})")
# every page asks /api/auth/viewer: nobody logged in is a 200 with nothing, so no console error
(s4, h4, b4), = fetch(["/api/auth/viewer"])
check(s4 == 200 and b4 == b"" and "no-store" in h4.get("cache-control", ""), f"/api/auth/viewer signed out is 200 and empty ({s4})")
# /chat (docs/chat.md): the page, and its API refuses anyone signed out like the dashboard's.
(s1, h1, b1), (s2, h2, b2) = fetch(["/chat", "/api/chat/state"])
check(s1 == 200 and b'data-app="chat"' in b1, f"/chat is the chat page ({s1})")
check(s2 == 401, f"/api/chat/state signed out is 401 ({s2})")
print(f"smoke {base}{' via ' + via if via else ''}: " + ("passed" if not failed else f"{len(failed)} failed"))
sys.exit(1 if failed else 0)
PY
