# The render fixture origin

`render-test-origin.coax` is a loopback server for browser checks. It never
builds a producer or shader. The caller supplies a JSON configuration and a
new ledger directory, then binds the result to its own source fence.

The caller imports `Basic` once. The helper loads the shared Coax CDP/socket
and qualification effects without another `Basic` import. Its entry point
must dispatch the server child before its normal arguments:

```coax
a: [1] Args;
if !args_load(a[..]) { return 2; }
child := rto_child(a[..]);
if child >= 0 { return child; }
```

The stable APIs are:

| Call | Result |
| --- | --- |
| `rto_start(port_file, config_file, ledger_dir)` | Child process handle, or -1. Refuses an existing port/readiness/request/final file before spawning. |
| `rto_child(args)` | -1 for a normal caller; otherwise runs the private server mode and returns its exit status. |
| `rto_get(port, path)` | Bounded GET; true only for HTTP 200. |
| `rto_control(port, name, enabled)` | Toggle one explicitly named source variant through a reserved loopback GET. |
| `rto_finalize(port)` | Request finalization. This acknowledges the request; the caller must also wait for server exit 0. |
| `rto_add_inputs(ledger_dir, inputs)` | Require a passed, requested finalization and unchanged original files, then add every original file to `RtqInputs`. |
| `rto_page(html, wasm_url, package_url, out)` | Produce the fixture's HTML with one `data-app` insertion and one `data-render` replacement; -1 on missing/ambiguous sites or overflow. |

`rto_serve(port_file, config_file, ledger_dir)` is the implementation called
by the private child dispatch. A normal caller starts it with `rto_start`.

The configuration schema is `aethyr.render-test-origin.v1`:

```json
{
  "schema": "aethyr.render-test-origin.v1",
  "lifetime_ms": 180000,
  "routes": [
    {"url": "/", "file": "/owned/page.html", "mime": "text/html"},
    {"url": "/api/auth/viewer", "text": ""},
    {"url": "/test.wasm", "sequence": [
      {"file": "/owned/initial.wasm"},
      {"file": "/owned/alternate.wasm"},
      {"status": 404, "text": "planted replacement fetch failure"},
      {"file": "/owned/initial.wasm"}
    ]},
    {"prefix": "/package/", "directory": "/owned/package"},
    {"prefix": "/coaxial/", "directory": "/repo/coax/web"},
    {"prefix": "/", "directory": "/repo/apps/openagents-web"}
  ],
  "variants": [{
    "name": "keep-cache", "url": "/coaxial/render.js", "kind": "replace",
    "needle": "this.mediaCache?.clear();",
    "replacement": "/* planted: retained retired cache */", "enabled": false
  }],
  "pins": [{"file": "/owned/initial.wasm", "sha256": "64 lowercase hex digits"}]
}
```

Routes are checked in declaration order. An exact `url` or a `prefix`
selects one row. A prefix with `directory` appends only a validated sibling
path. An explicit `file` serves the same file for the whole matched prefix,
which is useful for an image fixture endpoint. An inline `text` is returned
literally. A response sequence consumes one row per hit and repeats its final
row; use an explicit fourth row to restore the initial response after a
third-request failure. A row defaults to status 200 and a MIME type selected
from `.js`, `.wasm`, `.json`, or `application/octet-stream`.

Variants match an exact `url`, or a `prefix` plus `extension`. `replace`
requires exactly one literal site. `append` uses `replacement` as its suffix.
Each active variant's original and served hashes remain distinct in the
ledger. An intentional variant does not change the original source file or
its fence. `GET /__rto/control/NAME/0` and `/1` select only configured names.

The port file is written after the configuration, pins, image and ledger are
ready. `ready.json` records the port, configuration/image hashes, lifetime and
capabilities. The server appends every request's method/path/status, original
file, original/served SHA256, byte count, applied variant and send result to
`requests.jsonl`. Missing files have no claimed original SHA256.

After closing the browser, request finalization, wait for child exit 0 and
call `rto_add_inputs`. `final.json` records `reason: "requested"`, the complete
original-file inventory, counts and a passed status only if the files stayed
unchanged. Deadline expiration produces a failed final record. A missing final
record, nonzero child exit or changed inventory cannot qualify a run. The
lifetime is bounded to 840 seconds; each socket operation is also bounded.

Version 1 accepts no POST sinks and cannot write a caller artifact from a URL.
It drains a declared, bounded POST body before returning the legacy fixture's
404 `not found` response. It rejects malformed, duplicate-length, chunked,
truncated or surplus framing. `ready.json` therefore reports
`POST_supported: false`. Explicit, exact-path byte sinks with complete body
hash receipts belong to a later additive capability; callers must not infer
sink support from this origin.

The current controls are in `render-test-origin-tool-checks.coax`. They use a
real loopback connection to check the response sequence, variant switch,
served hashes and finalization. The pure path/framing/byte-control decisions
are mutation checked in `render-test-origin-policy.coax`.
