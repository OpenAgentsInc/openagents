#include "coax-identity.h"
#include <inttypes.h>
#include <stdio.h>
int main(void){printf("%"PRId64"\n%s\n%s\n%s\n%s\n",AETHYR_RENDER_PROFILE,AETHYR_RENDER_APP,AETHYR_RENDER_SLUG,AETHYR_RENDER_PACKAGE,AETHYR_RENDER_PACKAGE_SHA256);}
