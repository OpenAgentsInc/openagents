struct coax_t9 {
  x: vec4f,
  y: vec3f,
}
struct coax_io_9 {
  @builtin(position) x: vec4f,
  @location(0) y: vec3f,
}
@group(0) @binding(0) var<uniform> u: array<vec4f, 3>;
fn coax_at_u(i: i32) -> f32 {
  return u[i / 4][i % 4];
}
fn coax_p_render_clip_output_probe_vs(p_vertex: u32, p_instance: u32) -> coax_t9 {
  var l_vertex: u32 = p_vertex;
  var l_instance: u32 = p_instance;
  var l_at: i32;
  var l_basis: vec3f;
  l_at = (i32(l_vertex) * 4i);
  l_basis = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
  if ((l_vertex == 0u))
  {
    l_basis = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
  }
  if ((l_vertex == 1u))
  {
    l_basis = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
  }
  return coax_t9(coax_p_v4(coax_at_u(i32(l_at)), coax_at_u(i32((l_at + 1i))), coax_at_u(i32((l_at + 2i))), coax_at_u(i32((l_at + 3i)))), l_basis);
}
fn coax_p_render_clip_output_probe_fs(p_v: coax_t9) -> vec4f {
  var l_v: coax_t9 = p_v;
  return coax_p_v4(l_v.x.z, l_v.y.x, l_v.y.y, l_v.x.w);
}
fn coax_p_v3(p_x: f32, p_y: f32, p_z: f32) -> vec3f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  return vec3f(l_x, l_y, l_z);
}
fn coax_p_v4(p_x: f32, p_y: f32, p_z: f32, p_w: f32) -> vec4f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  var l_w: f32 = p_w;
  return vec4f(l_x, l_y, l_z, l_w);
}
@vertex
fn render_clip_output_probe_vs(@builtin(vertex_index) coax_vid: u32, @builtin(instance_index) coax_iid: u32) -> coax_io_9 {
  let coax_r = coax_p_render_clip_output_probe_vs(coax_vid, coax_iid);
  return coax_io_9(coax_r.x, coax_r.y);
}
@fragment
fn render_clip_output_probe_fs(coax_in: coax_io_9) -> @location(0) vec4f {
  let coax_r = coax_p_render_clip_output_probe_fs(coax_t9(coax_in.x, coax_in.y));
  return coax_r;
}
