struct coax_t8 {
  x: vec4f,
  y: vec4f,
  z: vec4f,
  w: vec4f,
}
struct coax_t11 {
  x: vec4f,
  y: vec3f,
  z: vec3f,
  w: vec3f,
  f4: f32,
}
struct coax_t14 {
  x: vec4f,
  y: vec4f,
  z: vec3f,
  w: vec3f,
  f4: vec3f,
  f5: f32,
}
struct coax_io_14 {
  @builtin(position) x: vec4f,
  @location(0) @interpolate(flat) y: vec4f,
  @location(1) @interpolate(flat) z: vec3f,
  @location(2) @interpolate(flat) w: vec3f,
  @location(3) @interpolate(flat) f4: vec3f,
  @location(4) @interpolate(flat) f5: f32,
}
struct coax_t15 {
  x: vec3f,
  y: vec3f,
}
@group(0) @binding(0) var<uniform> u: array<vec4f, 171>;
fn coax_at_u(i: i32) -> f32 {
  return u[i / 4][i % 4];
}
@group(1) @binding(0) var<storage, read> objects: array<coax_t8>;
@group(0) @binding(1) var<uniform> probes: array<vec4f, 1>;
fn coax_at_probes(i: i32) -> f32 {
  return probes[i / 4][i % 4];
}
fn coax_p_render_deadgears_vs_probe_vs(p_vertex: u32, p_instance: u32) -> coax_t14 {
  var l_vertex: u32 = p_vertex;
  var l_instance: u32 = p_instance;
  var l_actual: coax_t11;
  var l_points: array<vec2f, 3>;
  var l_point: vec2f;
  l_actual = coax_p_deadgears_scene_vs(u32(coax_at_probes(i32(0i))), u32(coax_at_probes(i32(1i))));
  l_points = array<vec2f, 3>(coax_p_v2((-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(0x1.800000p1f, 0x1.000000p0f), coax_p_v2((-0x1.000000p0f), (-0x1.800000p1f)));
  l_point = l_points[i32(l_vertex)];
  return coax_t14(coax_p_v4(l_point.x, l_point.y, 0x1.000000p-1f, 0x1.000000p0f), l_actual.x, l_actual.y, l_actual.z, l_actual.w, l_actual.f4);
}
fn coax_p_render_deadgears_vs_probe_fs(p_v: coax_t14) -> vec4f {
  var l_v: coax_t14 = p_v;
  var l_mode: i32;
  l_mode = i32(coax_at_probes(i32(2i)));
  if ((l_mode == 0i))
  {
    return l_v.y;
  }
  if ((l_mode == 1i))
  {
    return coax_p_v4(l_v.z.x, l_v.z.y, l_v.z.z, l_v.f5);
  }
  if ((l_mode == 2i))
  {
    return coax_p_v4(l_v.w.x, l_v.w.y, l_v.w.z, 0x1.000000p0f);
  }
  return coax_p_v4(l_v.f4.x, l_v.f4.y, l_v.f4.z, 0x1.000000p0f);
}
fn coax_p_deadgears_scene_vs(p_id: u32, p_instance: u32) -> coax_t11 {
  var l_id: u32 = p_id;
  var l_instance: u32 = p_instance;
  var l_o: coax_t11;
  var l_m: coax_t8;
  var l_v: coax_t15;
  var l_f: u32;
  var l_c: vec2f;
  var l_n: vec3f;
  var l_a: vec3f;
  var l_b: vec3f;
  var l__sw2: u32;
  var l_p: vec4f;
  var l_w: vec3f;
  var l_c0: vec3f;
  var l_c1: vec3f;
  var l_c2: vec3f;
  var l_normal: vec3f;
  var l_wp: vec4f;
  l_o = coax_t11();
  l_m = objects[i32(l_instance)];
  if ((l_instance < 96u))
  {
    l_v = coax_p_deadgears_round_vertex(l_m, l_id);
    l_o.x = coax_p_v4(coax_p_wg_dot4(coax_p_wg_at4(8i), coax_p_v4(l_v.x.x, l_v.x.y, l_v.x.z, 0x1.000000p0f)), coax_p_wg_dot4(coax_p_wg_at4(12i), coax_p_v4(l_v.x.x, l_v.x.y, l_v.x.z, 0x1.000000p0f)), coax_p_wg_dot4(coax_p_wg_at4(16i), coax_p_v4(l_v.x.x, l_v.x.y, l_v.x.z, 0x1.000000p0f)), coax_p_wg_dot4(coax_p_wg_at4(20i), coax_p_v4(l_v.x.x, l_v.x.y, l_v.x.z, 0x1.000000p0f)));
    l_o.y = l_v.x;
    l_o.z = l_v.y;
    l_o.w = coax_p_wg_pow_f3f3(coax_p_wg_max_f3f3(coax_p_v3(l_m.w.x, l_m.w.y, l_m.w.z), coax_p_v3(0.0f, 0.0f, 0.0f)), coax_p_v3(0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f));
    l_o.f4 = l_m.w.w;
    return l_o;
  }
  l_f = (l_id / 6u);
  l_c = coax_p_wg_sub_f2f2(coax_p_deadgears_quad((l_id % 6u)), coax_p_v2(0x1.000000p-1f, 0x1.000000p-1f));
  l_n = coax_p_v3(0.0f, 0.0f, 0.0f);
  l_a = coax_p_v3(0.0f, 0.0f, 0.0f);
  l_b = coax_p_v3(0.0f, 0.0f, 0.0f);
  {
    l__sw2 = l_f;
    if ((l__sw2 == 0u))
    {
      l_n = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
      l_a = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
      l_b = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
    }
    else
    {
      if ((l__sw2 == 1u))
      {
        l_n = coax_p_v3((-0x1.000000p0f), 0.0f, 0.0f);
        l_a = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
        l_b = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
      }
      else
      {
        if ((l__sw2 == 2u))
        {
          l_n = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
          l_a = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
          l_b = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
        }
        else
        {
          if ((l__sw2 == 3u))
          {
            l_n = coax_p_v3(0.0f, (-0x1.000000p0f), 0.0f);
            l_a = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
            l_b = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
          }
          else
          {
            if ((l__sw2 == 4u))
            {
              l_n = coax_p_v3(0.0f, 0.0f, 0x1.000000p0f);
              l_a = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
              l_b = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
            }
            else
            {
              l_n = coax_p_v3(0.0f, 0.0f, (-0x1.000000p0f));
              l_a = coax_p_v3(0.0f, 0x1.000000p0f, 0.0f);
              l_b = coax_p_v3(0x1.000000p0f, 0.0f, 0.0f);
            }
          }
        }
      }
    }
  }
  l_p = coax_p_wg_make_f4_f3f(coax_p_wg_add_f3f3(coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(l_n, 0x1.000000p-1f), coax_p_wg_mul_f3f(l_a, l_c.x)), coax_p_wg_mul_f3f(l_b, l_c.y)), 0x1.000000p0f);
  l_w = coax_p_v3(coax_p_wg_dot4(l_m.x, l_p), coax_p_wg_dot4(l_m.y, l_p), coax_p_wg_dot4(l_m.z, l_p));
  l_c0 = coax_p_v3(l_m.x.x, l_m.y.x, l_m.z.x);
  l_c1 = coax_p_v3(l_m.x.y, l_m.y.y, l_m.z.y);
  l_c2 = coax_p_v3(l_m.x.z, l_m.y.z, l_m.z.z);
  l_normal = coax_p_wg_add_f3f3(coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(coax_p_wg_cross3(l_c1, l_c2), l_n.x), coax_p_wg_mul_f3f(coax_p_wg_cross3(l_c2, l_c0), l_n.y)), coax_p_wg_mul_f3f(coax_p_wg_cross3(l_c0, l_c1), l_n.z));
  l_wp = coax_p_v4(l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  l_o.x = coax_p_v4(coax_p_wg_dot4(coax_p_wg_at4(8i), l_wp), coax_p_wg_dot4(coax_p_wg_at4(12i), l_wp), coax_p_wg_dot4(coax_p_wg_at4(16i), l_wp), coax_p_wg_dot4(coax_p_wg_at4(20i), l_wp));
  l_o.y = l_w;
  l_o.z = coax_p_wg_normalize3(coax_p_wg_add_f3f3(l_normal, coax_p_v3(0.0f, 0x1.4f8b58p-17f, 0.0f)));
  l_o.w = coax_p_wg_pow_f3f3(coax_p_wg_max_f3f3(coax_p_v3(l_m.w.x, l_m.w.y, l_m.w.z), coax_p_v3(0.0f, 0.0f, 0.0f)), coax_p_v3(0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f));
  l_o.f4 = l_m.w.w;
  return l_o;
}
fn coax_p_v2(p_x: f32, p_y: f32) -> vec2f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  return vec2f(l_x, l_y);
}
fn coax_p_v4(p_x: f32, p_y: f32, p_z: f32, p_w: f32) -> vec4f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  var l_w: f32 = p_w;
  return vec4f(l_x, l_y, l_z, l_w);
}
fn coax_p_deadgears_round_vertex(p_m: coax_t8, p_id: u32) -> coax_t15 {
  var l_m: coax_t8 = p_m;
  var l_id: u32 = p_id;
  var l_q: u32;
  var l_c: vec2f;
  var l_row: u32;
  var l_k: f32;
  var l_a: vec3f;
  var l_b: vec3f;
  var l_axis: vec3f;
  var l_side: vec3f;
  var l_other: vec3f;
  var l_out: vec3f;
  var l_top: bool;
  var l_step: f32;
  var l_phi: f32;
  var l_n: vec3f;
  var l_r: f32;
  l_q = (l_id / 6u);
  l_c = coax_p_deadgears_quad((l_id % 6u));
  l_row = ((l_q / 8u) + coax_p_wg_u32_f(l_c.y));
  l_k = ((f32(((l_q % 8u) + coax_p_wg_u32_f(l_c.x))) / f32(8u)) * 0x1.921fb6p2f);
  l_a = coax_p_v3(l_m.x.x, l_m.x.y, l_m.x.z);
  l_b = coax_p_v3(l_m.y.x, l_m.y.y, l_m.y.z);
  l_axis = coax_p_wg_normalize3(coax_p_wg_add_f3f3(coax_p_wg_sub_f3f3(l_b, l_a), coax_p_v3(0.0f, 0x1.4f8b58p-17f, 0.0f)));
  l_side = coax_p_wg_normalize3(coax_p_wg_cross3(l_axis, select(coax_p_v3(0x1.000000p0f, 0.0f, 0.0f), coax_p_v3(0.0f, 0x1.000000p0f, 0.0f), (abs(l_axis.y) < 0x1.ccccccp-1f))));
  l_other = coax_p_wg_cross3(l_axis, l_side);
  l_out = coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(l_side, cos(l_k)), coax_p_wg_mul_f3f(l_other, sin(l_k)));
  l_top = (l_row > 2u);
  l_step = ((f32(select(l_row, ((l_row - 2u) - 1u), l_top)) / f32(2u)) * 0x1.921fb4p0f);
  l_phi = select((l_step - 0x1.921fb4p0f), l_step, l_top);
  l_n = coax_p_wg_add_f3f3(coax_p_wg_mul_f3f(l_out, cos(l_phi)), coax_p_wg_mul_f3f(l_axis, sin(l_phi)));
  l_r = select(l_m.x.w, l_m.y.w, l_top);
  return coax_t15(coax_p_wg_add_f3f3(select(l_a, l_b, l_top), coax_p_wg_mul_f3f(l_n, l_r)), l_n);
}
fn coax_p_wg_at4(p_at: i32) -> vec4f {
  var l_at: i32 = p_at;
  return coax_p_v4(coax_at_u(i32(l_at)), coax_at_u(i32((l_at + 1i))), coax_at_u(i32((l_at + 2i))), coax_at_u(i32((l_at + 3i))));
}
fn coax_p_wg_dot4(p_a: vec4f, p_b: vec4f) -> f32 {
  var l_a: vec4f = p_a;
  var l_b: vec4f = p_b;
  return dot(l_a, l_b);
}
fn coax_p_v3(p_x: f32, p_y: f32, p_z: f32) -> vec3f {
  var l_x: f32 = p_x;
  var l_y: f32 = p_y;
  var l_z: f32 = p_z;
  return vec3f(l_x, l_y, l_z);
}
fn coax_p_wg_max_f3f3(p_p0: vec3f, p_p1: vec3f) -> vec3f {
  var l_p0: vec3f = p_p0;
  var l_p1: vec3f = p_p1;
  return coax_p_v3(coax_p_fmax(l_p0.x, l_p1.x), coax_p_fmax(l_p0.y, l_p1.y), coax_p_fmax(l_p0.z, l_p1.z));
}
fn coax_p_wg_pow_f3f3(p_p0: vec3f, p_p1: vec3f) -> vec3f {
  var l_p0: vec3f = p_p0;
  var l_p1: vec3f = p_p1;
  return coax_p_v3(coax_pow_render_deadgears_vs_probe_vs(l_p0.x, l_p1.x), coax_pow_render_deadgears_vs_probe_vs(l_p0.y, l_p1.y), coax_pow_render_deadgears_vs_probe_vs(l_p0.z, l_p1.z));
}
fn coax_p_deadgears_quad(p_v: u32) -> vec2f {
  var l_v: u32 = p_v;
  var l_q: array<vec2f, 6>;
  l_q = array<vec2f, 6>(coax_p_v2(0.0f, 0.0f), coax_p_v2(0x1.000000p0f, 0.0f), coax_p_v2(0x1.000000p0f, 0x1.000000p0f), coax_p_v2(0.0f, 0.0f), coax_p_v2(0x1.000000p0f, 0x1.000000p0f), coax_p_v2(0.0f, 0x1.000000p0f));
  return l_q[i32(l_v)];
}
fn coax_p_wg_sub_f2f2(p_a: vec2f, p_b: vec2f) -> vec2f {
  var l_a: vec2f = p_a;
  var l_b: vec2f = p_b;
  return coax_p_v2((l_a.x - l_b.x), (l_a.y - l_b.y));
}
fn coax_p_wg_mul_f3f(p_a: vec3f, p_b: f32) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: f32 = p_b;
  return coax_p_v3((l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
fn coax_p_wg_add_f3f3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_v3((l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
fn coax_p_wg_make_f4_f3f(p_p0: vec3f, p_p1: f32) -> vec4f {
  var l_p0: vec3f = p_p0;
  var l_p1: f32 = p_p1;
  return coax_p_v4(l_p0.x, l_p0.y, l_p0.z, l_p1);
}
fn coax_p_wg_cross3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_cross3(l_a, l_b);
}
fn coax_p_wg_normalize3(p_a: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  return coax_p_normalize3(l_a);
}
fn coax_p_wg_u32_f(p_x: f32) -> u32 {
  var l_x: f32 = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return u32(l_x);
}
fn coax_p_wg_sub_f3f3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return coax_p_v3((l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
fn coax_p_fmax(p_a: f32, p_b: f32) -> f32 {
  var l_a: f32 = p_a;
  var l_b: f32 = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
fn coax_p_cross3(p_a: vec3f, p_b: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  var l_b: vec3f = p_b;
  return vec3f(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
fn coax_p_normalize3(p_a: vec3f) -> vec3f {
  var l_a: vec3f = p_a;
  return coax_p_scale3(l_a, (0x1.000000p0f / coax_p_length3(l_a)));
}
fn coax_p_length3(p_a: vec3f) -> f32 {
  var l_a: vec3f = p_a;
  return sqrt(dot(l_a, l_a));
}
fn coax_p_scale3(p_a: vec3f, p_k: f32) -> vec3f {
  var l_a: vec3f = p_a;
  var l_k: f32 = p_k;
  return vec3f((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
@vertex
fn render_deadgears_vs_probe_vs(@builtin(vertex_index) coax_vid: u32, @builtin(instance_index) coax_iid: u32) -> coax_io_14 {
  let coax_r = coax_p_render_deadgears_vs_probe_vs(coax_vid, coax_iid);
  return coax_io_14(coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4, coax_r.f5);
}
@fragment
fn render_deadgears_vs_probe_fs(coax_in: coax_io_14) -> @location(0) vec4f {
  let coax_r = coax_p_render_deadgears_vs_probe_fs(coax_t14(coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4, coax_in.f5));
  return coax_r;
}
fn coax_bits_render_deadgears_vs_probe_vs(b: u32) -> f32 {
  return bitcast<f32>(b);
}
fn coax_pow_render_deadgears_vs_probe_vs(x: f32, y: f32) -> f32 {
  if (y == 0.0f) {
    return 1.0f;
  }
  if (x == 0.0f) {
    return select(coax_bits_render_deadgears_vs_probe_vs(0x7f800000u), 0.0f, y > 0.0f);
  }
  let r = pow(abs(x), y);
  if (!(x < 0.0f)) {
    return r;
  }
  if (floor(y) != y) {
    return coax_bits_render_deadgears_vs_probe_vs(0x7fc00000u);
  }
  if (fract(y * 0.5f) != 0.0f) {
    return -r;
  }
  return r;
}
