# Firm reason: 2 (independent transport audit comparing frozen legacy GPU readback words with the Coax-owned probe executor).
from pathlib import Path
import re,json,subprocess,time,hashlib
root=Path('/Users/christopherdavid/work/openagents-aethyr-book-main');out=Path('/tmp/aethyr-webgpu-port-20261102');rows=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for old in json.loads((out/'old-commands.json').read_text()):
 mode=old['mode'];part=out/mode;source=Path(old['argv'][1]);text=source.read_text()
 text=text.replace('from "../../coax/web/chrome.ts"','from '+json.dumps(str(root/'coax/web/chrome.ts')))
 text=re.sub(r'new URL\("([^"]+)",\s*import.meta.url\)\.pathname',lambda m:json.dumps(str((source.parent/m[1]).resolve())),text)
 assert text.count('results=[];')==1;text=text.replace('results=[];','results=[],raw_words=[];')
 needle='const rgba=Array.from(new Float32Array(read.getMappedRange(),0,4));results.push('
 assert text.count(needle)==1;text=text.replace(needle,'const mapped=read.getMappedRange();const rgba=Array.from(new Float32Array(mapped,0,4));raw_words.push(Array.from(new Uint32Array(mapped,0,4)));results.push(')
 assert text.count('messages,errors,results};')==1;text=text.replace('messages,errors,results};','messages,errors,results,raw_words};')
 driver=part/'legacy-raw-observer.ts';driver.write_text('// Frozen legacy executor with only raw-u32 readback observation added; import/probe paths relocated explicitly.\n'+text)
 argv=['bun',str(driver),old['argv'][2],str(part/'old-raw.json')];start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True,timeout=120);(part/'old-raw.stdout').write_bytes(p.stdout);(part/'old-raw.stderr').write_bytes(p.stderr)
 assert p.returncode==0,(mode,p.stderr.decode());raw=json.loads((part/'old-raw.json').read_text());new=json.loads((part/'new.json').read_text());original=json.loads((part/'old.json').read_text())
 assert raw['results']==original['results']==new['results'],mode
 assert raw['raw_words']==new['raw_words'],(mode,raw['raw_words'],new['raw_words'])
 assert raw['source_changes']==[]==new['source_changes'] and raw['errors']==[]==new['errors'] and raw['messages']==[]==new['messages']
 rows.append({'mode':mode,'observations':len(new['results']),'channels':len(new['results'])*4,'all_original_numbers_equal':True,'all_raw_u32_words_equal':True,'old_raw_observer_sha256':sha(driver),'old_original_driver_sha256':sha(source),'new_receipt_sha256':sha(part/'new.json'),'old_raw_receipt_sha256':sha(part/'old-raw.json'),'argv':argv,'seconds':time.monotonic()-start});print(mode,flush=True)
record={'schema':'aethyr.webgpu.probe-port-parity.v1','status':'pass','scope':'Six exact authored fixture sets through original legacy executors, legacy observer-only u32 extensions, and Coax fixture/CDP runner with browser WebGPU effects. Every raw u32 channel equals; no numerical tolerance or mask used. This is calibration-tool parity, not a whole-renderer/profile claim.','profiles':rows,'total_observations':sum(r['observations']for r in rows),'total_channels':sum(r['channels']for r in rows)}
(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':'pass','observations':record['total_observations'],'channels':record['total_channels']}))
