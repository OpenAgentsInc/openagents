# Firm reason: 2 (independent Python IEEE binary32 decode oracle for reported raw-u32 readbacks, compared with the Coax probe verdict and frozen original GPU observations).
from pathlib import Path
import subprocess,time,json,hashlib,os,signal,struct,math
root=Path('/Users/christopherdavid/work/openagents-aethyr-book-main');out=Path('/tmp/aethyr-webgpu-port-20261102');binary=root/'coax/web/build/tools/webgpu-probe-1fac3750bcffbb735ef26f4a065d16414b911068fd7d68bc3ca112565d2432aa';deadline=time.monotonic()+810;rows=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def clean_owned(pid):
 text=subprocess.check_output(['ps','-axo','pid=,ppid=,pgid='],text=True);table=[tuple(map(int,line.split()))for line in text.splitlines()];owned={pid}
 while True:
  found=owned|{p for p,pp,g in table if pp in owned}
  if found==owned:break
  owned=found
 for group in {g for p,pp,g in table if p in owned}:
  try:os.killpg(group,signal.SIGKILL)
  except ProcessLookupError:pass
for old in json.loads((out/'old-commands.json').read_text()):
 mode=old['mode'];part=out/mode;path=part/'new-final.json';argv=[str(binary),mode,old['argv'][2],str(path)];start=time.monotonic();reused=path.exists()
 if not reused:
  child=subprocess.Popen(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  try:stdout,stderr=child.communicate(timeout=min(180,max(1,deadline-time.monotonic())))
  except BaseException:clean_owned(child.pid);child.communicate(timeout=5);raise
  (part/'new-final.stdout').write_bytes(stdout);(part/'new-final.stderr').write_bytes(stderr);assert child.returncode==0,(mode,stderr.decode())
 new=json.loads(path.read_text());original=json.loads((part/'old.json').read_text());raw=json.loads((part/'old-raw.json').read_text())
 for field in ['format','width','height','device','messages','errors','results']:assert new[field]==original[field],(mode,field)
 assert new['raw_words']==raw['raw_words'] and new['results']==raw['results'],mode
 for captured in [new,raw]:
  for values,words in zip(captured['results'],captured['raw_words']):
   decoded=list(struct.unpack('<4f',struct.pack('<4I',*words)))
   assert all(math.isfinite(x) for x in decoded) and decoded[3]==1
   assert decoded==values['rgba'],(mode,decoded,values['rgba'])
 assert new['source_changes']==[]
 for source,digest in new['inputs'].items():assert sha(source)==digest,(mode,source)
 row={'mode':mode,'argv':argv,'exit_status':0,'seconds':time.monotonic()-start,'reused_unchanged_final_capture':reused,'observations':len(new['results']),'channels':len(new['results'])*4,'all_original_values_equal':True,'all_raw_u32_words_equal':True,'receipt_sha256':sha(path)};rows.append(row);(out/'final-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
print(json.dumps({'status':'pass','observations':sum(r['observations']for r in rows),'channels':sum(r['channels']for r in rows)}))
