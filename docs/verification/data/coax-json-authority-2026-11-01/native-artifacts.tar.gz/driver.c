#include "json.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned nibble(char c){return c<='9'?c-'0':c-'a'+10;}
int main(int argc,char **argv){char op,hex[4097];int cap;
 while(scanf(" %c %d %4096s",&op,&cap,hex)==3){
  if(cap<0||cap>128)return 2;size_t n=!strcmp(hex,"-")?0:strlen(hex)/2;
  char raw[2049]={0};for(size_t i=0;i<n;i++)raw[i]=(char)((nibble(hex[i*2])<<4)|nibble(hex[i*2+1]));
  coax_string text={raw,(int64_t)n};unsigned char output[136];memset(output,0xa5,sizeof output);
  if(op=='I'){int64_t v=json_integer_native(text);if(argc>1&&!strcmp(argv[1],"integer"))v=0;printf("I %"PRId64"\n",v);continue;}
  int64_t count;int bad=0;
  if(op=='E'){count=json_unescape_native(text,(coax_v_u8){output+4,cap});bad=count<0;}
  else if(op=='Q'){coax_t_JsonNativeWrite r=json_requote_native(text,(coax_v_u8){output+4,cap});bad=r.bad;count=bad?-1:r.count;}
  else return 2;
  int guard=1;for(int i=0;i<136;i++)if((i<4||i>=cap+4)&&output[i]!=0xa5)guard=0;
  if(argc>1){if(!strcmp(argv[1],"guard"))guard=0;if(!strcmp(argv[1],"status")){bad=0;count=0;}
   if(!strcmp(argv[1],"byte")&&count>0)output[4]^=1;}
  printf("%c %d %"PRId64" %d ",op,bad,count,guard);
  if(count>0)for(int64_t i=0;i<count;i++)printf("%02x",output[4+i]);else printf("-");puts("");
 }return ferror(stdin)?2:0;}
