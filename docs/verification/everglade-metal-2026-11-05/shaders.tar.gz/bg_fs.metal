// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t11 {
  float4 x;
  float4 y;
};
struct coax_out_11 {
  float4 x [[color(0)]];
  float4 y [[color(1)]];
};
struct coax_t12 {
  float4 x;
  float4 y;
  float4 z;
  float4 w;
};
struct coax_t14 {
  uint x;
  uint y;
  uint z;
};
struct coax_t15 {
  int x;
  int y;
  int z;
};
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1);
coax_t11 coax_p_eg_bg_fs(CoaxResources cx, float4 p_pos);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
float3 coax_p_eg_pixel_ray(CoaxResources cx, float2 p_p);
float4 coax_p_eg_st(CoaxResources cx, uint p_i);
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p);
float3 coax_p_eg_sky(CoaxResources cx, float3 p_d, float3 p_l);
float3 coax_p_eg_ridges(CoaxResources cx, float3 p_d, float3 p_sky_c);
float3 coax_p_eg_weather_sky(CoaxResources cx, float3 p_c, float3 p_d);
float3 coax_p_eg_weather_streaks(CoaxResources cx, float3 p_c, float3 p_v, float p_d);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_eg_water_under_view(CoaxResources cx, float3 p_c, float3 p_world, float3 p_d);
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b);
float coax_p_verse_style_bloom_share(CoaxResources cx, float p_lum, float p_threshold, float p_knee);
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_verse_style_shaft_source(CoaxResources cx, float p_cos_t);
coax_t12 coax_p_eg_unview(CoaxResources cx);
float4 coax_p_m4_apply(CoaxResources cx, coax_t12 p_m, float4 p_v);
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up);
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2);
float coax_p_eg_saturation(CoaxResources cx, float3 p_c);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
float coax_p_verse_style_chroma_gain(CoaxResources cx, float p_have, float p_albedo, float p_keep);
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float coax_p_verse_style_sky_band(CoaxResources cx, float p_up, float p_lift);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_sw_xy_f4(CoaxResources cx, float4 p_p);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_verse_style_cloud_field(CoaxResources cx, float p_x, float p_z, float p_s1, float p_s2, float p_octaves);
float coax_p_verse_style_cloud_cover(CoaxResources cx, float p_n, float p_cover, float p_cut_lo, float p_cut_hi);
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a);
float coax_p_verse_style_cloud_lit(CoaxResources cx, float p_n, float p_toward);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_verse_style_cloud_fade(CoaxResources cx, float p_up);
float coax_p_eg_stars(CoaxResources cx, float3 p_d);
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x);
float4 coax_p_eg_ridge_ring(CoaxResources cx, uint p_i);
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_eg_noise(CoaxResources cx, float2 p_p);
float coax_p_fract(CoaxResources cx, float p_x);
float coax_p_eg_hash2(CoaxResources cx, float2 p_p);
float coax_p_stepf(CoaxResources cx, float p_edge, float p_x);
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale);
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y);
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v);
bool coax_p_eg_weather_desktop(CoaxResources cx);
float coax_p_wg_length3(CoaxResources cx, float3 p_a);
float coax_p_wg_exp2(CoaxResources cx, float p_x);
bool coax_p_eg_weather_covered(CoaxResources cx, float3 p_p);
float coax_p_wg_round(CoaxResources cx, float p_x);
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0);
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p);
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b);
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d);
float coax_p_eg_water_eye_over(CoaxResources cx);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float3 coax_p_EG_WATER_UNDER_ABSORB(CoaxResources cx);
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a);
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_EG_WATER_UNDER_SCATTER(CoaxResources cx);
float3 coax_p_EG_WATER_UNDER_TINT(CoaxResources cx);
float coax_p_eg_water_motes(CoaxResources cx, float3 p_o, float3 p_d, float p_reach);
float coax_p_eg_water_shafts(CoaxResources cx, float3 p_o, float3 p_d, float p_path, float p_level);
float coax_p_st_max(CoaxResources cx, float p_a, float p_b);
float coax_p_st_min(CoaxResources cx, float p_a, float p_b);
coax_t12 coax_p_wg_transpose(CoaxResources cx, coax_t12 p_m);
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b);
float4 coax_p_scale4(CoaxResources cx, float4 p_a, float p_k);
float4 coax_p_add4(CoaxResources cx, float4 p_a, float4 p_b);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
float coax_p_st_sat(CoaxResources cx, float p_x);
float coax_p_saturate(CoaxResources cx, float p_x);
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y);
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x);
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_wg_atan01(CoaxResources cx, float p_x);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b);
float coax_p_eg_hash(CoaxResources cx, float2 p_p);
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y);
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff);
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap);
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t);
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl);
float4 coax_p_EG_RAIN_BRIDGE(CoaxResources cx);
bool coax_p_wg_all_ge_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_sw_zw_f4(CoaxResources cx, float4 p_p);
bool coax_p_wg_all_le_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
uint coax_p_wg_u32_f(CoaxResources cx, float p_x);
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b);
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0);
float4 coax_p_eg_water_mote_hash(CoaxResources cx, float3 p_c);
float2 coax_p_wg_sw_xz_f4(CoaxResources cx, float4 p_p);
float coax_p_eg_water_caustic_pattern(CoaxResources cx, float2 p_p, float p_t);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y);
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x);
uint coax_p_render_noise_cell(CoaxResources cx, float p_x);
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_render_noise_unit(CoaxResources cx, uint p_word);
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch);
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx);
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx);
float coax_p_wg_trunc(CoaxResources cx, float p_x);
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p);
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1);
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p);
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word);
coax_t15 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p);
coax_t14 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t15 p_p);
coax_t14 coax_p_wg_mul_u3u(CoaxResources cx, coax_t14 p_a, uint p_b);
coax_t14 coax_p_wg_add_u3u(CoaxResources cx, coax_t14 p_a, uint p_b);
coax_t14 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z);
coax_t14 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t14 p_a, coax_t14 p_b);
coax_t14 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t14 p_a, coax_t14 p_b);
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b);
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
coax_t15 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z);
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1) {
  uint l_i = p_i;
  uint l__iid1 = p__iid1;
  array<float2, 3> l_p{};
  l_p = array<float2, 3>{coax_p_v2(cx, (-0x1.000000p0f), (-0x1.800000p1f)), coax_p_v2(cx, (-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(cx, 0x1.800000p1f, 0x1.000000p0f)};
  return coax_p_v4(cx, l_p[int(l_i)].x, l_p[int(l_i)].y, 0.0f, 0x1.000000p0f);
}
coax_t11 coax_p_eg_bg_fs(CoaxResources cx, float4 p_pos) {
  float4 l_pos = p_pos;
  float3 l_d{};
  float3 l_l{};
  float3 l_c{};
  float4 l_b{};
  l_d = coax_p_eg_pixel_ray(cx, coax_p_v2(cx, l_pos.x, l_pos.y));
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_c = coax_p_eg_water_under_view(cx, coax_p_eg_weather_streaks(cx, coax_p_eg_weather_sky(cx, coax_p_eg_ridges(cx, l_d, coax_p_eg_sky(cx, l_d, l_l)), l_d), l_d, 0x1.f40000p9f), coax_p_wg_add_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_wg_mul_f3f(cx, l_d, 0x1.f40000p9f)), l_d);
  l_b = coax_p_eg_st(cx, 19u);
  return coax_t11{coax_p_v4(cx, l_c.x, l_c.y, l_c.z, coax_p_verse_style_bloom_share(cx, coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z), l_b.x, l_b.y)), coax_p_v4(cx, coax_p_verse_style_shaft_source(cx, coax_p_wg_dot3(cx, l_d, l_l)), 0.0f, 0.0f, 0.0f)};
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
float3 coax_p_eg_pixel_ray(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float4 l_ndc{};
  float4 l_w{};
  l_ndc = coax_p_v4(cx, (((l_p.x / cx.r_u[0]) * 0x1.000000p1f) - 0x1.000000p0f), (0x1.000000p0f - ((l_p.y / cx.r_u[1]) * 0x1.000000p1f)), 0x1.ccccccp-1f, 0x1.000000p0f);
  l_w = coax_p_m4_apply(cx, coax_p_eg_unview(cx), l_ndc);
  return coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_wg_div_f3f(cx, coax_p_v3(cx, l_w.x, l_w.y, l_w.z), l_w.w), coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26])));
}
float4 coax_p_eg_st(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return coax_p_wg_at4(cx, ((int(l_i) * 4) + 1084));
}
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_eg_sky(CoaxResources cx, float3 p_d, float3 p_l) {
  float3 l_d = p_d;
  float3 l_l = p_l;
  float l_up{};
  float3 l_h{};
  float3 l_z{};
  float l_t{};
  float3 l_c{};
  float l_gain{};
  float l_cy{};
  float l_ct{};
  bool l_moon{};
  float l_disc{};
  float l_halo{};
  float l_overcast{};
  float l_glow_patch{};
  float4 l_cl{};
  float4 l_c2{};
  float l_t_2{};
  float2 l_p{};
  float l_n{};
  float l_cover{};
  float2 l_toward{};
  float l_lit{};
  float l_night{};
  float3 l_cloud{};
  l_up = l_d.y;
  l_h = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 13u));
  l_z = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 12u));
  l_t = coax_p_verse_style_sky_t(cx, l_up);
  l_c = coax_p_wg_mix_f3f3f(cx, l_h, l_z, l_t);
  l_gain = coax_p_verse_style_chroma_gain(cx, coax_p_eg_saturation(cx, l_c), coax_p_mix(cx, coax_p_eg_saturation(cx, l_h), coax_p_eg_saturation(cx, l_z), l_t), 0x1.000000p0f);
  l_cy = coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z);
  l_c = coax_p_wg_max_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, l_cy, l_cy, l_cy), coax_p_wg_mul_f3f(cx, coax_p_wg_sub_f3f3(cx, l_c, coax_p_v3(cx, l_cy, l_cy, l_cy)), l_gain)), coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
  l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u)), coax_p_verse_style_sky_band(cx, l_up, (coax_p_eg_st(cx, 12u)).w));
  l_ct = coax_p_wg_dot3(cx, l_d, l_l);
  l_moon = ((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f);
  l_disc = coax_p_smoothstep(cx, cos(((coax_p_eg_st(cx, 14u)).x * 0x1.266666p0f)), cos(((coax_p_eg_st(cx, 14u)).x * 0x1.b33334p-1f)), l_ct);
  l_halo = ((coax_p_verse_style_halo(cx, l_ct, (coax_p_eg_st(cx, 14u)).y) * 0x1.000000p-1f) + (coax_p_verse_style_halo(cx, l_ct, (coax_p_eg_st(cx, 14u)).z) * 0x1.000000p-2f));
  if (l_moon)
  {
    l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), l_halo), 0x1.000000p-1f));
  }
  else
  {
    l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u)), 0x1.800000p0f), coax_p_clampf(cx, (l_halo * 0x1.19999ap0f), 0.0f, 0x1.ccccccp-1f));
  }
  l_overcast = coax_p_clampf(cx, ((cx.r_u[1478] - 0x1.333334p-3f) / 0x1.19999ap-1f), 0.0f, 0x1.000000p0f);
  l_glow_patch = (coax_p_smoothstep(cx, cos(((coax_p_eg_st(cx, 14u)).x * 0x1.c00000p2f)), 0x1.000000p0f, l_ct) * 0x1.eb851ep-4f);
  l_c = coax_p_wg_mix_f3f3f(cx, l_c, (l_moon ? coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.b33334p-1f, 0x1.c28f5cp-1f, 0x1.000000p0f), 0x1.99999ap0f) : coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.f0a3d8p-1f, 0x1.c28f5cp-1f), 0x1.000000p2f)), coax_p_mix(cx, l_disc, l_glow_patch, l_overcast));
  l_cl = coax_p_eg_st(cx, 15u);
  l_c2 = coax_p_eg_st(cx, 16u);
  if (((l_up > 0x1.47ae14p-7f) && (l_cl.x > 0.0f)))
  {
    l_t_2 = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
    l_p = coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_d.x, l_d.z), l_up), l_cl.y), coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_sw_xy_f4(cx, coax_p_eg_st(cx, 25u)), l_cl.z), l_t_2));
    l_n = coax_p_verse_style_cloud_field(cx, l_p.x, l_p.y, l_c2.x, l_c2.y, l_cl.w);
    l_cover = coax_p_verse_style_cloud_cover(cx, l_n, l_cl.x, l_c2.z, l_c2.w);
    l_toward = coax_p_wg_mul_f2f(cx, coax_p_wg_normalize2(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_l.x, l_l.z), coax_p_v2(cx, 0x1.a36e2ep-14f, 0x1.a36e2ep-14f))), 0x1.040000p8f);
    l_lit = coax_p_verse_style_cloud_lit(cx, l_n, coax_p_verse_style_cloud_field(cx, (l_p.x + l_toward.x), (l_p.y + l_toward.y), l_c2.x, l_c2.y, l_cl.w));
    l_night = (coax_p_eg_st(cx, 14u)).w;
    l_cloud = coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mix_f3f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 4u)), (coax_p_eg_st(cx, 17u)).w), 0x1.ccccccp-1f), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 17u)), l_lit), coax_p_fmax(cx, (coax_p_eg_st(cx, 0u)).w, 0x1.333334p-2f)), (0x1.000000p0f - (0x1.800000p-1f * l_night)));
    l_c = coax_p_wg_mix_f3f3f(cx, l_c, l_cloud, ((l_cover * coax_p_verse_style_cloud_fade(cx, l_up)) * (0x1.000000p0f - (0x1.000000p-1f * l_night))));
  }
  return coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_make_f3_f(cx, coax_p_eg_stars(cx, l_d)), (coax_p_eg_st(cx, 14u)).w), 0x1.333334p-1f));
}
float3 coax_p_eg_ridges(CoaxResources cx, float3 p_d, float3 p_sky_c) {
  float3 l_d = p_d;
  float3 l_sky_c = p_sky_c;
  float l_flat{};
  float2 l_dir{};
  float2 l_e{};
  float l_a{};
  uint l_i{};
  float4 l_r{};
  float l_b{};
  float l_c{};
  float l_t{};
  float2 l_ring{};
  float l_k{};
  float l_shape{};
  float l_top{};
  float l_cell{};
  float l_f{};
  float l_h{};
  float l_lean{};
  float l_face{};
  float3 l_land{};
  float3 l_amb{};
  float3 l_lit{};
  float l_fog{};
  float l_night{};
  float3 l_behind{};
  l_flat = coax_p_wg_length2(cx, coax_p_v2(cx, l_d.x, l_d.z));
  if ((l_flat < 0x1.0624dep-10f))
  {
    return l_sky_c;
  }
  l_dir = coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_d.x, l_d.z), l_flat);
  l_e = coax_p_v2(cx, cx.r_u[24], cx.r_u[26]);
  l_a = coax_p_wg_atan2(cx, l_dir.y, l_dir.x);
  {
    l_i = 0u;
    while ((l_i < 3u))
    {
      l_r = coax_p_eg_ridge_ring(cx, l_i);
      l_b = coax_p_wg_dot2(cx, l_e, l_dir);
      l_c = (coax_p_wg_dot2(cx, l_e, l_e) - (l_r.x * l_r.x));
      l_t = ((-l_b) + sqrt(coax_p_fmax(cx, ((l_b * l_b) - l_c), 0.0f)));
      l_ring = coax_p_wg_mul_f2f(cx, coax_p_v2(cx, cos(l_a), sin(l_a)), l_r.z);
      l_k = (float(l_i) * 0x1.100000p4f);
      l_shape = ((0x1.3d70a4p-1f * coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, l_ring, coax_p_v2(cx, l_k, 0x1.800000p1f)))) + (0x1.851eb8p-2f * coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_ring, 0x1.59999ap1f), coax_p_v2(cx, 0x1.400000p2f, l_k)))));
      l_top = (l_r.y * (0x1.666666p-2f + (0x1.4cccccp-1f * l_shape)));
      if ((l_r.w > 0.0f))
      {
        l_cell = (l_a * 0x1.180000p6f);
        l_f = coax_p_fract(cx, l_cell);
        l_h = coax_p_eg_hash2(cx, coax_p_v2(cx, floor(l_cell), l_k));
        l_top = (l_top + (((l_r.w * (0x1.99999ap-2f + (0x1.333334p-1f * l_h))) * coax_metal_pow(coax_p_fmax(cx, (0x1.000000p0f - abs(((0x1.000000p1f * l_f) - 0x1.000000p0f))), 0.0f), 0x1.333334p-1f)) * coax_p_stepf(cx, 0x1.99999ap-3f, l_h)));
      }
      if ((((l_d.y * l_t) / l_flat) > (l_top - cx.r_u[25])))
      {
        {
          l_i = (l_i + 1u);
          continue;
        }
      }
      l_lean = (coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_ring, 0x1.b33334p0f), coax_p_v2(cx, 0x1.200000p3f, l_k))) - 0x1.000000p-1f);
      l_face = (0x1.800000p-1f + (0x1.000000p-1f * coax_p_clampf(cx, ((coax_p_wg_dot3(cx, coax_p_v3(cx, (-l_dir.x), 0.0f, (-l_dir.y)), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u))) * 0x1.000000p-1f) + l_lean), 0.0f, 0x1.000000p0f)));
      l_land = coax_p_wg_mix_f3f3f(cx, coax_p_v3(cx, 0x1.99999ap-5f, 0x1.333334p-3f, 0x1.99999ap-5f), coax_p_v3(cx, 0x1.eb851ep-5f, 0x1.eb851ep-4f, 0x1.5c28f6p-3f), (float(l_i) * 0x1.000000p-1f));
      l_amb = coax_p_v3(cx, coax_p_verse_style_ambient(cx, 0x1.000000p0f, (coax_p_eg_st(cx, 5u)).x, (coax_p_eg_st(cx, 6u)).x, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, 0x1.000000p0f, (coax_p_eg_st(cx, 5u)).y, (coax_p_eg_st(cx, 6u)).y, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, 0x1.000000p0f, (coax_p_eg_st(cx, 5u)).z, (coax_p_eg_st(cx, 6u)).z, (coax_p_eg_st(cx, 5u)).w));
      l_lit = coax_p_wg_mul_f3f3(cx, l_land, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w), l_face), l_amb));
      l_fog = coax_p_fmax(cx, ((coax_p_eg_st(cx, 9u)).z * (0x1.333334p-3f + (0x1.000000p-2f * float(l_i)))), coax_p_eg_haze_share(cx, l_t, (l_r.y * 0x1.000000p-1f)));
      l_night = (coax_p_eg_st(cx, 14u)).w;
      l_behind = coax_p_wg_max_f3f3(cx, coax_p_wg_sub_f3f3(cx, l_sky_c, coax_p_wg_make_f3_f(cx, ((coax_p_eg_stars(cx, l_d) * l_night) * 0x1.333334p-1f))), coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
      return coax_p_wg_mix_f3f3f(cx, l_lit, coax_p_wg_mix_f3f3f(cx, coax_p_eg_haze_colour(cx, l_fog, l_d), coax_p_wg_mul_f3f(cx, l_behind, 0x1.99999ap-1f), l_night), l_fog);
      l_i = (l_i + 1u);
    }
  }
  return l_sky_c;
}
float3 coax_p_eg_weather_sky(CoaxResources cx, float3 p_c, float3 p_d) {
  float3 l_c = p_c;
  float3 l_d = p_d;
  float l_cloud{};
  float3 l_grey{};
  float3 l_o{};
  l_cloud = (coax_p_fmax(cx, (cx.r_u[1478] - 0x1.333334p-3f), 0.0f) / 0x1.b33334p-1f);
  l_grey = coax_p_wg_mul_f3f3(cx, coax_p_wg_make_f3_f(cx, coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z)), coax_p_v3(cx, 0x1.b851ecp-1f, 0x1.d70a3ep-1f, 0x1.f5c290p-1f));
  l_o = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, l_grey, (0x1.000000p0f - (0x1.000000p-2f * l_cloud))), (l_cloud * 0x1.666666p-1f));
  l_o = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.800000p-1f, 0x1.99999ap-1f, 0x1.000000p0f), cx.r_u[1475]), 0x1.99999ap-1f), coax_p_smoothstep(cx, (-0x1.99999ap-4f), 0x1.333334p-2f, l_d.y)));
  return l_o;
}
float3 coax_p_eg_weather_streaks(CoaxResources cx, float3 p_c, float3 p_v, float p_d) {
  float3 l_c = p_c;
  float3 l_v = p_v;
  float l_d = p_d;
  float l_rain{};
  int l_layers{};
  float l_t{};
  float2 l_lean{};
  float3 l_w{};
  float l_flat{};
  float l_k{};
  float l_around{};
  float l_px{};
  float l_a{};
  int l_i{};
  float l_r{};
  float l_along{};
  float l_fade{};
  float l_y{};
  float l_cells{};
  float2 l_q{};
  float2 l_cell{};
  float l_h{};
  float2 l_f{};
  float l_off{};
  float l_top{};
  float l_width{};
  float l_x{};
  float l_len_2{};
  float l_streak{};
  float3 l_key{};
  float3 l_tint{};
  l_rain = cx.r_u[1472];
  if ((l_rain <= 0x1.47ae14p-7f))
  {
    return l_c;
  }
  l_layers = (coax_p_eg_weather_desktop(cx) ? 4 : 2);
  l_t = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
  l_lean = coax_p_wg_div_f2f(cx, coax_p_v2(cx, cx.r_u[1473], cx.r_u[1474]), 0x1.c00000p2f);
  l_w = coax_p_v3(cx, (l_v.x + (l_lean.x * l_v.y)), l_v.y, (l_v.z + (l_lean.y * l_v.y)));
  l_flat = coax_p_wg_length2(cx, coax_p_v2(cx, l_w.x, l_w.z));
  l_k = (l_flat / coax_p_fmax(cx, coax_p_wg_length3(cx, l_w), 0x1.a36e2ep-14f));
  if ((l_k < 0x1.eb851ep-5f))
  {
    return l_c;
  }
  l_around = ((coax_p_wg_atan2(cx, l_w.x, l_w.z) * 0x1.45f306p-3f) + 0x1.000000p-1f);
  l_px = coax_p_fmax(cx, cx.r_u[1065], 0x1.a36e2ep-14f);
  l_a = 0.0f;
  {
    l_i = 0;
    while ((l_i < 4))
    {
      if ((l_i >= l_layers))
      {
        break;
      }
      l_r = (0x1.333334p0f * coax_p_wg_exp2(cx, float(l_i)));
      l_along = (l_r / l_flat);
      if ((l_along > l_d))
      {
        break;
      }
      if (coax_p_eg_weather_covered(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_wg_mul_f3f(cx, l_v, l_along))))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_fade = (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.47ae14p-5f, 0x1.eb851ep-4f, ((l_px * l_along) / l_k)));
      if ((l_fade <= 0.0f))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_y = (l_w.y * l_along);
      l_cells = coax_p_wg_round(cx, ((0x1.921fb6p2f * l_r) / 0x1.eb851ep-4f));
      l_q = coax_p_v2(cx, (l_around * l_cells), (((l_y + (l_t * 0x1.c00000p2f)) + (float(l_i) * 0x1.b66666p3f)) / 0x1.b33334p-1f));
      l_cell = coax_p_wg_floor_f2(cx, l_q);
      l_h = coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f2(cx, l_cell, coax_p_v2(cx, (float(l_i) * 0x1.100000p4f), 0x1.800000p1f)));
      if ((l_h > (l_rain * 0x1.19999ap-1f)))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_f = coax_p_wg_fract_f2(cx, l_q);
      l_off = ((coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_cell, 0x1.233334p3f)) * 0x1.666666p-1f) + 0x1.333334p-3f);
      l_top = (coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_cell, 0x1.2cccccp2f)) * 0x1.666666p-1f);
      l_width = coax_p_fmax(cx, (((l_px * l_along) * 0x1.19999ap0f) / 0x1.eb851ep-4f), 0x1.47ae14p-6f);
      l_x = abs((l_f.x - l_off));
      l_len_2 = ((0x1.1eb852p-4f * coax_p_wg_exp2(cx, (float(l_i) * 0x1.000000p-1f))) / 0x1.b33334p-1f);
      l_streak = (((0x1.000000p0f - coax_p_smoothstep(cx, (l_width * 0x1.000000p-1f), l_width, l_x)) * coax_p_smoothstep(cx, l_top, (l_top + 0x1.47ae14p-6f), l_f.y)) * (0x1.000000p0f - coax_p_smoothstep(cx, ((l_top + l_len_2) - 0x1.47ae14p-6f), (l_top + l_len_2), l_f.y)));
      l_a = (l_a + ((l_streak * (0x1.19999ap-1f - (0x1.99999ap-4f * float(l_i)))) * l_fade));
      l_i = (l_i + 1);
    }
  }
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  l_tint = coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.8f5c28p-1f, 0x1.ae147ap-1f, 0x1.ccccccp-1f), (0x1.ccccccp-2f + (0x1.19999ap-1f * coax_p_clampf(cx, coax_p_verse_style_luma(cx, l_key.x, l_key.y, l_key.z), 0.0f, 0x1.000000p0f))));
  return coax_p_wg_mix_f3f3f(cx, l_c, l_tint, (coax_p_clampf(cx, l_a, 0.0f, 0x1.000000p0f) * 0x1.99999ap-2f));
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float3 coax_p_eg_water_under_view(CoaxResources cx, float3 p_c, float3 p_world, float3 p_d) {
  float3 l_c = p_c;
  float3 l_world = p_world;
  float3 l_d = p_d;
  float3 l_o{};
  float l_level{};
  float l_dist{};
  float l_path{};
  float3 l_tr{};
  float3 l_key{};
  float3 l_light{};
  float3 l_col{};
  if ((!coax_p_eg_water_pixel_under(cx, l_d)))
  {
    return l_c;
  }
  l_o = coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]);
  l_level = (l_o.y - coax_p_eg_water_eye_over(cx));
  l_dist = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, l_world, l_o));
  l_path = l_dist;
  if (((l_world.y > l_level) && (l_d.y > 0.0f)))
  {
    l_path = coax_p_fmin(cx, l_dist, ((l_level - l_o.y) / l_d.y));
  }
  l_tr = coax_p_wg_exp_f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_EG_WATER_UNDER_ABSORB(cx)), l_path));
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  l_light = coax_p_wg_mul_f3f(cx, coax_p_EG_WATER_UNDER_SCATTER(cx), (0x1.666666p-2f + (0x1.4cccccp-1f * coax_p_verse_style_luma(cx, l_key.x, l_key.y, l_key.z))));
  l_col = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_c, coax_p_EG_WATER_UNDER_TINT(cx)), l_tr), coax_p_wg_mul_f3f3(cx, l_light, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), l_tr)));
  l_col = coax_p_wg_add_f3f3(cx, l_col, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.f0a3d8p-1f, 0x1.b33334p-1f), l_key), ((coax_p_eg_water_motes(cx, l_o, l_d, coax_p_fmin(cx, l_path, 0x1.800000p2f)) * 0x1.333334p-1f) + coax_p_eg_water_shafts(cx, l_o, l_d, l_path, l_level))));
  return l_col;
}
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b) {
  float l_r = p_r;
  float l_g = p_g;
  float l_b = p_b;
  return (((0x1.b367a0p-3f * l_r) + (0x1.6e2eb2p-1f * l_g)) + (0x1.27bb30p-4f * l_b));
}
float coax_p_verse_style_bloom_share(CoaxResources cx, float p_lum, float p_threshold, float p_knee) {
  float l_lum = p_lum;
  float l_threshold = p_threshold;
  float l_knee = p_knee;
  float l_k{};
  float l_q{};
  if ((l_lum <= 0.0f))
  {
    return 0.0f;
  }
  l_k = coax_p_st_max(cx, l_knee, 0x1.4f8b58p-17f);
  l_q = coax_p_st_min(cx, coax_p_st_max(cx, ((l_lum - l_threshold) + l_k), 0.0f), (0x1.000000p1f * l_k));
  return coax_p_st_min(cx, (coax_p_st_max(cx, ((l_q * l_q) / (0x1.000000p2f * l_k)), (l_lum - l_threshold)) / l_lum), 0x1.000000p0f);
}
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_verse_style_shaft_source(CoaxResources cx, float p_cos_t) {
  float l_cos_t = p_cos_t;
  return exp(((-0x1.800000p4f) * coax_p_st_max(cx, (0x1.000000p0f - l_cos_t), 0.0f)));
}
coax_t12 coax_p_eg_unview(CoaxResources cx) {
  coax_t12 l_m{};
  float l_a00{};
  float l_a01{};
  float l_a02{};
  float l_a03{};
  float l_a10{};
  float l_a11{};
  float l_a12{};
  float l_a13{};
  float l_a20{};
  float l_a21{};
  float l_a22{};
  float l_a23{};
  float l_a30{};
  float l_a31{};
  float l_a32{};
  float l_a33{};
  float l_b00{};
  float l_b01{};
  float l_b02{};
  float l_b03{};
  float l_b04{};
  float l_b05{};
  float l_b06{};
  float l_b07{};
  float l_b08{};
  float l_b09{};
  float l_b10{};
  float l_b11{};
  float l_det{};
  float l_k{};
  l_m = coax_p_wg_transpose(cx, coax_t12{coax_p_wg_at4(cx, 8), coax_p_wg_at4(cx, 12), coax_p_wg_at4(cx, 16), coax_p_wg_at4(cx, 20)});
  l_a00 = l_m.x.x;
  l_a01 = l_m.x.y;
  l_a02 = l_m.x.z;
  l_a03 = l_m.x.w;
  l_a10 = l_m.y.x;
  l_a11 = l_m.y.y;
  l_a12 = l_m.y.z;
  l_a13 = l_m.y.w;
  l_a20 = l_m.z.x;
  l_a21 = l_m.z.y;
  l_a22 = l_m.z.z;
  l_a23 = l_m.z.w;
  l_a30 = l_m.w.x;
  l_a31 = l_m.w.y;
  l_a32 = l_m.w.z;
  l_a33 = l_m.w.w;
  l_b00 = ((l_a00 * l_a11) - (l_a01 * l_a10));
  l_b01 = ((l_a00 * l_a12) - (l_a02 * l_a10));
  l_b02 = ((l_a00 * l_a13) - (l_a03 * l_a10));
  l_b03 = ((l_a01 * l_a12) - (l_a02 * l_a11));
  l_b04 = ((l_a01 * l_a13) - (l_a03 * l_a11));
  l_b05 = ((l_a02 * l_a13) - (l_a03 * l_a12));
  l_b06 = ((l_a20 * l_a31) - (l_a21 * l_a30));
  l_b07 = ((l_a20 * l_a32) - (l_a22 * l_a30));
  l_b08 = ((l_a20 * l_a33) - (l_a23 * l_a30));
  l_b09 = ((l_a21 * l_a32) - (l_a22 * l_a31));
  l_b10 = ((l_a21 * l_a33) - (l_a23 * l_a31));
  l_b11 = ((l_a22 * l_a33) - (l_a23 * l_a32));
  l_det = ((((((l_b00 * l_b11) - (l_b01 * l_b10)) + (l_b02 * l_b09)) + (l_b03 * l_b08)) - (l_b04 * l_b07)) + (l_b05 * l_b06));
  l_k = (0x1.000000p0f / ((abs(l_det) < 0x1.197998p-40f) ? 0x1.12e0bep-30f : l_det));
  return coax_t12{coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a11 * l_b11) - (l_a12 * l_b10)) + (l_a13 * l_b09)), (((l_a02 * l_b10) - (l_a01 * l_b11)) - (l_a03 * l_b09)), (((l_a31 * l_b05) - (l_a32 * l_b04)) + (l_a33 * l_b03)), (((l_a22 * l_b04) - (l_a21 * l_b05)) - (l_a23 * l_b03))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a12 * l_b08) - (l_a10 * l_b11)) - (l_a13 * l_b07)), (((l_a00 * l_b11) - (l_a02 * l_b08)) + (l_a03 * l_b07)), (((l_a32 * l_b02) - (l_a30 * l_b05)) - (l_a33 * l_b01)), (((l_a20 * l_b05) - (l_a22 * l_b02)) + (l_a23 * l_b01))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a10 * l_b10) - (l_a11 * l_b08)) + (l_a13 * l_b06)), (((l_a01 * l_b08) - (l_a00 * l_b10)) - (l_a03 * l_b06)), (((l_a30 * l_b04) - (l_a31 * l_b02)) + (l_a33 * l_b00)), (((l_a21 * l_b02) - (l_a20 * l_b04)) - (l_a23 * l_b00))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a11 * l_b07) - (l_a10 * l_b09)) - (l_a12 * l_b06)), (((l_a00 * l_b09) - (l_a01 * l_b07)) + (l_a02 * l_b06)), (((l_a31 * l_b01) - (l_a30 * l_b03)) - (l_a32 * l_b00)), (((l_a20 * l_b03) - (l_a21 * l_b01)) + (l_a22 * l_b00))), l_k)};
}
float4 coax_p_m4_apply(CoaxResources cx, coax_t12 p_m, float4 p_v) {
  coax_t12 l_m = p_m;
  float4 l_v = p_v;
  return coax_p_add4(cx, coax_p_add4(cx, coax_p_scale4(cx, l_m.x, l_v.x), coax_p_scale4(cx, l_m.y, l_v.y)), coax_p_add4(cx, coax_p_scale4(cx, l_m.z, l_v.z), coax_p_scale4(cx, l_m.w, l_v.w)));
}
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x / l_b), (l_a.y / l_b), (l_a.z / l_b));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up) {
  float l_up = p_up;
  return coax_metal_pow(coax_p_st_max(cx, l_up, 0x1.0c6f7ap-20f), 0x1.19999ap-1f);
}
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_mix(cx, l_p0.x, l_p1.x, l_p2), coax_p_mix(cx, l_p0.y, l_p1.y, l_p2), coax_p_mix(cx, l_p0.z, l_p1.z, l_p2));
}
float coax_p_eg_saturation(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  float l_hi{};
  l_hi = coax_p_fmax(cx, l_c.x, coax_p_fmax(cx, l_c.y, l_c.z));
  return ((l_hi - coax_p_fmin(cx, l_c.x, coax_p_fmin(cx, l_c.y, l_c.z))) / coax_p_fmax(cx, l_hi, 0x1.a36e2ep-14f));
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
float coax_p_verse_style_chroma_gain(CoaxResources cx, float p_have, float p_albedo, float p_keep) {
  float l_have = p_have;
  float l_albedo = p_albedo;
  float l_keep = p_keep;
  if ((l_have < 0x1.a36e2ep-14f))
  {
    return 0x1.000000p0f;
  }
  return coax_p_st_min(cx, 0x1.400000p1f, coax_p_st_max(cx, 0x1.000000p0f, ((l_albedo * l_keep) / l_have)));
}
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_p_fmax(cx, l_p0.x, l_p1.x), coax_p_fmax(cx, l_p0.y, l_p1.y), coax_p_fmax(cx, l_p0.z, l_p1.z));
}
float coax_p_verse_style_sky_band(CoaxResources cx, float p_up, float p_lift) {
  float l_up = p_up;
  float l_lift = p_lift;
  return (l_lift * (0x1.000000p0f - coax_p_st_sat(cx, (abs(l_up) / 0x1.ac0832p-4f))));
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k) {
  float l_cos_t = p_cos_t;
  float l_k = p_k;
  return exp(((-l_k) * coax_p_st_max(cx, (0x1.000000p0f - l_cos_t), 0.0f)));
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x / l_b), (l_a.y / l_b));
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float2 coax_p_wg_sw_xy_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.x, l_p.y);
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_verse_style_cloud_field(CoaxResources cx, float p_x, float p_z, float p_s1, float p_s2, float p_octaves) {
  float l_x = p_x;
  float l_z = p_z;
  float l_s1 = p_s1;
  float l_s2 = p_s2;
  float l_octaves = p_octaves;
  float l_n{};
  l_n = coax_p_verse_style_noise(cx, (l_x * l_s1), (l_z * l_s1));
  if ((l_octaves < 0x1.800000p0f))
  {
    return l_n;
  }
  return ((l_n * 0x1.4cccccp-1f) + (coax_p_verse_style_noise(cx, ((l_x * l_s2) + 0x1.8cccccp1f), ((l_z * l_s2) + 0x1.ecccccp2f)) * 0x1.666666p-2f));
}
float coax_p_verse_style_cloud_cover(CoaxResources cx, float p_n, float p_cover, float p_cut_lo, float p_cut_hi) {
  float l_n = p_n;
  float l_cover = p_cover;
  float l_cut_lo = p_cut_lo;
  float l_cut_hi = p_cut_hi;
  return (coax_p_verse_style_soft_step(cx, ((l_cut_lo + l_cut_hi) * 0x1.000000p-1f), ((l_cut_hi - l_cut_lo) * 0x1.000000p-1f), (l_n + ((l_cover - 0x1.666666p-2f) * 0x1.99999ap-2f))) * coax_p_verse_style_soft_step(cx, 0x1.99999ap-6f, 0x1.99999ap-6f, l_cover));
}
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return coax_p_scale2(cx, l_a, (0x1.000000p0f / coax_p_wg_length2(cx, l_a)));
}
float coax_p_verse_style_cloud_lit(CoaxResources cx, float p_n, float p_toward) {
  float l_n = p_n;
  float l_toward = p_toward;
  return coax_p_st_sat(cx, (((l_n - l_toward) * 0x1.400000p2f) + 0x1.19999ap-1f));
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_verse_style_cloud_fade(CoaxResources cx, float p_up) {
  float l_up = p_up;
  return (coax_p_verse_style_soft_step(cx, 0x1.5c28f6p-4f, 0x1.333334p-4f, l_up) * 0x1.d70a3ep-1f);
}
float coax_p_eg_stars(CoaxResources cx, float3 p_d) {
  float3 l_d = p_d;
  float2 l_q{};
  float2 l_g{};
  float l_h{};
  float2 l_at{};
  if ((l_d.y <= 0.0f))
  {
    return 0.0f;
  }
  l_q = coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_d.x, l_d.z), (l_d.y + 0x1.666666p-2f)), 0x1.040000p8f);
  l_g = coax_p_wg_floor_f2(cx, l_q);
  l_h = coax_p_eg_hash2(cx, l_g);
  if ((l_h < 0x1.dc28f6p-1f))
  {
    return 0.0f;
  }
  l_at = coax_p_wg_add_f2f(cx, coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, coax_p_eg_hash2(cx, coax_p_wg_add_f2f(cx, l_g, 0x1.b33334p0f)), coax_p_eg_hash2(cx, coax_p_wg_add_f2f(cx, l_g, 0x1.233334p3f))), 0x1.99999ap-1f)), 0x1.99999ap-4f);
  return (((l_h > 0x1.fbe76cp-1f) ? 0x1.800000p-1f : 0x1.47ae14p-2f) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.eb851ep-4f, 0x1.ae147ap-2f, coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_q, l_at)))));
}
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0) {
  float l_p0 = p_p0;
  return coax_p_v3(cx, l_p0, l_p0, l_p0);
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x) {
  float l_y = p_y;
  float l_x = p_x;
  float l_ax{};
  float l_ay{};
  float l_high{};
  float l_r{};
  l_ax = abs(l_x);
  l_ay = abs(l_y);
  l_high = coax_p_fmax(cx, l_ax, l_ay);
  if ((l_high == 0.0f))
  {
    return 0.0f;
  }
  l_r = coax_p_wg_atan01(cx, (coax_p_fmin(cx, l_ax, l_ay) / l_high));
  if ((l_ay > l_ax))
  {
    l_r = ((0x1.921fb6p1f * 0x1.000000p-1f) - l_r);
  }
  if ((l_x < 0.0f))
  {
    l_r = (0x1.921fb6p1f - l_r);
  }
  if ((l_y < 0.0f))
  {
    l_r = (-l_r);
  }
  return l_r;
}
float4 coax_p_eg_ridge_ring(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  array<float4, 3> l_r{};
  l_r = array<float4, 3>{coax_p_v4(cx, 0x1.400000p7f, 0x1.a00000p4f, 0x1.800000p1f, 0x1.c00000p2f), coax_p_v4(cx, 0x1.040000p8f, 0x1.200000p6f, 0x1.000000p1f, 0.0f), coax_p_v4(cx, 0x1.a40000p8f, 0x1.180000p7f, 0x1.4cccccp0f, 0.0f)};
  return l_r[int(l_i)];
}
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_eg_noise(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float2 l_i{};
  float2 l_f{};
  float2 l_s{};
  l_i = coax_p_wg_floor_f2(cx, l_p);
  l_f = coax_p_wg_fract_f2(cx, l_p);
  l_s = coax_p_wg_mul_f2f2(cx, coax_p_wg_mul_f2f2(cx, l_f, l_f), coax_p_wg_sub_ff2(cx, 0x1.800000p1f, coax_p_wg_mul_ff2(cx, 0x1.000000p1f, l_f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_hash(cx, l_i), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0.0f))), l_s.x), coax_p_mix(cx, coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0.0f, 0x1.000000p0f))), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f))), l_s.x), l_s.y);
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
float coax_p_eg_hash2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_stepf(CoaxResources cx, float p_edge, float p_x) {
  float l_edge = p_edge;
  float l_x = p_x;
  if ((l_x < l_edge))
  {
    return 0.0f;
  }
  return 0x1.000000p0f;
}
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale) {
  float l_ny = p_ny;
  float l_sky = p_sky;
  float l_ground = p_ground;
  float l_scale = p_scale;
  return ((l_ground + ((l_sky - l_ground) * coax_p_st_sat(cx, ((l_ny * 0x1.000000p-1f) + 0x1.000000p-1f)))) * l_scale);
}
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b.x), (l_a.y * l_b.y), (l_a.z * l_b.z));
}
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y) {
  float l_d = p_d;
  float l_y = p_y;
  return coax_p_verse_style_haze(cx, l_d, l_y, (cx.r_u[25] - 0x1.400000p1f), cx.r_u[31], cx.r_u[27], (coax_p_eg_st(cx, 9u)).z, (coax_p_eg_st(cx, 9u)).w);
}
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v) {
  float l_f = p_f;
  float3 l_v = p_v;
  float3 l_hz{};
  float l_cap{};
  float3 l_h{};
  float3 l_green{};
  float l_level{};
  float l_glow{};
  l_hz = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u));
  l_cap = (coax_p_eg_st(cx, 9u)).z;
  l_h = coax_p_v3(cx, coax_p_verse_style_haze_hue(cx, l_hz.x, 0.0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.y, 0x1.000000p0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.z, 0x1.000000p1f, l_f, l_cap));
  l_green = coax_p_wg_div_f3f(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_wg_dot3(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_v3(cx, 0x1.554c98p-2f, 0x1.554c98p-2f, 0x1.554c98p-2f)));
  l_level = (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.666666p-2f, abs(l_v.y)));
  l_h = coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_mul_f3f3(cx, l_h, l_green), ((0x1.851eb8p-2f * l_level) * (0x1.000000p0f - (coax_p_eg_st(cx, 14u)).w)));
  l_glow = coax_p_verse_style_haze_glow(cx, coax_p_wg_dot3(cx, l_v, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u))));
  if (((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f))
  {
    return coax_p_wg_add_f3f3(cx, l_h, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (((coax_p_eg_st(cx, 0u)).w * l_glow) * 0x1.000000p-1f)));
  }
  return coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u)), l_glow);
}
bool coax_p_eg_weather_desktop(CoaxResources cx) {
  return (cx.r_u[1068] >= 0x1.000000p3f);
}
float coax_p_wg_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_wg_exp2(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return exp((l_x * 0x1.62e430p-1f));
}
bool coax_p_eg_weather_covered(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  uint l_n{};
  uint l_i{};
  float4 l_b{};
  if (((coax_p_wg_all_ge_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_wg_sw_xy_f4(cx, coax_p_EG_RAIN_BRIDGE(cx))) && coax_p_wg_all_le_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_wg_sw_zw_f4(cx, coax_p_EG_RAIN_BRIDGE(cx)))) && (l_p.y < cx.r_u[1482])))
  {
    return true;
  }
  l_n = coax_p_wg_u32_f(cx, cx.r_u[1483]);
  {
    l_i = 0u;
    while ((l_i < 32u))
    {
      if ((l_i >= l_n))
      {
        break;
      }
      l_b = coax_p_wg_at4(cx, ((int(l_i) * 4) + 1212));
      if ((coax_p_wg_all_ge_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_v2(cx, l_b.x, l_b.y)) && coax_p_wg_all_le_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_v2(cx, l_b.z, l_b.w))))
      {
        return true;
      }
      l_i = (l_i + 1u);
    }
  }
  return false;
}
float coax_p_wg_round(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_r{};
  l_r = floor((l_x + 0x1.000000p-1f));
  if ((((l_r - l_x) == 0x1.000000p-1f) && (coax_p_wg_fmod(cx, l_r, 0x1.000000p1f) != 0.0f)))
  {
    return (l_r - 0x1.000000p0f);
  }
  return l_r;
}
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, floor(l_p0.x), floor(l_p0.y));
}
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y));
}
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b), (l_a.y + l_b));
}
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d) {
  float3 l_d = p_d;
  return ((coax_p_eg_water_eye_over(cx) + (0x1.99999ap-4f * l_d.y)) < 0.0f);
}
float coax_p_eg_water_eye_over(CoaxResources cx) {
  return ((cx.r_u[1072] >= 0x1.000000p1f) ? cx.r_u[1071] : 0x1.900000p6f);
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float3 coax_p_EG_WATER_UNDER_ABSORB(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.ae147ap-2f, 0x1.eb851ep-4f, 0x1.70a3d8p-4f);
}
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_v3(cx, (-l_a.x), (-l_a.y), (-l_a.z));
}
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, exp(l_p0.x), exp(l_p0.y), exp(l_p0.z));
}
float3 coax_p_EG_WATER_UNDER_SCATTER(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.99999ap-5f, 0x1.333334p-2f, 0x1.51eb86p-2f);
}
float3 coax_p_EG_WATER_UNDER_TINT(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.0a3d70p-1f, 0x1.ae147ap-1f, 0x1.e66666p-1f);
}
float coax_p_eg_water_motes(CoaxResources cx, float3 p_o, float3 p_d, float p_reach) {
  float3 l_o = p_o;
  float3 l_d = p_d;
  float l_reach = p_reach;
  float l_a{};
  int l_n{};
  int l_i{};
  float l_t{};
  float3 l_c{};
  float4 l_h{};
  float3 l_drift{};
  float3 l_m{};
  float l_along{};
  float l_off{};
  float l_size{};
  l_a = 0.0f;
  l_n = ((cx.r_u[1068] < 0x1.000000p3f) ? 3 : 6);
  {
    l_i = 0;
    while ((l_i < l_n))
    {
      l_t = (((float(l_i) + 0x1.000000p-1f) * l_reach) / float(l_n));
      l_c = coax_p_wg_floor_f3(cx, coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_t)));
      l_h = coax_p_eg_water_mote_hash(cx, l_c);
      if ((l_h.w > 0x1.000000p-2f))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_drift = coax_p_wg_mul_f3f(cx, coax_p_v3(cx, sin(((cx.r_u[1048] * 0x1.333334p-2f) + (l_h.x * 0x1.800000p2f))), cos(((cx.r_u[1048] * 0x1.d70a3ep-3f) + (l_h.y * 0x1.800000p2f))), 0.0f), 0x1.47ae14p-4f);
      l_m = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, l_h.x, l_h.y, l_h.z)), l_drift);
      l_along = coax_p_fmax(cx, coax_p_wg_dot3(cx, coax_p_wg_sub_f3f3(cx, l_m, l_o), l_d), 0x1.99999ap-5f);
      if ((l_along > l_reach))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_off = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, l_m, coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_along))));
      l_size = ((0x1.89374cp-7f * l_along) + 0x1.0624dep-8f);
      l_a = (l_a + (((0x1.000000p0f - coax_p_smoothstep(cx, (l_size * 0x1.99999ap-2f), l_size, l_off)) * 0x1.000000p-1f) * exp(((-l_along) * 0x1.000000p-2f))));
      l_i = (l_i + 1);
    }
  }
  return l_a;
}
float coax_p_eg_water_shafts(CoaxResources cx, float3 p_o, float3 p_d, float p_path, float p_level) {
  float3 l_o = p_o;
  float3 l_d = p_d;
  float l_path = p_path;
  float l_level = p_level;
  float l_sum{};
  float l_reach{};
  int l_i{};
  float l_t{};
  float3 l_q{};
  float l_below{};
  if ((cx.r_u[1068] < 0x1.000000p3f))
  {
    return 0.0f;
  }
  l_sum = 0.0f;
  l_reach = coax_p_fmin(cx, l_path, 0x1.000000p3f);
  {
    l_i = 0;
    while ((l_i < 16))
    {
      l_t = (((float(l_i) + 0x1.000000p-1f) / 0x1.000000p4f) * l_reach);
      l_q = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_t));
      l_below = coax_p_fmax(cx, (l_level - l_q.y), 0.0f);
      l_sum = (l_sum + (coax_p_eg_water_caustic_pattern(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_q.x, l_q.z), coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_sw_xz_f4(cx, coax_p_eg_st(cx, 1u)), l_below), 0x1.333334p-1f)), cx.r_u[1048]) * exp((((-l_below) * 0x1.000000p-1f) - (l_t * 0x1.333334p-2f)))));
      l_i = (l_i + 1);
    }
  }
  return (((l_sum / 0x1.000000p4f) * l_reach) * 0x1.666666p-2f);
}
float coax_p_st_max(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a > l_b))
  {
    return l_a;
  }
  return l_b;
}
float coax_p_st_min(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a < l_b))
  {
    return l_a;
  }
  return l_b;
}
coax_t12 coax_p_wg_transpose(CoaxResources cx, coax_t12 p_m) {
  coax_t12 l_m = p_m;
  return coax_t12{coax_p_v4(cx, l_m.x.x, l_m.y.x, l_m.z.x, l_m.w.x), coax_p_v4(cx, l_m.x.y, l_m.y.y, l_m.z.y, l_m.w.y), coax_p_v4(cx, l_m.x.z, l_m.y.z, l_m.z.z, l_m.w.z), coax_p_v4(cx, l_m.x.w, l_m.y.w, l_m.z.w, l_m.w.w)};
}
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b) {
  float4 l_a = p_a;
  float l_b = p_b;
  return coax_p_v4(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b), (l_a.w * l_b));
}
float4 coax_p_scale4(CoaxResources cx, float4 p_a, float p_k) {
  float4 l_a = p_a;
  float l_k = p_k;
  return float4((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k), (l_a.w * l_k));
}
float4 coax_p_add4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return float4((l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z), (l_a.w + l_b.w));
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
float coax_p_st_sat(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_st_min(cx, 0x1.000000p0f, coax_p_st_max(cx, 0.0f, l_x));
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  float l_ix{};
  float l_iy{};
  float l_fx{};
  float l_fy{};
  float l_sx{};
  float l_sy{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  l_ix = floor(l_x);
  l_iy = floor(l_y);
  l_fx = (l_x - l_ix);
  l_fy = (l_y - l_iy);
  l_sx = ((l_fx * l_fx) * (0x1.800000p1f - (0x1.000000p1f * l_fx)));
  l_sy = ((l_fy * l_fy) * (0x1.800000p1f - (0x1.000000p1f * l_fy)));
  l_a = coax_p_verse_style_hash(cx, l_ix, l_iy);
  l_b = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), l_iy);
  l_c = coax_p_verse_style_hash(cx, l_ix, (l_iy + 0x1.000000p0f));
  l_d = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), (l_iy + 0x1.000000p0f));
  return ((l_a + ((l_b - l_a) * l_sx)) + (((l_c + ((l_d - l_c) * l_sx)) - (l_a + ((l_b - l_a) * l_sx))) * l_sy));
}
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x) {
  float l_e = p_e;
  float l_s = p_s;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_st_sat(cx, ((l_x - (l_e - l_s)) / coax_p_st_max(cx, (0x1.000000p1f * l_s), 0x1.0c6f7ap-20f)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k) {
  float2 l_a = p_a;
  float l_k = p_k;
  return float2((l_a.x * l_k), (l_a.y * l_k));
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
float coax_p_wg_atan01(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_z{};
  float l_p{};
  l_z = (l_x * l_x);
  l_p = (-0x1.09afcep-8f);
  l_p = ((l_p * l_z) + 0x1.662ca4p-6f);
  l_p = ((l_p * l_z) - 0x1.ca0388p-5f);
  l_p = ((l_p * l_z) + 0x1.8aefbep-4f);
  l_p = ((l_p * l_z) - 0x1.1cd8c6p-3f);
  l_p = ((l_p * l_z) + 0x1.98814cp-3f);
  l_p = ((l_p * l_z) - 0x1.554c38p-2f);
  l_p = ((l_p * l_z) + 0x1.ffffeap-1f);
  return (l_x * l_p);
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a * l_b.x), (l_a * l_b.y));
}
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a - l_b.x), (l_a - l_b.y));
}
float coax_p_eg_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  if (((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix2(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y)));
}
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff) {
  float l_d = p_d;
  float l_y = p_y;
  float l_base_y = p_base_y;
  float l_start = p_start;
  float l_density = p_density;
  float l_cap = p_cap;
  float l_falloff = p_falloff;
  float l_dist{};
  float l_height{};
  l_dist = (0x1.000000p0f - exp(((-l_density) * coax_p_st_max(cx, (l_d - l_start), 0.0f))));
  l_height = exp(((-coax_p_st_max(cx, (l_y - l_base_y), 0.0f)) / coax_p_st_max(cx, l_falloff, 0x1.0624dep-10f)));
  return coax_p_st_min(cx, (l_dist * (0x1.000000p0f + ((l_height - 0x1.000000p0f) * 0x1.333334p-1f))), l_cap);
}
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap) {
  float l_h = p_h;
  float l_ch = p_ch;
  float l_f = p_f;
  float l_cap = p_cap;
  float l_t{};
  float l_far{};
  l_t = coax_p_verse_style_haze_teal(cx, l_ch);
  l_far = coax_p_verse_style_soft_step(cx, ((0x1.333334p-3f + l_cap) * 0x1.000000p-1f), ((l_cap - 0x1.333334p-3f) * 0x1.000000p-1f), l_f);
  return (l_h * (l_t + ((0x1.000000p0f - l_t) * l_far)));
}
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t) {
  float l_t = p_t;
  return coax_p_wg_mix_f3f3f(cx, coax_p_EG_MEADOW_COOL(cx), coax_p_EG_MEADOW_WARM(cx), l_t);
}
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl) {
  float l_vdl = p_vdl;
  float l_a{};
  float l_a2{};
  float l_a4{};
  l_a = coax_p_st_sat(cx, l_vdl);
  l_a2 = (l_a * l_a);
  l_a4 = (l_a2 * l_a2);
  return ((l_a4 * l_a4) * 0x1.ccccccp-2f);
}
float4 coax_p_EG_RAIN_BRIDGE(CoaxResources cx) {
  return coax_p_v4(cx, 0x1.500000p6f, (-0x1.200000p4f), 0x1.700000p6f, (-0x1.400000p2f));
}
bool coax_p_wg_all_ge_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x >= l_b.x) && (l_a.y >= l_b.y));
}
float2 coax_p_wg_sw_zw_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.z, l_p.w);
}
bool coax_p_wg_all_le_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x <= l_b.x) && (l_a.y <= l_b.y));
}
uint coax_p_wg_u32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return uint(l_x);
}
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  return (l_a - (l_b * coax_p_wg_trunc(cx, (l_a / l_b))));
}
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, floor(l_p0.x), floor(l_p0.y), floor(l_p0.z));
}
float4 coax_p_eg_water_mote_hash(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  float4 l_h{};
  l_h = coax_p_v4(cx, coax_p_eg_water_hash(cx, l_c), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.100000p4f, 0x1.800000p1f, 0x1.400000p2f))), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.c00000p2f, 0x1.d00000p4f, 0x1.600000p3f))), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.000000p1f, 0x1.a00000p3f, 0x1.f00000p4f))));
  return l_h;
}
float2 coax_p_wg_sw_xz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.x, l_p.z);
}
float coax_p_eg_water_caustic_pattern(CoaxResources cx, float2 p_p, float p_t) {
  float2 l_p = p_p;
  float l_t = p_t;
  float l_a{};
  float l_b{};
  float l_ra{};
  float l_rb{};
  l_a = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_p, 0x1.99999ap0f), (l_t * 0x1.ccccccp-2f)));
  l_b = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_p, 0x1.733334p1f), coax_p_v2(cx, 0x1.8cccccp1f, 0x1.ecccccp2f)), ((l_t * 0x1.333334p-1f) + 0x1.000000p2f)));
  l_ra = (0x1.000000p0f - abs(((0x1.000000p1f * l_a) - 0x1.000000p0f)));
  l_rb = (0x1.000000p0f - abs(((0x1.000000p1f * l_b) - 0x1.000000p0f)));
  return ((coax_metal_pow(l_ra, 0x1.c00000p2f) * 0x1.99999ap-1f) + (coax_metal_pow(l_rb, 0x1.c00000p2f) * 0x1.19999ap-1f));
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return coax_p_render_noise2(cx, l_x, l_y);
}
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return ((l_x >= (-0x1.fffffep127f)) && (l_x <= 0x1.fffffep127f));
}
uint coax_p_render_noise_cell(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_bounded{};
  l_bounded = coax_p_fmin(cx, coax_p_fmax(cx, l_x, (-0x1.000000p25f)), 0x1.fffffep24f);
  return uint(int(floor((l_bounded * 0x1.000000p6f))));
}
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_p_render_noise_permute(cx, ((l_x * 1597334677u) ^ (l_y * 3812015801u)));
}
float coax_p_render_noise_unit(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  return (float((l_word >> uint(8u))) * 0x1.000000p-24f);
}
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch) {
  float l_ch = p_ch;
  if ((l_ch < 0x1.000000p-1f))
  {
    return 0x1.666666p-1f;
  }
  if ((l_ch < 0x1.800000p0f))
  {
    return 0x1.000000p0f;
  }
  return 0x1.ae147ap-1f;
}
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.000000p-2f, 0x1.851eb8p-2f, 0x1.c28f5cp-3f);
}
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.a3d70ap-2f, 0x1.f5c290p-2f, 0x1.000000p-2f);
}
float coax_p_wg_trunc(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x < 0.0f))
  {
    return (-floor((-l_x)));
  }
  return floor(l_x);
}
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  coax_t14 l_v{};
  l_v = coax_p_wg_add_u3u(cx, coax_p_wg_mul_u3u(cx, coax_p_wg_bits_u3i3(cx, coax_p_wg_cvt_i3f3(cx, l_p)), 1664525u), 1013904223u);
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  l_v.y = (l_v.y + (l_v.z * l_v.x));
  l_v.z = (l_v.z + (l_v.x * l_v.y));
  l_v = coax_p_wg_xor_u3u3(cx, l_v, coax_p_wg_shr_u3u3(cx, l_v, coax_p_u3(cx, 16u, 16u, 16u)));
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  return (float((l_v.x >> uint(8u))) / 0x1.fffffep23f);
}
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1) {
  float2 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v3(cx, l_p0.x, l_p0.y, l_p1);
}
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  float3 l_i{};
  float3 l_f{};
  float3 l_s{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  float l_e{};
  float l_g{};
  float l_h{};
  float l_k{};
  l_i = coax_p_wg_floor_f3(cx, l_p);
  l_f = coax_p_wg_fract_f3(cx, l_p);
  l_s = coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_f, l_f), coax_p_wg_sub_ff3(cx, 0x1.800000p1f, coax_p_wg_mul_ff3(cx, 0x1.000000p1f, l_f)));
  l_a = coax_p_eg_water_hash(cx, l_i);
  l_b = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f)));
  l_c = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f)));
  l_d = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0.0f)));
  l_e = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f)));
  l_g = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0x1.000000p0f)));
  l_h = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0x1.000000p0f)));
  l_k = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_mix(cx, l_a, l_b, l_s.x), coax_p_mix(cx, l_c, l_d, l_s.x), l_s.y), coax_p_mix(cx, coax_p_mix(cx, l_e, l_g, l_s.x), coax_p_mix(cx, l_h, l_k, l_s.x), l_s.y), l_s.z);
}
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  uint l_h{};
  l_h = (l_word * 747796405u);
  l_h = ((l_h ^ (l_h >> uint(16u))) * 2246822519u);
  return (l_h ^ (l_h >> uint(13u)));
}
coax_t15 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  return coax_p_i3(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y), coax_p_wg_i32_f(cx, l_p.z));
}
coax_t14 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t15 p_p) {
  coax_t15 l_p = p_p;
  return coax_p_u3(cx, uint(l_p.x), uint(l_p.y), uint(l_p.z));
}
coax_t14 coax_p_wg_mul_u3u(CoaxResources cx, coax_t14 p_a, uint p_b) {
  coax_t14 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
coax_t14 coax_p_wg_add_u3u(CoaxResources cx, coax_t14 p_a, uint p_b) {
  coax_t14 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x + l_b), (l_a.y + l_b), (l_a.z + l_b));
}
coax_t14 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z) {
  uint l_x = p_x;
  uint l_y = p_y;
  uint l_z = p_z;
  return coax_t14{l_x, l_y, l_z};
}
coax_t14 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t14 p_a, coax_t14 p_b) {
  coax_t14 l_a = p_a;
  coax_t14 l_b = p_b;
  return coax_p_u3(cx, (l_a.x >> uint(l_b.x)), (l_a.y >> uint(l_b.y)), (l_a.z >> uint(l_b.z)));
}
coax_t14 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t14 p_a, coax_t14 p_b) {
  coax_t14 l_a = p_a;
  coax_t14 l_b = p_b;
  return coax_p_u3(cx, (l_a.x ^ l_b.x), (l_a.y ^ l_b.y), (l_a.z ^ l_b.z));
}
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y), coax_p_fract(cx, l_p0.z));
}
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a * l_b.x), (l_a * l_b.y), (l_a * l_b.z));
}
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a - l_b.x), (l_a - l_b.y), (l_a - l_b.z));
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
coax_t15 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z) {
  int l_x = p_x;
  int l_y = p_y;
  int l_z = p_z;
  return coax_t15{l_x, l_y, l_z};
}
vertex float4 eg_bg_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_bg_vs(cx, coax_vid, coax_iid);
  return coax_r;
}
fragment coax_out_11 eg_bg_fs(float4 coax_pos [[position]], CoaxResources cx) {
  auto coax_r = coax_p_eg_bg_fs(cx, coax_pos);
  return coax_out_11{coax_r.x, coax_r.y};
}
