// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t13 {
  uint x;
  uint y;
};
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  texture2d<float> r_bloom_src [[texture(0)]];
  sampler r_bloom_lin [[sampler(0)]];
  device const float* r_bloom_step [[buffer(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1);
float4 coax_p_eg_bloom_fs(CoaxResources cx, float4 p_pos);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
coax_t13 coax_p_wg_dims_2d(CoaxResources cx);
float2 coax_p_wg_cvt_f2u2(CoaxResources cx, coax_t13 p_p);
float2 coax_p_wg_div_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float2 coax_p_wg_sub_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
coax_t13 coax_p_u2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1) {
  uint l_i = p_i;
  uint l__iid1 = p__iid1;
  array<float2, 3> l_p{};
  l_p = array<float2, 3>{coax_p_v2(cx, (-0x1.000000p0f), (-0x1.800000p1f)), coax_p_v2(cx, (-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(cx, 0x1.800000p1f, 0x1.000000p0f)};
  return coax_p_v4(cx, l_p[int(l_i)].x, l_p[int(l_i)].y, 0.0f, 0x1.000000p0f);
}
float4 coax_p_eg_bloom_fs(CoaxResources cx, float4 p_pos) {
  float4 l_pos = p_pos;
  float2 l_texel_2{};
  float2 l_uv{};
  float3 l_c{};
  int l_k{};
  float4 l_t{};
  float2 l_d{};
  float3 l_c_10{};
  l_texel_2 = coax_p_wg_div_ff2(cx, 0x1.000000p0f, coax_p_wg_cvt_f2u2(cx, coax_p_wg_dims_2d(cx)));
  l_uv = coax_p_wg_mul_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_pos.x, l_pos.y), cx.r_bloom_step[3]), l_texel_2);
  if ((cx.r_bloom_step[2] < 0x1.000000p-1f))
  {
    l_c = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
    {
      l_k = 0;
      while ((l_k < 4))
      {
        l_t = (cx.r_bloom_src).sample(cx.r_bloom_lin, coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f2(cx, coax_p_wg_sub_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, float((l_k & 1)), float((l_k >> uint(1)))), 0x1.000000p1f), 0x1.000000p0f), l_texel_2)), level(0.0f));
        l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_t.x, l_t.y, l_t.z), coax_p_clampf(cx, l_t.w, 0.0f, 0x1.000000p0f)));
        l_k = (l_k + 1);
      }
    }
    return coax_p_wg_make_f4_f3f(cx, coax_p_wg_mul_f3f(cx, l_c, 0x1.000000p-2f), 0x1.000000p0f);
  }
  l_d = coax_p_wg_mul_f2f2(cx, coax_p_v2(cx, cx.r_bloom_step[0], cx.r_bloom_step[1]), l_texel_2);
  l_c_10 = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_bloom_src).sample(cx.r_bloom_lin, l_uv, level(0.0f))), 0x1.d0e560p-3f);
  l_c_10 = coax_p_wg_add_f3f3(cx, l_c_10, coax_p_wg_mul_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_bloom_src).sample(cx.r_bloom_lin, coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, l_d, 0x1.628f5cp0f)), level(0.0f))), coax_p_wg_sw_rgb_f4(cx, (cx.r_bloom_src).sample(cx.r_bloom_lin, coax_p_wg_sub_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, l_d, 0x1.628f5cp0f)), level(0.0f)))), 0x1.439582p-2f));
  l_c_10 = coax_p_wg_add_f3f3(cx, l_c_10, coax_p_wg_mul_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_bloom_src).sample(cx.r_bloom_lin, coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, l_d, 0x1.9d9168p1f)), level(0.0f))), coax_p_wg_sw_rgb_f4(cx, (cx.r_bloom_src).sample(cx.r_bloom_lin, coax_p_wg_sub_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, l_d, 0x1.9d9168p1f)), level(0.0f)))), 0x1.1eb852p-4f));
  return coax_p_v4(cx, l_c_10.x, l_c_10.y, l_c_10.z, 0x1.000000p0f);
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
coax_t13 coax_p_wg_dims_2d(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_bloom_src).get_width(), (cx.r_bloom_src).get_height());
}
float2 coax_p_wg_cvt_f2u2(CoaxResources cx, coax_t13 p_p) {
  coax_t13 l_p = p_p;
  return coax_p_v2(cx, float(l_p.x), float(l_p.y));
}
float2 coax_p_wg_div_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a / l_b.x), (l_a / l_b.y));
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float2 coax_p_wg_sub_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b), (l_a.y - l_b));
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
coax_t13 coax_p_u2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_t13{l_x, l_y};
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
vertex float4 eg_bg_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_bg_vs(cx, coax_vid, coax_iid);
  return coax_r;
}
fragment float4 eg_bloom_fs(float4 coax_pos [[position]], CoaxResources cx) {
  auto coax_r = coax_p_eg_bloom_fs(cx, coax_pos);
  return coax_r;
}
