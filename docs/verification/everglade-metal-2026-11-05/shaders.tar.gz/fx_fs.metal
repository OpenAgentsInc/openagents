// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t7 {
  float4 x;
  float4 y;
  float4 z;
  float4 w;
};
struct coax_in_7 {
  float4 x [[attribute(0)]];
  float4 y [[attribute(1)]];
  float4 z [[attribute(2)]];
  float4 w [[attribute(3)]];
};
struct coax_t10 {
  float4 x;
  float2 y;
  float4 z;
  float4 w;
  float4 f4;
};
struct coax_io_10 {
  float4 x [[position]];
  float2 y [[user(locn0)]];
  float4 z [[user(locn1)]];
  float4 w [[user(locn2)]];
  float4 f4 [[user(locn3)]];
};
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
coax_t10 coax_p_eg_fx_vs(CoaxResources cx, uint p__vid4, uint p__iid5, coax_t7 p_in_);
float4 coax_p_eg_fx_fs(CoaxResources cx, coax_t10 p_v);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float coax_p_saturate(CoaxResources cx, float p_x);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
coax_t10 coax_p_eg_fx_vs(CoaxResources cx, uint p__vid4, uint p__iid5, coax_t7 p_in_) {
  uint l__vid4 = p__vid4;
  uint l__iid5 = p__iid5;
  coax_t7 l_in_ = p_in_;
  float4 l_a{};
  float4 l_b{};
  float4 l_c{};
  float4 l_d{};
  coax_t10 l_o{};
  l_a = l_in_.x;
  l_b = l_in_.y;
  l_c = l_in_.z;
  l_d = l_in_.w;
  l_o = coax_t10{};
  l_o.x = coax_p_v4(cx, (((l_a.x / cx.r_u[0]) * 0x1.000000p1f) - 0x1.000000p0f), (0x1.000000p0f - ((l_a.y / cx.r_u[1]) * 0x1.000000p1f)), 0.0f, 0x1.000000p0f);
  l_o.y = coax_p_v2(cx, l_a.z, l_a.w);
  l_o.z = l_b;
  l_o.w = l_c;
  l_o.f4 = l_d;
  return l_o;
}
float4 coax_p_eg_fx_fs(CoaxResources cx, coax_t10 p_v) {
  coax_t10 l_v = p_v;
  float l_along{};
  float l_d{};
  float l_core{};
  float l_g{};
  float l_halo{};
  l_along = coax_p_fmax(cx, coax_p_fmax(cx, (-l_v.y.x), (l_v.y.x - l_v.z.x)), 0.0f);
  l_d = coax_p_wg_length2(cx, coax_p_v2(cx, l_along, l_v.y.y));
  l_core = (0x1.000000p0f - coax_p_smoothstep(cx, (l_v.z.y - 0x1.000000p-1f), (l_v.z.y + 0x1.333334p-1f), l_d));
  l_g = (l_d / coax_p_fmax(cx, l_v.z.w, 0x1.000000p0f));
  l_halo = (exp((((-0x1.400000p2f) * l_g) * l_g)) * 0x1.1eb852p-2f);
  return coax_p_wg_make_f4_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_v.w.x, l_v.w.y, l_v.w.z), (l_core + l_halo)), l_v.z.z), cx.r_u[3]), 0x1.000000p0f);
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
vertex coax_io_10 eg_fx_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], coax_in_7 coax_in [[stage_in]], CoaxResources cx) {
  auto coax_r = coax_p_eg_fx_vs(cx, coax_vid, coax_iid, coax_t7{coax_in.x, coax_in.y, coax_in.z, coax_in.w});
  return coax_io_10{coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4};
}
fragment float4 eg_fx_fs(coax_io_10 coax_in [[stage_in]], CoaxResources cx) {
  auto coax_r = coax_p_eg_fx_fs(cx, coax_t10{coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4});
  return coax_r;
}
