// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t9 {
  float4 x;
  alignas(16) packed_float3 y;
  alignas(16) packed_float3 z;
  alignas(16) packed_float3 w;
  alignas(16) packed_float3 f4;
};
struct coax_io_9 {
  float4 x [[position]];
  float3 y [[user(locn0)]];
  float3 z [[user(locn1)]];
  float3 w [[user(locn2)]];
  float3 f4 [[user(locn3)]];
};
struct coax_t11 {
  alignas(16) packed_float3 x;
  float y;
  alignas(16) packed_float3 z;
  float w;
  float f4;
};
struct coax_t14 {
  float4 x;
  float4 y;
};
struct coax_out_14 {
  float4 x [[color(0)]];
  float4 y [[color(1)]];
};
struct coax_t15 {
  int x;
  int y;
};
struct coax_t16 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
  alignas(16) packed_float3 z;
  float w;
  float f4;
  float f5;
};
struct coax_t17 {
  uint x;
  uint y;
};
struct coax_t18 {
  alignas(16) packed_float3 x;
  float y;
  float z;
  float2 w;
  float f4;
};
struct coax_t20 {
  uint x;
  uint y;
  uint z;
};
struct coax_t21 {
  int x;
  int y;
  int z;
};
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  device const float* r_heights [[buffer(1)]];
  device const float* r_water_nodes [[buffer(2)]];
  depth2d<float> r_shadow_map [[texture(0)]];
  sampler r_shadow_cmp [[sampler(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
coax_t9 coax_p_eg_grass_vs(CoaxResources cx, uint p_v, uint p_i);
coax_t14 coax_p_eg_grass_fs(CoaxResources cx, coax_t9 p_g);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float4 coax_p_eg_st(CoaxResources cx, uint p_i);
uint coax_p_wg_u32_f(CoaxResources cx, float p_x);
uint coax_p_wg_max_u(CoaxResources cx, uint p_a, uint p_b);
float coax_p_verse_style_near_reach(CoaxResources cx, float p_on_phone);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_eg_hash(CoaxResources cx, float2 p_p);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
float coax_p_eg_ground_y(CoaxResources cx, float2 p_q);
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w);
coax_t11 coax_p_eg_ground_mark(CoaxResources cx, float2 p_q, float p_tip);
float coax_p_verse_style_blade_height(CoaxResources cx, float p_h, float p_low, float p_high);
float coax_p_verse_style_grass_fade(CoaxResources cx, float p_d, float p_radius, float p_fade);
float coax_p_eg_grass_mask(CoaxResources cx, float2 p_q);
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_verse_style_gust(CoaxResources cx, float p_x, float p_z, float p_t, float p_wx, float p_wz, float p_speed, float p_scale);
float coax_p_verse_style_wind(CoaxResources cx, float p_along, float p_gust, float p_t, float p_amp, float p_wavelength, float p_speed);
float coax_p_verse_style_bend(CoaxResources cx, float p_theta, float p_height, float p_share);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a);
float coax_p_verse_style_part(CoaxResources cx, float p_d, float p_radius);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float coax_p_verse_style_near_width(CoaxResources cx, float p_d, float p_reach);
float3 coax_p_eg_meadow(CoaxResources cx, float2 p_q);
float coax_p_verse_style_jitter(CoaxResources cx, float p_c, float p_ch, float p_h, float p_jitter);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_verse_style_tip(CoaxResources cx, float p_c, float p_ch, float p_lift);
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2);
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p);
float coax_p_verse_style_grass_tilt(CoaxResources cx, float p_theta, float p_amp, float p_tilt_most);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
float coax_p_eg_map_lit(CoaxResources cx, float3 p_p, float3 p_n, bool p_paint_leaf_far);
coax_t14 coax_p_eg_paint(CoaxResources cx, float3 p_dry, float3 p_n, float3 p_world, float p_lit, bool p_character, bool p_rim, bool p_paint_leaf_far);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y);
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b);
coax_t15 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p);
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0);
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
float coax_p_eg_noise(CoaxResources cx, float2 p_p);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b);
float coax_p_st_sat(CoaxResources cx, float p_x);
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x);
float coax_p_eg_path_near(CoaxResources cx, float2 p_p);
float coax_p_verse_style_grass_clear(CoaxResources cx, float p_past);
float coax_p_eg_water_over(CoaxResources cx, float2 p_xz);
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y);
float coax_p_st_max(CoaxResources cx, float p_a, float p_b);
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k);
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t);
float coax_p_st_min(CoaxResources cx, float p_a, float p_b);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
coax_t16 coax_p_eg_light_space(CoaxResources cx);
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t16 p_k);
coax_t17 coax_p_wg_dims_depth(CoaxResources cx);
float coax_p_verse_style_shadow_tap(CoaxResources cx, float p_k, float p_on_phone, float p_which);
bool coax_p_wg_all_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
bool coax_p_wg_all_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float3 coax_p_eg_weather_wet_base(CoaxResources cx, float3 p_base, float3 p_n, bool p_character);
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_verse_style_wrap(CoaxResources cx, float p_ndl);
float coax_p_verse_style_bands2(CoaxResources cx, float p_w, float p_e, float p_s);
float coax_p_verse_style_bands(CoaxResources cx, float p_w, float p_e0, float p_e1, float p_s, float p_mid);
float coax_p_wg_length3(CoaxResources cx, float3 p_a);
float coax_p_eg_sky_seen(CoaxResources cx, float3 p_world);
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale);
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b);
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_eg_banded(CoaxResources cx, float3 p_a, float3 p_dark, float3 p_bright, float p_band);
float3 coax_p_eg_lamp_light(CoaxResources cx, float3 p_p, float3 p_n);
float coax_p_eg_saturation(CoaxResources cx, float3 p_c);
float coax_p_verse_style_chroma_gain(CoaxResources cx, float p_have, float p_albedo, float p_keep);
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b);
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a);
float coax_p_verse_style_rim(CoaxResources cx, float p_ndv, float p_ndl, float p_start, float p_full, float p_strength);
float coax_p_eg_water_caustics(CoaxResources cx, float3 p_p, float3 p_n);
float3 coax_p_eg_weather_surface(CoaxResources cx, float3 p_c, float3 p_base, float3 p_n, float3 p_world, float3 p_v, float p_lit, bool p_character);
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y);
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v);
float3 coax_p_eg_weather_streaks(CoaxResources cx, float3 p_c, float3 p_v, float p_d);
float3 coax_p_eg_water_under_view(CoaxResources cx, float3 p_c, float3 p_world, float3 p_d);
float coax_p_verse_style_bloom_share(CoaxResources cx, float p_lum, float p_threshold, float p_knee);
float coax_p_verse_style_shaft_source(CoaxResources cx, float p_cos_t);
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x);
uint coax_p_render_noise_cell(CoaxResources cx, float p_x);
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_render_noise_unit(CoaxResources cx, uint p_word);
coax_t15 coax_p_i2(CoaxResources cx, int p_x, int p_y);
float coax_p_fract(CoaxResources cx, float p_x);
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b);
float coax_p_saturate(CoaxResources cx, float p_x);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float coax_p_eg_pond_depth_at(CoaxResources cx, float3 p_p);
float2 coax_p_eg_water_uv(CoaxResources cx, float2 p_xz);
coax_t18 coax_p_eg_water_rest(CoaxResources cx, float2 p_uv);
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y);
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx);
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone);
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size);
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach);
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach);
coax_t17 coax_p_u2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_eg_weather_wet_share(CoaxResources cx, float3 p_n, bool p_character);
float coax_p_verse_style_cool(CoaxResources cx, float p_c, float p_tint, float p_tint_lum, float p_amount);
float coax_p_verse_style_keep_value(CoaxResources cx, float p_c, float p_before, float p_after);
float coax_p_verse_style_banded(CoaxResources cx, float p_shadow_c, float p_lit_c, float p_band);
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b);
float coax_p_eg_water_depth_at(CoaxResources cx, float3 p_p);
float coax_p_eg_water_caustic_pattern(CoaxResources cx, float2 p_p, float p_t);
float3 coax_p_wg_reflect3(CoaxResources cx, float3 p_i, float3 p_n);
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1);
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p);
float2 coax_p_eg_weather_rain_slope(CoaxResources cx, float2 p_p);
float3 coax_p_eg_sky(CoaxResources cx, float3 p_d, float3 p_l);
float3 coax_p_eg_weather_sky(CoaxResources cx, float3 p_c, float3 p_d);
float3 coax_p_wg_min_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff);
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap);
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl);
bool coax_p_eg_weather_desktop(CoaxResources cx);
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x);
float coax_p_wg_exp2(CoaxResources cx, float p_x);
bool coax_p_eg_weather_covered(CoaxResources cx, float3 p_p);
float coax_p_wg_round(CoaxResources cx, float p_x);
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p);
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b);
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d);
float coax_p_eg_water_eye_over(CoaxResources cx);
float3 coax_p_EG_WATER_UNDER_ABSORB(CoaxResources cx);
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_EG_WATER_UNDER_SCATTER(CoaxResources cx);
float3 coax_p_EG_WATER_UNDER_TINT(CoaxResources cx);
float coax_p_eg_water_motes(CoaxResources cx, float3 p_o, float3 p_d, float p_reach);
float coax_p_eg_water_shafts(CoaxResources cx, float3 p_o, float3 p_d, float p_path, float p_level);
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word);
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b);
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b);
float4 coax_p_eg_pond_row(CoaxResources cx, uint p_p);
float2 coax_p_wg_clamp_f2f2f2(CoaxResources cx, float2 p_p0, float2 p_p1, float2 p_p2);
float coax_p_eg_water_node(CoaxResources cx, uint p_k, uint p_f);
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_eg_fountain_depth_at(CoaxResources cx, float3 p_p);
float3 coax_p_reflect3(CoaxResources cx, float3 p_i, float3 p_n);
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b);
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p);
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up);
float coax_p_verse_style_sky_band(CoaxResources cx, float p_up, float p_lift);
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k);
float2 coax_p_wg_sw_xy_f4(CoaxResources cx, float4 p_p);
float coax_p_verse_style_cloud_field(CoaxResources cx, float p_x, float p_z, float p_s1, float p_s2, float p_octaves);
float coax_p_verse_style_cloud_cover(CoaxResources cx, float p_n, float p_cover, float p_cut_lo, float p_cut_hi);
float coax_p_verse_style_cloud_lit(CoaxResources cx, float p_n, float p_toward);
float coax_p_verse_style_cloud_fade(CoaxResources cx, float p_up);
float coax_p_eg_stars(CoaxResources cx, float3 p_d);
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0);
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch);
float coax_p_wg_atan01(CoaxResources cx, float p_x);
float4 coax_p_EG_RAIN_BRIDGE(CoaxResources cx);
bool coax_p_wg_all_ge_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_sw_zw_f4(CoaxResources cx, float4 p_p);
bool coax_p_wg_all_le_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b);
float4 coax_p_eg_water_mote_hash(CoaxResources cx, float3 p_c);
float2 coax_p_wg_sw_xz_f4(CoaxResources cx, float4 p_p);
bool coax_p_eg_fountain_on(CoaxResources cx);
float coax_p_eg_fountain_base(CoaxResources cx);
float3 coax_p_sub3(CoaxResources cx, float3 p_a, float3 p_b);
coax_t21 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p);
coax_t20 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t21 p_p);
coax_t20 coax_p_wg_mul_u3u(CoaxResources cx, coax_t20 p_a, uint p_b);
coax_t20 coax_p_wg_add_u3u(CoaxResources cx, coax_t20 p_a, uint p_b);
coax_t20 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z);
coax_t20 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t20 p_a, coax_t20 p_b);
coax_t20 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t20 p_a, coax_t20 p_b);
float coax_p_eg_hash2(CoaxResources cx, float2 p_p);
float coax_p_wg_trunc(CoaxResources cx, float p_x);
coax_t21 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z);
coax_t9 coax_p_eg_grass_vs(CoaxResources cx, uint p_v, uint p_i) {
  uint l_v = p_v;
  uint l_i = p_i;
  coax_t9 l_o{};
  float4 l_g{};
  float4 l_g2{};
  float4 l_w{};
  float4 l_w2{};
  uint l_per{};
  float l_r{};
  uint l_side{};
  float l_reach{};
  uint l_far_n{};
  bool l_near{};
  uint l_nper{};
  uint l_nside{};
  uint l_j{};
  uint l_bper{};
  uint l_bside{};
  float l_half{};
  uint l_cell{};
  float l_b{};
  float2 l_c{};
  float2 l_k{};
  float2 l_q{};
  float2 l_rel{};
  float l_dist{};
  float4 l_root_clip{};
  coax_t11 l_mk{};
  float l_tall{};
  float l_t{};
  float2 l_wd{};
  float l_theta{};
  float2 l_lean{};
  int l_m{};
  float4 l_sh{};
  float2 l_away{};
  float l_ang{};
  float3 l_across{};
  float3 l_world{};
  float3 l_base{};
  float l_hj{};
  float3 l_a{};
  float3 l_l{};
  float2 l_lx{};
  float l_tilt{};
  l_o = coax_t9{};
  l_o.x = coax_p_v4(cx, 0.0f, 0.0f, (-0x1.000000p0f), 0x1.000000p0f);
  l_o.y = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_o.z = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
  l_o.w = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_o.f4 = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_g = coax_p_eg_st(cx, 22u);
  l_g2 = coax_p_eg_st(cx, 23u);
  l_w = coax_p_eg_st(cx, 24u);
  l_w2 = coax_p_eg_st(cx, 25u);
  l_per = coax_p_wg_max_u(cx, coax_p_wg_u32_f(cx, l_g.x), 1u);
  l_r = l_g.y;
  l_side = coax_p_wg_u32_f(cx, (0x1.000000p1f * l_r));
  l_reach = coax_p_verse_style_near_reach(cx, (coax_p_eg_st(cx, 31u)).z);
  l_far_n = ((l_per * l_side) * l_side);
  l_near = (l_i >= l_far_n);
  l_nper = coax_p_wg_max_u(cx, coax_p_wg_u32_f(cx, (coax_p_eg_st(cx, 26u)).w), 1u);
  l_nside = coax_p_wg_u32_f(cx, (0x1.000000p1f * l_reach));
  l_j = (l_near ? (l_i - l_far_n) : l_i);
  l_bper = (l_near ? l_nper : l_per);
  l_bside = (l_near ? l_nside : l_side);
  l_half = (l_near ? l_reach : l_r);
  l_cell = (l_j / l_bper);
  l_b = (float((l_j % l_bper)) + (l_near ? 0x1.940000p6f : 0.0f));
  l_c = coax_p_wg_add_f2f2(cx, coax_p_wg_sub_f2f2(cx, coax_p_wg_floor_f2(cx, coax_p_v2(cx, cx.r_u[24], cx.r_u[26])), coax_p_v2(cx, l_half, l_half)), coax_p_v2(cx, float((l_cell % l_bside)), float((l_cell / l_bside))));
  l_k = coax_p_wg_add_f2f2(cx, l_c, coax_p_v2(cx, (l_b * 0x1.c851ecp2f), (l_b * (-0x1.dae148p1f))));
  l_q = coax_p_wg_add_f2f2(cx, l_c, coax_p_v2(cx, coax_p_eg_hash(cx, l_k), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_k, coax_p_v2(cx, 0x1.31999ap4f, 0x1.ecccccp2f)))));
  l_rel = coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, cx.r_u[24], cx.r_u[26]));
  l_dist = coax_p_wg_length2(cx, l_rel);
  l_root_clip = coax_p_eg_clip(cx, coax_p_v3(cx, l_q.x, coax_p_eg_ground_y(cx, l_q), l_q.y));
  if (((l_root_clip.w < (-0x1.000000p0f)) || (abs(l_root_clip.x) > ((l_root_clip.w * 0x1.333334p0f) + 0x1.000000p0f))))
  {
    return l_o;
  }
  l_mk = coax_p_eg_ground_mark(cx, l_q, ((l_v == 2u) ? 0x1.000000p0f : 0.0f));
  l_tall = (((coax_p_verse_style_blade_height(cx, coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_k, coax_p_v2(cx, 0x1.a66666p1f, 0x1.4f3334p5f))), l_g.w, l_g2.x) * coax_p_verse_style_grass_fade(cx, l_dist, l_r, l_g.z)) * coax_p_eg_grass_mask(cx, l_q)) * (0x1.000000p0f - l_mk.w));
  if ((l_tall < 0x1.47ae14p-6f))
  {
    return l_o;
  }
  l_t = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
  l_wd = coax_p_v2(cx, l_w2.x, l_w2.y);
  l_theta = coax_p_verse_style_wind(cx, coax_p_wg_dot2(cx, l_q, l_wd), coax_p_verse_style_gust(cx, l_q.x, l_q.y, l_t, l_wd.x, l_wd.y, l_w.z, l_w.w), l_t, l_w.x, l_w.y, l_w.z);
  l_lean = coax_p_wg_mul_f2f(cx, l_wd, coax_p_verse_style_bend(cx, l_theta, l_tall, 0x1.000000p0f));
  {
    l_m = 0;
    while ((l_m < 8))
    {
      l_sh = coax_p_wg_at4(cx, ((int(l_m) * 4) + 36));
      if ((l_sh.z <= 0.0f))
      {
        break;
      }
      l_away = coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, l_sh.x, l_sh.y));
      l_lean = coax_p_wg_add_f2f2(cx, l_lean, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_normalize2(cx, coax_p_wg_add_f2f2(cx, l_away, coax_p_v2(cx, 0x1.a36e2ep-14f, 0x1.a36e2ep-14f))), l_tall), 0x1.b33334p-1f), coax_p_verse_style_part(cx, coax_p_wg_length2(cx, l_away), l_w2.w)));
      l_m = (l_m + 1);
    }
  }
  l_ang = (coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_k, coax_p_v2(cx, 0x1.79999ap2f, 0x1.a9999ap3f))) * 0x1.921fb6p2f);
  l_across = coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, cos(l_ang), 0.0f, sin(l_ang)), l_g2.y), 0x1.000000p-1f), coax_p_verse_style_near_width(cx, l_dist, l_reach));
  l_world = coax_p_v3(cx, l_q.x, coax_p_eg_ground_y(cx, l_q), l_q.y);
  l_base = coax_p_eg_meadow(cx, l_q);
  l_hj = coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_k, coax_p_v2(cx, 0x1.fb3334p4f, 0x1.733334p1f)));
  l_a = coax_p_v3(cx, coax_p_verse_style_jitter(cx, l_base.x, 0.0f, l_hj, l_g2.w), coax_p_verse_style_jitter(cx, l_base.y, 0x1.000000p0f, l_hj, l_g2.w), coax_p_verse_style_jitter(cx, l_base.z, 0x1.000000p1f, l_hj, l_g2.w));
  if ((l_v == 0u))
  {
    l_world = coax_p_wg_sub_f3f3(cx, l_world, l_across);
    l_o.w = coax_p_wg_mul_f3f(cx, l_a, 0x1.8f5c28p-1f);
  }
  else
  {
    if ((l_v == 1u))
    {
      l_world = coax_p_wg_add_f3f3(cx, l_world, l_across);
      l_o.w = coax_p_wg_mul_f3f(cx, l_a, 0x1.8f5c28p-1f);
    }
    else
    {
      l_world = coax_p_wg_add_f3f3(cx, l_world, coax_p_v3(cx, l_lean.x, sqrt(coax_p_fmax(cx, ((l_tall * l_tall) - coax_p_wg_dot2(cx, l_lean, l_lean)), ((l_tall * l_tall) * 0x1.333334p-3f))), l_lean.y));
      l_o.w = coax_p_v3(cx, coax_p_verse_style_tip(cx, l_a.x, 0.0f, l_g2.z), coax_p_verse_style_tip(cx, l_a.y, 0x1.000000p0f, l_g2.z), coax_p_verse_style_tip(cx, l_a.z, 0x1.000000p1f, l_g2.z));
    }
  }
  l_o.w = coax_p_wg_mix_f3f3f(cx, l_o.w, coax_p_wg_pow_f3f3(cx, l_mk.x, coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f)), l_mk.y);
  l_o.f4 = l_mk.z;
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_lx = coax_p_wg_normalize2(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_l.x, l_l.z), coax_p_v2(cx, 0x1.a36e2ep-14f, 0x1.a36e2ep-14f)));
  l_tilt = coax_p_verse_style_grass_tilt(cx, l_theta, l_w.x, l_w2.z);
  l_o.z = coax_p_wg_normalize3(cx, coax_p_v3(cx, (l_lx.x * sin(l_tilt)), cos(l_tilt), (l_lx.y * sin(l_tilt))));
  l_o.x = coax_p_eg_clip(cx, l_world);
  l_o.y = l_world;
  return l_o;
}
coax_t14 coax_p_eg_grass_fs(CoaxResources cx, coax_t9 p_g) {
  coax_t9 l_g = p_g;
  bool l_paint_leaf_far{};
  coax_t14 l_res{};
  l_paint_leaf_far = bool{};
  l_res = coax_p_eg_paint(cx, l_g.w, coax_p_wg_normalize3(cx, l_g.z), l_g.y, coax_p_eg_map_lit(cx, l_g.y, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_paint_leaf_far), false, false, l_paint_leaf_far);
  l_res.x = coax_p_wg_make_f4_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, l_res.x.x, l_res.x.y, l_res.x.z), coax_p_wg_mul_f3f(cx, l_g.f4, 0x1.70a3d8p-3f)), l_res.x.w);
  return l_res;
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float4 coax_p_eg_st(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return coax_p_wg_at4(cx, ((int(l_i) * 4) + 1084));
}
uint coax_p_wg_u32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return uint(l_x);
}
uint coax_p_wg_max_u(CoaxResources cx, uint p_a, uint p_b) {
  uint l_a = p_a;
  uint l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_verse_style_near_reach(CoaxResources cx, float p_on_phone) {
  float l_on_phone = p_on_phone;
  return ((l_on_phone > 0x1.000000p-1f) ? 0x1.800000p2f : 0x1.c00000p2f);
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, floor(l_p0.x), floor(l_p0.y));
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_eg_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_eg_ground_y(CoaxResources cx, float2 p_q) {
  float2 l_q = p_q;
  float2 l_g{};
  coax_t15 l_i{};
  float2 l_f{};
  l_g = coax_p_wg_div_f2f(cx, coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, cx.r_u[34], cx.r_u[35])), cx.r_u[33]);
  l_i = coax_p_wg_cvt_i2f2(cx, coax_p_wg_floor_f2(cx, l_g));
  l_f = coax_p_wg_fract_f2(cx, l_g);
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_height(cx, l_i.x, l_i.y), coax_p_eg_height(cx, (l_i.x + 1), l_i.y), l_f.x), coax_p_mix(cx, coax_p_eg_height(cx, l_i.x, (l_i.y + 1)), coax_p_eg_height(cx, (l_i.x + 1), (l_i.y + 1)), l_f.x), l_f.y);
}
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w) {
  float3 l_w = p_w;
  float4 l_p{};
  l_p = coax_p_v4(cx, l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  return coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), l_p));
}
coax_t11 coax_p_eg_ground_mark(CoaxResources cx, float2 p_q, float p_tip) {
  float2 l_q = p_q;
  float l_tip = p_tip;
  coax_t11 l_m{};
  int l_n{};
  int l_k{};
  float4 l_a{};
  float4 l_b{};
  float2 l_rel{};
  float l_r{};
  float l_d{};
  float l_broad{};
  float l_fine{};
  float l_edge{};
  float l_inside{};
  int l_kind{};
  float3 l_c{};
  float l_w{};
  float l_dust{};
  float l_pool{};
  float l_ice{};
  float l_grain{};
  float l_total{};
  l_m = coax_t11{};
  l_m.x = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_m.y = 0.0f;
  l_m.z = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_m.w = 0.0f;
  l_m.f4 = 0.0f;
  l_n = coax_p_wg_i32_f(cx, cx.r_u[2104]);
  {
    l_k = 0;
    while ((l_k < 24))
    {
      if ((l_k >= l_n))
      {
        break;
      }
      l_a = coax_p_wg_at4(cx, ((int((1 + (2 * l_k))) * 4) + 2104));
      l_b = coax_p_wg_at4(cx, ((int((2 + (2 * l_k))) * 4) + 2104));
      l_rel = coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, l_a.x, l_a.y));
      l_r = coax_p_fmax(cx, l_a.z, 0x1.99999ap-4f);
      l_d = ((l_b.z > 0x1.000000p-1f) ? coax_p_fmax(cx, abs(l_rel.x), abs(l_rel.y)) : coax_p_wg_length2(cx, l_rel));
      if ((l_d > ((l_r * 0x1.59999ap0f) + 0x1.333334p-2f)))
      {
        {
          l_k = (l_k + 1);
          continue;
        }
      }
      l_broad = coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, (0x1.99999ap0f / coax_p_fmax(cx, l_r, 0x1.99999ap-1f))), coax_p_v2(cx, l_b.y, (l_b.y * 0x1.666666p-1f))));
      l_fine = coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.4cccccp0f), coax_p_v2(cx, (l_b.y * 0x1.b33334p0f), 0x1.8cccccp1f)));
      l_edge = (((l_d / l_r) + ((l_broad - 0x1.000000p-1f) * 0x1.000000p-1f)) + ((l_fine - 0x1.000000p-1f) * 0x1.1eb852p-3f));
      l_inside = ((0x1.000000p0f - coax_p_smoothstep(cx, 0x1.19999ap-1f, 0x1.051eb8p0f, l_edge)) * l_b.x);
      if ((l_inside <= 0x1.0624dep-9f))
      {
        {
          l_k = (l_k + 1);
          continue;
        }
      }
      l_kind = coax_p_wg_i32_f(cx, (l_a.w + 0x1.000000p-1f));
      l_c = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
      l_w = 0.0f;
      if ((l_kind == 1))
      {
        l_dust = ((0x1.333334p-1f + (0x1.99999ap-2f * coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.59999ap1f), coax_p_v2(cx, l_b.y, l_b.y))))) * (0x1.70a3d8p-1f + (0x1.1eb852p-2f * coax_p_eg_noise(cx, coax_p_wg_sub_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.09999ap3f), coax_p_v2(cx, l_b.y, l_b.y))))));
        l_w = ((l_inside * l_dust) * coax_p_mix(cx, 0x1.99999ap-2f, 0x1.d70a3ep-1f, l_tip));
        l_c = coax_p_v3(cx, 0x1.a8f5c2p-1f, 0x1.bd70a4p-1f, 0x1.ccccccp-1f);
        l_pool = ((coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.ccccccp-1f), coax_p_v2(cx, (l_b.y * 0x1.8cccccp1f), 0x1.4cccccp0f))) * 0x1.800000p-1f) + (coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.d9999ap1f), coax_p_v2(cx, 0x1.b33334p0f, l_b.y))) * 0x1.000000p-2f));
        l_ice = ((coax_p_smoothstep(cx, (0x1.000000p0f - l_b.w), (0x1.3851ecp0f - l_b.w), l_pool) * l_inside) * (0x1.000000p0f - l_tip));
        l_grain = (0x1.b33334p-1f + (0x1.333334p-3f * coax_p_eg_noise(cx, coax_p_v2(cx, ((l_q.x * 0x1.200000p3f) + (l_q.y * 0x1.800000p1f)), (l_q.y * 0x1.800000p0f)))));
        l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.51eb86p-1f, 0x1.6b851ep-1f, 0x1.7ae148p-1f), l_grain), l_ice);
        l_w = coax_p_fmax(cx, l_w, (l_ice * 0x1.333334p-1f));
        l_m.f4 = coax_p_fmax(cx, l_m.f4, l_ice);
      }
      else
      {
        if ((l_kind == 2))
        {
          l_c = coax_p_wg_mix_f3f3f(cx, coax_p_v3(cx, 0x1.eb851ep-3f, 0x1.5c28f6p-3f, 0x1.99999ap-4f), coax_p_v3(cx, 0x1.c28f5cp-5f, 0x1.89374cp-5f, 0x1.581062p-5f), coax_p_smoothstep(cx, 0x1.e66666p-1f, 0x1.ccccccp-2f, l_edge));
          l_w = (l_inside * 0x1.d70a3ep-1f);
          l_m.w = coax_p_fmax(cx, l_m.w, (l_inside * 0x1.99999ap-1f));
        }
        else
        {
          if ((l_kind == 3))
          {
            l_c = coax_p_v3(cx, 0x1.19999ap-1f, 0x1.e147aep-2f, 0x1.666666p-2f);
            l_w = ((l_inside * 0x1.333334p-1f) * coax_p_mix(cx, 0x1.000000p0f, 0x1.666666p-1f, l_tip));
          }
          else
          {
            if ((l_kind == 4))
            {
              l_m.z = coax_p_wg_add_f3f3(cx, l_m.z, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.ae147ap-2f, 0x1.000000p-1f, 0x1.666666p-1f), l_inside), (0x1.800000p-1f + (0x1.000000p-2f * l_fine))));
              {
                l_k = (l_k + 1);
                continue;
              }
            }
            else
            {
              if ((l_kind == 5))
              {
                l_c = coax_p_v3(cx, 0x1.1eb852p-3f, 0x1.c28f5cp-3f, 0x1.70a3d8p-4f);
                l_w = (l_inside * 0x1.19999ap-1f);
              }
              else
              {
                if ((l_kind == 6))
                {
                  l_c = coax_p_v3(cx, 0x1.333334p-4f, 0x1.c28f5cp-5f, 0x1.5c28f6p-4f);
                  l_w = (l_inside * coax_p_mix(cx, 0x1.b33334p-1f, 0x1.000000p-1f, l_tip));
                }
                else
                {
                  if ((l_kind == 7))
                  {
                    l_c = coax_p_v3(cx, 0x1.99999ap-2f, 0x1.51eb86p-2f, 0x1.99999ap-3f);
                    l_w = ((l_inside * 0x1.ae147ap-2f) * (0x1.666666p-1f + (0x1.333334p-2f * l_fine)));
                  }
                  else
                  {
                    l_c = coax_p_v3(cx, 0x1.99999ap-3f, 0x1.851eb8p-3f, 0x1.47ae14p-3f);
                    l_w = (l_inside * 0x1.ccccccp-2f);
                  }
                }
              }
            }
          }
        }
      }
      l_total = (0x1.000000p0f - ((0x1.000000p0f - l_m.y) * (0x1.000000p0f - l_w)));
      l_m.x = coax_p_wg_div_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_m.x, l_m.y), (0x1.000000p0f - l_w)), coax_p_wg_mul_f3f(cx, l_c, l_w)), coax_p_fmax(cx, l_total, 0x1.a36e2ep-14f));
      l_m.y = l_total;
      l_k = (l_k + 1);
    }
  }
  return l_m;
}
float coax_p_verse_style_blade_height(CoaxResources cx, float p_h, float p_low, float p_high) {
  float l_h = p_h;
  float l_low = p_low;
  float l_high = p_high;
  return (l_low + ((l_high - l_low) * coax_p_st_sat(cx, l_h)));
}
float coax_p_verse_style_grass_fade(CoaxResources cx, float p_d, float p_radius, float p_fade) {
  float l_d = p_d;
  float l_radius = p_radius;
  float l_fade = p_fade;
  return (0x1.000000p0f - coax_p_verse_style_soft_step(cx, (l_radius - (l_fade * 0x1.000000p-1f)), (l_fade * 0x1.000000p-1f), l_d));
}
float coax_p_eg_grass_mask(CoaxResources cx, float2 p_q) {
  float2 l_q = p_q;
  float l_m{};
  int l_k{};
  float4 l_sq{};
  int l_k_7{};
  float4 l_b{};
  float l_d{};
  l_m = coax_p_verse_style_grass_clear(cx, (coax_p_eg_path_near(cx, l_q) - cx.r_u[229]));
  {
    l_k = 0;
    while ((l_k < 4))
    {
      l_sq = coax_p_wg_at4(cx, ((int(l_k) * 4) + 232));
      if ((l_sq.z <= 0.0f))
      {
        break;
      }
      l_m = (l_m * coax_p_verse_style_grass_clear(cx, (coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, l_sq.x, l_sq.y))) - l_sq.z)));
      l_k = (l_k + 1);
    }
  }
  {
    l_k_7 = 0;
    while ((l_k_7 < 32))
    {
      l_b = coax_p_wg_at4(cx, ((int(l_k_7) * 4) + 1212));
      if ((l_b.z <= l_b.x))
      {
        {
          l_k_7 = (l_k_7 + 1);
          continue;
        }
      }
      l_d = coax_p_fmax(cx, coax_p_fmax(cx, (l_b.x - l_q.x), (l_q.x - l_b.z)), coax_p_fmax(cx, (l_b.y - l_q.y), (l_q.y - l_b.w)));
      l_m = (l_m * coax_p_verse_style_grass_clear(cx, (l_d - 0x1.333334p-2f)));
      l_k_7 = (l_k_7 + 1);
    }
  }
  return (l_m * coax_p_verse_style_grass_clear(cx, (0x1.000000p-2f - (coax_p_eg_water_over(cx, l_q) * 0x1.400000p2f))));
}
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_verse_style_gust(CoaxResources cx, float p_x, float p_z, float p_t, float p_wx, float p_wz, float p_speed, float p_scale) {
  float l_x = p_x;
  float l_z = p_z;
  float l_t = p_t;
  float l_wx = p_wx;
  float l_wz = p_wz;
  float l_speed = p_speed;
  float l_scale = p_scale;
  return ((0x1.000000p1f * coax_p_verse_style_noise(cx, ((l_x - ((l_wx * l_speed) * l_t)) * l_scale), ((l_z - ((l_wz * l_speed) * l_t)) * l_scale))) - 0x1.000000p0f);
}
float coax_p_verse_style_wind(CoaxResources cx, float p_along, float p_gust, float p_t, float p_amp, float p_wavelength, float p_speed) {
  float l_along = p_along;
  float l_gust = p_gust;
  float l_t = p_t;
  float l_amp = p_amp;
  float l_wavelength = p_wavelength;
  float l_speed = p_speed;
  float l_k{};
  l_k = (0x1.921fb6p2f / coax_p_st_max(cx, l_wavelength, 0x1.0624dep-10f));
  return (l_amp * ((0x1.333334p-1f * sin(((l_k * l_along) - ((l_k * l_speed) * l_t)))) + (0x1.99999ap-2f * l_gust)));
}
float coax_p_verse_style_bend(CoaxResources cx, float p_theta, float p_height, float p_share) {
  float l_theta = p_theta;
  float l_height = p_height;
  float l_share = p_share;
  return (((sin(l_theta) * l_height) * l_share) * l_share);
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return coax_p_scale2(cx, l_a, (0x1.000000p0f / coax_p_wg_length2(cx, l_a)));
}
float coax_p_verse_style_part(CoaxResources cx, float p_d, float p_radius) {
  float l_d = p_d;
  float l_radius = p_radius;
  return coax_p_st_sat(cx, (0x1.000000p0f - (l_d / coax_p_st_max(cx, l_radius, 0x1.0624dep-10f))));
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float coax_p_verse_style_near_width(CoaxResources cx, float p_d, float p_reach) {
  float l_d = p_d;
  float l_reach = p_reach;
  return (0x1.000000p0f + (0x1.666666p0f * (0x1.000000p0f - coax_p_st_sat(cx, (l_d / coax_p_st_max(cx, l_reach, 0x1.0624dep-10f))))));
}
float3 coax_p_eg_meadow(CoaxResources cx, float2 p_q) {
  float2 l_q = p_q;
  return coax_p_wg_pow_f3f3(cx, coax_p_eg_meadow_srgb(cx, coax_p_eg_noise(cx, coax_p_wg_mul_f2f(cx, l_q, 0x1.0a3d70p-3f))), coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f));
}
float coax_p_verse_style_jitter(CoaxResources cx, float p_c, float p_ch, float p_h, float p_jitter) {
  float l_c = p_c;
  float l_ch = p_ch;
  float l_h = p_h;
  float l_jitter = p_jitter;
  float l_j{};
  l_j = (((l_h * 0x1.000000p1f) - 0x1.000000p0f) * l_jitter);
  if ((l_ch < 0x1.000000p-1f))
  {
    return (l_c * (0x1.000000p0f + l_j));
  }
  if ((l_ch < 0x1.800000p0f))
  {
    return l_c;
  }
  return (l_c * (0x1.000000p0f - l_j));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_verse_style_tip(CoaxResources cx, float p_c, float p_ch, float p_lift) {
  float l_c = p_c;
  float l_ch = p_ch;
  float l_lift = p_lift;
  if ((l_ch < 0x1.000000p-1f))
  {
    return (l_c * (0x1.000000p0f + (l_lift * 0x1.4cccccp0f)));
  }
  if ((l_ch < 0x1.800000p0f))
  {
    return (l_c * (0x1.000000p0f + l_lift));
  }
  return l_c;
}
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_metal_pow(l_p0.x, l_p1.x), coax_metal_pow(l_p0.y, l_p1.y), coax_metal_pow(l_p0.z, l_p1.z));
}
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_mix(cx, l_p0.x, l_p1.x, l_p2), coax_p_mix(cx, l_p0.y, l_p1.y, l_p2), coax_p_mix(cx, l_p0.z, l_p1.z, l_p2));
}
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float coax_p_verse_style_grass_tilt(CoaxResources cx, float p_theta, float p_amp, float p_tilt_most) {
  float l_theta = p_theta;
  float l_amp = p_amp;
  float l_tilt_most = p_tilt_most;
  return (l_tilt_most * coax_p_st_max(cx, (-0x1.000000p0f), coax_p_st_min(cx, 0x1.000000p0f, (l_theta / coax_p_st_max(cx, l_amp, 0x1.a36e2ep-14f)))));
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
float coax_p_eg_map_lit(CoaxResources cx, float3 p_p, float3 p_n, bool p_paint_leaf_far) {
  float3 l_p = p_p;
  float3 l_n = p_n;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_q{};
  float2 l_uv{};
  float l_texel_2{};
  float l_phone{};
  float l_taps{};
  float l_r{};
  float l_lit{};
  float l_k{};
  float2 l_o{};
  bool l_inside{};
  if (((coax_p_eg_st(cx, 21u)).x < 0x1.000000p0f))
  {
    return 0x1.000000p0f;
  }
  l_q = coax_p_eg_shadow_place(cx, coax_p_wg_add_f3f3(cx, l_p, coax_p_wg_mul_f3f(cx, l_n, 0x1.47ae14p-4f)), coax_p_eg_light_space(cx));
  l_uv = coax_p_v2(cx, (0x1.000000p-1f + (0x1.000000p-1f * l_q.x)), (0x1.000000p-1f - (0x1.000000p-1f * l_q.y)));
  l_texel_2 = (0x1.000000p0f / float((coax_p_wg_dims_depth(cx)).x));
  l_phone = (coax_p_eg_st(cx, 31u)).z;
  l_taps = (l_paint_leaf_far ? 0x1.000000p0f : (coax_p_eg_st(cx, 21u)).y);
  l_r = (coax_p_eg_st(cx, 21u)).z;
  l_lit = 0.0f;
  {
    l_k = 0.0f;
    while ((l_k < 0x1.200000p3f))
    {
      if ((l_k >= l_taps))
      {
        break;
      }
      l_o = coax_p_v2(cx, coax_p_verse_style_shadow_tap(cx, l_k, l_phone, 0.0f), coax_p_verse_style_shadow_tap(cx, l_k, l_phone, 0x1.000000p0f));
      l_lit = (l_lit + (cx.r_shadow_map).sample_compare(cx.r_shadow_cmp, coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_o, l_r), 0x1.99999ap0f), l_texel_2)), (l_q.z - 0x1.3a92a4p-11f), level(0.0f)));
      l_k = (l_k + 0x1.000000p0f);
    }
  }
  l_inside = (coax_p_wg_all_gt_f2f2(cx, l_uv, coax_p_v2(cx, 0.0f, 0.0f)) && coax_p_wg_all_lt_f2f2(cx, l_uv, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f)));
  return (l_inside ? coax_p_smoothstep(cx, 0x1.99999ap-4f, 0x1.800000p-1f, (l_lit / coax_p_fmax(cx, l_taps, 0x1.000000p0f))) : 0x1.000000p0f);
}
coax_t14 coax_p_eg_paint(CoaxResources cx, float3 p_dry, float3 p_n, float3 p_world, float p_lit, bool p_character, bool p_rim, bool p_paint_leaf_far) {
  float3 l_dry = p_dry;
  float3 l_n = p_n;
  float3 l_world = p_world;
  float l_lit = p_lit;
  bool l_character = p_character;
  bool l_rim = p_rim;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_l{};
  float3 l_v{};
  float3 l_base{};
  float l_w{};
  float l_band0{};
  float l_band{};
  float3 l_key{};
  float3 l_amb{};
  float3 l_c{};
  float l_gain{};
  float l_cy{};
  float l_rs{};
  float l_d{};
  float l_fog{};
  float4 l_b{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_v = coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, l_world, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26])));
  l_base = coax_p_eg_weather_wet_base(cx, l_dry, l_n, l_character);
  l_w = (coax_p_verse_style_wrap(cx, coax_p_wg_dot3(cx, l_n, l_l)) * l_lit);
  l_band0 = (l_character ? coax_p_verse_style_bands2(cx, l_w, (coax_p_eg_st(cx, 8u)).x, (coax_p_eg_st(cx, 8u)).y) : coax_p_verse_style_bands(cx, l_w, (coax_p_eg_st(cx, 7u)).x, (coax_p_eg_st(cx, 7u)).y, (coax_p_eg_st(cx, 7u)).z, (coax_p_eg_st(cx, 7u)).w));
  l_band = coax_p_mix(cx, l_band0, 0x1.333334p-1f, (0x1.ccccccp-2f * coax_p_smoothstep(cx, 0x1.e00000p3f, 0x1.e00000p5f, coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world)))));
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  l_amb = coax_p_wg_mul_ff3(cx, coax_p_eg_sky_seen(cx, l_world), coax_p_v3(cx, coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).x, (coax_p_eg_st(cx, 6u)).x, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).y, (coax_p_eg_st(cx, 6u)).y, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).z, (coax_p_eg_st(cx, 6u)).z, (coax_p_eg_st(cx, 5u)).w)));
  l_c = coax_p_eg_banded(cx, l_base, coax_p_wg_mul_f3f3(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 4u)), l_amb), coax_p_wg_add_f3f3(cx, l_key, l_amb), l_band);
  l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f3(cx, l_base, coax_p_eg_lamp_light(cx, l_world, l_n)));
  l_gain = coax_p_verse_style_chroma_gain(cx, coax_p_eg_saturation(cx, l_c), coax_p_eg_saturation(cx, l_base), 0x1.666666p-1f);
  l_cy = coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z);
  l_c = coax_p_wg_max_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, l_cy, l_cy, l_cy), coax_p_wg_mul_f3f(cx, coax_p_wg_sub_f3f3(cx, l_c, coax_p_v3(cx, l_cy, l_cy, l_cy)), l_gain)), coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
  l_rs = (l_character ? (coax_p_eg_st(cx, 3u)).x : (coax_p_eg_st(cx, 2u)).w);
  if ((l_rim && (l_rs > 0.0f)))
  {
    l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 2u)), coax_p_verse_style_rim(cx, coax_p_wg_dot3(cx, l_n, coax_p_wg_neg_f3(cx, l_v)), coax_p_wg_dot3(cx, l_n, l_l), (coax_p_eg_st(cx, 3u)).y, (coax_p_eg_st(cx, 3u)).z, l_rs)), l_lit));
  }
  if ((!l_paint_leaf_far))
  {
    l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_ff3(cx, coax_p_eg_water_caustics(cx, l_world, l_n), l_base), l_key), l_lit));
  }
  l_c = coax_p_eg_weather_surface(cx, l_c, l_base, l_n, l_world, l_v, l_lit, l_character);
  l_d = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_fog = coax_p_eg_haze_share(cx, l_d, l_world.y);
  l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_eg_haze_colour(cx, l_fog, l_v), l_fog);
  l_c = coax_p_eg_weather_streaks(cx, l_c, l_v, l_d);
  l_c = coax_p_eg_water_under_view(cx, l_c, l_world, l_v);
  l_b = coax_p_eg_st(cx, 19u);
  return coax_t14{coax_p_v4(cx, l_c.x, l_c.y, l_c.z, coax_p_verse_style_bloom_share(cx, coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z), l_b.x, l_b.y)), coax_p_v4(cx, (coax_p_verse_style_shaft_source(cx, coax_p_wg_dot3(cx, l_v, l_l)) * l_fog), (l_d / 0x1.000000p8f), 0.0f, 0.0f)};
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  if (((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix2(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y)));
}
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x / l_b), (l_a.y / l_b));
}
coax_t15 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_i2(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y));
}
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y));
}
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z) {
  int l_x = p_x;
  int l_z = p_z;
  int l_n{};
  int l_cx{};
  int l_cz{};
  l_n = coax_p_wg_i32_f(cx, cx.r_u[32]);
  l_cx = coax_p_wg_clamp_i(cx, l_x, 0, l_n);
  l_cz = coax_p_wg_clamp_i(cx, l_z, 0, l_n);
  return cx.r_heights[int(uint(((l_cz * (l_n + 1)) + l_cx)))];
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return dot(l_a, l_b);
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
float coax_p_eg_noise(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float2 l_i{};
  float2 l_f{};
  float2 l_s{};
  l_i = coax_p_wg_floor_f2(cx, l_p);
  l_f = coax_p_wg_fract_f2(cx, l_p);
  l_s = coax_p_wg_mul_f2f2(cx, coax_p_wg_mul_f2f2(cx, l_f, l_f), coax_p_wg_sub_ff2(cx, 0x1.800000p1f, coax_p_wg_mul_ff2(cx, 0x1.000000p1f, l_f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_hash(cx, l_i), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0.0f))), l_s.x), coax_p_mix(cx, coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0.0f, 0x1.000000p0f))), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f))), l_s.x), l_s.y);
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x / l_b), (l_a.y / l_b), (l_a.z / l_b));
}
float coax_p_st_sat(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_st_min(cx, 0x1.000000p0f, coax_p_st_max(cx, 0.0f, l_x));
}
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x) {
  float l_e = p_e;
  float l_s = p_s;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_st_sat(cx, ((l_x - (l_e - l_s)) / coax_p_st_max(cx, (0x1.000000p1f * l_s), 0x1.0c6f7ap-20f)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float coax_p_eg_path_near(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float l_d{};
  int l_count{};
  int l_i{};
  float4 l_seg{};
  float2 l_a{};
  float2 l_ab{};
  float l_t{};
  l_d = 0x1.f40000p9f;
  l_count = coax_p_wg_i32_f(cx, cx.r_u[228]);
  {
    l_i = 0;
    while ((l_i < 32))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_seg = coax_p_wg_at4(cx, ((int(l_i) * 4) + 100));
      l_a = coax_p_v2(cx, l_seg.x, l_seg.y);
      l_ab = coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, l_seg.z, l_seg.w), l_a);
      l_t = coax_p_clampf(cx, (coax_p_wg_dot2(cx, coax_p_wg_sub_f2f2(cx, l_p, l_a), l_ab) / coax_p_fmax(cx, coax_p_wg_dot2(cx, l_ab, l_ab), 0x1.a36e2ep-14f)), 0.0f, 0x1.000000p0f);
      l_d = coax_p_fmin(cx, l_d, coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, coax_p_wg_sub_f2f2(cx, l_p, l_a), coax_p_wg_mul_f2f(cx, l_ab, l_t))));
      l_i = (l_i + 1);
    }
  }
  return l_d;
}
float coax_p_verse_style_grass_clear(CoaxResources cx, float p_past) {
  float l_past = p_past;
  return coax_p_verse_style_soft_step(cx, 0x1.000000p-3f, 0x1.000000p-3f, l_past);
}
float coax_p_eg_water_over(CoaxResources cx, float2 p_xz) {
  float2 l_xz = p_xz;
  float l_q{};
  float2 l_uv{};
  l_q = coax_p_eg_pond_depth_at(cx, coax_p_v3(cx, l_xz.x, coax_p_eg_ground_y(cx, l_xz), l_xz.y));
  if ((l_q > 0.0f))
  {
    return l_q;
  }
  if (((cx.r_u[1072] < 0x1.000000p1f) || (cx.r_u[1083] <= 0.0f)))
  {
    return 0.0f;
  }
  l_uv = coax_p_eg_water_uv(cx, l_xz);
  if (((((l_uv.x < 0.0f) || (l_uv.y < 0.0f)) || (l_uv.x > (cx.r_u[1072] - 0x1.000000p0f))) || (l_uv.y > (cx.r_u[1073] - 0x1.000000p0f))))
  {
    return 0.0f;
  }
  return coax_p_fmax(cx, (coax_p_eg_water_rest(cx, l_uv)).y, 0.0f);
}
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  float l_ix{};
  float l_iy{};
  float l_fx{};
  float l_fy{};
  float l_sx{};
  float l_sy{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  l_ix = floor(l_x);
  l_iy = floor(l_y);
  l_fx = (l_x - l_ix);
  l_fy = (l_y - l_iy);
  l_sx = ((l_fx * l_fx) * (0x1.800000p1f - (0x1.000000p1f * l_fx)));
  l_sy = ((l_fy * l_fy) * (0x1.800000p1f - (0x1.000000p1f * l_fy)));
  l_a = coax_p_verse_style_hash(cx, l_ix, l_iy);
  l_b = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), l_iy);
  l_c = coax_p_verse_style_hash(cx, l_ix, (l_iy + 0x1.000000p0f));
  l_d = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), (l_iy + 0x1.000000p0f));
  return ((l_a + ((l_b - l_a) * l_sx)) + (((l_c + ((l_d - l_c) * l_sx)) - (l_a + ((l_b - l_a) * l_sx))) * l_sy));
}
float coax_p_st_max(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a > l_b))
  {
    return l_a;
  }
  return l_b;
}
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k) {
  float2 l_a = p_a;
  float l_k = p_k;
  return float2((l_a.x * l_k), (l_a.y * l_k));
}
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t) {
  float l_t = p_t;
  return coax_p_wg_mix_f3f3f(cx, coax_p_EG_MEADOW_COOL(cx), coax_p_EG_MEADOW_WARM(cx), l_t);
}
float coax_p_st_min(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a < l_b))
  {
    return l_a;
  }
  return l_b;
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
coax_t16 coax_p_eg_light_space(CoaxResources cx) {
  float3 l_l{};
  float3 l_ax{};
  float3 l_ay{};
  float l_reach{};
  float l_size{};
  float3 l_c{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_ax = ((abs(l_l.y) < 0x1.ff7ceep-1f) ? coax_p_wg_normalize3(cx, coax_p_wg_cross3(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_l)) : coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f));
  l_ay = coax_p_wg_cross3(cx, l_l, l_ax);
  l_reach = coax_p_verse_style_shadow_reach(cx, (coax_p_eg_st(cx, 31u)).z);
  l_size = coax_p_fmax(cx, (coax_p_eg_st(cx, 21u)).x, 0x1.000000p0f);
  l_c = coax_p_v3(cx, cx.r_u[24], 0.0f, cx.r_u[26]);
  return coax_t16{l_ax, l_ay, l_l, coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ax), l_reach, l_size), coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ay), l_reach, l_size), l_reach};
}
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t16 p_k) {
  float3 l_w = p_w;
  coax_t16 l_k = p_k;
  return coax_p_v3(cx, coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.x) - l_k.w), l_k.f5), coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.y) - l_k.f4), l_k.f5), coax_p_verse_style_shadow_depth(cx, coax_p_wg_dot3(cx, coax_p_wg_sub_f3f3(cx, l_w, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_ff3(cx, l_k.w, l_k.x), coax_p_wg_mul_ff3(cx, l_k.f4, l_k.y))), l_k.z), l_k.f5));
}
coax_t17 coax_p_wg_dims_depth(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_shadow_map).get_width(), (cx.r_shadow_map).get_height());
}
float coax_p_verse_style_shadow_tap(CoaxResources cx, float p_k, float p_on_phone, float p_which) {
  float l_k = p_k;
  float l_on_phone = p_on_phone;
  float l_which = p_which;
  float l_x{};
  float l_y{};
  l_x = 0.0f;
  l_y = 0.0f;
  if ((l_on_phone > 0x1.000000p-1f))
  {
    if ((l_k < 0x1.000000p-1f))
    {
      l_x = (-0x1.333334p-1f);
      l_y = (-0x1.000000p-2f);
    }
    else
    {
      if ((l_k < 0x1.800000p0f))
      {
        l_x = 0x1.000000p-2f;
        l_y = (-0x1.333334p-1f);
      }
      else
      {
        if ((l_k < 0x1.400000p1f))
        {
          l_x = 0x1.333334p-1f;
          l_y = 0x1.000000p-2f;
        }
        else
        {
          l_x = (-0x1.000000p-2f);
          l_y = 0x1.333334p-1f;
        }
      }
    }
  }
  else
  {
    if ((l_k < 0x1.000000p-1f))
    {
      l_x = 0.0f;
      l_y = 0.0f;
    }
    else
    {
      if ((l_k < 0x1.800000p0f))
      {
        l_x = (-0x1.4dd2f2p-2f);
        l_y = (-0x1.9fbe76p-2f);
      }
      else
      {
        if ((l_k < 0x1.400000p1f))
        {
          l_x = (-0x1.ae147ap-1f);
          l_y = (-0x1.2f1aa0p-4f);
        }
        else
        {
          if ((l_k < 0x1.c00000p1f))
          {
            l_x = (-0x1.645a1cp-1f);
            l_y = 0x1.d3f7cep-2f;
          }
          else
          {
            if ((l_k < 0x1.200000p2f))
            {
              l_x = (-0x1.9fbe76p-3f);
              l_y = 0x1.3df3b6p-1f;
            }
            else
            {
              if ((l_k < 0x1.600000p2f))
              {
                l_x = 0x1.ec8b44p-1f;
                l_y = (-0x1.8f5c28p-3f);
              }
              else
              {
                if ((l_k < 0x1.a00000p2f))
                {
                  l_x = 0x1.e45a1cp-2f;
                  l_y = (-0x1.eb851ep-2f);
                }
                else
                {
                  if ((l_k < 0x1.e00000p2f))
                  {
                    l_x = 0x1.09ba5ep-1f;
                    l_y = 0x1.88b43ap-1f;
                  }
                  else
                  {
                    l_x = 0x1.7ae148p-3f;
                    l_y = (-0x1.c9374cp-1f);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((l_which > 0x1.000000p-1f))
  {
    return l_y;
  }
  return l_x;
}
bool coax_p_wg_all_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x > l_b.x) && (l_a.y > l_b.y));
}
bool coax_p_wg_all_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x < l_b.x) && (l_a.y < l_b.y));
}
float3 coax_p_eg_weather_wet_base(CoaxResources cx, float3 p_base, float3 p_n, bool p_character) {
  float3 l_base = p_base;
  float3 l_n = p_n;
  bool l_character = p_character;
  float l_wet{};
  l_wet = coax_p_eg_weather_wet_share(cx, l_n, l_character);
  if ((l_wet <= 0.0f))
  {
    return l_base;
  }
  return coax_p_wg_mul_f3f(cx, l_base, (0x1.000000p0f - (0x1.99999ap-2f * l_wet)));
}
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_verse_style_wrap(CoaxResources cx, float p_ndl) {
  float l_ndl = p_ndl;
  return coax_p_st_sat(cx, ((l_ndl + 0x1.000000p-2f) / 0x1.400000p0f));
}
float coax_p_verse_style_bands2(CoaxResources cx, float p_w, float p_e, float p_s) {
  float l_w = p_w;
  float l_e = p_e;
  float l_s = p_s;
  return coax_p_verse_style_soft_step(cx, l_e, l_s, l_w);
}
float coax_p_verse_style_bands(CoaxResources cx, float p_w, float p_e0, float p_e1, float p_s, float p_mid) {
  float l_w = p_w;
  float l_e0 = p_e0;
  float l_e1 = p_e1;
  float l_s = p_s;
  float l_mid = p_mid;
  return ((l_mid * coax_p_verse_style_soft_step(cx, l_e0, l_s, l_w)) + ((0x1.000000p0f - l_mid) * coax_p_verse_style_soft_step(cx, l_e1, l_s, l_w)));
}
float coax_p_wg_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_eg_sky_seen(CoaxResources cx, float3 p_world) {
  float3 l_world = p_world;
  int l_n{};
  float l_gx{};
  float l_gz{};
  int l_ix{};
  int l_iz{};
  float l_fx{};
  float l_fz{};
  int l_p{};
  int l_k{};
  float l_sky{};
  float l_ground{};
  float l_seen{};
  l_n = coax_p_wg_i32_f(cx, cx.r_u[32]);
  l_gx = ((l_world.x - cx.r_u[34]) / cx.r_u[33]);
  l_gz = ((l_world.z - cx.r_u[35]) / cx.r_u[33]);
  l_ix = coax_p_wg_clamp_i(cx, coax_p_wg_i32_f(cx, floor(l_gx)), 0, (l_n - 1));
  l_iz = coax_p_wg_clamp_i(cx, coax_p_wg_i32_f(cx, floor(l_gz)), 0, (l_n - 1));
  l_fx = coax_p_clampf(cx, (l_gx - float(l_ix)), 0.0f, 0x1.000000p0f);
  l_fz = coax_p_clampf(cx, (l_gz - float(l_iz)), 0.0f, 0x1.000000p0f);
  l_p = ((l_n + 1) * (l_n + 1));
  l_k = ((l_iz * (l_n + 1)) + l_ix);
  l_sky = coax_p_mix(cx, coax_p_mix(cx, cx.r_heights[int(uint((l_p + l_k)))], cx.r_heights[int(uint(((l_p + l_k) + 1)))], l_fx), coax_p_mix(cx, cx.r_heights[int(uint((((l_p + l_k) + l_n) + 1)))], cx.r_heights[int(uint((((l_p + l_k) + l_n) + 2)))], l_fx), l_fz);
  l_ground = coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_height(cx, l_ix, l_iz), coax_p_eg_height(cx, (l_ix + 1), l_iz), l_fx), coax_p_mix(cx, coax_p_eg_height(cx, l_ix, (l_iz + 1)), coax_p_eg_height(cx, (l_ix + 1), (l_iz + 1)), l_fx), l_fz);
  l_seen = coax_p_mix(cx, l_sky, 0x1.000000p0f, coax_p_smoothstep(cx, 0.0f, 0x1.c00000p2f, (l_world.y - l_ground)));
  return coax_p_mix(cx, 0x1.000000p0f, l_seen, 0x1.000000p0f);
}
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale) {
  float l_ny = p_ny;
  float l_sky = p_sky;
  float l_ground = p_ground;
  float l_scale = p_scale;
  return ((l_ground + ((l_sky - l_ground) * coax_p_st_sat(cx, ((l_ny * 0x1.000000p-1f) + 0x1.000000p-1f)))) * l_scale);
}
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a * l_b.x), (l_a * l_b.y), (l_a * l_b.z));
}
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b.x), (l_a.y * l_b.y), (l_a.z * l_b.z));
}
float3 coax_p_eg_banded(CoaxResources cx, float3 p_a, float3 p_dark, float3 p_bright, float p_band) {
  float3 l_a = p_a;
  float3 l_dark = p_dark;
  float3 l_bright = p_bright;
  float l_band = p_band;
  float3 l_s{};
  float3 l_t{};
  float l_tl{};
  float l_k{};
  float3 l_m{};
  float l_y{};
  float l_ym{};
  float3 l_cool{};
  float3 l_l{};
  l_s = coax_p_wg_mul_f3f3(cx, l_a, l_dark);
  l_t = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 4u));
  l_tl = coax_p_verse_style_luma(cx, l_t.x, l_t.y, l_t.z);
  l_k = (coax_p_eg_st(cx, 21u)).w;
  l_m = coax_p_v3(cx, coax_p_verse_style_cool(cx, l_s.x, l_t.x, l_tl, l_k), coax_p_verse_style_cool(cx, l_s.y, l_t.y, l_tl, l_k), coax_p_verse_style_cool(cx, l_s.z, l_t.z, l_tl, l_k));
  l_y = coax_p_verse_style_luma(cx, l_s.x, l_s.y, l_s.z);
  l_ym = coax_p_verse_style_luma(cx, l_m.x, l_m.y, l_m.z);
  l_cool = coax_p_v3(cx, coax_p_verse_style_keep_value(cx, l_m.x, l_y, l_ym), coax_p_verse_style_keep_value(cx, l_m.y, l_y, l_ym), coax_p_verse_style_keep_value(cx, l_m.z, l_y, l_ym));
  l_l = coax_p_wg_mul_f3f3(cx, l_a, l_bright);
  return coax_p_v3(cx, coax_p_verse_style_banded(cx, l_cool.x, l_l.x, l_band), coax_p_verse_style_banded(cx, l_cool.y, l_l.y, l_band), coax_p_verse_style_banded(cx, l_cool.z, l_l.z, l_band));
}
float3 coax_p_eg_lamp_light(CoaxResources cx, float3 p_p, float3 p_n) {
  float3 l_p = p_p;
  float3 l_n = p_n;
  float l_glow{};
  uint l_count{};
  uint l_lit_by_day{};
  float3 l_sum{};
  uint l_i{};
  float4 l_at{};
  float4 l_c{};
  float3 l_delta{};
  float l_d{};
  float l_k{};
  float l_face{};
  l_glow = cx.r_u[1341];
  l_count = coax_p_wg_u32_f(cx, cx.r_u[1340]);
  l_lit_by_day = (l_count - coax_p_wg_min_u(cx, coax_p_wg_u32_f(cx, cx.r_u[1342]), l_count));
  if (((l_glow <= 0.0f) && (l_lit_by_day == l_count)))
  {
    return coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  }
  l_sum = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  {
    l_i = 0u;
    while ((l_i < 16u))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_at = coax_p_wg_at4(cx, ((int((l_i * 2u)) * 4) + 1344));
      l_c = coax_p_wg_at4(cx, ((int(((l_i * 2u) + 1u)) * 4) + 1344));
      l_delta = coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, l_at.x, l_at.y, l_at.z), l_p);
      l_d = coax_p_wg_length3(cx, l_delta);
      if ((l_d >= l_at.w))
      {
        {
          l_i = (l_i + 1u);
          continue;
        }
      }
      l_k = (0x1.000000p0f - ((l_d * l_d) / (l_at.w * l_at.w)));
      l_face = coax_p_fmax(cx, 0x1.333334p-3f, ((coax_p_wg_dot3(cx, l_n, coax_p_wg_div_f3f(cx, l_delta, coax_p_fmax(cx, l_d, 0x1.0624dep-10f))) + 0x1.333334p-2f) / 0x1.4cccccp0f));
      l_sum = coax_p_wg_add_f3f3(cx, l_sum, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_c.x, l_c.y, l_c.z), l_c.w), l_k), l_k), l_face), ((l_i >= l_lit_by_day) ? 0x1.000000p0f : l_glow)));
      l_i = (l_i + 1u);
    }
  }
  return l_sum;
}
float coax_p_eg_saturation(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  float l_hi{};
  l_hi = coax_p_fmax(cx, l_c.x, coax_p_fmax(cx, l_c.y, l_c.z));
  return ((l_hi - coax_p_fmin(cx, l_c.x, coax_p_fmin(cx, l_c.y, l_c.z))) / coax_p_fmax(cx, l_hi, 0x1.a36e2ep-14f));
}
float coax_p_verse_style_chroma_gain(CoaxResources cx, float p_have, float p_albedo, float p_keep) {
  float l_have = p_have;
  float l_albedo = p_albedo;
  float l_keep = p_keep;
  if ((l_have < 0x1.a36e2ep-14f))
  {
    return 0x1.000000p0f;
  }
  return coax_p_st_min(cx, 0x1.400000p1f, coax_p_st_max(cx, 0x1.000000p0f, ((l_albedo * l_keep) / l_have)));
}
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b) {
  float l_r = p_r;
  float l_g = p_g;
  float l_b = p_b;
  return (((0x1.b367a0p-3f * l_r) + (0x1.6e2eb2p-1f * l_g)) + (0x1.27bb30p-4f * l_b));
}
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_p_fmax(cx, l_p0.x, l_p1.x), coax_p_fmax(cx, l_p0.y, l_p1.y), coax_p_fmax(cx, l_p0.z, l_p1.z));
}
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_v3(cx, (-l_a.x), (-l_a.y), (-l_a.z));
}
float coax_p_verse_style_rim(CoaxResources cx, float p_ndv, float p_ndl, float p_start, float p_full, float p_strength) {
  float l_ndv = p_ndv;
  float l_ndl = p_ndl;
  float l_start = p_start;
  float l_full = p_full;
  float l_strength = p_strength;
  float l_t{};
  float l_edge{};
  l_t = coax_p_st_sat(cx, ((l_ndv - l_start) / (l_full - l_start)));
  l_edge = ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
  return ((l_edge * (0x1.666666p-2f + (0x1.4cccccp-1f * coax_p_st_sat(cx, (l_ndl + 0x1.333334p-2f))))) * l_strength);
}
float coax_p_eg_water_caustics(CoaxResources cx, float3 p_p, float3 p_n) {
  float3 l_p = p_p;
  float3 l_n = p_n;
  float l_depth{};
  float l_up{};
  l_depth = coax_p_eg_water_depth_at(cx, l_p);
  if ((l_depth <= 0.0f))
  {
    return 0.0f;
  }
  l_up = coax_p_smoothstep(cx, (-0x1.99999ap-3f), 0x1.333334p-1f, l_n.y);
  return ((((coax_p_eg_water_caustic_pattern(cx, coax_p_v2(cx, l_p.x, l_p.z), cx.r_u[1048]) * coax_p_smoothstep(cx, 0.0f, 0x1.99999ap-4f, l_depth)) * exp(((-l_depth) * 0x1.666666p-1f))) * l_up) * 0x1.666666p0f);
}
float3 coax_p_eg_weather_surface(CoaxResources cx, float3 p_c, float3 p_base, float3 p_n, float3 p_world, float3 p_v, float p_lit, bool p_character) {
  float3 l_c = p_c;
  float3 l_base = p_base;
  float3 l_n = p_n;
  float3 l_world = p_world;
  float3 l_v = p_v;
  float l_lit = p_lit;
  bool l_character = p_character;
  float3 l_o{};
  float l_wet{};
  float3 l_l{};
  float3 l_key{};
  float3 l_r{};
  float l_puddles{};
  float l_m{};
  float l_fill{};
  float2 l_s{};
  float3 l_pn{};
  float3 l_mirror{};
  float l_f{};
  l_o = l_c;
  l_wet = coax_p_eg_weather_wet_share(cx, l_n, l_character);
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  if ((l_wet > 0.0f))
  {
    l_r = coax_p_wg_reflect3(cx, l_v, l_n);
    l_o = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_key, coax_p_smoothstep(cx, 0x1.dc28f6p-1f, 0x1.f33334p-1f, coax_p_wg_dot3(cx, l_r, l_l))), l_wet), 0x1.666666p-2f), l_lit));
  }
  l_puddles = cx.r_u[1477];
  if (((((l_puddles > 0.0f) && (!l_character)) && (l_n.y > 0x1.f0a3d8p-1f)) && (abs((l_world.y - coax_p_eg_ground_y(cx, coax_p_v2(cx, l_world.x, l_world.z)))) < 0x1.99999ap-5f)))
  {
    l_m = ((coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_world.x, l_world.z), 0x1.ccccccp-2f), 0x1.000000p-1f)) * 0x1.666666p-1f) + (coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_world.x, l_world.z), 0x1.b33334p0f), 0x1.400000p1f)) * 0x1.333334p-2f));
    l_fill = (0x1.000000p0f - coax_p_smoothstep(cx, (l_puddles * 0x1.333334p-2f), ((l_puddles * 0x1.333334p-2f) + 0x1.eb851ep-6f), l_m));
    if ((l_fill > 0.0f))
    {
      l_s = coax_p_eg_weather_rain_slope(cx, coax_p_v2(cx, l_world.x, l_world.z));
      l_pn = coax_p_wg_normalize3(cx, coax_p_v3(cx, (-l_s.x), 0x1.000000p0f, (-l_s.y)));
      l_mirror = coax_p_wg_mul_f3f(cx, coax_p_wg_min_f3f3(cx, coax_p_eg_weather_sky(cx, coax_p_eg_sky(cx, coax_p_wg_reflect3(cx, l_v, l_pn), l_l), coax_p_wg_reflect3(cx, l_v, l_pn)), coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f)), 0x1.800000p-1f);
      l_f = (0x1.000000p-2f + (0x1.333334p-1f * coax_metal_pow((0x1.000000p0f - coax_p_fmax(cx, (-l_v.y), 0.0f)), 0x1.800000p1f)));
      l_o = coax_p_wg_mix_f3f3f(cx, l_o, coax_p_wg_mix_f3f3f(cx, coax_p_wg_mul_f3f(cx, l_c, 0x1.19999ap-1f), l_mirror, l_f), (l_fill * 0x1.b33334p-1f));
    }
  }
  l_o = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, l_base, coax_p_v3(cx, 0x1.800000p-1f, 0x1.99999ap-1f, 0x1.000000p0f)), cx.r_u[1475]), 0x1.333334p0f));
  return l_o;
}
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y) {
  float l_d = p_d;
  float l_y = p_y;
  return coax_p_verse_style_haze(cx, l_d, l_y, (cx.r_u[25] - 0x1.400000p1f), cx.r_u[31], cx.r_u[27], (coax_p_eg_st(cx, 9u)).z, (coax_p_eg_st(cx, 9u)).w);
}
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v) {
  float l_f = p_f;
  float3 l_v = p_v;
  float3 l_hz{};
  float l_cap{};
  float3 l_h{};
  float3 l_green{};
  float l_level{};
  float l_glow{};
  l_hz = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u));
  l_cap = (coax_p_eg_st(cx, 9u)).z;
  l_h = coax_p_v3(cx, coax_p_verse_style_haze_hue(cx, l_hz.x, 0.0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.y, 0x1.000000p0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.z, 0x1.000000p1f, l_f, l_cap));
  l_green = coax_p_wg_div_f3f(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_wg_dot3(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_v3(cx, 0x1.554c98p-2f, 0x1.554c98p-2f, 0x1.554c98p-2f)));
  l_level = (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.666666p-2f, abs(l_v.y)));
  l_h = coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_mul_f3f3(cx, l_h, l_green), ((0x1.851eb8p-2f * l_level) * (0x1.000000p0f - (coax_p_eg_st(cx, 14u)).w)));
  l_glow = coax_p_verse_style_haze_glow(cx, coax_p_wg_dot3(cx, l_v, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u))));
  if (((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f))
  {
    return coax_p_wg_add_f3f3(cx, l_h, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (((coax_p_eg_st(cx, 0u)).w * l_glow) * 0x1.000000p-1f)));
  }
  return coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u)), l_glow);
}
float3 coax_p_eg_weather_streaks(CoaxResources cx, float3 p_c, float3 p_v, float p_d) {
  float3 l_c = p_c;
  float3 l_v = p_v;
  float l_d = p_d;
  float l_rain{};
  int l_layers{};
  float l_t{};
  float2 l_lean{};
  float3 l_w{};
  float l_flat{};
  float l_k{};
  float l_around{};
  float l_px{};
  float l_a{};
  int l_i{};
  float l_r{};
  float l_along{};
  float l_fade{};
  float l_y{};
  float l_cells{};
  float2 l_q{};
  float2 l_cell{};
  float l_h{};
  float2 l_f{};
  float l_off{};
  float l_top{};
  float l_width{};
  float l_x{};
  float l_len_2{};
  float l_streak{};
  float3 l_key{};
  float3 l_tint{};
  l_rain = cx.r_u[1472];
  if ((l_rain <= 0x1.47ae14p-7f))
  {
    return l_c;
  }
  l_layers = (coax_p_eg_weather_desktop(cx) ? 4 : 2);
  l_t = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
  l_lean = coax_p_wg_div_f2f(cx, coax_p_v2(cx, cx.r_u[1473], cx.r_u[1474]), 0x1.c00000p2f);
  l_w = coax_p_v3(cx, (l_v.x + (l_lean.x * l_v.y)), l_v.y, (l_v.z + (l_lean.y * l_v.y)));
  l_flat = coax_p_wg_length2(cx, coax_p_v2(cx, l_w.x, l_w.z));
  l_k = (l_flat / coax_p_fmax(cx, coax_p_wg_length3(cx, l_w), 0x1.a36e2ep-14f));
  if ((l_k < 0x1.eb851ep-5f))
  {
    return l_c;
  }
  l_around = ((coax_p_wg_atan2(cx, l_w.x, l_w.z) * 0x1.45f306p-3f) + 0x1.000000p-1f);
  l_px = coax_p_fmax(cx, cx.r_u[1065], 0x1.a36e2ep-14f);
  l_a = 0.0f;
  {
    l_i = 0;
    while ((l_i < 4))
    {
      if ((l_i >= l_layers))
      {
        break;
      }
      l_r = (0x1.333334p0f * coax_p_wg_exp2(cx, float(l_i)));
      l_along = (l_r / l_flat);
      if ((l_along > l_d))
      {
        break;
      }
      if (coax_p_eg_weather_covered(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_wg_mul_f3f(cx, l_v, l_along))))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_fade = (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.47ae14p-5f, 0x1.eb851ep-4f, ((l_px * l_along) / l_k)));
      if ((l_fade <= 0.0f))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_y = (l_w.y * l_along);
      l_cells = coax_p_wg_round(cx, ((0x1.921fb6p2f * l_r) / 0x1.eb851ep-4f));
      l_q = coax_p_v2(cx, (l_around * l_cells), (((l_y + (l_t * 0x1.c00000p2f)) + (float(l_i) * 0x1.b66666p3f)) / 0x1.b33334p-1f));
      l_cell = coax_p_wg_floor_f2(cx, l_q);
      l_h = coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f2(cx, l_cell, coax_p_v2(cx, (float(l_i) * 0x1.100000p4f), 0x1.800000p1f)));
      if ((l_h > (l_rain * 0x1.19999ap-1f)))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_f = coax_p_wg_fract_f2(cx, l_q);
      l_off = ((coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_cell, 0x1.233334p3f)) * 0x1.666666p-1f) + 0x1.333334p-3f);
      l_top = (coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_cell, 0x1.2cccccp2f)) * 0x1.666666p-1f);
      l_width = coax_p_fmax(cx, (((l_px * l_along) * 0x1.19999ap0f) / 0x1.eb851ep-4f), 0x1.47ae14p-6f);
      l_x = abs((l_f.x - l_off));
      l_len_2 = ((0x1.1eb852p-4f * coax_p_wg_exp2(cx, (float(l_i) * 0x1.000000p-1f))) / 0x1.b33334p-1f);
      l_streak = (((0x1.000000p0f - coax_p_smoothstep(cx, (l_width * 0x1.000000p-1f), l_width, l_x)) * coax_p_smoothstep(cx, l_top, (l_top + 0x1.47ae14p-6f), l_f.y)) * (0x1.000000p0f - coax_p_smoothstep(cx, ((l_top + l_len_2) - 0x1.47ae14p-6f), (l_top + l_len_2), l_f.y)));
      l_a = (l_a + ((l_streak * (0x1.19999ap-1f - (0x1.99999ap-4f * float(l_i)))) * l_fade));
      l_i = (l_i + 1);
    }
  }
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  l_tint = coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.8f5c28p-1f, 0x1.ae147ap-1f, 0x1.ccccccp-1f), (0x1.ccccccp-2f + (0x1.19999ap-1f * coax_p_clampf(cx, coax_p_verse_style_luma(cx, l_key.x, l_key.y, l_key.z), 0.0f, 0x1.000000p0f))));
  return coax_p_wg_mix_f3f3f(cx, l_c, l_tint, (coax_p_clampf(cx, l_a, 0.0f, 0x1.000000p0f) * 0x1.99999ap-2f));
}
float3 coax_p_eg_water_under_view(CoaxResources cx, float3 p_c, float3 p_world, float3 p_d) {
  float3 l_c = p_c;
  float3 l_world = p_world;
  float3 l_d = p_d;
  float3 l_o{};
  float l_level{};
  float l_dist{};
  float l_path{};
  float3 l_tr{};
  float3 l_key{};
  float3 l_light{};
  float3 l_col{};
  if ((!coax_p_eg_water_pixel_under(cx, l_d)))
  {
    return l_c;
  }
  l_o = coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]);
  l_level = (l_o.y - coax_p_eg_water_eye_over(cx));
  l_dist = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, l_world, l_o));
  l_path = l_dist;
  if (((l_world.y > l_level) && (l_d.y > 0.0f)))
  {
    l_path = coax_p_fmin(cx, l_dist, ((l_level - l_o.y) / l_d.y));
  }
  l_tr = coax_p_wg_exp_f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_EG_WATER_UNDER_ABSORB(cx)), l_path));
  l_key = coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w);
  l_light = coax_p_wg_mul_f3f(cx, coax_p_EG_WATER_UNDER_SCATTER(cx), (0x1.666666p-2f + (0x1.4cccccp-1f * coax_p_verse_style_luma(cx, l_key.x, l_key.y, l_key.z))));
  l_col = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_c, coax_p_EG_WATER_UNDER_TINT(cx)), l_tr), coax_p_wg_mul_f3f3(cx, l_light, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), l_tr)));
  l_col = coax_p_wg_add_f3f3(cx, l_col, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.f0a3d8p-1f, 0x1.b33334p-1f), l_key), ((coax_p_eg_water_motes(cx, l_o, l_d, coax_p_fmin(cx, l_path, 0x1.800000p2f)) * 0x1.333334p-1f) + coax_p_eg_water_shafts(cx, l_o, l_d, l_path, l_level))));
  return l_col;
}
float coax_p_verse_style_bloom_share(CoaxResources cx, float p_lum, float p_threshold, float p_knee) {
  float l_lum = p_lum;
  float l_threshold = p_threshold;
  float l_knee = p_knee;
  float l_k{};
  float l_q{};
  if ((l_lum <= 0.0f))
  {
    return 0.0f;
  }
  l_k = coax_p_st_max(cx, l_knee, 0x1.4f8b58p-17f);
  l_q = coax_p_st_min(cx, coax_p_st_max(cx, ((l_lum - l_threshold) + l_k), 0.0f), (0x1.000000p1f * l_k));
  return coax_p_st_min(cx, (coax_p_st_max(cx, ((l_q * l_q) / (0x1.000000p2f * l_k)), (l_lum - l_threshold)) / l_lum), 0x1.000000p0f);
}
float coax_p_verse_style_shaft_source(CoaxResources cx, float p_cos_t) {
  float l_cos_t = p_cos_t;
  return exp(((-0x1.800000p4f) * coax_p_st_max(cx, (0x1.000000p0f - l_cos_t), 0.0f)));
}
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return ((l_x >= (-0x1.fffffep127f)) && (l_x <= 0x1.fffffep127f));
}
uint coax_p_render_noise_cell(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_bounded{};
  l_bounded = coax_p_fmin(cx, coax_p_fmax(cx, l_x, (-0x1.000000p25f)), 0x1.fffffep24f);
  return uint(int(floor((l_bounded * 0x1.000000p6f))));
}
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_p_render_noise_permute(cx, ((l_x * 1597334677u) ^ (l_y * 3812015801u)));
}
float coax_p_render_noise_unit(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  return (float((l_word >> uint(8u))) * 0x1.000000p-24f);
}
coax_t15 coax_p_i2(CoaxResources cx, int p_x, int p_y) {
  int l_x = p_x;
  int l_y = p_y;
  return coax_t15{l_x, l_y};
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high) {
  int l_x = p_x;
  int l_low = p_low;
  int l_high = p_high;
  return coax_p_wg_min_i(cx, coax_p_wg_max_i(cx, l_x, l_low), l_high);
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a * l_b.x), (l_a * l_b.y));
}
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a - l_b.x), (l_a - l_b.y));
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_eg_pond_depth_at(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  uint l_k{};
  float4 l_q{};
  {
    l_k = 0u;
    while ((l_k < 4u))
    {
      l_q = coax_p_eg_pond_row(cx, l_k);
      if ((l_q.z <= 0x1.000000p-1f))
      {
        {
          l_k = (l_k + 1u);
          continue;
        }
      }
      if (((coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_v2(cx, l_q.x, l_q.y))) < (l_q.z + 0x1.333334p-2f)) && (l_p.y < (l_q.w + 0x1.47ae14p-4f))))
      {
        return (l_q.w - l_p.y);
      }
      l_k = (l_k + 1u);
    }
  }
  return (-0x1.000000p0f);
}
float2 coax_p_eg_water_uv(CoaxResources cx, float2 p_xz) {
  float2 l_xz = p_xz;
  float2 l_t{};
  float2 l_side{};
  float2 l_d{};
  l_t = coax_p_v2(cx, sin(cx.r_u[1082]), cos(cx.r_u[1082]));
  l_side = coax_p_v2(cx, (-l_t.y), l_t.x);
  l_d = coax_p_wg_sub_f2f2(cx, l_xz, coax_p_v2(cx, cx.r_u[1080], cx.r_u[1081]));
  return coax_p_v2(cx, (coax_p_wg_dot2(cx, l_d, l_side) / coax_p_fmax(cx, cx.r_u[1083], 0x1.0624dep-10f)), (coax_p_wg_dot2(cx, l_d, l_t) / coax_p_fmax(cx, cx.r_u[1067], 0x1.0624dep-10f)));
}
coax_t18 coax_p_eg_water_rest(CoaxResources cx, float2 p_uv) {
  float2 l_uv = p_uv;
  uint l_cols{};
  uint l_rows{};
  float2 l_a{};
  uint l_i{};
  uint l_j{};
  float2 l_f{};
  uint l_k00{};
  uint l_k10{};
  uint l_k01{};
  uint l_k11{};
  coax_t18 l_o{};
  array<float, 8> l_v{};
  uint l_c{};
  l_cols = coax_p_wg_u32_f(cx, cx.r_u[1072]);
  l_rows = coax_p_wg_u32_f(cx, cx.r_u[1073]);
  l_a = coax_p_wg_clamp_f2f2f2(cx, l_uv, coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, float((l_cols - 1u)), float((l_rows - 1u))));
  l_i = coax_p_wg_min_u(cx, coax_p_wg_u32_f(cx, floor(l_a.x)), (l_cols - 2u));
  l_j = coax_p_wg_min_u(cx, coax_p_wg_u32_f(cx, floor(l_a.y)), (l_rows - 2u));
  l_f = coax_p_wg_sub_f2f2(cx, l_a, coax_p_v2(cx, float(l_i), float(l_j)));
  l_k00 = ((l_j * l_cols) + l_i);
  l_k10 = (l_k00 + 1u);
  l_k01 = (l_k00 + l_cols);
  l_k11 = (l_k01 + 1u);
  l_o = coax_t18{};
  l_v = array<float, 8>{};
  {
    l_c = 0u;
    while ((l_c < 8u))
    {
      l_v[int(l_c)] = coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_water_node(cx, l_k00, l_c), coax_p_eg_water_node(cx, l_k10, l_c), l_f.x), coax_p_mix(cx, coax_p_eg_water_node(cx, l_k01, l_c), coax_p_eg_water_node(cx, l_k11, l_c), l_f.x), l_f.y);
      l_c = (l_c + 1u);
    }
  }
  l_o.x = coax_p_v3(cx, l_v[0], l_v[1], l_v[2]);
  l_o.y = l_v[3];
  l_o.z = l_v[4];
  l_o.w = coax_p_v2(cx, l_v[5], l_v[6]);
  l_o.f4 = l_v[7];
  return l_o;
}
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return coax_p_render_noise2(cx, l_x, l_y);
}
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.000000p-2f, 0x1.851eb8p-2f, 0x1.c28f5cp-3f);
}
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.a3d70ap-2f, 0x1.f5c290p-2f, 0x1.000000p-2f);
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_cross3(cx, l_a, l_b);
}
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone) {
  float l_on_phone = p_on_phone;
  if ((l_on_phone > 0x1.000000p-1f))
  {
    return 0x1.400000p5f;
  }
  return 0x1.e00000p5f;
}
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size) {
  float l_x = p_x;
  float l_reach = p_reach;
  float l_size = p_size;
  float l_texel{};
  l_texel = ((0x1.000000p1f * l_reach) / coax_p_st_max(cx, l_size, 0x1.000000p0f));
  return (floor(((l_x / l_texel) + 0x1.000000p-1f)) * l_texel);
}
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach) {
  float l_x = p_x;
  float l_reach = p_reach;
  return (l_x / coax_p_st_max(cx, l_reach, 0x1.0624dep-10f));
}
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach) {
  float l_along = p_along;
  float l_reach = p_reach;
  return (0x1.000000p-1f - (l_along / (0x1.000000p2f * coax_p_st_max(cx, l_reach, 0x1.0624dep-10f))));
}
coax_t17 coax_p_u2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_t17{l_x, l_y};
}
float coax_p_eg_weather_wet_share(CoaxResources cx, float3 p_n, bool p_character) {
  float3 l_n = p_n;
  bool l_character = p_character;
  return (cx.r_u[1476] * (l_character ? 0x1.99999ap-1f : coax_p_smoothstep(cx, (-0x1.333334p-2f), 0x1.666666p-1f, l_n.y)));
}
float coax_p_verse_style_cool(CoaxResources cx, float p_c, float p_tint, float p_tint_lum, float p_amount) {
  float l_c = p_c;
  float l_tint = p_tint;
  float l_tint_lum = p_tint_lum;
  float l_amount = p_amount;
  return (l_c * coax_metal_pow((coax_p_st_max(cx, l_tint, 0x1.0c6f7ap-20f) / coax_p_st_max(cx, l_tint_lum, 0x1.0c6f7ap-20f)), coax_p_st_max(cx, l_amount, 0.0f)));
}
float coax_p_verse_style_keep_value(CoaxResources cx, float p_c, float p_before, float p_after) {
  float l_c = p_c;
  float l_before = p_before;
  float l_after = p_after;
  return ((l_c * l_before) / coax_p_st_max(cx, l_after, 0x1.0c6f7ap-20f));
}
float coax_p_verse_style_banded(CoaxResources cx, float p_shadow_c, float p_lit_c, float p_band) {
  float l_shadow_c = p_shadow_c;
  float l_lit_c = p_lit_c;
  float l_band = p_band;
  return (l_shadow_c + ((l_lit_c - l_shadow_c) * coax_p_st_sat(cx, l_band)));
}
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b) {
  uint l_a = p_a;
  uint l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_eg_water_depth_at(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  float l_f{};
  float l_q{};
  float2 l_uv{};
  coax_t18 l_r{};
  l_f = coax_p_eg_fountain_depth_at(cx, l_p);
  if ((l_f > (-0x1.000000p-1f)))
  {
    return l_f;
  }
  l_q = coax_p_eg_pond_depth_at(cx, l_p);
  if ((l_q > (-0x1.000000p-1f)))
  {
    return l_q;
  }
  if (((cx.r_u[1072] < 0x1.000000p1f) || (cx.r_u[1083] <= 0.0f)))
  {
    return (-0x1.000000p0f);
  }
  l_uv = coax_p_eg_water_uv(cx, coax_p_v2(cx, l_p.x, l_p.z));
  if (((((l_uv.x < 0.0f) || (l_uv.y < 0.0f)) || (l_uv.x > (cx.r_u[1072] - 0x1.000000p0f))) || (l_uv.y > (cx.r_u[1073] - 0x1.000000p0f))))
  {
    return (-0x1.000000p0f);
  }
  l_r = coax_p_eg_water_rest(cx, l_uv);
  if ((l_r.y <= 0.0f))
  {
    return (-0x1.000000p0f);
  }
  return (l_r.x.y - l_p.y);
}
float coax_p_eg_water_caustic_pattern(CoaxResources cx, float2 p_p, float p_t) {
  float2 l_p = p_p;
  float l_t = p_t;
  float l_a{};
  float l_b{};
  float l_ra{};
  float l_rb{};
  l_a = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_p, 0x1.99999ap0f), (l_t * 0x1.ccccccp-2f)));
  l_b = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_p, 0x1.733334p1f), coax_p_v2(cx, 0x1.8cccccp1f, 0x1.ecccccp2f)), ((l_t * 0x1.333334p-1f) + 0x1.000000p2f)));
  l_ra = (0x1.000000p0f - abs(((0x1.000000p1f * l_a) - 0x1.000000p0f)));
  l_rb = (0x1.000000p0f - abs(((0x1.000000p1f * l_b) - 0x1.000000p0f)));
  return ((coax_metal_pow(l_ra, 0x1.c00000p2f) * 0x1.99999ap-1f) + (coax_metal_pow(l_rb, 0x1.c00000p2f) * 0x1.19999ap-1f));
}
float3 coax_p_wg_reflect3(CoaxResources cx, float3 p_i, float3 p_n) {
  float3 l_i = p_i;
  float3 l_n = p_n;
  return coax_p_reflect3(cx, l_i, l_n);
}
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1) {
  float2 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v3(cx, l_p0.x, l_p0.y, l_p1);
}
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  float3 l_i{};
  float3 l_f{};
  float3 l_s{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  float l_e{};
  float l_g{};
  float l_h{};
  float l_k{};
  l_i = coax_p_wg_floor_f3(cx, l_p);
  l_f = coax_p_wg_fract_f3(cx, l_p);
  l_s = coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_f, l_f), coax_p_wg_sub_ff3(cx, 0x1.800000p1f, coax_p_wg_mul_ff3(cx, 0x1.000000p1f, l_f)));
  l_a = coax_p_eg_water_hash(cx, l_i);
  l_b = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f)));
  l_c = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f)));
  l_d = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0.0f)));
  l_e = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f)));
  l_g = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0x1.000000p0f)));
  l_h = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0x1.000000p0f)));
  l_k = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_mix(cx, l_a, l_b, l_s.x), coax_p_mix(cx, l_c, l_d, l_s.x), l_s.y), coax_p_mix(cx, coax_p_mix(cx, l_e, l_g, l_s.x), coax_p_mix(cx, l_h, l_k, l_s.x), l_s.y), l_s.z);
}
float2 coax_p_eg_weather_rain_slope(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float l_rain{};
  float l_cell{};
  float2 l_base{};
  float l_t{};
  float2 l_g{};
  int l_j{};
  int l_i{};
  float2 l_c{};
  float l_h{};
  float l_clock{};
  float l_phase{};
  float l_turn{};
  float2 l_at{};
  float2 l_to{};
  float l_dist{};
  float l_x{};
  float l_env{};
  l_rain = cx.r_u[1472];
  if ((l_rain <= 0x1.47ae14p-7f))
  {
    return coax_p_v2(cx, 0.0f, 0.0f);
  }
  l_cell = 0x1.19999ap-1f;
  l_base = coax_p_wg_floor_f2(cx, coax_p_wg_div_f2f(cx, l_p, l_cell));
  l_t = cx.r_u[1048];
  l_g = coax_p_v2(cx, 0.0f, 0.0f);
  {
    l_j = (-1);
    while ((l_j <= 1))
    {
      {
        l_i = (-1);
        while ((l_i <= 1))
        {
          l_c = coax_p_wg_add_f2f2(cx, l_base, coax_p_v2(cx, float(l_i), float(l_j)));
          l_h = coax_p_eg_weather_hash(cx, l_c);
          if ((l_h > (0x1.000000p-2f + (0x1.800000p-1f * l_rain))))
          {
            {
              l_i = (l_i + 1);
              continue;
            }
          }
          l_clock = ((l_t / 0x1.666666p-1f) + (l_h * 0x1.c851ecp2f));
          l_phase = coax_p_fract(cx, l_clock);
          l_turn = floor(l_clock);
          l_at = coax_p_wg_mul_f2f(cx, coax_p_wg_add_f2f2(cx, l_c, coax_p_v2(cx, coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_c, (l_turn * 0x1.5eb852p0f))), coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, coax_p_wg_add_f2f(cx, l_c, 0x1.533334p2f), (l_turn * 0x1.0e147ap1f))))), l_cell);
          l_to = coax_p_wg_sub_f2f2(cx, l_p, l_at);
          l_dist = coax_p_wg_length2(cx, l_to);
          l_x = (l_dist - (l_phase * 0x1.333334p-2f));
          l_env = ((exp((((-l_x) * l_x) / 0x1.a36e2ep-10f)) * (0x1.000000p0f - l_phase)) * (0x1.000000p0f - l_phase));
          l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, l_to, coax_p_fmax(cx, l_dist, 0x1.0624dep-10f)), l_env), cos((l_x * 0x1.b80000p5f))), 0x1.666666p0f));
          l_i = (l_i + 1);
        }
      }
      l_j = (l_j + 1);
    }
  }
  return coax_p_wg_mul_f2f(cx, l_g, l_rain);
}
float3 coax_p_eg_sky(CoaxResources cx, float3 p_d, float3 p_l) {
  float3 l_d = p_d;
  float3 l_l = p_l;
  float l_up{};
  float3 l_h{};
  float3 l_z{};
  float l_t{};
  float3 l_c{};
  float l_gain{};
  float l_cy{};
  float l_ct{};
  bool l_moon{};
  float l_disc{};
  float l_halo{};
  float l_overcast{};
  float l_glow_patch{};
  float4 l_cl{};
  float4 l_c2{};
  float l_t_2{};
  float2 l_p{};
  float l_n{};
  float l_cover{};
  float2 l_toward{};
  float l_lit{};
  float l_night{};
  float3 l_cloud{};
  l_up = l_d.y;
  l_h = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 13u));
  l_z = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 12u));
  l_t = coax_p_verse_style_sky_t(cx, l_up);
  l_c = coax_p_wg_mix_f3f3f(cx, l_h, l_z, l_t);
  l_gain = coax_p_verse_style_chroma_gain(cx, coax_p_eg_saturation(cx, l_c), coax_p_mix(cx, coax_p_eg_saturation(cx, l_h), coax_p_eg_saturation(cx, l_z), l_t), 0x1.000000p0f);
  l_cy = coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z);
  l_c = coax_p_wg_max_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, l_cy, l_cy, l_cy), coax_p_wg_mul_f3f(cx, coax_p_wg_sub_f3f3(cx, l_c, coax_p_v3(cx, l_cy, l_cy, l_cy)), l_gain)), coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
  l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u)), coax_p_verse_style_sky_band(cx, l_up, (coax_p_eg_st(cx, 12u)).w));
  l_ct = coax_p_wg_dot3(cx, l_d, l_l);
  l_moon = ((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f);
  l_disc = coax_p_smoothstep(cx, cos(((coax_p_eg_st(cx, 14u)).x * 0x1.266666p0f)), cos(((coax_p_eg_st(cx, 14u)).x * 0x1.b33334p-1f)), l_ct);
  l_halo = ((coax_p_verse_style_halo(cx, l_ct, (coax_p_eg_st(cx, 14u)).y) * 0x1.000000p-1f) + (coax_p_verse_style_halo(cx, l_ct, (coax_p_eg_st(cx, 14u)).z) * 0x1.000000p-2f));
  if (l_moon)
  {
    l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), l_halo), 0x1.000000p-1f));
  }
  else
  {
    l_c = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u)), 0x1.800000p0f), coax_p_clampf(cx, (l_halo * 0x1.19999ap0f), 0.0f, 0x1.ccccccp-1f));
  }
  l_overcast = coax_p_clampf(cx, ((cx.r_u[1478] - 0x1.333334p-3f) / 0x1.19999ap-1f), 0.0f, 0x1.000000p0f);
  l_glow_patch = (coax_p_smoothstep(cx, cos(((coax_p_eg_st(cx, 14u)).x * 0x1.c00000p2f)), 0x1.000000p0f, l_ct) * 0x1.eb851ep-4f);
  l_c = coax_p_wg_mix_f3f3f(cx, l_c, (l_moon ? coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.b33334p-1f, 0x1.c28f5cp-1f, 0x1.000000p0f), 0x1.99999ap0f) : coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.f0a3d8p-1f, 0x1.c28f5cp-1f), 0x1.000000p2f)), coax_p_mix(cx, l_disc, l_glow_patch, l_overcast));
  l_cl = coax_p_eg_st(cx, 15u);
  l_c2 = coax_p_eg_st(cx, 16u);
  if (((l_up > 0x1.47ae14p-7f) && (l_cl.x > 0.0f)))
  {
    l_t_2 = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
    l_p = coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_d.x, l_d.z), l_up), l_cl.y), coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_sw_xy_f4(cx, coax_p_eg_st(cx, 25u)), l_cl.z), l_t_2));
    l_n = coax_p_verse_style_cloud_field(cx, l_p.x, l_p.y, l_c2.x, l_c2.y, l_cl.w);
    l_cover = coax_p_verse_style_cloud_cover(cx, l_n, l_cl.x, l_c2.z, l_c2.w);
    l_toward = coax_p_wg_mul_f2f(cx, coax_p_wg_normalize2(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_l.x, l_l.z), coax_p_v2(cx, 0x1.a36e2ep-14f, 0x1.a36e2ep-14f))), 0x1.040000p8f);
    l_lit = coax_p_verse_style_cloud_lit(cx, l_n, coax_p_verse_style_cloud_field(cx, (l_p.x + l_toward.x), (l_p.y + l_toward.y), l_c2.x, l_c2.y, l_cl.w));
    l_night = (coax_p_eg_st(cx, 14u)).w;
    l_cloud = coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mix_f3f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 4u)), (coax_p_eg_st(cx, 17u)).w), 0x1.ccccccp-1f), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 17u)), l_lit), coax_p_fmax(cx, (coax_p_eg_st(cx, 0u)).w, 0x1.333334p-2f)), (0x1.000000p0f - (0x1.800000p-1f * l_night)));
    l_c = coax_p_wg_mix_f3f3f(cx, l_c, l_cloud, ((l_cover * coax_p_verse_style_cloud_fade(cx, l_up)) * (0x1.000000p0f - (0x1.000000p-1f * l_night))));
  }
  return coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_make_f3_f(cx, coax_p_eg_stars(cx, l_d)), (coax_p_eg_st(cx, 14u)).w), 0x1.333334p-1f));
}
float3 coax_p_eg_weather_sky(CoaxResources cx, float3 p_c, float3 p_d) {
  float3 l_c = p_c;
  float3 l_d = p_d;
  float l_cloud{};
  float3 l_grey{};
  float3 l_o{};
  l_cloud = (coax_p_fmax(cx, (cx.r_u[1478] - 0x1.333334p-3f), 0.0f) / 0x1.b33334p-1f);
  l_grey = coax_p_wg_mul_f3f3(cx, coax_p_wg_make_f3_f(cx, coax_p_verse_style_luma(cx, l_c.x, l_c.y, l_c.z)), coax_p_v3(cx, 0x1.b851ecp-1f, 0x1.d70a3ep-1f, 0x1.f5c290p-1f));
  l_o = coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, l_grey, (0x1.000000p0f - (0x1.000000p-2f * l_cloud))), (l_cloud * 0x1.666666p-1f));
  l_o = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.800000p-1f, 0x1.99999ap-1f, 0x1.000000p0f), cx.r_u[1475]), 0x1.99999ap-1f), coax_p_smoothstep(cx, (-0x1.99999ap-4f), 0x1.333334p-2f, l_d.y)));
  return l_o;
}
float3 coax_p_wg_min_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_p_fmin(cx, l_p0.x, l_p1.x), coax_p_fmin(cx, l_p0.y, l_p1.y), coax_p_fmin(cx, l_p0.z, l_p1.z));
}
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff) {
  float l_d = p_d;
  float l_y = p_y;
  float l_base_y = p_base_y;
  float l_start = p_start;
  float l_density = p_density;
  float l_cap = p_cap;
  float l_falloff = p_falloff;
  float l_dist{};
  float l_height{};
  l_dist = (0x1.000000p0f - exp(((-l_density) * coax_p_st_max(cx, (l_d - l_start), 0.0f))));
  l_height = exp(((-coax_p_st_max(cx, (l_y - l_base_y), 0.0f)) / coax_p_st_max(cx, l_falloff, 0x1.0624dep-10f)));
  return coax_p_st_min(cx, (l_dist * (0x1.000000p0f + ((l_height - 0x1.000000p0f) * 0x1.333334p-1f))), l_cap);
}
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap) {
  float l_h = p_h;
  float l_ch = p_ch;
  float l_f = p_f;
  float l_cap = p_cap;
  float l_t{};
  float l_far{};
  l_t = coax_p_verse_style_haze_teal(cx, l_ch);
  l_far = coax_p_verse_style_soft_step(cx, ((0x1.333334p-3f + l_cap) * 0x1.000000p-1f), ((l_cap - 0x1.333334p-3f) * 0x1.000000p-1f), l_f);
  return (l_h * (l_t + ((0x1.000000p0f - l_t) * l_far)));
}
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl) {
  float l_vdl = p_vdl;
  float l_a{};
  float l_a2{};
  float l_a4{};
  l_a = coax_p_st_sat(cx, l_vdl);
  l_a2 = (l_a * l_a);
  l_a4 = (l_a2 * l_a2);
  return ((l_a4 * l_a4) * 0x1.ccccccp-2f);
}
bool coax_p_eg_weather_desktop(CoaxResources cx) {
  return (cx.r_u[1068] >= 0x1.000000p3f);
}
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x) {
  float l_y = p_y;
  float l_x = p_x;
  float l_ax{};
  float l_ay{};
  float l_high{};
  float l_r{};
  l_ax = abs(l_x);
  l_ay = abs(l_y);
  l_high = coax_p_fmax(cx, l_ax, l_ay);
  if ((l_high == 0.0f))
  {
    return 0.0f;
  }
  l_r = coax_p_wg_atan01(cx, (coax_p_fmin(cx, l_ax, l_ay) / l_high));
  if ((l_ay > l_ax))
  {
    l_r = ((0x1.921fb6p1f * 0x1.000000p-1f) - l_r);
  }
  if ((l_x < 0.0f))
  {
    l_r = (0x1.921fb6p1f - l_r);
  }
  if ((l_y < 0.0f))
  {
    l_r = (-l_r);
  }
  return l_r;
}
float coax_p_wg_exp2(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return exp((l_x * 0x1.62e430p-1f));
}
bool coax_p_eg_weather_covered(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  uint l_n{};
  uint l_i{};
  float4 l_b{};
  if (((coax_p_wg_all_ge_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_wg_sw_xy_f4(cx, coax_p_EG_RAIN_BRIDGE(cx))) && coax_p_wg_all_le_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_wg_sw_zw_f4(cx, coax_p_EG_RAIN_BRIDGE(cx)))) && (l_p.y < cx.r_u[1482])))
  {
    return true;
  }
  l_n = coax_p_wg_u32_f(cx, cx.r_u[1483]);
  {
    l_i = 0u;
    while ((l_i < 32u))
    {
      if ((l_i >= l_n))
      {
        break;
      }
      l_b = coax_p_wg_at4(cx, ((int(l_i) * 4) + 1212));
      if ((coax_p_wg_all_ge_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_v2(cx, l_b.x, l_b.y)) && coax_p_wg_all_le_f2f2(cx, coax_p_v2(cx, l_p.x, l_p.z), coax_p_v2(cx, l_b.z, l_b.w))))
      {
        return true;
      }
      l_i = (l_i + 1u);
    }
  }
  return false;
}
float coax_p_wg_round(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_r{};
  l_r = floor((l_x + 0x1.000000p-1f));
  if ((((l_r - l_x) == 0x1.000000p-1f) && (coax_p_wg_fmod(cx, l_r, 0x1.000000p1f) != 0.0f)))
  {
    return (l_r - 0x1.000000p0f);
  }
  return l_r;
}
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b), (l_a.y + l_b));
}
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d) {
  float3 l_d = p_d;
  return ((coax_p_eg_water_eye_over(cx) + (0x1.99999ap-4f * l_d.y)) < 0.0f);
}
float coax_p_eg_water_eye_over(CoaxResources cx) {
  return ((cx.r_u[1072] >= 0x1.000000p1f) ? cx.r_u[1071] : 0x1.900000p6f);
}
float3 coax_p_EG_WATER_UNDER_ABSORB(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.ae147ap-2f, 0x1.eb851ep-4f, 0x1.70a3d8p-4f);
}
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, exp(l_p0.x), exp(l_p0.y), exp(l_p0.z));
}
float3 coax_p_EG_WATER_UNDER_SCATTER(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.99999ap-5f, 0x1.333334p-2f, 0x1.51eb86p-2f);
}
float3 coax_p_EG_WATER_UNDER_TINT(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.0a3d70p-1f, 0x1.ae147ap-1f, 0x1.e66666p-1f);
}
float coax_p_eg_water_motes(CoaxResources cx, float3 p_o, float3 p_d, float p_reach) {
  float3 l_o = p_o;
  float3 l_d = p_d;
  float l_reach = p_reach;
  float l_a{};
  int l_n{};
  int l_i{};
  float l_t{};
  float3 l_c{};
  float4 l_h{};
  float3 l_drift{};
  float3 l_m{};
  float l_along{};
  float l_off{};
  float l_size{};
  l_a = 0.0f;
  l_n = ((cx.r_u[1068] < 0x1.000000p3f) ? 3 : 6);
  {
    l_i = 0;
    while ((l_i < l_n))
    {
      l_t = (((float(l_i) + 0x1.000000p-1f) * l_reach) / float(l_n));
      l_c = coax_p_wg_floor_f3(cx, coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_t)));
      l_h = coax_p_eg_water_mote_hash(cx, l_c);
      if ((l_h.w > 0x1.000000p-2f))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_drift = coax_p_wg_mul_f3f(cx, coax_p_v3(cx, sin(((cx.r_u[1048] * 0x1.333334p-2f) + (l_h.x * 0x1.800000p2f))), cos(((cx.r_u[1048] * 0x1.d70a3ep-3f) + (l_h.y * 0x1.800000p2f))), 0.0f), 0x1.47ae14p-4f);
      l_m = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, l_h.x, l_h.y, l_h.z)), l_drift);
      l_along = coax_p_fmax(cx, coax_p_wg_dot3(cx, coax_p_wg_sub_f3f3(cx, l_m, l_o), l_d), 0x1.99999ap-5f);
      if ((l_along > l_reach))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_off = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, l_m, coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_along))));
      l_size = ((0x1.89374cp-7f * l_along) + 0x1.0624dep-8f);
      l_a = (l_a + (((0x1.000000p0f - coax_p_smoothstep(cx, (l_size * 0x1.99999ap-2f), l_size, l_off)) * 0x1.000000p-1f) * exp(((-l_along) * 0x1.000000p-2f))));
      l_i = (l_i + 1);
    }
  }
  return l_a;
}
float coax_p_eg_water_shafts(CoaxResources cx, float3 p_o, float3 p_d, float p_path, float p_level) {
  float3 l_o = p_o;
  float3 l_d = p_d;
  float l_path = p_path;
  float l_level = p_level;
  float l_sum{};
  float l_reach{};
  int l_i{};
  float l_t{};
  float3 l_q{};
  float l_below{};
  if ((cx.r_u[1068] < 0x1.000000p3f))
  {
    return 0.0f;
  }
  l_sum = 0.0f;
  l_reach = coax_p_fmin(cx, l_path, 0x1.000000p3f);
  {
    l_i = 0;
    while ((l_i < 16))
    {
      l_t = (((float(l_i) + 0x1.000000p-1f) / 0x1.000000p4f) * l_reach);
      l_q = coax_p_wg_add_f3f3(cx, l_o, coax_p_wg_mul_f3f(cx, l_d, l_t));
      l_below = coax_p_fmax(cx, (l_level - l_q.y), 0.0f);
      l_sum = (l_sum + (coax_p_eg_water_caustic_pattern(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_q.x, l_q.z), coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_sw_xz_f4(cx, coax_p_eg_st(cx, 1u)), l_below), 0x1.333334p-1f)), cx.r_u[1048]) * exp((((-l_below) * 0x1.000000p-1f) - (l_t * 0x1.333334p-2f)))));
      l_i = (l_i + 1);
    }
  }
  return (((l_sum / 0x1.000000p4f) * l_reach) * 0x1.666666p-2f);
}
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  uint l_h{};
  l_h = (l_word * 747796405u);
  l_h = ((l_h ^ (l_h >> uint(16u))) * 2246822519u);
  return (l_h ^ (l_h >> uint(13u)));
}
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float4 coax_p_eg_pond_row(CoaxResources cx, uint p_p) {
  uint l_p = p_p;
  float4 l_q{};
  l_q = coax_p_wg_at4(cx, ((int(l_p) * 4) + 1484));
  l_q.w = (l_q.w + cx.r_u[1480]);
  return l_q;
}
float2 coax_p_wg_clamp_f2f2f2(CoaxResources cx, float2 p_p0, float2 p_p1, float2 p_p2) {
  float2 l_p0 = p_p0;
  float2 l_p1 = p_p1;
  float2 l_p2 = p_p2;
  return coax_p_v2(cx, coax_p_clampf(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_clampf(cx, l_p0.y, l_p1.y, l_p2.y));
}
float coax_p_eg_water_node(CoaxResources cx, uint p_k, uint p_f) {
  uint l_k = p_k;
  uint l_f = p_f;
  return cx.r_water_nodes[int(((l_k * 8u) + l_f))];
}
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
float coax_p_eg_fountain_depth_at(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  float l_r{};
  float l_y{};
  if ((!coax_p_eg_fountain_on(cx)))
  {
    return (-0x1.000000p0f);
  }
  l_r = coax_p_wg_length2(cx, coax_p_v2(cx, l_p.x, l_p.z));
  l_y = (l_p.y - coax_p_eg_fountain_base(cx));
  if (((l_r < 0x1.51eb86p1f) && (l_y < (0x1.3d70a4p-1f + 0x1.47ae14p-4f))))
  {
    return (0x1.3d70a4p-1f - l_y);
  }
  if ((((l_r < 0x1.30a3d8p0f) && (l_y > 0x1.d9999ap0f)) && (l_y < (0x1.0b851ep1f + 0x1.47ae14p-4f))))
  {
    return (0x1.0b851ep1f - l_y);
  }
  return (-0x1.000000p0f);
}
float3 coax_p_reflect3(CoaxResources cx, float3 p_i, float3 p_n) {
  float3 l_i = p_i;
  float3 l_n = p_n;
  return coax_p_sub3(cx, l_i, coax_p_scale3(cx, l_n, (0x1.000000p1f * dot(l_n, l_i))));
}
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, floor(l_p0.x), floor(l_p0.y), floor(l_p0.z));
}
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y), coax_p_fract(cx, l_p0.z));
}
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a - l_b.x), (l_a - l_b.y), (l_a - l_b.z));
}
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  coax_t20 l_v{};
  l_v = coax_p_wg_add_u3u(cx, coax_p_wg_mul_u3u(cx, coax_p_wg_bits_u3i3(cx, coax_p_wg_cvt_i3f3(cx, l_p)), 1664525u), 1013904223u);
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  l_v.y = (l_v.y + (l_v.z * l_v.x));
  l_v.z = (l_v.z + (l_v.x * l_v.y));
  l_v = coax_p_wg_xor_u3u3(cx, l_v, coax_p_wg_shr_u3u3(cx, l_v, coax_p_u3(cx, 16u, 16u, 16u)));
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  return (float((l_v.x >> uint(8u))) / 0x1.fffffep23f);
}
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up) {
  float l_up = p_up;
  return coax_metal_pow(coax_p_st_max(cx, l_up, 0x1.0c6f7ap-20f), 0x1.19999ap-1f);
}
float coax_p_verse_style_sky_band(CoaxResources cx, float p_up, float p_lift) {
  float l_up = p_up;
  float l_lift = p_lift;
  return (l_lift * (0x1.000000p0f - coax_p_st_sat(cx, (abs(l_up) / 0x1.ac0832p-4f))));
}
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k) {
  float l_cos_t = p_cos_t;
  float l_k = p_k;
  return exp(((-l_k) * coax_p_st_max(cx, (0x1.000000p0f - l_cos_t), 0.0f)));
}
float2 coax_p_wg_sw_xy_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.x, l_p.y);
}
float coax_p_verse_style_cloud_field(CoaxResources cx, float p_x, float p_z, float p_s1, float p_s2, float p_octaves) {
  float l_x = p_x;
  float l_z = p_z;
  float l_s1 = p_s1;
  float l_s2 = p_s2;
  float l_octaves = p_octaves;
  float l_n{};
  l_n = coax_p_verse_style_noise(cx, (l_x * l_s1), (l_z * l_s1));
  if ((l_octaves < 0x1.800000p0f))
  {
    return l_n;
  }
  return ((l_n * 0x1.4cccccp-1f) + (coax_p_verse_style_noise(cx, ((l_x * l_s2) + 0x1.8cccccp1f), ((l_z * l_s2) + 0x1.ecccccp2f)) * 0x1.666666p-2f));
}
float coax_p_verse_style_cloud_cover(CoaxResources cx, float p_n, float p_cover, float p_cut_lo, float p_cut_hi) {
  float l_n = p_n;
  float l_cover = p_cover;
  float l_cut_lo = p_cut_lo;
  float l_cut_hi = p_cut_hi;
  return (coax_p_verse_style_soft_step(cx, ((l_cut_lo + l_cut_hi) * 0x1.000000p-1f), ((l_cut_hi - l_cut_lo) * 0x1.000000p-1f), (l_n + ((l_cover - 0x1.666666p-2f) * 0x1.99999ap-2f))) * coax_p_verse_style_soft_step(cx, 0x1.99999ap-6f, 0x1.99999ap-6f, l_cover));
}
float coax_p_verse_style_cloud_lit(CoaxResources cx, float p_n, float p_toward) {
  float l_n = p_n;
  float l_toward = p_toward;
  return coax_p_st_sat(cx, (((l_n - l_toward) * 0x1.400000p2f) + 0x1.19999ap-1f));
}
float coax_p_verse_style_cloud_fade(CoaxResources cx, float p_up) {
  float l_up = p_up;
  return (coax_p_verse_style_soft_step(cx, 0x1.5c28f6p-4f, 0x1.333334p-4f, l_up) * 0x1.d70a3ep-1f);
}
float coax_p_eg_stars(CoaxResources cx, float3 p_d) {
  float3 l_d = p_d;
  float2 l_q{};
  float2 l_g{};
  float l_h{};
  float2 l_at{};
  if ((l_d.y <= 0.0f))
  {
    return 0.0f;
  }
  l_q = coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_d.x, l_d.z), (l_d.y + 0x1.666666p-2f)), 0x1.040000p8f);
  l_g = coax_p_wg_floor_f2(cx, l_q);
  l_h = coax_p_eg_hash2(cx, l_g);
  if ((l_h < 0x1.dc28f6p-1f))
  {
    return 0.0f;
  }
  l_at = coax_p_wg_add_f2f(cx, coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, coax_p_eg_hash2(cx, coax_p_wg_add_f2f(cx, l_g, 0x1.b33334p0f)), coax_p_eg_hash2(cx, coax_p_wg_add_f2f(cx, l_g, 0x1.233334p3f))), 0x1.99999ap-1f)), 0x1.99999ap-4f);
  return (((l_h > 0x1.fbe76cp-1f) ? 0x1.800000p-1f : 0x1.47ae14p-2f) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.eb851ep-4f, 0x1.ae147ap-2f, coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_q, l_at)))));
}
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0) {
  float l_p0 = p_p0;
  return coax_p_v3(cx, l_p0, l_p0, l_p0);
}
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch) {
  float l_ch = p_ch;
  if ((l_ch < 0x1.000000p-1f))
  {
    return 0x1.666666p-1f;
  }
  if ((l_ch < 0x1.800000p0f))
  {
    return 0x1.000000p0f;
  }
  return 0x1.ae147ap-1f;
}
float coax_p_wg_atan01(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_z{};
  float l_p{};
  l_z = (l_x * l_x);
  l_p = (-0x1.09afcep-8f);
  l_p = ((l_p * l_z) + 0x1.662ca4p-6f);
  l_p = ((l_p * l_z) - 0x1.ca0388p-5f);
  l_p = ((l_p * l_z) + 0x1.8aefbep-4f);
  l_p = ((l_p * l_z) - 0x1.1cd8c6p-3f);
  l_p = ((l_p * l_z) + 0x1.98814cp-3f);
  l_p = ((l_p * l_z) - 0x1.554c38p-2f);
  l_p = ((l_p * l_z) + 0x1.ffffeap-1f);
  return (l_x * l_p);
}
float4 coax_p_EG_RAIN_BRIDGE(CoaxResources cx) {
  return coax_p_v4(cx, 0x1.500000p6f, (-0x1.200000p4f), 0x1.700000p6f, (-0x1.400000p2f));
}
bool coax_p_wg_all_ge_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x >= l_b.x) && (l_a.y >= l_b.y));
}
float2 coax_p_wg_sw_zw_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.z, l_p.w);
}
bool coax_p_wg_all_le_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x <= l_b.x) && (l_a.y <= l_b.y));
}
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  return (l_a - (l_b * coax_p_wg_trunc(cx, (l_a / l_b))));
}
float4 coax_p_eg_water_mote_hash(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  float4 l_h{};
  l_h = coax_p_v4(cx, coax_p_eg_water_hash(cx, l_c), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.100000p4f, 0x1.800000p1f, 0x1.400000p2f))), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.c00000p2f, 0x1.d00000p4f, 0x1.600000p3f))), coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_c, coax_p_v3(cx, 0x1.000000p1f, 0x1.a00000p3f, 0x1.f00000p4f))));
  return l_h;
}
float2 coax_p_wg_sw_xz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v2(cx, l_p.x, l_p.z);
}
bool coax_p_eg_fountain_on(CoaxResources cx) {
  return (cx.r_u[1079] > 0x1.000000p-1f);
}
float coax_p_eg_fountain_base(CoaxResources cx) {
  return cx.r_u[1078];
}
float3 coax_p_sub3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3((l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
coax_t21 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  return coax_p_i3(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y), coax_p_wg_i32_f(cx, l_p.z));
}
coax_t20 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t21 p_p) {
  coax_t21 l_p = p_p;
  return coax_p_u3(cx, uint(l_p.x), uint(l_p.y), uint(l_p.z));
}
coax_t20 coax_p_wg_mul_u3u(CoaxResources cx, coax_t20 p_a, uint p_b) {
  coax_t20 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
coax_t20 coax_p_wg_add_u3u(CoaxResources cx, coax_t20 p_a, uint p_b) {
  coax_t20 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x + l_b), (l_a.y + l_b), (l_a.z + l_b));
}
coax_t20 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z) {
  uint l_x = p_x;
  uint l_y = p_y;
  uint l_z = p_z;
  return coax_t20{l_x, l_y, l_z};
}
coax_t20 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t20 p_a, coax_t20 p_b) {
  coax_t20 l_a = p_a;
  coax_t20 l_b = p_b;
  return coax_p_u3(cx, (l_a.x >> uint(l_b.x)), (l_a.y >> uint(l_b.y)), (l_a.z >> uint(l_b.z)));
}
coax_t20 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t20 p_a, coax_t20 p_b) {
  coax_t20 l_a = p_a;
  coax_t20 l_b = p_b;
  return coax_p_u3(cx, (l_a.x ^ l_b.x), (l_a.y ^ l_b.y), (l_a.z ^ l_b.z));
}
float coax_p_eg_hash2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_wg_trunc(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x < 0.0f))
  {
    return (-floor((-l_x)));
  }
  return floor(l_x);
}
coax_t21 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z) {
  int l_x = p_x;
  int l_y = p_y;
  int l_z = p_z;
  return coax_t21{l_x, l_y, l_z};
}
vertex coax_io_9 eg_grass_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_grass_vs(cx, coax_vid, coax_iid);
  return coax_io_9{coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4};
}
fragment coax_out_14 eg_grass_fs(coax_io_9 coax_in [[stage_in]], CoaxResources cx) {
  auto coax_r = coax_p_eg_grass_fs(cx, coax_t9{coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4});
  return coax_out_14{coax_r.x, coax_r.y};
}
