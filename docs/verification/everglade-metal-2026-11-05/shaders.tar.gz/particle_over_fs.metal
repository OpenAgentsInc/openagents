// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t8 {
  float4 x;
  float4 y;
  float4 z;
};
struct coax_t11 {
  float4 x;
  float2 y;
  float4 z;
  float4 w;
  float2 f4;
  float f5;
};
struct coax_io_11 {
  float4 x [[position]];
  float2 y [[user(locn0)]];
  float4 z [[user(locn1)]];
  float4 w [[user(locn2)]] [[flat]];
  float2 f4 [[user(locn3)]];
  float f5 [[user(locn4)]] [[flat]];
};
struct coax_t15 {
  int x;
  int y;
};
struct coax_t16 {
  uint x;
  uint y;
};
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(coax_t8) == 48, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  device const coax_t8* r_puffs [[buffer(1)]];
  depth2d<float> r_particle_depth [[texture(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
coax_t11 coax_p_egfx_particle_over_vs(CoaxResources cx, uint p_v, uint p_n);
float4 coax_p_egfx_particle_over_fs(CoaxResources cx, coax_t11 p_p);
coax_t11 coax_p_egfx_gone(CoaxResources cx);
coax_t11 coax_p_egfx_place(CoaxResources cx, uint p_v, uint p_n);
float coax_p_egfx_billow(CoaxResources cx, float2 p_c, float p_seed, float p_rag, float p_soft, float p_cover);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float coax_p_egfx_far(CoaxResources cx, float p_d);
float coax_p_egfx_soft(CoaxResources cx, coax_t11 p_p);
float3 coax_p_egfx_fire(CoaxResources cx, coax_t11 p_p, float p_m);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_egfx_churn(CoaxResources cx, float2 p_c, float p_seed);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
float coax_p_fract(CoaxResources cx, float p_x);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_wg_length3(CoaxResources cx, float3 p_a);
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
float4 coax_p_egfx_clip(CoaxResources cx, float3 p_w);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b);
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b);
coax_t15 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p);
coax_t15 coax_p_i2(CoaxResources cx, int p_x, int p_y);
coax_t16 coax_p_wg_dims_depth(CoaxResources cx);
coax_t15 coax_p_wg_cvt_i2u2(CoaxResources cx, coax_t16 p_p);
coax_t15 coax_p_wg_sub_i2i(CoaxResources cx, coax_t15 p_a, int p_b);
coax_t15 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t15 p_p0, coax_t15 p_p1, coax_t15 p_p2);
float coax_p_wg_load_depth(CoaxResources cx, coax_t15 p_c, int p_level);
float coax_p_egfx_noise2(CoaxResources cx, float2 p_p);
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2);
float coax_p_saturate(CoaxResources cx, float p_x);
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
coax_t16 coax_p_u2(CoaxResources cx, uint p_x, uint p_y);
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high);
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b);
float coax_p_egfx_hash2(CoaxResources cx, float2 p_p);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b);
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b);
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y);
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x);
uint coax_p_render_noise_cell(CoaxResources cx, float p_x);
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_render_noise_unit(CoaxResources cx, uint p_word);
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word);
coax_t11 coax_p_egfx_particle_over_vs(CoaxResources cx, uint p_v, uint p_n) {
  uint l_v = p_v;
  uint l_n = p_n;
  float l_kind{};
  l_kind = floor(cx.r_puffs[int(l_n)].z.w);
  if (((l_kind != 0x1.000000p0f) && (l_kind != 0.0f)))
  {
    return coax_p_egfx_gone(cx);
  }
  return coax_p_egfx_place(cx, l_v, l_n);
}
float4 coax_p_egfx_particle_over_fs(CoaxResources cx, coax_t11 p_p) {
  coax_t11 l_p = p_p;
  float l_m{};
  float l_a{};
  float l_m_5{};
  float l_a_6{};
  float l_n{};
  float l_r{};
  float l_bulge{};
  float l_up{};
  float l_lit{};
  if ((l_p.w.x == 0.0f))
  {
    l_m = coax_p_egfx_billow(cx, l_p.y, l_p.w.y, 0x1.333334p-1f, 0x1.47ae14p-4f, l_p.w.z);
    if ((l_m <= 0x1.0624dep-9f))
    {
      discard_fragment();
    }
    l_a = (((coax_p_clampf(cx, l_m, 0.0f, 0x1.000000p0f) * l_p.f5) * coax_p_egfx_far(cx, l_p.w.w)) * coax_p_egfx_soft(cx, l_p));
    return coax_p_wg_make_f4_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_egfx_fire(cx, l_p, l_m), l_a), l_a);
  }
  l_m_5 = coax_p_egfx_billow(cx, l_p.y, l_p.w.y, 0x1.666666p-1f, 0x1.eb851ep-4f, l_p.z.w);
  if ((l_m_5 <= 0x1.0624dep-9f))
  {
    discard_fragment();
  }
  l_a_6 = (((coax_p_clampf(cx, (l_m_5 * coax_p_fmin(cx, (l_p.z.w * 0x1.99999ap0f), 0x1.d70a3ep-1f)), 0.0f, 0x1.000000p0f) * l_p.f5) * coax_p_egfx_far(cx, l_p.w.w)) * coax_p_egfx_soft(cx, l_p));
  l_n = coax_p_egfx_churn(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_p.y, 0x1.19999ap0f), coax_p_v2(cx, 0.0f, 0x1.99999ap-2f)), (l_p.w.y + 0x1.800000p1f));
  l_r = coax_p_wg_length2(cx, l_p.y);
  l_bulge = sqrt(coax_p_fmax(cx, (0x1.000000p0f - (l_r * l_r)), 0.0f));
  l_up = coax_p_clampf(cx, (0x1.000000p-1f + (0x1.000000p-1f * ((l_p.y.y + (0x1.333334p-1f * l_bulge)) - 0x1.333334p-2f))), 0.0f, 0x1.000000p0f);
  l_lit = coax_p_mix(cx, 0x1.000000p-1f, 0x1.4cccccp0f, coax_p_smoothstep(cx, 0x1.ae147ap-2f, 0x1.000000p-1f, (l_up * (0x1.19999ap-1f + (0x1.99999ap-1f * l_n)))));
  return coax_p_wg_make_f4_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_p.z.x, l_p.z.y, l_p.z.z), l_lit), l_a_6), l_a_6);
}
coax_t11 coax_p_egfx_gone(CoaxResources cx) {
  coax_t11 l_o{};
  l_o = coax_t11{};
  l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
  return l_o;
}
coax_t11 coax_p_egfx_place(CoaxResources cx, uint p_v, uint p_n) {
  uint l_v = p_v;
  uint l_n = p_n;
  coax_t11 l_o{};
  coax_t8 l_e{};
  array<float2, 6> l_quad{};
  float2 l_c{};
  float l_kind{};
  float l_seed{};
  float l_size{};
  float3 l_to_eye{};
  float l_d{};
  float3 l_view{};
  float3 l_w{};
  float l_streak{};
  float l_along{};
  float3 l_a{};
  float3 l_side{};
  float3 l_right{};
  float3 l_up{};
  l_o = coax_t11{};
  l_e = cx.r_puffs[int(l_n)];
  l_quad = array<float2, 6>{coax_p_v2(cx, (-0x1.000000p0f), (-0x1.000000p0f)), coax_p_v2(cx, 0x1.000000p0f, (-0x1.000000p0f)), coax_p_v2(cx, (-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(cx, (-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(cx, 0x1.000000p0f, (-0x1.000000p0f)), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f)};
  l_c = l_quad[int(l_v)];
  l_kind = floor(l_e.z.w);
  l_seed = (coax_p_fract(cx, l_e.z.w) * 0x1.000000p1f);
  l_size = l_e.x.w;
  l_to_eye = coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_v3(cx, l_e.x.x, l_e.x.y, l_e.x.z));
  l_d = coax_p_fmax(cx, coax_p_wg_length3(cx, l_to_eye), 0x1.0624dep-10f);
  l_view = coax_p_wg_div_f3f(cx, l_to_eye, l_d);
  l_w = coax_p_v3(cx, l_e.x.x, l_e.x.y, l_e.x.z);
  l_streak = ((l_kind == 0x1.000000p1f) ? coax_p_wg_length3(cx, coax_p_v3(cx, l_e.z.x, l_e.z.y, l_e.z.z)) : 0.0f);
  l_along = 0.0f;
  if ((l_kind == 0x1.800000p1f))
  {
    l_w = coax_p_wg_add_f3f3(cx, l_w, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_c.x, 0.0f, l_c.y), l_size));
  }
  else
  {
    if ((l_streak > 0x1.0624dep-10f))
    {
      l_a = coax_p_wg_div_f3f(cx, coax_p_v3(cx, l_e.z.x, l_e.z.y, l_e.z.z), l_streak);
      l_side = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_cross3(cx, l_a, l_view), coax_p_v3(cx, 0x1.4f8b58p-17f, 0.0f, 0.0f)));
      l_w = coax_p_wg_add_f3f3(cx, l_w, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_a, l_c.x), (l_streak + l_size)), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_side, l_c.y), l_size)));
      l_along = (l_streak / coax_p_fmax(cx, l_size, 0x1.0624dep-10f));
    }
    else
    {
      l_right = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_cross3(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_view), coax_p_v3(cx, 0x1.4f8b58p-17f, 0.0f, 0.0f)));
      l_up = coax_p_wg_cross3(cx, l_view, l_right);
      l_w = coax_p_wg_add_f3f3(cx, l_w, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_right, l_c.x), coax_p_wg_mul_f3f(cx, l_up, l_c.y)), l_size), coax_p_wg_mul_f3f(cx, l_view, coax_p_fmin(cx, (l_size * 0x1.99999ap-3f), (l_d * 0x1.000000p-1f)))));
    }
  }
  l_o.x = coax_p_egfx_clip(cx, l_w);
  l_o.f4 = coax_p_v2(cx, l_o.x.w, coax_p_fmax(cx, (l_size * 0x1.333334p-1f), 0x1.333334p-3f));
  l_o.y = l_c;
  l_o.z = l_e.y;
  l_o.w = coax_p_v4(cx, l_kind, l_seed, ((l_kind == 0.0f) ? l_e.z.x : l_along), l_d);
  l_o.f5 = ((l_kind == 0x1.800000p1f) ? 0x1.000000p0f : coax_p_smoothstep(cx, ((l_size * 0x1.ccccccp-1f) + 0x1.333334p-2f), ((l_size * 0x1.19999ap1f) + 0x1.000000p0f), l_d));
  return l_o;
}
float coax_p_egfx_billow(CoaxResources cx, float2 p_c, float p_seed, float p_rag, float p_soft, float p_cover) {
  float2 l_c = p_c;
  float l_seed = p_seed;
  float l_rag = p_rag;
  float l_soft = p_soft;
  float l_cover = p_cover;
  float l_n{};
  float l_edge{};
  l_n = coax_p_egfx_churn(cx, l_c, l_seed);
  l_edge = (((0x1.000000p0f - coax_p_wg_length2(cx, l_c)) + ((l_n - 0x1.000000p-1f) * l_rag)) - ((0x1.000000p0f - coax_p_clampf(cx, l_cover, 0.0f, 0x1.000000p0f)) * (0x1.000000p0f + (0x1.000000p-1f * l_rag))));
  return coax_p_smoothstep(cx, 0.0f, l_soft, l_edge);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float coax_p_egfx_far(CoaxResources cx, float p_d) {
  float l_d = p_d;
  return exp((((-coax_p_fmax(cx, (l_d - 0x1.900000p4f), 0.0f)) * coax_p_fmax(cx, cx.r_u[27], 0x1.0624dep-9f)) * 0x1.800000p0f));
}
float coax_p_egfx_soft(CoaxResources cx, coax_t11 p_p) {
  coax_t11 l_p = p_p;
  float l_b{};
  float3 l_ahead{};
  float l_a{};
  coax_t15 l_at{};
  float l_z{};
  float l_under{};
  float l_scene{};
  l_b = coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), coax_p_wg_make_f4_f3f(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), 0x1.000000p0f));
  l_ahead = coax_p_wg_add_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22]));
  l_a = ((l_b - coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), coax_p_v4(cx, l_ahead.x, l_ahead.y, l_ahead.z, 0x1.000000p0f))) / coax_p_fmax(cx, coax_p_wg_dot3(cx, coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22]), coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22])), 0x1.0c6f7ap-20f));
  l_at = coax_p_wg_clamp_i2i2i2(cx, coax_p_wg_cvt_i2f2(cx, coax_p_v2(cx, l_p.x.x, l_p.x.y)), coax_p_i2(cx, 0, 0), coax_p_wg_sub_i2i(cx, coax_p_wg_cvt_i2u2(cx, coax_p_wg_dims_depth(cx)), 1));
  l_z = coax_p_wg_load_depth(cx, l_at, 0);
  l_under = (l_z + l_a);
  l_scene = ((abs(l_under) > 0x1.ad7f2ap-24f) ? (l_b / l_under) : 0x1.e84800p19f);
  return coax_p_clampf(cx, ((l_scene - l_p.f4.x) / l_p.f4.y), 0.0f, 0x1.000000p0f);
}
float3 coax_p_egfx_fire(CoaxResources cx, coax_t11 p_p, float p_m) {
  coax_t11 l_p = p_p;
  float l_m = p_m;
  float l_n{};
  float l_r{};
  float l_bulge{};
  float l_v{};
  float l_band{};
  float l_heart{};
  float3 l_c{};
  l_n = ((0x1.333334p-1f * coax_p_egfx_churn(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_p.y, 0x1.99999ap0f), coax_p_v2(cx, 0.0f, ((-cx.r_u[2]) * 0x1.666666p-1f))), (l_p.w.y + 0x1.400000p2f))) + (0x1.99999ap-2f * coax_p_egfx_noise2(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_p.y, 0x1.600000p2f), coax_p_v2(cx, (l_p.w.y * 0x1.f00000p4f), ((-cx.r_u[2]) * 0x1.19999ap1f))))));
  l_r = coax_p_wg_length2(cx, l_p.y);
  l_bulge = sqrt(coax_p_fmax(cx, (0x1.000000p0f - (l_r * l_r)), 0.0f));
  l_v = (l_bulge * (0x1.000000p-1f + (0x1.99999ap-1f * l_n)));
  l_band = ((coax_p_smoothstep(cx, 0x1.70a3d8p-3f, 0x1.0a3d70p-2f, l_v) * 0x1.ccccccp-2f) + (coax_p_smoothstep(cx, 0x1.000000p-1f, 0x1.28f5c2p-1f, l_v) * 0x1.19999ap-1f));
  l_heart = (l_p.z.w * coax_p_smoothstep(cx, 0x1.70a3d8p-1f, 0x1.99999ap-1f, l_v));
  l_c = coax_p_wg_mix_f3f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, l_p.z.x, l_p.z.y, l_p.z.z), coax_p_v3(cx, 0x1.ae147ap-2f, 0x1.99999ap-3f, 0x1.0a3d70p-3f)), coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_p.z.x, l_p.z.y, l_p.z.z), 0x1.266666p0f), l_band);
  return coax_p_wg_mix_f3f3f(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.c28f5cp-1f, 0x1.3d70a4p-1f), coax_p_fmax(cx, coax_p_fmax(cx, l_p.z.x, 0x1.666666p-1f), 0x1.000000p0f)), 0x1.400000p0f), l_heart);
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_egfx_churn(CoaxResources cx, float2 p_c, float p_seed) {
  float2 l_c = p_c;
  float l_seed = p_seed;
  float l_t{};
  l_t = cx.r_u[2];
  return ((0x1.3d70a4p-1f * coax_p_egfx_noise2(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_c, 0x1.b33334p0f), coax_p_v2(cx, ((l_seed * 0x1.300000p4f) + (l_t * 0x1.666666p-2f)), ((l_seed * 0x1.c00000p2f) - (l_t * 0x1.19999ap-1f)))))) + (0x1.851eb8p-2f * coax_p_egfx_noise2(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_c, 0x1.f33334p1f), coax_p_v2(cx, ((-l_t) * 0x1.ccccccp-1f), ((l_seed * 0x1.a00000p3f) + (l_t * 0x1.99999ap-2f)))))));
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float coax_p_wg_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x / l_b), (l_a.y / l_b), (l_a.z / l_b));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_cross3(cx, l_a, l_b);
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
float4 coax_p_egfx_clip(CoaxResources cx, float3 p_w) {
  float3 l_w = p_w;
  float4 l_p{};
  l_p = coax_p_v4(cx, l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  return coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), l_p));
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return dot(l_a, l_b);
}
coax_t15 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_i2(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y));
}
coax_t15 coax_p_i2(CoaxResources cx, int p_x, int p_y) {
  int l_x = p_x;
  int l_y = p_y;
  return coax_t15{l_x, l_y};
}
coax_t16 coax_p_wg_dims_depth(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_particle_depth).get_width(), (cx.r_particle_depth).get_height());
}
coax_t15 coax_p_wg_cvt_i2u2(CoaxResources cx, coax_t16 p_p) {
  coax_t16 l_p = p_p;
  return coax_p_i2(cx, int(l_p.x), int(l_p.y));
}
coax_t15 coax_p_wg_sub_i2i(CoaxResources cx, coax_t15 p_a, int p_b) {
  coax_t15 l_a = p_a;
  int l_b = p_b;
  return coax_p_i2(cx, (l_a.x - l_b), (l_a.y - l_b));
}
coax_t15 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t15 p_p0, coax_t15 p_p1, coax_t15 p_p2) {
  coax_t15 l_p0 = p_p0;
  coax_t15 l_p1 = p_p1;
  coax_t15 l_p2 = p_p2;
  return coax_p_i2(cx, coax_p_wg_clamp_i(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_wg_clamp_i(cx, l_p0.y, l_p1.y, l_p2.y));
}
float coax_p_wg_load_depth(CoaxResources cx, coax_t15 p_c, int p_level) {
  coax_t15 l_c = p_c;
  int l_level = p_level;
  return (cx.r_particle_depth).read(uint2(l_c.x, l_c.y), uint(l_level));
}
float coax_p_egfx_noise2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float2 l_i{};
  float2 l_f{};
  float2 l_s{};
  l_i = coax_p_wg_floor_f2(cx, l_p);
  l_f = coax_p_wg_fract_f2(cx, l_p);
  l_s = coax_p_wg_mul_f2f2(cx, coax_p_wg_mul_f2f2(cx, l_f, l_f), coax_p_wg_sub_ff2(cx, 0x1.800000p1f, coax_p_wg_mul_ff2(cx, 0x1.000000p1f, l_f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_egfx_hash2(cx, l_i), coax_p_egfx_hash2(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0.0f))), l_s.x), coax_p_mix(cx, coax_p_egfx_hash2(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0.0f, 0x1.000000p0f))), coax_p_egfx_hash2(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f))), l_s.x), l_s.y);
}
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b.x), (l_a.y * l_b.y), (l_a.z * l_b.z));
}
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_mix(cx, l_p0.x, l_p1.x, l_p2), coax_p_mix(cx, l_p0.y, l_p1.y, l_p2), coax_p_mix(cx, l_p0.z, l_p1.z, l_p2));
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
coax_t16 coax_p_u2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_t16{l_x, l_y};
}
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high) {
  int l_x = p_x;
  int l_low = p_low;
  int l_high = p_high;
  return coax_p_wg_min_i(cx, coax_p_wg_max_i(cx, l_x, l_low), l_high);
}
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, floor(l_p0.x), floor(l_p0.y));
}
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y));
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a * l_b.x), (l_a * l_b.y));
}
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a - l_b.x), (l_a - l_b.y));
}
float coax_p_egfx_hash2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  if (((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix2(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y)));
}
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return ((l_x >= (-0x1.fffffep127f)) && (l_x <= 0x1.fffffep127f));
}
uint coax_p_render_noise_cell(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_bounded{};
  l_bounded = coax_p_fmin(cx, coax_p_fmax(cx, l_x, (-0x1.000000p25f)), 0x1.fffffep24f);
  return uint(int(floor((l_bounded * 0x1.000000p6f))));
}
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_p_render_noise_permute(cx, ((l_x * 1597334677u) ^ (l_y * 3812015801u)));
}
float coax_p_render_noise_unit(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  return (float((l_word >> uint(8u))) * 0x1.000000p-24f);
}
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  uint l_h{};
  l_h = (l_word * 747796405u);
  l_h = ((l_h ^ (l_h >> uint(16u))) * 2246822519u);
  return (l_h ^ (l_h >> uint(13u)));
}
vertex coax_io_11 egfx_particle_over_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_egfx_particle_over_vs(cx, coax_vid, coax_iid);
  return coax_io_11{coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4, coax_r.f5};
}
fragment float4 egfx_particle_over_fs(coax_io_11 coax_in [[stage_in]], CoaxResources cx) {
  auto coax_r = coax_p_egfx_particle_over_fs(cx, coax_t11{coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4, coax_in.f5});
  return coax_r;
}
