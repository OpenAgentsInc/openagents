// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t13 {
  int x;
  int y;
};
struct coax_t14 {
  float4 x;
  float4 y;
  float4 z;
  float4 w;
};
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  texture2d<float> r_post_light [[texture(0)]];
  texture2d<float> r_post_quarter [[texture(1)]];
  texture2d<float> r_post_eighth [[texture(2)]];
  texture2d<float> r_post_aux [[texture(3)]];
  sampler r_post_lin [[sampler(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1);
float4 coax_p_eg_post_fs(CoaxResources cx, float4 p_pos);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
coax_t13 coax_p_eg_water_waver_at(CoaxResources cx, float2 p_pos);
float4 coax_p_wg_load_2d(CoaxResources cx, coax_t13 p_c, int p_level);
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p);
float3 coax_p_eg_water_meniscus(CoaxResources cx, float3 p_c, float2 p_pos);
float2 coax_p_wg_at2(CoaxResources cx, int p_at);
float2 coax_p_wg_div_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float4 coax_p_eg_st(CoaxResources cx, uint p_i);
coax_t13 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p);
float4 coax_p_wg_load_2d_1(CoaxResources cx, coax_t13 p_c, int p_level);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float2 coax_p_wg_div_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2);
float coax_p_verse_style_bloom_mix(CoaxResources cx, float p_c, float p_bloom, float p_amount);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float coax_p_eg_shafts(CoaxResources cx, float2 p_p, float2 p_uv);
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p);
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b);
float3 coax_p_eg_tone(CoaxResources cx, float3 p_c);
float3 coax_p_eg_encode(CoaxResources cx, float3 p_c);
float3 coax_p_eg_plates(CoaxResources cx, float2 p_p, float3 p_under);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float coax_p_eg_water_eye_over(CoaxResources cx);
bool coax_p_eg_weather_desktop(CoaxResources cx);
float3 coax_p_eg_pixel_ray(CoaxResources cx, float2 p_p);
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
coax_t13 coax_p_i2(CoaxResources cx, int p_x, int p_y);
coax_t13 coax_p_wg_sub_i2i(CoaxResources cx, coax_t13 p_a, int p_b);
coax_t13 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t13 p_p0, coax_t13 p_p1, coax_t13 p_p2);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
float coax_p_saturate(CoaxResources cx, float p_x);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w);
float coax_p_verse_style_shaft_fade(CoaxResources cx, float p_x, float p_y, float p_margin);
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b);
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_fract(CoaxResources cx, float p_x);
bool coax_p_wg_any_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
bool coax_p_wg_any_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_verse_style_shaft_tap(CoaxResources cx, float p_i, float p_decay);
float coax_p_verse_style_shaft_total(CoaxResources cx, float p_n, float p_decay);
float coax_p_verse_style_shaft(CoaxResources cx, float p_sum, float p_total, float p_weight, float p_fade);
float coax_p_verse_style_tone(CoaxResources cx, float p_c, float p_exposure);
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b);
float coax_p_verse_style_saturation(CoaxResources cx, float p_c, float p_lum, float p_amount);
float coax_p_verse_style_lift(CoaxResources cx, float p_c, float p_lift);
float3 coax_p_wg_clamp_f3f3f3(CoaxResources cx, float3 p_p0, float3 p_p1, float3 p_p2);
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0);
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float3 coax_p_eg_plate(CoaxResources cx, float2 p_p, float3 p_under, float4 p_r, float4 p_s);
coax_t14 coax_p_eg_unview(CoaxResources cx);
float4 coax_p_m4_apply(CoaxResources cx, coax_t14 p_m, float4 p_v);
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b);
float coax_p_st_max(CoaxResources cx, float p_a, float p_b);
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x);
float coax_p_st_sat(CoaxResources cx, float p_x);
float3 coax_p_eg_hud_rect(CoaxResources cx, float2 p_p, float3 p_under, float4 p_r, float4 p_s);
float2 coax_p_wg_abs_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_max_f2f2(CoaxResources cx, float2 p_p0, float2 p_p1);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
coax_t14 coax_p_wg_transpose(CoaxResources cx, coax_t14 p_m);
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b);
float4 coax_p_scale4(CoaxResources cx, float4 p_a, float p_k);
float4 coax_p_add4(CoaxResources cx, float4 p_a, float4 p_b);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b);
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b);
float coax_p_st_min(CoaxResources cx, float p_a, float p_b);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
float4 coax_p_eg_bg_vs(CoaxResources cx, uint p_i, uint p__iid1) {
  uint l_i = p_i;
  uint l__iid1 = p__iid1;
  array<float2, 3> l_p{};
  l_p = array<float2, 3>{coax_p_v2(cx, (-0x1.000000p0f), (-0x1.800000p1f)), coax_p_v2(cx, (-0x1.000000p0f), 0x1.000000p0f), coax_p_v2(cx, 0x1.800000p1f, 0x1.000000p0f)};
  return coax_p_v4(cx, l_p[int(l_i)].x, l_p[int(l_i)].y, 0.0f, 0x1.000000p0f);
}
float4 coax_p_eg_post_fs(CoaxResources cx, float4 p_pos) {
  float4 l_pos = p_pos;
  float3 l_light{};
  float2 l_uv{};
  float l_soft_k{};
  float l_far{};
  float2 l_t{};
  float3 l_soft{};
  float3 l_b{};
  float l_m{};
  float3 l_c{};
  l_light = coax_p_eg_water_meniscus(cx, coax_p_wg_sw_rgb_f4(cx, coax_p_wg_load_2d(cx, coax_p_eg_water_waver_at(cx, coax_p_v2(cx, l_pos.x, l_pos.y)), 0)), coax_p_v2(cx, l_pos.x, l_pos.y));
  l_uv = coax_p_wg_div_f2f2(cx, coax_p_v2(cx, l_pos.x, l_pos.y), coax_p_wg_at2(cx, 0));
  l_soft_k = (((coax_p_eg_st(cx, 31u)).z > 0x1.000000p-1f) ? 0x1.666666p-1f : 0x1.000000p0f);
  l_far = coax_p_smoothstep(cx, (0x1.800000p3f * l_soft_k), (0x1.400000p5f * l_soft_k), ((coax_p_wg_load_2d_1(cx, coax_p_wg_cvt_i2f2(cx, coax_p_v2(cx, l_pos.x, l_pos.y)), 0)).y * 0x1.000000p8f));
  if ((l_far > 0.0f))
  {
    l_t = coax_p_wg_div_ff2(cx, 0x1.4cccccp-1f, coax_p_wg_at2(cx, 0));
    l_soft = coax_p_wg_mul_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_post_light).sample(cx.r_post_lin, coax_p_wg_add_f2f2(cx, l_uv, l_t), level(0.0f))), coax_p_wg_sw_rgb_f4(cx, (cx.r_post_light).sample(cx.r_post_lin, coax_p_wg_sub_f2f2(cx, l_uv, l_t), level(0.0f)))), coax_p_wg_sw_rgb_f4(cx, (cx.r_post_light).sample(cx.r_post_lin, coax_p_wg_add_f2f2(cx, l_uv, coax_p_v2(cx, l_t.x, (-l_t.y))), level(0.0f)))), coax_p_wg_sw_rgb_f4(cx, (cx.r_post_light).sample(cx.r_post_lin, coax_p_wg_add_f2f2(cx, l_uv, coax_p_v2(cx, (-l_t.x), l_t.y)), level(0.0f)))), 0x1.000000p-2f);
    l_light = coax_p_wg_mix_f3f3f(cx, l_light, l_soft, l_far);
  }
  l_b = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_post_quarter).sample(cx.r_post_lin, l_uv, level(0.0f))), 0x1.19999ap-1f), coax_p_wg_mul_f3f(cx, coax_p_wg_sw_rgb_f4(cx, (cx.r_post_eighth).sample(cx.r_post_lin, l_uv, level(0.0f))), 0x1.ccccccp-2f));
  l_m = (coax_p_eg_st(cx, 19u)).z;
  l_c = coax_p_v3(cx, coax_p_verse_style_bloom_mix(cx, l_light.x, l_b.x, l_m), coax_p_verse_style_bloom_mix(cx, l_light.y, l_b.y, l_m), coax_p_verse_style_bloom_mix(cx, l_light.z, l_b.z, l_m));
  l_c = coax_p_wg_add_f3f3(cx, l_c, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_ff3(cx, coax_p_eg_shafts(cx, coax_p_v2(cx, l_pos.x, l_pos.y), l_uv), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u))), (coax_p_eg_st(cx, 0u)).w));
  return coax_p_wg_make_f4_f3f(cx, coax_p_eg_plates(cx, coax_p_v2(cx, l_pos.x, l_pos.y), coax_p_eg_encode(cx, coax_p_wg_mul_f3f(cx, coax_p_eg_tone(cx, l_c), cx.r_u[3]))), 0x1.000000p0f);
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
coax_t13 coax_p_eg_water_waver_at(CoaxResources cx, float2 p_pos) {
  float2 l_pos = p_pos;
  float l_over{};
  float l_t{};
  float l_px{};
  float2 l_o{};
  l_over = coax_p_eg_water_eye_over(cx);
  if ((((!coax_p_eg_weather_desktop(cx)) || (l_over > 0x1.99999ap-3f)) || ((l_over > (-0x1.99999ap-4f)) && (!coax_p_eg_water_pixel_under(cx, coax_p_eg_pixel_ray(cx, l_pos))))))
  {
    return coax_p_wg_cvt_i2f2(cx, l_pos);
  }
  l_t = cx.r_u[1048];
  l_px = ((0x1.800000p1f * cx.r_u[1]) / 0x1.c20000p9f);
  l_o = coax_p_wg_mul_f2f(cx, coax_p_v2(cx, sin(((l_pos.y * 0x1.47ae14p-6f) + (l_t * 0x1.b33334p0f))), cos(((l_pos.x * 0x1.16872cp-6f) + (l_t * 0x1.4cccccp0f)))), l_px);
  return coax_p_wg_clamp_i2i2i2(cx, coax_p_wg_cvt_i2f2(cx, coax_p_wg_add_f2f2(cx, l_pos, l_o)), coax_p_i2(cx, 0, 0), coax_p_wg_sub_i2i(cx, coax_p_wg_cvt_i2f2(cx, coax_p_wg_at2(cx, 0)), 1));
}
float4 coax_p_wg_load_2d(CoaxResources cx, coax_t13 p_c, int p_level) {
  coax_t13 l_c = p_c;
  int l_level = p_level;
  return (cx.r_post_light).read(uint2(l_c.x, l_c.y), uint(l_level));
}
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_eg_water_meniscus(CoaxResources cx, float3 p_c, float2 p_pos) {
  float3 l_c = p_c;
  float2 l_pos = p_pos;
  float l_line{};
  if (((!coax_p_eg_weather_desktop(cx)) || (abs(coax_p_eg_water_eye_over(cx)) > 0x1.99999ap-3f)))
  {
    return l_c;
  }
  l_line = (coax_p_eg_water_eye_over(cx) + (0x1.99999ap-4f * (coax_p_eg_pixel_ray(cx, l_pos)).y));
  if ((l_line >= 0.0f))
  {
    return l_c;
  }
  return coax_p_wg_mix_f3f3f(cx, l_c, coax_p_v3(cx, 0x1.b33334p-1f, 0x1.e66666p-1f, 0x1.e66666p-1f), ((0x1.000000p0f - coax_p_smoothstep(cx, 0.0f, 0x1.89374cp-8f, (-l_line))) * 0x1.666666p-1f));
}
float2 coax_p_wg_at2(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v2(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)]);
}
float2 coax_p_wg_div_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x / l_b.x), (l_a.y / l_b.y));
}
float4 coax_p_eg_st(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return coax_p_wg_at4(cx, ((int(l_i) * 4) + 1084));
}
coax_t13 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_i2(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y));
}
float4 coax_p_wg_load_2d_1(CoaxResources cx, coax_t13 p_c, int p_level) {
  coax_t13 l_c = p_c;
  int l_level = p_level;
  return (cx.r_post_aux).read(uint2(l_c.x, l_c.y), uint(l_level));
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float2 coax_p_wg_div_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a / l_b.x), (l_a / l_b.y));
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_mix(cx, l_p0.x, l_p1.x, l_p2), coax_p_mix(cx, l_p0.y, l_p1.y, l_p2), coax_p_mix(cx, l_p0.z, l_p1.z, l_p2));
}
float coax_p_verse_style_bloom_mix(CoaxResources cx, float p_c, float p_bloom, float p_amount) {
  float l_c = p_c;
  float l_bloom = p_bloom;
  float l_amount = p_amount;
  return (l_c + (l_bloom * l_amount));
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float coax_p_eg_shafts(CoaxResources cx, float2 p_p, float2 p_uv) {
  float2 l_p = p_p;
  float2 l_uv = p_uv;
  float4 l_sh{};
  float4 l_k{};
  float2 l_at{};
  float l_fade{};
  float l_n{};
  float2 l_step{};
  float l_jitter{};
  float l_sum{};
  float l_i{};
  float2 l_q{};
  l_sh = coax_p_eg_st(cx, 20u);
  l_k = coax_p_eg_clip(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u)), 0x1.f40000p9f)));
  if (((l_k.w <= 0x1.47ae14p-7f) || (l_sh.z <= 0.0f)))
  {
    return 0.0f;
  }
  l_at = coax_p_v2(cx, (0x1.000000p-1f + ((0x1.000000p-1f * l_k.x) / l_k.w)), (0x1.000000p-1f - ((0x1.000000p-1f * l_k.y) / l_k.w)));
  l_fade = coax_p_verse_style_shaft_fade(cx, l_at.x, l_at.y, l_sh.w);
  if ((l_fade <= 0.0f))
  {
    return 0.0f;
  }
  l_n = l_sh.x;
  l_step = coax_p_wg_div_f2f(cx, coax_p_wg_sub_f2f2(cx, l_at, l_uv), l_n);
  l_jitter = coax_p_fract(cx, (0x1.a7dd04p5f * coax_p_fract(cx, coax_p_wg_dot2(cx, l_p, coax_p_v2(cx, 0x1.12e286p-4f, 0x1.7e8b20p-8f)))));
  l_sum = 0.0f;
  {
    l_i = 0.0f;
    while ((l_i < 0x1.800000p4f))
    {
      if ((l_i >= l_n))
      {
        break;
      }
      l_q = coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, l_step, (l_i + l_jitter)));
      if ((coax_p_wg_any_lt_f2f2(cx, l_q, coax_p_v2(cx, 0.0f, 0.0f)) || coax_p_wg_any_gt_f2f2(cx, l_q, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f))))
      {
        break;
      }
      l_sum = (l_sum + (((cx.r_post_aux).sample(cx.r_post_lin, l_q, level(0.0f))).x * coax_p_verse_style_shaft_tap(cx, l_i, l_sh.y)));
      l_i = (l_i + 0x1.000000p0f);
    }
  }
  return coax_p_verse_style_shaft(cx, l_sum, coax_p_verse_style_shaft_total(cx, l_n, l_sh.y), l_sh.z, l_fade);
}
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a * l_b.x), (l_a * l_b.y), (l_a * l_b.z));
}
float3 coax_p_eg_tone(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  float l_e{};
  float3 l_t{};
  float l_y{};
  l_e = (coax_p_eg_st(cx, 18u)).x;
  l_t = coax_p_v3(cx, coax_p_verse_style_tone(cx, l_c.x, l_e), coax_p_verse_style_tone(cx, l_c.y, l_e), coax_p_verse_style_tone(cx, l_c.z, l_e));
  l_y = coax_p_verse_style_luma(cx, l_t.x, l_t.y, l_t.z);
  l_t = coax_p_v3(cx, coax_p_verse_style_saturation(cx, l_t.x, l_y, (coax_p_eg_st(cx, 18u)).y), coax_p_verse_style_saturation(cx, l_t.y, l_y, (coax_p_eg_st(cx, 18u)).y), coax_p_verse_style_saturation(cx, l_t.z, l_y, (coax_p_eg_st(cx, 18u)).y));
  return coax_p_v3(cx, coax_p_verse_style_lift(cx, l_t.x, (coax_p_eg_st(cx, 18u)).z), coax_p_verse_style_lift(cx, l_t.y, (coax_p_eg_st(cx, 18u)).z), coax_p_verse_style_lift(cx, l_t.z, (coax_p_eg_st(cx, 18u)).z));
}
float3 coax_p_eg_encode(CoaxResources cx, float3 p_c) {
  float3 l_c = p_c;
  return coax_p_wg_pow_f3f3(cx, coax_p_wg_clamp_f3f3f3(cx, l_c, coax_p_v3(cx, 0.0f, 0.0f, 0.0f), coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f)), coax_p_wg_make_f3_f(cx, (0x1.000000p0f / 0x1.19999ap1f)));
}
float3 coax_p_eg_plates(CoaxResources cx, float2 p_p, float3 p_under) {
  float2 l_p = p_p;
  float3 l_under = p_under;
  float3 l_c{};
  int l_k{};
  l_c = l_under;
  {
    l_k = 0;
    while ((l_k < 64))
    {
      if ((float(l_k) >= cx.r_u[5]))
      {
        break;
      }
      l_c = coax_p_eg_plate(cx, l_p, l_c, coax_p_wg_at4(cx, ((int((l_k * 2)) * 4) + 248)), coax_p_wg_at4(cx, ((int(((l_k * 2) + 1)) * 4) + 248)));
      l_k = (l_k + 1);
    }
  }
  return l_c;
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float coax_p_eg_water_eye_over(CoaxResources cx) {
  return ((cx.r_u[1072] >= 0x1.000000p1f) ? cx.r_u[1071] : 0x1.900000p6f);
}
bool coax_p_eg_weather_desktop(CoaxResources cx) {
  return (cx.r_u[1068] >= 0x1.000000p3f);
}
float3 coax_p_eg_pixel_ray(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float4 l_ndc{};
  float4 l_w{};
  l_ndc = coax_p_v4(cx, (((l_p.x / cx.r_u[0]) * 0x1.000000p1f) - 0x1.000000p0f), (0x1.000000p0f - ((l_p.y / cx.r_u[1]) * 0x1.000000p1f)), 0x1.ccccccp-1f, 0x1.000000p0f);
  l_w = coax_p_m4_apply(cx, coax_p_eg_unview(cx), l_ndc);
  return coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_wg_div_f3f(cx, coax_p_v3(cx, l_w.x, l_w.y, l_w.z), l_w.w), coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26])));
}
bool coax_p_eg_water_pixel_under(CoaxResources cx, float3 p_d) {
  float3 l_d = p_d;
  return ((coax_p_eg_water_eye_over(cx) + (0x1.99999ap-4f * l_d.y)) < 0.0f);
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
coax_t13 coax_p_i2(CoaxResources cx, int p_x, int p_y) {
  int l_x = p_x;
  int l_y = p_y;
  return coax_t13{l_x, l_y};
}
coax_t13 coax_p_wg_sub_i2i(CoaxResources cx, coax_t13 p_a, int p_b) {
  coax_t13 l_a = p_a;
  int l_b = p_b;
  return coax_p_i2(cx, (l_a.x - l_b), (l_a.y - l_b));
}
coax_t13 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t13 p_p0, coax_t13 p_p1, coax_t13 p_p2) {
  coax_t13 l_p0 = p_p0;
  coax_t13 l_p1 = p_p1;
  coax_t13 l_p2 = p_p2;
  return coax_p_i2(cx, coax_p_wg_clamp_i(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_wg_clamp_i(cx, l_p0.y, l_p1.y, l_p2.y));
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w) {
  float3 l_w = p_w;
  float4 l_p{};
  l_p = coax_p_v4(cx, l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  return coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), l_p));
}
float coax_p_verse_style_shaft_fade(CoaxResources cx, float p_x, float p_y, float p_margin) {
  float l_x = p_x;
  float l_y = p_y;
  float l_margin = p_margin;
  float l_out{};
  l_out = coax_p_st_max(cx, coax_p_st_max(cx, coax_p_st_max(cx, (-l_x), (l_x - 0x1.000000p0f)), coax_p_st_max(cx, (-l_y), (l_y - 0x1.000000p0f))), 0.0f);
  return (0x1.000000p0f - coax_p_verse_style_soft_step(cx, (l_margin * 0x1.000000p-1f), (l_margin * 0x1.000000p-1f), l_out));
}
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x / l_b), (l_a.y / l_b));
}
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
bool coax_p_wg_any_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x < l_b.x) || (l_a.y < l_b.y));
}
bool coax_p_wg_any_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x > l_b.x) || (l_a.y > l_b.y));
}
float coax_p_verse_style_shaft_tap(CoaxResources cx, float p_i, float p_decay) {
  float l_i = p_i;
  float l_decay = p_decay;
  return coax_metal_pow(coax_p_st_max(cx, l_decay, 0x1.0c6f7ap-20f), l_i);
}
float coax_p_verse_style_shaft_total(CoaxResources cx, float p_n, float p_decay) {
  float l_n = p_n;
  float l_decay = p_decay;
  if ((abs((0x1.000000p0f - l_decay)) < 0x1.0c6f7ap-20f))
  {
    return l_n;
  }
  return ((0x1.000000p0f - coax_metal_pow(coax_p_st_max(cx, l_decay, 0x1.0c6f7ap-20f), l_n)) / (0x1.000000p0f - l_decay));
}
float coax_p_verse_style_shaft(CoaxResources cx, float p_sum, float p_total, float p_weight, float p_fade) {
  float l_sum = p_sum;
  float l_total = p_total;
  float l_weight = p_weight;
  float l_fade = p_fade;
  return (((l_sum / coax_p_st_max(cx, l_total, 0x1.0c6f7ap-20f)) * l_weight) * coax_p_st_sat(cx, l_fade));
}
float coax_p_verse_style_tone(CoaxResources cx, float p_c, float p_exposure) {
  float l_c = p_c;
  float l_exposure = p_exposure;
  return (0x1.000000p0f - exp(((-coax_p_st_max(cx, l_c, 0.0f)) * l_exposure)));
}
float coax_p_verse_style_luma(CoaxResources cx, float p_r, float p_g, float p_b) {
  float l_r = p_r;
  float l_g = p_g;
  float l_b = p_b;
  return (((0x1.b367a0p-3f * l_r) + (0x1.6e2eb2p-1f * l_g)) + (0x1.27bb30p-4f * l_b));
}
float coax_p_verse_style_saturation(CoaxResources cx, float p_c, float p_lum, float p_amount) {
  float l_c = p_c;
  float l_lum = p_lum;
  float l_amount = p_amount;
  return coax_p_st_max(cx, 0.0f, (l_lum + ((l_c - l_lum) * l_amount)));
}
float coax_p_verse_style_lift(CoaxResources cx, float p_c, float p_lift) {
  float l_c = p_c;
  float l_lift = p_lift;
  return (l_lift + ((0x1.000000p0f - l_lift) * l_c));
}
float3 coax_p_wg_clamp_f3f3f3(CoaxResources cx, float3 p_p0, float3 p_p1, float3 p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float3 l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_clampf(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_clampf(cx, l_p0.y, l_p1.y, l_p2.y), coax_p_clampf(cx, l_p0.z, l_p1.z, l_p2.z));
}
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0) {
  float l_p0 = p_p0;
  return coax_p_v3(cx, l_p0, l_p0, l_p0);
}
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_metal_pow(l_p0.x, l_p1.x), coax_metal_pow(l_p0.y, l_p1.y), coax_metal_pow(l_p0.z, l_p1.z));
}
float3 coax_p_eg_plate(CoaxResources cx, float2 p_p, float3 p_under, float4 p_r, float4 p_s) {
  float2 l_p = p_p;
  float3 l_under = p_under;
  float4 l_r = p_r;
  float4 l_s = p_s;
  float2 l_half{};
  float l_corner{};
  float2 l_q{};
  float l_d{};
  bool l_over{};
  float3 l_fill{};
  float3 l_line{};
  float l_w{};
  float l_inside{};
  float l_edge{};
  float l_a{};
  if ((l_s.x <= 0.0f))
  {
    return l_under;
  }
  if ((l_s.y > 0x1.400000p1f))
  {
    return coax_p_eg_hud_rect(cx, l_p, l_under, l_r, l_s);
  }
  l_half = coax_p_wg_mul_f2f(cx, coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, l_r.z, l_r.w), coax_p_v2(cx, l_r.x, l_r.y)), 0x1.000000p-1f);
  l_corner = (0x1.800000p2f * l_s.z);
  l_q = coax_p_wg_add_f2f2(cx, coax_p_wg_sub_f2f2(cx, coax_p_wg_abs_f2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_r.x, l_r.y), l_half))), l_half), coax_p_v2(cx, l_corner, l_corner));
  l_d = ((coax_p_wg_length2(cx, coax_p_wg_max_f2f2(cx, l_q, coax_p_v2(cx, 0.0f, 0.0f))) + coax_p_fmin(cx, coax_p_fmax(cx, l_q.x, l_q.y), 0.0f)) - l_corner);
  if ((l_d > 0x1.000000p0f))
  {
    return l_under;
  }
  l_over = (l_s.y >= 0x1.000000p1f);
  l_fill = (l_over ? coax_p_v3(cx, 0x1.70a3d8p-4f, 0x1.eb851ep-4f, 0x1.70a3d8p-4f) : coax_p_v3(cx, 0x1.c28f5cp-5f, 0x1.333334p-4f, 0x1.eb851ep-5f));
  l_line = ((l_over || (l_s.y >= 0x1.000000p0f)) ? coax_p_v3(cx, 0x1.ccccccp-1f, 0x1.851eb8p-1f, 0x1.ccccccp-2f) : coax_p_v3(cx, 0x1.3d70a4p-1f, 0x1.0a3d70p-1f, 0x1.333334p-2f));
  l_w = (0x1.400000p0f * l_s.z);
  l_inside = coax_p_clampf(cx, (0x1.000000p-1f - l_d), 0.0f, 0x1.000000p0f);
  l_edge = coax_p_clampf(cx, (((l_w * 0x1.000000p-1f) + 0x1.000000p-1f) - abs((l_d + (l_w * 0x1.000000p-1f)))), 0.0f, 0x1.000000p0f);
  l_a = coax_p_clampf(cx, l_s.x, 0.0f, 0x1.000000p0f);
  return coax_p_wg_mix_f3f3f(cx, coax_p_wg_mix_f3f3f(cx, l_under, l_fill, (l_a * l_inside)), l_line, ((l_edge * coax_p_fmin(cx, 0x1.000000p0f, (l_a + 0x1.99999ap-4f))) * 0x1.99999ap-1f));
}
coax_t14 coax_p_eg_unview(CoaxResources cx) {
  coax_t14 l_m{};
  float l_a00{};
  float l_a01{};
  float l_a02{};
  float l_a03{};
  float l_a10{};
  float l_a11{};
  float l_a12{};
  float l_a13{};
  float l_a20{};
  float l_a21{};
  float l_a22{};
  float l_a23{};
  float l_a30{};
  float l_a31{};
  float l_a32{};
  float l_a33{};
  float l_b00{};
  float l_b01{};
  float l_b02{};
  float l_b03{};
  float l_b04{};
  float l_b05{};
  float l_b06{};
  float l_b07{};
  float l_b08{};
  float l_b09{};
  float l_b10{};
  float l_b11{};
  float l_det{};
  float l_k{};
  l_m = coax_p_wg_transpose(cx, coax_t14{coax_p_wg_at4(cx, 8), coax_p_wg_at4(cx, 12), coax_p_wg_at4(cx, 16), coax_p_wg_at4(cx, 20)});
  l_a00 = l_m.x.x;
  l_a01 = l_m.x.y;
  l_a02 = l_m.x.z;
  l_a03 = l_m.x.w;
  l_a10 = l_m.y.x;
  l_a11 = l_m.y.y;
  l_a12 = l_m.y.z;
  l_a13 = l_m.y.w;
  l_a20 = l_m.z.x;
  l_a21 = l_m.z.y;
  l_a22 = l_m.z.z;
  l_a23 = l_m.z.w;
  l_a30 = l_m.w.x;
  l_a31 = l_m.w.y;
  l_a32 = l_m.w.z;
  l_a33 = l_m.w.w;
  l_b00 = ((l_a00 * l_a11) - (l_a01 * l_a10));
  l_b01 = ((l_a00 * l_a12) - (l_a02 * l_a10));
  l_b02 = ((l_a00 * l_a13) - (l_a03 * l_a10));
  l_b03 = ((l_a01 * l_a12) - (l_a02 * l_a11));
  l_b04 = ((l_a01 * l_a13) - (l_a03 * l_a11));
  l_b05 = ((l_a02 * l_a13) - (l_a03 * l_a12));
  l_b06 = ((l_a20 * l_a31) - (l_a21 * l_a30));
  l_b07 = ((l_a20 * l_a32) - (l_a22 * l_a30));
  l_b08 = ((l_a20 * l_a33) - (l_a23 * l_a30));
  l_b09 = ((l_a21 * l_a32) - (l_a22 * l_a31));
  l_b10 = ((l_a21 * l_a33) - (l_a23 * l_a31));
  l_b11 = ((l_a22 * l_a33) - (l_a23 * l_a32));
  l_det = ((((((l_b00 * l_b11) - (l_b01 * l_b10)) + (l_b02 * l_b09)) + (l_b03 * l_b08)) - (l_b04 * l_b07)) + (l_b05 * l_b06));
  l_k = (0x1.000000p0f / ((abs(l_det) < 0x1.197998p-40f) ? 0x1.12e0bep-30f : l_det));
  return coax_t14{coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a11 * l_b11) - (l_a12 * l_b10)) + (l_a13 * l_b09)), (((l_a02 * l_b10) - (l_a01 * l_b11)) - (l_a03 * l_b09)), (((l_a31 * l_b05) - (l_a32 * l_b04)) + (l_a33 * l_b03)), (((l_a22 * l_b04) - (l_a21 * l_b05)) - (l_a23 * l_b03))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a12 * l_b08) - (l_a10 * l_b11)) - (l_a13 * l_b07)), (((l_a00 * l_b11) - (l_a02 * l_b08)) + (l_a03 * l_b07)), (((l_a32 * l_b02) - (l_a30 * l_b05)) - (l_a33 * l_b01)), (((l_a20 * l_b05) - (l_a22 * l_b02)) + (l_a23 * l_b01))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a10 * l_b10) - (l_a11 * l_b08)) + (l_a13 * l_b06)), (((l_a01 * l_b08) - (l_a00 * l_b10)) - (l_a03 * l_b06)), (((l_a30 * l_b04) - (l_a31 * l_b02)) + (l_a33 * l_b00)), (((l_a21 * l_b02) - (l_a20 * l_b04)) - (l_a23 * l_b00))), l_k), coax_p_wg_mul_f4f(cx, coax_p_v4(cx, (((l_a11 * l_b07) - (l_a10 * l_b09)) - (l_a12 * l_b06)), (((l_a00 * l_b09) - (l_a01 * l_b07)) + (l_a02 * l_b06)), (((l_a31 * l_b01) - (l_a30 * l_b03)) - (l_a32 * l_b00)), (((l_a20 * l_b03) - (l_a21 * l_b01)) + (l_a22 * l_b00))), l_k)};
}
float4 coax_p_m4_apply(CoaxResources cx, coax_t14 p_m, float4 p_v) {
  coax_t14 l_m = p_m;
  float4 l_v = p_v;
  return coax_p_add4(cx, coax_p_add4(cx, coax_p_scale4(cx, l_m.x, l_v.x), coax_p_scale4(cx, l_m.y, l_v.y)), coax_p_add4(cx, coax_p_scale4(cx, l_m.z, l_v.z), coax_p_scale4(cx, l_m.w, l_v.w)));
}
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x / l_b), (l_a.y / l_b), (l_a.z / l_b));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high) {
  int l_x = p_x;
  int l_low = p_low;
  int l_high = p_high;
  return coax_p_wg_min_i(cx, coax_p_wg_max_i(cx, l_x, l_low), l_high);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_st_max(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a > l_b))
  {
    return l_a;
  }
  return l_b;
}
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x) {
  float l_e = p_e;
  float l_s = p_s;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_st_sat(cx, ((l_x - (l_e - l_s)) / coax_p_st_max(cx, (0x1.000000p1f * l_s), 0x1.0c6f7ap-20f)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float coax_p_st_sat(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_st_min(cx, 0x1.000000p0f, coax_p_st_max(cx, 0.0f, l_x));
}
float3 coax_p_eg_hud_rect(CoaxResources cx, float2 p_p, float3 p_under, float4 p_r, float4 p_s) {
  float2 l_p = p_p;
  float3 l_under = p_under;
  float4 l_r = p_r;
  float4 l_s = p_s;
  float l_e{};
  float l_t{};
  float l_look{};
  float2 l_h{};
  float l_d{};
  float l_dx{};
  float l_dy{};
  float l_cut{};
  float l_rim{};
  if (((((l_p.x < l_r.x) || (l_p.y < l_r.y)) || (l_p.x >= l_r.z)) || (l_p.y >= l_r.w)))
  {
    return l_under;
  }
  l_e = coax_p_fmin(cx, coax_p_fmin(cx, (l_p.x - l_r.x), (l_r.z - l_p.x)), coax_p_fmin(cx, (l_p.y - l_r.y), (l_r.w - l_p.y)));
  l_t = coax_p_fmax(cx, l_s.w, 0x1.000000p0f);
  l_look = l_s.y;
  if ((l_look > 0x1.e00000p2f))
  {
    l_h = coax_p_wg_max_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, l_r.z, l_r.w), coax_p_v2(cx, l_r.x, l_r.y)), 0x1.000000p-1f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f));
    l_d = coax_p_wg_length2(cx, coax_p_wg_div_f2f2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_r.x, l_r.y), l_h)), l_h));
    return coax_p_wg_mix_f3f3f(cx, l_under, coax_p_v3(cx, 0x1.eb851ep-6f, 0.0f, 0.0f), (coax_p_clampf(cx, l_s.x, 0.0f, 0x1.000000p0f) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.99999ap-2f, 0x1.000000p0f, l_d))));
  }
  if ((l_look < 0x1.c00000p1f))
  {
    l_dx = coax_p_fmin(cx, (l_p.x - l_r.x), (l_r.z - l_p.x));
    l_dy = coax_p_fmin(cx, (l_p.y - l_r.y), (l_r.w - l_p.y));
    l_cut = (0x1.400000p2f * l_t);
    if (((l_dx + l_dy) < l_cut))
    {
      return l_under;
    }
    l_rim = coax_p_fmin(cx, l_e, (((l_dx + l_dy) - l_cut) * 0x1.6a0902p-1f));
    if ((l_rim < l_t))
    {
      return coax_p_wg_mix_f3f3f(cx, l_under, coax_p_v3(cx, 0x1.d70a3ep-2f, 0x1.eb851ep-2f, 0x1.000000p-1f), 0x1.ccccccp-1f);
    }
    return coax_p_wg_mix_f3f3f(cx, l_under, coax_p_v3(cx, 0x1.70a3d8p-5f, 0x1.99999ap-5f, 0x1.db22d0p-5f), 0x1.a3d70ap-1f);
  }
  if ((l_look < 0x1.600000p2f))
  {
    if ((l_e >= l_t))
    {
      return l_under;
    }
    return ((l_look > 0x1.200000p2f) ? coax_p_v3(cx, 0x1.eb851ep-2f, 0x1.70a3d8p-1f, 0x1.000000p0f) : coax_p_v3(cx, 0x1.0a3d70p-2f, 0x1.1eb852p-2f, 0x1.333334p-2f));
  }
  if ((l_look < 0x1.a00000p2f))
  {
    if ((l_e < l_t))
    {
      return coax_p_v3(cx, 0x1.6a7efap-1f, 0x1.50e560p-1f, 0x1.0dd2f2p-1f);
    }
    return coax_p_wg_mix_f3f3f(cx, l_under, coax_p_v3(cx, 0x1.bf7ceep-2f, 0x1.408312p-2f, 0x1.c49ba6p-3f), 0x1.e147aep-1f);
  }
  return coax_p_v3(cx, 0x1.000000p0f, 0x1.7851ecp-1f, 0x1.8624dep-2f);
}
float2 coax_p_wg_abs_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, abs(l_p0.x), abs(l_p0.y));
}
float2 coax_p_wg_max_f2f2(CoaxResources cx, float2 p_p0, float2 p_p1) {
  float2 l_p0 = p_p0;
  float2 l_p1 = p_p1;
  return coax_p_v2(cx, coax_p_fmax(cx, l_p0.x, l_p1.x), coax_p_fmax(cx, l_p0.y, l_p1.y));
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
coax_t14 coax_p_wg_transpose(CoaxResources cx, coax_t14 p_m) {
  coax_t14 l_m = p_m;
  return coax_t14{coax_p_v4(cx, l_m.x.x, l_m.y.x, l_m.z.x, l_m.w.x), coax_p_v4(cx, l_m.x.y, l_m.y.y, l_m.z.y, l_m.w.y), coax_p_v4(cx, l_m.x.z, l_m.y.z, l_m.z.z, l_m.w.z), coax_p_v4(cx, l_m.x.w, l_m.y.w, l_m.z.w, l_m.w.w)};
}
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b) {
  float4 l_a = p_a;
  float l_b = p_b;
  return coax_p_v4(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b), (l_a.w * l_b));
}
float4 coax_p_scale4(CoaxResources cx, float4 p_a, float p_k) {
  float4 l_a = p_a;
  float l_k = p_k;
  return float4((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k), (l_a.w * l_k));
}
float4 coax_p_add4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return float4((l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z), (l_a.w + l_b.w));
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_st_min(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a < l_b))
  {
    return l_a;
  }
  return l_b;
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
vertex float4 eg_bg_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_bg_vs(cx, coax_vid, coax_iid);
  return coax_r;
}
fragment float4 eg_post_fs(float4 coax_pos [[position]], CoaxResources cx) {
  auto coax_r = coax_p_eg_post_fs(cx, coax_pos);
  return coax_r;
}
