// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t9 {
  float4 x;
  float4 y;
  float4 z;
  float4 w;
};
struct coax_t14 {
  float4 x;
  float2 y;
  uint z;
  uint w;
  alignas(16) packed_float3 f4;
  uint f5;
  float f6;
};
struct coax_io_14 {
  float4 x [[position]];
  float2 y [[user(locn0)]];
  uint z [[user(locn1)]] [[flat]];
  uint w [[user(locn2)]] [[flat]];
  float3 f4 [[user(locn3)]];
  uint f5 [[user(locn4)]] [[flat]];
  float f6 [[user(locn5)]] [[flat]];
};
struct coax_t15 {
  float4 x;
  alignas(16) packed_float3 y;
  alignas(16) packed_float3 z;
  alignas(16) packed_float3 w;
  uint f4;
  float2 f5;
  uint f6;
  float4 f7;
  alignas(16) packed_float3 f8;
  uint f9;
};
struct coax_t18 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
};
struct coax_t19 {
  uint x;
  uint y;
  uint z;
  uint w;
};
struct coax_t20 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
  alignas(16) packed_float3 z;
  float w;
  float f4;
  float f5;
};
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(uint) == 4, "portable storage stride");
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(coax_t9) == 64, "portable storage stride");
static_assert(sizeof(float4) == 16, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  device const uint* r_vertices [[buffer(1)]];
  device const float* r_heights [[buffer(2)]];
  device const coax_t9* r_objects [[buffer(3)]];
  device const float4* r_pose [[buffer(4)]];
  texture2d_array<float> r_sheets [[texture(0)]];
  sampler r_sheet [[sampler(0)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
coax_t14 coax_p_eg_shadow_vs(CoaxResources cx, uint p_id, uint p_instance);
void coax_p_eg_shadow_fs(CoaxResources cx, coax_t14 p_v);
uint coax_p_wg_u32_f(CoaxResources cx, float p_x);
float4 coax_p_eg_st(CoaxResources cx, uint p_i);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
coax_t15 coax_p_eg_place(CoaxResources cx, uint p_id, uint p_instance);
bool coax_p_eg_spell_soft(CoaxResources cx, uint p_look);
coax_t20 coax_p_eg_light_space(CoaxResources cx);
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t20 p_k);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
float4 coax_p_wg_make_f4_f2ff(CoaxResources cx, float2 p_p0, float p_p1, float p_p2);
float coax_p_eg_shard_inside(CoaxResources cx, uint p_shard, float3 p_p);
bool coax_p_eg_leaf_gone(CoaxResources cx, float3 p_local, float p_bare);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
float2 coax_p_eg_quad(CoaxResources cx, uint p_v);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w);
coax_t18 coax_p_eg_box_vertex(CoaxResources cx, uint p_id);
coax_t18 coax_p_eg_sphere_vertex(CoaxResources cx, uint p_id);
coax_t18 coax_p_eg_cylinder_vertex(CoaxResources cx, uint p_id);
float coax_p_eg_word(CoaxResources cx, uint p_i);
float4 coax_p_wg_unpack4x8unorm(CoaxResources cx, uint p_x);
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p);
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
float4 coax_p_wg_unpack4x8snorm(CoaxResources cx, uint p_x);
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p);
float3 coax_p_eg_canopy_n(CoaxResources cx, float3 p_n, float3 p_blob);
float2 coax_p_wg_unpack2x16unorm(CoaxResources cx, uint p_x);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_EG_PERSON_LOW(CoaxResources cx);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b);
float4 coax_p_wg_add_f4f(CoaxResources cx, float4 p_a, float p_b);
coax_t19 coax_p_wg_cvt_u4f4(CoaxResources cx, float4 p_p);
uint coax_p_wg_get_u4(CoaxResources cx, coax_t19 p_p, int p_i);
float coax_p_wg_get_f4(CoaxResources cx, float4 p_p, int p_i);
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b);
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b);
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
coax_t18 coax_p_eg_lathe_vertex(CoaxResources cx, uint p_id, uint p_word);
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
coax_t18 coax_p_eg_cone_vertex(CoaxResources cx, uint p_id);
coax_t18 coax_p_eg_far_tree_vertex(CoaxResources cx, uint p_id);
float3 coax_p_eg_canopy_sway(CoaxResources cx, float3 p_at, float p_share);
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_render_noise3(CoaxResources cx, float p_x, float p_y, float p_z);
float coax_p_fract(CoaxResources cx, float p_x);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size);
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach);
float4 coax_p_eg_shard_plane(CoaxResources cx, uint p_cell, uint p_k);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_eg_noise(CoaxResources cx, float2 p_p);
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
uint coax_p_wg_byte(CoaxResources cx, uint p_x, uint p_at);
float coax_p_wg_snorm8(CoaxResources cx, uint p_b);
float coax_p_verse_style_canopy_normal(CoaxResources cx, float p_mesh_n, float p_blob_n, float p_k);
coax_t19 coax_p_u4(CoaxResources cx, uint p_x, uint p_y, uint p_z, uint p_w);
float2 coax_p_eg_lathe_point(CoaxResources cx, uint p_profile, uint p_j);
float2 coax_p_eg_lathe_segment_n(CoaxResources cx, uint p_profile, uint p_k);
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a);
float coax_p_wg_atan01(CoaxResources cx, float p_x);
float2 coax_p_EG_WIND_DIR(CoaxResources cx);
float4 coax_p_EG_WIND(CoaxResources cx);
float coax_p_verse_style_gust(CoaxResources cx, float p_x, float p_z, float p_t, float p_wx, float p_wz, float p_speed, float p_scale);
float coax_p_verse_style_wind(CoaxResources cx, float p_along, float p_gust, float p_t, float p_amp, float p_wavelength, float p_speed);
float coax_p_verse_style_canopy_sway(CoaxResources cx, float p_theta, float p_amp, float p_reach, float p_share);
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b);
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x);
uint coax_p_render_noise_cell(CoaxResources cx, float p_x);
uint coax_p_render_noise_mix3(CoaxResources cx, uint p_x, uint p_y, uint p_z);
float coax_p_render_noise_unit(CoaxResources cx, uint p_word);
float coax_p_st_max(CoaxResources cx, float p_a, float p_b);
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b);
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b);
float coax_p_eg_hash(CoaxResources cx, float2 p_p);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b);
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b);
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k);
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y);
float coax_p_st_sat(CoaxResources cx, float p_x);
float coax_p_st_min(CoaxResources cx, float p_a, float p_b);
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word);
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y);
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y);
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y);
coax_t14 coax_p_eg_shadow_vs(CoaxResources cx, uint p_id, uint p_instance) {
  uint l_id = p_id;
  uint l_instance = p_instance;
  coax_t14 l_o{};
  uint l_n{};
  coax_t15 l_v{};
  float3 l_q{};
  l_o = coax_t14{};
  l_n = coax_p_wg_u32_f(cx, cx.r_u[32]);
  if (((l_instance < (l_n * l_n)) || ((coax_p_eg_st(cx, 21u)).x < 0x1.000000p0f)))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, (-0x1.000000p0f), 0x1.000000p0f);
    return l_o;
  }
  l_v = coax_p_eg_place(cx, l_id, l_instance);
  if ((((l_v.f4 == 15u) || (l_v.f4 == 16u)) || coax_p_eg_spell_soft(cx, l_v.f4)))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, (-0x1.000000p0f), 0x1.000000p0f);
    return l_o;
  }
  l_q = coax_p_eg_shadow_place(cx, l_v.y, coax_p_eg_light_space(cx));
  l_o.x = coax_p_wg_make_f4_f2ff(cx, coax_p_v2(cx, l_q.x, l_q.y), l_q.z, 0x1.000000p0f);
  l_o.y = l_v.f5;
  l_o.z = l_v.f6;
  l_o.f4 = l_v.f8;
  l_o.f5 = l_v.f9;
  l_o.w = ((((((l_v.f4 == 5u) || (l_v.f4 == 7u)) || (l_v.f4 == 8u)) || (l_v.f4 == 10u)) || (l_v.f4 == 14u)) ? 1u : 0u);
  l_o.f6 = ((l_v.f4 == 7u) ? l_v.f7.z : 0.0f);
  return l_o;
}
void coax_p_eg_shadow_fs(CoaxResources cx, coax_t14 p_v) {
  coax_t14 l_v = p_v;
  if (((l_v.w == 1u) && (((cx.r_sheets).sample(cx.r_sheet, l_v.y, uint(int(l_v.z)), level(0.0f))).w < 0x1.666666p-2f)))
  {
    discard_fragment();
  }
  if (((l_v.f5 != 0u) && (coax_p_eg_shard_inside(cx, l_v.f5, l_v.f4) < 0.0f)))
  {
    discard_fragment();
  }
  if (coax_p_eg_leaf_gone(cx, l_v.f4, l_v.f6))
  {
    discard_fragment();
  }
}
uint coax_p_wg_u32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return uint(l_x);
}
float4 coax_p_eg_st(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return coax_p_wg_at4(cx, ((int(l_i) * 4) + 1084));
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
coax_t15 coax_p_eg_place(CoaxResources cx, uint p_id, uint p_instance) {
  uint l_id = p_id;
  uint l_instance = p_instance;
  coax_t15 l_o{};
  uint l_n{};
  float2 l_c{};
  int l_gx{};
  int l_gz{};
  float3 l_w{};
  float3 l_normal{};
  coax_t9 l_m{};
  uint l_kind{};
  coax_t18 l_v{};
  float3 l_tint{};
  bool l_canopy{};
  bool l_cone{};
  bool l_ranger{};
  float l_share{};
  bool l_glass{};
  uint l__sw3{};
  uint l_b{};
  uint l_blob{};
  float l_bare{};
  uint l_b_27{};
  float2 l_xy{};
  uint l_zw{};
  float4 l_at{};
  float3 l_nw{};
  coax_t19 l_j{};
  float4 l_wt{};
  uint l_base{};
  float3 l_sp{};
  float3 l_sn{};
  uint l_k{};
  uint l_r{};
  float4 l_a{};
  float4 l_c_40{};
  float4 l_e{};
  uint l_colours{};
  float4 l_skin{};
  uint l_kind_2{};
  float4 l_d{};
  uint l_base_46{};
  uint l_b_47{};
  float4 l_at_48{};
  float3 l_nw_49{};
  coax_t19 l_j_50{};
  float4 l_wt_51{};
  float3 l_sp_52{};
  float3 l_sn_53{};
  uint l_k_54{};
  uint l_r_55{};
  float4 l_a_56{};
  float4 l_c_57{};
  float4 l_e_58{};
  uint l_lr{};
  float4 l_l0{};
  float4 l_l1{};
  int l_rel{};
  uint l_word{};
  float l_a_64{};
  float4 l_p{};
  float3 l_w_66{};
  float3 l_c0{};
  float3 l_c1{};
  float3 l_c2{};
  float3 l_normal_70{};
  float l_h{};
  float3 l_at_72{};
  l_o = coax_t15{};
  l_n = coax_p_wg_u32_f(cx, cx.r_u[32]);
  if ((l_instance < (l_n * l_n)))
  {
    l_c = coax_p_eg_quad(cx, (l_id % 6u));
    l_gx = (int((l_instance % l_n)) + coax_p_wg_i32_f(cx, l_c.x));
    l_gz = (int((l_instance / l_n)) + coax_p_wg_i32_f(cx, l_c.y));
    l_w = coax_p_v3(cx, (cx.r_u[34] + (float(l_gx) * cx.r_u[33])), coax_p_eg_height(cx, l_gx, l_gz), (cx.r_u[35] + (float(l_gz) * cx.r_u[33])));
    l_normal = coax_p_wg_normalize3(cx, coax_p_v3(cx, (coax_p_eg_height(cx, (l_gx - 1), l_gz) - coax_p_eg_height(cx, (l_gx + 1), l_gz)), (0x1.000000p1f * cx.r_u[33]), (coax_p_eg_height(cx, l_gx, (l_gz - 1)) - coax_p_eg_height(cx, l_gx, (l_gz + 1)))));
    l_o.x = coax_p_eg_clip(cx, l_w);
    l_o.y = l_w;
    l_o.z = l_normal;
    l_o.w = coax_p_v3(cx, 0x1.333334p-2f, 0x1.000000p-1f, 0x1.99999ap-3f);
    l_o.f4 = 99u;
    l_o.f5 = coax_p_v2(cx, 0.0f, 0.0f);
    l_o.f6 = 0u;
    return l_o;
  }
  l_m = cx.r_objects[int((l_instance - (l_n * l_n)))];
  l_kind = (coax_p_wg_u32_f(cx, l_m.w.w) % 8u);
  l_v = coax_t18{};
  l_tint = coax_p_v3(cx, l_m.w.x, l_m.w.y, l_m.w.z);
  l_canopy = false;
  l_cone = false;
  l_ranger = false;
  l_share = 0.0f;
  l_glass = false;
  l_o.f5 = coax_p_v2(cx, 0.0f, 0.0f);
  l_o.f6 = 0u;
  l_o.f7 = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
  {
    l__sw3 = l_kind;
    if ((l__sw3 == 1u))
    {
      l_v = coax_p_eg_box_vertex(cx, l_id);
    }
    else
    {
      if ((l__sw3 == 2u))
      {
        l_v = coax_p_eg_sphere_vertex(cx, l_id);
      }
      else
      {
        if ((l__sw3 == 3u))
        {
          l_v = coax_p_eg_cylinder_vertex(cx, l_id);
        }
        else
        {
          if ((l__sw3 == 5u))
          {
            l_b = (l_id * 12u);
            l_v = coax_t18{coax_p_v3(cx, coax_p_eg_word(cx, l_b), coax_p_eg_word(cx, (l_b + 1u)), coax_p_eg_word(cx, (l_b + 2u))), coax_p_v3(cx, coax_p_eg_word(cx, (l_b + 3u)), coax_p_eg_word(cx, (l_b + 4u)), coax_p_eg_word(cx, (l_b + 5u)))};
            l_o.f5 = coax_p_v2(cx, coax_p_eg_word(cx, (l_b + 6u)), coax_p_eg_word(cx, (l_b + 7u)));
            l_o.f6 = (cx.r_vertices[int((l_b + 8u))] >> uint(24u));
            l_tint = coax_p_wg_mul_f3f3(cx, coax_p_wg_sw_rgb_f4(cx, coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b + 8u))])), coax_p_v3(cx, l_m.w.x, l_m.w.y, l_m.w.z));
            if ((l_m.w.x < 0.0f))
            {
              l_tint = coax_p_wg_sw_rgb_f4(cx, coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b + 8u))]));
              l_o.f7 = coax_p_wg_make_f4_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_v3(cx, l_m.w.x, l_m.w.y, l_m.w.z)), 0x1.800000p2f);
            }
            l_blob = cx.r_vertices[int((l_b + 9u))];
            if ((l_blob != 0u))
            {
              l_v.y = coax_p_eg_canopy_n(cx, l_v.y, coax_p_wg_sw_xyz_f4(cx, coax_p_wg_unpack4x8snorm(cx, l_blob)));
              l_share = (float((l_blob >> uint(24u))) / 0x1.fe0000p7f);
              l_canopy = true;
              l_bare = (float((coax_p_wg_u32_f(cx, l_m.w.w) / 256u)) / 0x1.fe0000p7f);
              if ((l_bare >= 0x1.fae148p-1f))
              {
                l_v.x = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
                l_share = 0.0f;
              }
              l_o.f7.z = l_bare;
            }
            l_glass = (cx.r_vertices[int((l_b + 10u))] == 1u);
            if ((((coax_p_wg_u32_f(cx, l_m.w.w) / 8u) % 32u) == 24u))
            {
              l_o.f9 = ((l_instance - (l_n * l_n)) + 1u);
            }
          }
          else
          {
            if ((l__sw3 == 6u))
            {
              if (((l_m.w.z > 0x1.800000p0f) && (l_m.w.z < 0x1.400000p1f)))
              {
                l_b_27 = (coax_p_wg_u32_f(cx, l_m.w.x) + (l_id * 6u));
                l_xy = coax_p_wg_unpack2x16unorm(cx, cx.r_vertices[int(l_b_27)]);
                l_zw = cx.r_vertices[int((l_b_27 + 1u))];
                l_at = coax_p_wg_make_f4_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_xy.x, l_xy.y, (float((l_zw & 65535u)) / 0x1.fffe00p15f)), 0x1.400000p1f), coax_p_EG_PERSON_LOW(cx)), 0x1.000000p0f);
                l_nw = coax_p_wg_sw_xyz_f4(cx, coax_p_wg_unpack4x8snorm(cx, cx.r_vertices[int((l_b_27 + 2u))]));
                l_j = coax_p_wg_cvt_u4f4(cx, coax_p_wg_add_f4f(cx, coax_p_wg_mul_f4f(cx, coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b_27 + 4u))]), 0x1.fe0000p7f), 0x1.000000p-1f));
                l_wt = coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b_27 + 5u))]);
                l_base = coax_p_wg_u32_f(cx, l_m.w.y);
                l_sp = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
                l_sn = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
                {
                  l_k = 0u;
                  while ((l_k < 4u))
                  {
                    l_r = (l_base + (coax_p_wg_get_u4(cx, l_j, int(l_k)) * 3u));
                    l_a = cx.r_pose[int(l_r)];
                    l_c_40 = cx.r_pose[int((l_r + 1u))];
                    l_e = cx.r_pose[int((l_r + 2u))];
                    l_sp = coax_p_wg_add_f3f3(cx, l_sp, coax_p_wg_mul_ff3(cx, coax_p_wg_get_f4(cx, l_wt, int(l_k)), coax_p_v3(cx, coax_p_wg_dot4(cx, l_a, l_at), coax_p_wg_dot4(cx, l_c_40, l_at), coax_p_wg_dot4(cx, l_e, l_at))));
                    l_sn = coax_p_wg_add_f3f3(cx, l_sn, coax_p_wg_mul_ff3(cx, coax_p_wg_get_f4(cx, l_wt, int(l_k)), coax_p_v3(cx, coax_p_wg_dot3(cx, coax_p_v3(cx, l_a.x, l_a.y, l_a.z), l_nw), coax_p_wg_dot3(cx, coax_p_v3(cx, l_c_40.x, l_c_40.y, l_c_40.z), l_nw), coax_p_wg_dot3(cx, coax_p_v3(cx, l_e.x, l_e.y, l_e.z), l_nw))));
                    l_k = (l_k + 1u);
                  }
                }
                l_v = coax_t18{l_sp, l_sn};
                l_o.f5 = coax_p_wg_unpack2x16unorm(cx, cx.r_vertices[int((l_b_27 + 3u))]);
                l_colours = (l_base + (65u * 3u));
                l_skin = cx.r_pose[int(l_colours)];
                l_kind_2 = ((l_zw >> uint(24u)) & 255u);
                l_o.f6 = ((l_zw >> uint(16u)) & 255u);
                l_tint = coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f);
                if ((l_kind_2 == 1u))
                {
                  l_tint = coax_p_v3(cx, l_skin.x, l_skin.y, l_skin.z);
                }
                if ((l_kind_2 == 2u))
                {
                  l_tint = coax_p_v3(cx, cx.r_pose[int((l_colours + 1u))].x, cx.r_pose[int((l_colours + 1u))].y, cx.r_pose[int((l_colours + 1u))].z);
                }
                if (((l_kind_2 == 3u) || (l_kind_2 == 4u)))
                {
                  l_o.f6 = (l_o.f6 + coax_p_wg_u32_f(cx, l_skin.w));
                  l_d = cx.r_pose[int((l_colours + 2u))];
                  l_o.f7 = coax_p_wg_make_f4_f3f(cx, coax_p_v3(cx, l_d.x, l_d.y, l_d.z), ((float((l_kind_2 - 2u)) * 0x1.000000p1f) + l_d.w));
                }
                l_ranger = true;
              }
              else
              {
                l_base_46 = 0u;
                if ((l_m.w.z > 0x1.400000p1f))
                {
                  l_base_46 = coax_p_wg_u32_f(cx, l_m.w.y);
                }
                l_b_47 = (coax_p_wg_u32_f(cx, l_m.w.x) + (l_id * 8u));
                l_at_48 = coax_p_v4(cx, coax_p_eg_word(cx, l_b_47), coax_p_eg_word(cx, (l_b_47 + 1u)), coax_p_eg_word(cx, (l_b_47 + 2u)), 0x1.000000p0f);
                l_nw_49 = coax_p_wg_sw_xyz_f4(cx, coax_p_wg_unpack4x8snorm(cx, cx.r_vertices[int((l_b_47 + 3u))]));
                l_j_50 = coax_p_wg_cvt_u4f4(cx, coax_p_wg_add_f4f(cx, coax_p_wg_mul_f4f(cx, coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b_47 + 6u))]), 0x1.fe0000p7f), 0x1.000000p-1f));
                l_wt_51 = coax_p_wg_unpack4x8unorm(cx, cx.r_vertices[int((l_b_47 + 7u))]);
                l_sp_52 = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
                l_sn_53 = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
                {
                  l_k_54 = 0u;
                  while ((l_k_54 < 4u))
                  {
                    l_r_55 = (l_base_46 + (coax_p_wg_get_u4(cx, l_j_50, int(l_k_54)) * 3u));
                    l_a_56 = cx.r_pose[int(l_r_55)];
                    l_c_57 = cx.r_pose[int((l_r_55 + 1u))];
                    l_e_58 = cx.r_pose[int((l_r_55 + 2u))];
                    l_sp_52 = coax_p_wg_add_f3f3(cx, l_sp_52, coax_p_wg_mul_ff3(cx, coax_p_wg_get_f4(cx, l_wt_51, int(l_k_54)), coax_p_v3(cx, coax_p_wg_dot4(cx, l_a_56, l_at_48), coax_p_wg_dot4(cx, l_c_57, l_at_48), coax_p_wg_dot4(cx, l_e_58, l_at_48))));
                    l_sn_53 = coax_p_wg_add_f3f3(cx, l_sn_53, coax_p_wg_mul_ff3(cx, coax_p_wg_get_f4(cx, l_wt_51, int(l_k_54)), coax_p_v3(cx, coax_p_wg_dot3(cx, coax_p_v3(cx, l_a_56.x, l_a_56.y, l_a_56.z), l_nw_49), coax_p_wg_dot3(cx, coax_p_v3(cx, l_c_57.x, l_c_57.y, l_c_57.z), l_nw_49), coax_p_wg_dot3(cx, coax_p_v3(cx, l_e_58.x, l_e_58.y, l_e_58.z), l_nw_49))));
                    l_k_54 = (l_k_54 + 1u);
                  }
                }
                l_v = coax_t18{l_sp_52, l_sn_53};
                l_o.f5 = coax_p_v2(cx, coax_p_eg_word(cx, (l_b_47 + 4u)), coax_p_eg_word(cx, (l_b_47 + 5u)));
                l_o.f6 = (cx.r_vertices[int((l_b_47 + 3u))] >> uint(24u));
                l_tint = coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f);
                if ((l_m.w.z > 0x1.400000p1f))
                {
                  l_lr = (coax_p_wg_u32_f(cx, l_m.w.w) / 256u);
                  l_l0 = cx.r_pose[int(l_lr)];
                  l_l1 = cx.r_pose[int((l_lr + 1u))];
                  l_o.f7 = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, (0x1.000000p3f + (0x1.fae148p-1f * coax_p_clampf(cx, l_l1.w, 0.0f, 0x1.000000p0f))));
                  if ((l_l0.w >= 0.0f))
                  {
                    l_rel = (int(l_o.f6) - coax_p_wg_i32_f(cx, l_l0.w));
                    if (((l_rel == 1) || (l_rel == 4)))
                    {
                      l_tint = coax_p_v3(cx, l_l0.x, l_l0.y, l_l0.z);
                    }
                    if ((l_rel == 0))
                    {
                      l_o.f7 = coax_p_v4(cx, l_l1.x, l_l1.y, 0.0f, l_o.f7.w);
                    }
                  }
                }
                l_ranger = true;
              }
            }
            else
            {
              if ((l__sw3 == 7u))
              {
                l_word = (coax_p_wg_u32_f(cx, l_m.w.w) / 256u);
                l_v = coax_p_eg_lathe_vertex(cx, l_id, l_word);
                l_a_64 = coax_p_wg_atan2(cx, l_v.x.z, l_v.x.x);
                l_o.f5 = coax_p_v2(cx, (l_a_64 * coax_p_wg_length2(cx, coax_p_v2(cx, l_v.x.x, l_v.x.z))), l_v.x.y);
              }
              else
              {
                l_v = coax_p_eg_cone_vertex(cx, l_id);
                if (((coax_p_wg_u32_f(cx, l_m.w.w) / 8u) == 1u))
                {
                  l_v = coax_p_eg_far_tree_vertex(cx, l_id);
                  if ((l_id < 48u))
                  {
                    l_v.y = coax_p_eg_canopy_n(cx, l_v.y, coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_v.x, coax_p_v3(cx, 0.0f, 0x1.a36e2ep-14f, 0.0f))));
                    l_cone = true;
                  }
                  else
                  {
                    l_tint = coax_p_v3(cx, 0x1.99999ap-3f, 0x1.1eb852p-3f, 0x1.70a3d8p-4f);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  l_p = coax_p_v4(cx, l_v.x.x, l_v.x.y, l_v.x.z, 0x1.000000p0f);
  l_w_66 = coax_p_v3(cx, coax_p_wg_dot4(cx, l_m.x, l_p), coax_p_wg_dot4(cx, l_m.y, l_p), coax_p_wg_dot4(cx, l_m.z, l_p));
  if ((l_share > 0.0f))
  {
    l_w_66 = coax_p_wg_add_f3f3(cx, l_w_66, coax_p_eg_canopy_sway(cx, coax_p_v3(cx, l_m.x.w, l_m.y.w, l_m.z.w), l_share));
  }
  l_c0 = coax_p_v3(cx, l_m.x.x, l_m.y.x, l_m.z.x);
  l_c1 = coax_p_v3(cx, l_m.x.y, l_m.y.y, l_m.z.y);
  l_c2 = coax_p_v3(cx, l_m.x.z, l_m.y.z, l_m.z.z);
  l_normal_70 = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_cross3(cx, l_c1, l_c2), l_v.y.x), coax_p_wg_mul_f3f(cx, coax_p_wg_cross3(cx, l_c2, l_c0), l_v.y.y)), coax_p_wg_mul_f3f(cx, coax_p_wg_cross3(cx, l_c0, l_c1), l_v.y.z));
  l_o.x = coax_p_eg_clip(cx, l_w_66);
  l_o.y = l_w_66;
  l_o.z = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_normal_70, coax_p_v3(cx, 0.0f, 0x1.4f8b58p-17f, 0.0f)));
  l_o.w = l_tint;
  l_o.f4 = (l_ranger ? 8u : (l_cone ? 6u : (l_canopy ? 7u : ((coax_p_wg_u32_f(cx, l_m.w.w) / 8u) % 32u))));
  l_o.f8 = l_v.x;
  if ((l_o.f9 != 0u))
  {
    l_o.f4 = 5u;
  }
  if ((l_o.f4 == 14u))
  {
    l_h = coax_p_render_noise3(cx, l_m.x.w, l_m.y.w, l_m.z.w);
    l_o.f7 = coax_p_v4(cx, ((l_h < 0x1.51eb86p-1f) ? (0x1.333334p-1f + (0x1.99999ap-2f * coax_p_fract(cx, (l_h * 0x1.d3d70ap2f)))) : 0.0f), (l_glass ? 0x1.000000p0f : 0x1.000000p-1f), coax_p_fract(cx, (l_h * 0x1.b66666p3f)), 0.0f);
  }
  if (coax_p_eg_spell_soft(cx, l_o.f4))
  {
    l_at_72 = coax_p_v3(cx, l_m.x.w, l_m.y.w, l_m.z.w);
    l_o.f7 = coax_p_v4(cx, coax_p_fmin(cx, (coax_p_fract(cx, l_m.w.w) / 0x1.f5c290p-1f), 0x1.000000p0f), coax_p_render_noise3(cx, l_at_72.x, l_at_72.y, l_at_72.z), 0.0f, 0.0f);
  }
  return l_o;
}
bool coax_p_eg_spell_soft(CoaxResources cx, uint p_look) {
  uint l_look = p_look;
  return ((l_look >= 17u) && (l_look <= 19u));
}
coax_t20 coax_p_eg_light_space(CoaxResources cx) {
  float3 l_l{};
  float3 l_ax{};
  float3 l_ay{};
  float l_reach{};
  float l_size{};
  float3 l_c{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_ax = ((abs(l_l.y) < 0x1.ff7ceep-1f) ? coax_p_wg_normalize3(cx, coax_p_wg_cross3(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_l)) : coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f));
  l_ay = coax_p_wg_cross3(cx, l_l, l_ax);
  l_reach = coax_p_verse_style_shadow_reach(cx, (coax_p_eg_st(cx, 31u)).z);
  l_size = coax_p_fmax(cx, (coax_p_eg_st(cx, 21u)).x, 0x1.000000p0f);
  l_c = coax_p_v3(cx, cx.r_u[24], 0.0f, cx.r_u[26]);
  return coax_t20{l_ax, l_ay, l_l, coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ax), l_reach, l_size), coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ay), l_reach, l_size), l_reach};
}
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t20 p_k) {
  float3 l_w = p_w;
  coax_t20 l_k = p_k;
  return coax_p_v3(cx, coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.x) - l_k.w), l_k.f5), coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.y) - l_k.f4), l_k.f5), coax_p_verse_style_shadow_depth(cx, coax_p_wg_dot3(cx, coax_p_wg_sub_f3f3(cx, l_w, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_ff3(cx, l_k.w, l_k.x), coax_p_wg_mul_ff3(cx, l_k.f4, l_k.y))), l_k.z), l_k.f5));
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
float4 coax_p_wg_make_f4_f2ff(CoaxResources cx, float2 p_p0, float p_p1, float p_p2) {
  float2 l_p0 = p_p0;
  float l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p1, l_p2);
}
float coax_p_eg_shard_inside(CoaxResources cx, uint p_shard, float3 p_p) {
  uint l_shard = p_shard;
  float3 l_p = p_p;
  uint l_cell{};
  float l_d{};
  uint l_k{};
  float4 l_pl{};
  l_cell = (coax_p_wg_u32_f(cx, cx.r_objects[int((l_shard - 1u))].w.w) / 256u);
  l_d = 0x1.dcd650p29f;
  {
    l_k = 0u;
    while ((l_k < 8u))
    {
      l_pl = coax_p_eg_shard_plane(cx, l_cell, l_k);
      l_d = coax_p_fmin(cx, l_d, (l_pl.w - coax_p_wg_dot3(cx, coax_p_v3(cx, l_pl.x, l_pl.y, l_pl.z), l_p)));
      l_k = (l_k + 1u);
    }
  }
  return l_d;
}
bool coax_p_eg_leaf_gone(CoaxResources cx, float3 p_local, float p_bare) {
  float3 l_local = p_local;
  float l_bare = p_bare;
  if ((l_bare <= 0.0f))
  {
    return false;
  }
  return (coax_p_eg_noise(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_local.x, l_local.z), 0x1.b33334p0f), coax_p_v2(cx, (l_local.y * 0x1.4cccccp0f), ((-l_local.y) * 0x1.ccccccp-1f)))) < ((l_bare * 0x1.266666p0f) - 0x1.47ae14p-4f));
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
float2 coax_p_eg_quad(CoaxResources cx, uint p_v) {
  uint l_v = p_v;
  array<float2, 6> l_q{};
  l_q = array<float2, 6>{coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f), coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f), coax_p_v2(cx, 0.0f, 0x1.000000p0f)};
  return l_q[int(l_v)];
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z) {
  int l_x = p_x;
  int l_z = p_z;
  int l_n{};
  int l_cx{};
  int l_cz{};
  l_n = coax_p_wg_i32_f(cx, cx.r_u[32]);
  l_cx = coax_p_wg_clamp_i(cx, l_x, 0, l_n);
  l_cz = coax_p_wg_clamp_i(cx, l_z, 0, l_n);
  return cx.r_heights[int(uint(((l_cz * (l_n + 1)) + l_cx)))];
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w) {
  float3 l_w = p_w;
  float4 l_p{};
  l_p = coax_p_v4(cx, l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  return coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), l_p));
}
coax_t18 coax_p_eg_box_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  uint l_f{};
  float2 l_c{};
  float3 l_n{};
  float3 l_a{};
  float3 l_b{};
  uint l__sw2{};
  l_f = (l_id / 6u);
  l_c = coax_p_wg_sub_f2f2(cx, coax_p_eg_quad(cx, (l_id % 6u)), coax_p_v2(cx, 0x1.000000p-1f, 0x1.000000p-1f));
  l_n = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_a = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_b = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  {
    l__sw2 = l_f;
    if ((l__sw2 == 0u))
    {
      l_n = coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f);
      l_a = coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f);
      l_b = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
    }
    else
    {
      if ((l__sw2 == 1u))
      {
        l_n = coax_p_v3(cx, (-0x1.000000p0f), 0.0f, 0.0f);
        l_a = coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f);
        l_b = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
      }
      else
      {
        if ((l__sw2 == 2u))
        {
          l_n = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
          l_a = coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f);
          l_b = coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f);
        }
        else
        {
          if ((l__sw2 == 3u))
          {
            l_n = coax_p_v3(cx, 0.0f, (-0x1.000000p0f), 0.0f);
            l_a = coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f);
            l_b = coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f);
          }
          else
          {
            if ((l__sw2 == 4u))
            {
              l_n = coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f);
              l_a = coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f);
              l_b = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
            }
            else
            {
              l_n = coax_p_v3(cx, 0.0f, 0.0f, (-0x1.000000p0f));
              l_a = coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f);
              l_b = coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f);
            }
          }
        }
      }
    }
  }
  return coax_t18{coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_n, 0x1.000000p-1f), coax_p_wg_mul_f3f(cx, l_a, l_c.x)), coax_p_wg_mul_f3f(cx, l_b, l_c.y)), l_n};
}
coax_t18 coax_p_eg_sphere_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  uint l_q{};
  float2 l_c{};
  float l_lon{};
  float l_lat{};
  float3 l_n{};
  l_q = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  l_lon = (((float((l_q % 16u)) + l_c.x) / 0x1.000000p4f) * 0x1.921fb6p2f);
  l_lat = (((float((l_q / 16u)) + l_c.y) / 0x1.400000p3f) * 0x1.921fb6p1f);
  l_n = coax_p_v3(cx, (sin(l_lat) * cos(l_lon)), cos(l_lat), (sin(l_lat) * sin(l_lon)));
  return coax_t18{coax_p_wg_mul_f3f(cx, l_n, 0x1.000000p-1f), l_n};
}
coax_t18 coax_p_eg_cylinder_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  float2 l_c{};
  float l_a{};
  float3 l_n{};
  uint l_t{};
  uint l_k{};
  bool l_top{};
  float l_y{};
  float3 l_n_8{};
  float l_a_9{};
  if ((l_id < 96u))
  {
    l_c = coax_p_eg_quad(cx, (l_id % 6u));
    l_a = (((float((l_id / 6u)) + l_c.x) / 0x1.000000p4f) * 0x1.921fb6p2f);
    l_n = coax_p_v3(cx, cos(l_a), 0.0f, sin(l_a));
    return coax_t18{coax_p_v3(cx, (l_n.x * 0x1.000000p-1f), (l_c.y - 0x1.000000p-1f), (l_n.z * 0x1.000000p-1f)), l_n};
  }
  l_t = ((l_id - 96u) / 3u);
  l_k = ((l_id - 96u) % 3u);
  l_top = (l_t < 16u);
  l_y = (l_top ? 0x1.000000p-1f : (-0x1.000000p-1f));
  l_n_8 = coax_p_v3(cx, 0.0f, (l_top ? 0x1.000000p0f : (-0x1.000000p0f)), 0.0f);
  if ((l_k == 0u))
  {
    return coax_t18{coax_p_v3(cx, 0.0f, l_y, 0.0f), l_n_8};
  }
  l_a_9 = (((float((l_t % 16u)) + float((l_k - 1u))) / 0x1.000000p4f) * 0x1.921fb6p2f);
  return coax_t18{coax_p_v3(cx, (cos(l_a_9) * 0x1.000000p-1f), l_y, (sin(l_a_9) * 0x1.000000p-1f)), l_n_8};
}
float coax_p_eg_word(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return as_type<float>(cx.r_vertices[int(l_i)]);
}
float4 coax_p_wg_unpack4x8unorm(CoaxResources cx, uint p_x) {
  uint l_x = p_x;
  return coax_p_v4(cx, (float(coax_p_wg_byte(cx, l_x, 0u)) / 0x1.fe0000p7f), (float(coax_p_wg_byte(cx, l_x, 8u)) / 0x1.fe0000p7f), (float(coax_p_wg_byte(cx, l_x, 16u)) / 0x1.fe0000p7f), (float(coax_p_wg_byte(cx, l_x, 24u)) / 0x1.fe0000p7f));
}
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b.x), (l_a.y * l_b.y), (l_a.z * l_b.z));
}
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_v3(cx, (-l_a.x), (-l_a.y), (-l_a.z));
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
float4 coax_p_wg_unpack4x8snorm(CoaxResources cx, uint p_x) {
  uint l_x = p_x;
  return coax_p_v4(cx, coax_p_wg_snorm8(cx, coax_p_wg_byte(cx, l_x, 0u)), coax_p_wg_snorm8(cx, coax_p_wg_byte(cx, l_x, 8u)), coax_p_wg_snorm8(cx, coax_p_wg_byte(cx, l_x, 16u)), coax_p_wg_snorm8(cx, coax_p_wg_byte(cx, l_x, 24u)));
}
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_eg_canopy_n(CoaxResources cx, float3 p_n, float3 p_blob) {
  float3 l_n = p_n;
  float3 l_blob = p_blob;
  return coax_p_wg_normalize3(cx, coax_p_v3(cx, coax_p_verse_style_canopy_normal(cx, l_n.x, l_blob.x, 0x1.b33334p-1f), coax_p_verse_style_canopy_normal(cx, l_n.y, l_blob.y, 0x1.b33334p-1f), coax_p_verse_style_canopy_normal(cx, l_n.z, l_blob.z, 0x1.b33334p-1f)));
}
float2 coax_p_wg_unpack2x16unorm(CoaxResources cx, uint p_x) {
  uint l_x = p_x;
  return coax_p_v2(cx, (float((l_x & 65535u)) / 0x1.fffe00p15f), (float((l_x >> uint(16u))) / 0x1.fffe00p15f));
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
float3 coax_p_EG_PERSON_LOW(CoaxResources cx) {
  return coax_p_v3(cx, (-0x1.400000p0f), (-0x1.000000p-2f), (-0x1.400000p0f));
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float4 coax_p_wg_mul_f4f(CoaxResources cx, float4 p_a, float p_b) {
  float4 l_a = p_a;
  float l_b = p_b;
  return coax_p_v4(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b), (l_a.w * l_b));
}
float4 coax_p_wg_add_f4f(CoaxResources cx, float4 p_a, float p_b) {
  float4 l_a = p_a;
  float l_b = p_b;
  return coax_p_v4(cx, (l_a.x + l_b), (l_a.y + l_b), (l_a.z + l_b), (l_a.w + l_b));
}
coax_t19 coax_p_wg_cvt_u4f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_u4(cx, coax_p_wg_u32_f(cx, l_p.x), coax_p_wg_u32_f(cx, l_p.y), coax_p_wg_u32_f(cx, l_p.z), coax_p_wg_u32_f(cx, l_p.w));
}
uint coax_p_wg_get_u4(CoaxResources cx, coax_t19 p_p, int p_i) {
  coax_t19 l_p = p_p;
  int l_i = p_i;
  if ((l_i == 0))
  {
    return l_p.x;
  }
  if ((l_i == 1))
  {
    return l_p.y;
  }
  if ((l_i == 2))
  {
    return l_p.z;
  }
  return l_p.w;
}
float coax_p_wg_get_f4(CoaxResources cx, float4 p_p, int p_i) {
  float4 l_p = p_p;
  int l_i = p_i;
  if ((l_i == 0))
  {
    return l_p.x;
  }
  if ((l_i == 1))
  {
    return l_p.y;
  }
  if ((l_i == 2))
  {
    return l_p.z;
  }
  return l_p.w;
}
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return dot(l_a, l_b);
}
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a * l_b.x), (l_a * l_b.y), (l_a * l_b.z));
}
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
coax_t18 coax_p_eg_lathe_vertex(CoaxResources cx, uint p_id, uint p_word) {
  uint l_id = p_id;
  uint l_word = p_word;
  uint l_profile{};
  uint l_wedge{};
  uint l_q{};
  float2 l_c{};
  uint l_seg{};
  uint l_sector{};
  float l_a{};
  uint l_j{};
  float2 l_p{};
  float2 l_n2{};
  float2 l_other{};
  float3 l_dir{};
  l_profile = (l_word / 8u);
  l_wedge = (l_word % 8u);
  l_q = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  l_seg = (l_q % 28u);
  l_sector = (l_q / 28u);
  l_a = (((float(((l_wedge * 6u) + l_sector)) + l_c.x) / 0x1.800000p5f) * 0x1.921fb6p2f);
  l_j = (l_seg + coax_p_wg_u32_f(cx, l_c.y));
  l_p = coax_p_eg_lathe_point(cx, l_profile, l_j);
  l_n2 = coax_p_eg_lathe_segment_n(cx, l_profile, l_seg);
  l_other = coax_p_v2(cx, 0.0f, 0.0f);
  if ((l_c.y > 0x1.000000p-1f))
  {
    l_other = coax_p_eg_lathe_segment_n(cx, l_profile, (l_seg + 1u));
  }
  else
  {
    if ((l_seg > 0u))
    {
      l_other = coax_p_eg_lathe_segment_n(cx, l_profile, (l_seg - 1u));
    }
  }
  if ((coax_p_wg_dot2(cx, l_n2, l_other) > 0x1.800000p-1f))
  {
    l_n2 = coax_p_wg_normalize2(cx, coax_p_wg_add_f2f2(cx, l_n2, l_other));
  }
  if ((coax_p_wg_dot2(cx, l_n2, l_n2) < 0x1.000000p-1f))
  {
    l_n2 = coax_p_v2(cx, 0.0f, 0x1.000000p0f);
  }
  l_dir = coax_p_v3(cx, cos(l_a), 0.0f, sin(l_a));
  return coax_t18{coax_p_v3(cx, (l_dir.x * l_p.x), l_p.y, (l_dir.z * l_p.x)), coax_p_wg_normalize3(cx, coax_p_v3(cx, (l_dir.x * l_n2.x), l_n2.y, (l_dir.z * l_n2.x)))};
}
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x) {
  float l_y = p_y;
  float l_x = p_x;
  float l_ax{};
  float l_ay{};
  float l_high{};
  float l_r{};
  l_ax = abs(l_x);
  l_ay = abs(l_y);
  l_high = coax_p_fmax(cx, l_ax, l_ay);
  if ((l_high == 0.0f))
  {
    return 0.0f;
  }
  l_r = coax_p_wg_atan01(cx, (coax_p_fmin(cx, l_ax, l_ay) / l_high));
  if ((l_ay > l_ax))
  {
    l_r = ((0x1.921fb6p1f * 0x1.000000p-1f) - l_r);
  }
  if ((l_x < 0.0f))
  {
    l_r = (0x1.921fb6p1f - l_r);
  }
  if ((l_y < 0.0f))
  {
    l_r = (-l_r);
  }
  return l_r;
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
coax_t18 coax_p_eg_cone_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  uint l_t{};
  uint l_k{};
  float l_mid{};
  float l_a{};
  float3 l_n{};
  float l_a_6{};
  l_t = ((l_id % 48u) / 3u);
  l_k = (l_id % 3u);
  if ((l_id < 48u))
  {
    l_mid = (((float(l_t) + 0x1.000000p-1f) / 0x1.000000p4f) * 0x1.921fb6p2f);
    if ((l_k == 0u))
    {
      return coax_t18{coax_p_v3(cx, 0.0f, 0x1.000000p-1f, 0.0f), coax_p_wg_normalize3(cx, coax_p_v3(cx, cos(l_mid), 0x1.000000p-1f, sin(l_mid)))};
    }
    l_a = (((float(l_t) + float((l_k - 1u))) / 0x1.000000p4f) * 0x1.921fb6p2f);
    return coax_t18{coax_p_v3(cx, (cos(l_a) * 0x1.000000p-1f), (-0x1.000000p-1f), (sin(l_a) * 0x1.000000p-1f)), coax_p_wg_normalize3(cx, coax_p_v3(cx, cos(l_a), 0x1.000000p-1f, sin(l_a)))};
  }
  l_n = coax_p_v3(cx, 0.0f, (-0x1.000000p0f), 0.0f);
  if ((l_k == 0u))
  {
    return coax_t18{coax_p_v3(cx, 0.0f, (-0x1.000000p-1f), 0.0f), l_n};
  }
  l_a_6 = (((float(l_t) + float((l_k - 1u))) / 0x1.000000p4f) * 0x1.921fb6p2f);
  return coax_t18{coax_p_v3(cx, (cos(l_a_6) * 0x1.000000p-1f), (-0x1.000000p-1f), (sin(l_a_6) * 0x1.000000p-1f)), l_n};
}
coax_t18 coax_p_eg_far_tree_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  bool l_low{};
  uint l_j{};
  uint l_t{};
  uint l_k{};
  float l_top{};
  float l_foot{};
  float l_r{};
  float l_lean{};
  float l_mid{};
  float l_a{};
  uint l_q{};
  float2 l_c{};
  float l_a_13{};
  float3 l_n{};
  if ((l_id < 48u))
  {
    l_low = (l_id >= 24u);
    l_j = (l_id % 24u);
    l_t = (l_j / 3u);
    l_k = (l_j % 3u);
    l_top = (l_low ? 0x1.70a3d8p-3f : 0x1.000000p-1f);
    l_foot = (l_low ? (-0x1.000000p-1f) : (-0x1.47ae14p-4f));
    l_r = (l_low ? 0x1.000000p-1f : 0x1.70a3d8p-2f);
    l_lean = (l_r / (l_top - l_foot));
    if ((l_k == 0u))
    {
      l_mid = (((float(l_t) + 0x1.000000p-1f) / 0x1.000000p3f) * 0x1.921fb6p2f);
      return coax_t18{coax_p_v3(cx, 0.0f, l_top, 0.0f), coax_p_wg_normalize3(cx, coax_p_v3(cx, cos(l_mid), l_lean, sin(l_mid)))};
    }
    l_a = (((float(l_t) + float((l_k - 1u))) / 0x1.000000p3f) * 0x1.921fb6p2f);
    return coax_t18{coax_p_v3(cx, (cos(l_a) * l_r), l_foot, (sin(l_a) * l_r)), coax_p_wg_normalize3(cx, coax_p_v3(cx, cos(l_a), l_lean, sin(l_a)))};
  }
  l_q = (l_id - 48u);
  l_c = coax_p_eg_quad(cx, (l_q % 6u));
  l_a_13 = (((float((l_q / 6u)) + l_c.x) / 0x1.000000p3f) * 0x1.921fb6p2f);
  l_n = coax_p_v3(cx, cos(l_a_13), 0.0f, sin(l_a_13));
  return coax_t18{coax_p_v3(cx, (l_n.x * 0x1.eb851ep-5f), ((-0x1.000000p-1f) - (0x1.99999ap-2f * (0x1.000000p0f - l_c.y))), (l_n.z * 0x1.eb851ep-5f)), l_n};
}
float3 coax_p_eg_canopy_sway(CoaxResources cx, float3 p_at, float p_share) {
  float3 l_at = p_at;
  float l_share = p_share;
  float l_t{};
  float l_theta{};
  float l_d{};
  l_t = ((cx.r_u[4] > 0x1.000000p-1f) ? 0.0f : cx.r_u[2]);
  l_theta = coax_p_verse_style_wind(cx, coax_p_wg_dot2(cx, coax_p_v2(cx, l_at.x, l_at.z), coax_p_EG_WIND_DIR(cx)), coax_p_verse_style_gust(cx, l_at.x, l_at.z, l_t, (coax_p_EG_WIND_DIR(cx)).x, (coax_p_EG_WIND_DIR(cx)).y, (coax_p_EG_WIND(cx)).z, (coax_p_EG_WIND(cx)).w), l_t, (coax_p_EG_WIND(cx)).x, (coax_p_EG_WIND(cx)).y, (coax_p_EG_WIND(cx)).z);
  l_d = coax_p_verse_style_canopy_sway(cx, l_theta, (coax_p_EG_WIND(cx)).x, 0x1.99999ap-5f, l_share);
  return coax_p_v3(cx, ((coax_p_EG_WIND_DIR(cx)).x * l_d), 0.0f, ((coax_p_EG_WIND_DIR(cx)).y * l_d));
}
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_cross3(cx, l_a, l_b);
}
float coax_p_render_noise3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  if ((((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))) || (!coax_p_render_noise_coordinate_ok(cx, l_z))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix3(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y), coax_p_render_noise_cell(cx, l_z)));
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone) {
  float l_on_phone = p_on_phone;
  if ((l_on_phone > 0x1.000000p-1f))
  {
    return 0x1.400000p5f;
  }
  return 0x1.e00000p5f;
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size) {
  float l_x = p_x;
  float l_reach = p_reach;
  float l_size = p_size;
  float l_texel{};
  l_texel = ((0x1.000000p1f * l_reach) / coax_p_st_max(cx, l_size, 0x1.000000p0f));
  return (floor(((l_x / l_texel) + 0x1.000000p-1f)) * l_texel);
}
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach) {
  float l_x = p_x;
  float l_reach = p_reach;
  return (l_x / coax_p_st_max(cx, l_reach, 0x1.0624dep-10f));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach) {
  float l_along = p_along;
  float l_reach = p_reach;
  return (0x1.000000p-1f - (l_along / (0x1.000000p2f * coax_p_st_max(cx, l_reach, 0x1.0624dep-10f))));
}
float4 coax_p_eg_shard_plane(CoaxResources cx, uint p_cell, uint p_k) {
  uint l_cell = p_cell;
  uint l_k = p_k;
  coax_t9 l_o{};
  uint l_j{};
  l_o = cx.r_objects[int((l_cell + (l_k / 4u)))];
  l_j = (l_k % 4u);
  if ((l_j == 0u))
  {
    return l_o.x;
  }
  if ((l_j == 1u))
  {
    return l_o.y;
  }
  if ((l_j == 2u))
  {
    return l_o.z;
  }
  return l_o.w;
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_eg_noise(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float2 l_i{};
  float2 l_f{};
  float2 l_s{};
  l_i = coax_p_wg_floor_f2(cx, l_p);
  l_f = coax_p_wg_fract_f2(cx, l_p);
  l_s = coax_p_wg_mul_f2f2(cx, coax_p_wg_mul_f2f2(cx, l_f, l_f), coax_p_wg_sub_ff2(cx, 0x1.800000p1f, coax_p_wg_mul_ff2(cx, 0x1.000000p1f, l_f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_hash(cx, l_i), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0.0f))), l_s.x), coax_p_mix(cx, coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0.0f, 0x1.000000p0f))), coax_p_eg_hash(cx, coax_p_wg_add_f2f2(cx, l_i, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f))), l_s.x), l_s.y);
}
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high) {
  int l_x = p_x;
  int l_low = p_low;
  int l_high = p_high;
  return coax_p_wg_min_i(cx, coax_p_wg_max_i(cx, l_x, l_low), l_high);
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
uint coax_p_wg_byte(CoaxResources cx, uint p_x, uint p_at) {
  uint l_x = p_x;
  uint l_at = p_at;
  return ((l_x >> uint(l_at)) & 255u);
}
float coax_p_wg_snorm8(CoaxResources cx, uint p_b) {
  uint l_b = p_b;
  float l_s{};
  l_s = float(l_b);
  if ((l_b >= 128u))
  {
    l_s = (l_s - 0x1.000000p8f);
  }
  return coax_p_fmax(cx, (l_s / 0x1.fc0000p6f), (-0x1.000000p0f));
}
float coax_p_verse_style_canopy_normal(CoaxResources cx, float p_mesh_n, float p_blob_n, float p_k) {
  float l_mesh_n = p_mesh_n;
  float l_blob_n = p_blob_n;
  float l_k = p_k;
  return (l_mesh_n + ((l_blob_n - l_mesh_n) * l_k));
}
coax_t19 coax_p_u4(CoaxResources cx, uint p_x, uint p_y, uint p_z, uint p_w) {
  uint l_x = p_x;
  uint l_y = p_y;
  uint l_z = p_z;
  uint l_w = p_w;
  return coax_t19{l_x, l_y, l_z, l_w};
}
float2 coax_p_eg_lathe_point(CoaxResources cx, uint p_profile, uint p_j) {
  uint l_profile = p_profile;
  uint l_j = p_j;
  array<float2, 22> l_basin{};
  array<float2, 29> l_column{};
  l_basin = array<float2, 22>{coax_p_v2(cx, 0.0f, 0x1.99999ap-5f), coax_p_v2(cx, 0x1.333334p0f, 0x1.99999ap-4f), coax_p_v2(cx, 0x1.000000p1f, 0x1.000000p-2f), coax_p_v2(cx, 0x1.333334p1f, 0x1.851eb8p-2f), coax_p_v2(cx, 0x1.451eb8p1f, 0x1.d70a3ep-2f), coax_p_v2(cx, 0x1.4cccccp1f, 0x1.1eb852p-1f), coax_p_v2(cx, 0x1.4f5c28p1f, 0x1.666666p-1f), coax_p_v2(cx, 0x1.547ae2p1f, 0x1.99999ap-1f), coax_p_v2(cx, 0x1.5eb852p1f, 0x1.b851ecp-1f), coax_p_v2(cx, 0x1.6e147ap1f, 0x1.c7ae14p-1f), coax_p_v2(cx, 0x1.7d70a4p1f, 0x1.c28f5cp-1f), coax_p_v2(cx, 0x1.87ae14p1f, 0x1.ae147ap-1f), coax_p_v2(cx, 0x1.8cccccp1f, 0x1.8a3d70p-1f), coax_p_v2(cx, 0x1.8a3d70p1f, 0x1.6147aep-1f), coax_p_v2(cx, 0x1.800000p1f, 0x1.4cccccp-1f), coax_p_v2(cx, 0x1.7c28f6p1f, 0x1.333334p-1f), coax_p_v2(cx, 0x1.7c28f6p1f, 0x1.333334p-2f), coax_p_v2(cx, 0x1.828f5cp1f, 0x1.000000p-2f), coax_p_v2(cx, 0x1.99999ap1f, 0x1.d70a3ep-3f), coax_p_v2(cx, 0x1.a3d70ap1f, 0x1.851eb8p-3f), coax_p_v2(cx, 0x1.a7ae14p1f, 0x1.eb851ep-4f), coax_p_v2(cx, 0x1.a8f5c2p1f, (-0x1.333334p-2f))};
  l_column = array<float2, 29>{coax_p_v2(cx, 0.0f, 0x1.4f5c28p1f), coax_p_v2(cx, 0x1.70a3d8p-4f, 0x1.4cccccp1f), coax_p_v2(cx, 0x1.5c28f6p-3f, 0x1.43d70ap1f), coax_p_v2(cx, 0x1.ae147ap-3f, 0x1.3851ecp1f), coax_p_v2(cx, 0x1.5c28f6p-3f, 0x1.2e147ap1f), coax_p_v2(cx, 0x1.0a3d70p-3f, 0x1.1c28f6p1f), coax_p_v2(cx, 0x1.333334p-3f, 0x1.0cccccp1f), coax_p_v2(cx, 0x1.eb851ep-3f, 0x1.eb851ep0f), coax_p_v2(cx, 0x1.666666p-1f, 0x1.e66666p0f), coax_p_v2(cx, 0x1.0cccccp0f, 0x1.ee147ap0f), coax_p_v2(cx, 0x1.28f5c2p0f, 0x1.028f5cp1f), coax_p_v2(cx, 0x1.333334p0f, 0x1.0f5c28p1f), coax_p_v2(cx, 0x1.47ae14p0f, 0x1.147ae2p1f), coax_p_v2(cx, 0x1.5c28f6p0f, 0x1.10a3d8p1f), coax_p_v2(cx, 0x1.666666p0f, 0x1.07ae14p1f), coax_p_v2(cx, 0x1.5c28f6p0f, 0x1.fd70a4p0f), coax_p_v2(cx, 0x1.1eb852p0f, 0x1.dc28f6p0f), coax_p_v2(cx, 0x1.99999ap-1f, 0x1.bd70a4p0f), coax_p_v2(cx, 0x1.000000p-1f, 0x1.9eb852p0f), coax_p_v2(cx, 0x1.99999ap-2f, 0x1.8a3d70p0f), coax_p_v2(cx, 0x1.ae147ap-2f, 0x1.75c290p0f), coax_p_v2(cx, 0x1.51eb86p-2f, 0x1.6147aep0f), coax_p_v2(cx, 0x1.28f5c2p-2f, 0x1.4cccccp0f), coax_p_v2(cx, 0x1.3d70a4p-2f, 0x1.19999ap-1f), coax_p_v2(cx, 0x1.99999ap-2f, 0x1.c28f5cp-2f), coax_p_v2(cx, 0x1.d70a3ep-2f, 0x1.333334p-2f), coax_p_v2(cx, 0x1.333334p-1f, 0x1.c28f5cp-3f), coax_p_v2(cx, 0x1.3d70a4p-1f, 0x1.1eb852p-3f), coax_p_v2(cx, 0x1.3d70a4p-1f, (-0x1.99999ap-4f))};
  if ((l_profile == 0u))
  {
    return l_basin[int(coax_p_wg_min_u(cx, l_j, 21u))];
  }
  return l_column[int(coax_p_wg_min_u(cx, l_j, 28u))];
}
float2 coax_p_eg_lathe_segment_n(CoaxResources cx, uint p_profile, uint p_k) {
  uint l_profile = p_profile;
  uint l_k = p_k;
  float2 l_t{};
  l_t = coax_p_wg_sub_f2f2(cx, coax_p_eg_lathe_point(cx, l_profile, (l_k + 1u)), coax_p_eg_lathe_point(cx, l_profile, l_k));
  if ((coax_p_wg_dot2(cx, l_t, l_t) < 0x1.5798eep-27f))
  {
    return coax_p_v2(cx, 0.0f, 0.0f);
  }
  return coax_p_wg_normalize2(cx, coax_p_v2(cx, (-l_t.y), l_t.x));
}
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return dot(l_a, l_b);
}
float2 coax_p_wg_normalize2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return coax_p_scale2(cx, l_a, (0x1.000000p0f / coax_p_wg_length2(cx, l_a)));
}
float coax_p_wg_atan01(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_z{};
  float l_p{};
  l_z = (l_x * l_x);
  l_p = (-0x1.09afcep-8f);
  l_p = ((l_p * l_z) + 0x1.662ca4p-6f);
  l_p = ((l_p * l_z) - 0x1.ca0388p-5f);
  l_p = ((l_p * l_z) + 0x1.8aefbep-4f);
  l_p = ((l_p * l_z) - 0x1.1cd8c6p-3f);
  l_p = ((l_p * l_z) + 0x1.98814cp-3f);
  l_p = ((l_p * l_z) - 0x1.554c38p-2f);
  l_p = ((l_p * l_z) + 0x1.ffffeap-1f);
  return (l_x * l_p);
}
float2 coax_p_EG_WIND_DIR(CoaxResources cx) {
  return coax_p_v2(cx, 0x1.99999ap-1f, 0x1.333334p-1f);
}
float4 coax_p_EG_WIND(CoaxResources cx) {
  return coax_p_v4(cx, 0x1.333334p-2f, 0x1.800000p3f, 0x1.800000p1f, (0x1.000000p0f / 0x1.900000p4f));
}
float coax_p_verse_style_gust(CoaxResources cx, float p_x, float p_z, float p_t, float p_wx, float p_wz, float p_speed, float p_scale) {
  float l_x = p_x;
  float l_z = p_z;
  float l_t = p_t;
  float l_wx = p_wx;
  float l_wz = p_wz;
  float l_speed = p_speed;
  float l_scale = p_scale;
  return ((0x1.000000p1f * coax_p_verse_style_noise(cx, ((l_x - ((l_wx * l_speed) * l_t)) * l_scale), ((l_z - ((l_wz * l_speed) * l_t)) * l_scale))) - 0x1.000000p0f);
}
float coax_p_verse_style_wind(CoaxResources cx, float p_along, float p_gust, float p_t, float p_amp, float p_wavelength, float p_speed) {
  float l_along = p_along;
  float l_gust = p_gust;
  float l_t = p_t;
  float l_amp = p_amp;
  float l_wavelength = p_wavelength;
  float l_speed = p_speed;
  float l_k{};
  l_k = (0x1.921fb6p2f / coax_p_st_max(cx, l_wavelength, 0x1.0624dep-10f));
  return (l_amp * ((0x1.333334p-1f * sin(((l_k * l_along) - ((l_k * l_speed) * l_t)))) + (0x1.99999ap-2f * l_gust)));
}
float coax_p_verse_style_canopy_sway(CoaxResources cx, float p_theta, float p_amp, float p_reach, float p_share) {
  float l_theta = p_theta;
  float l_amp = p_amp;
  float l_reach = p_reach;
  float l_share = p_share;
  return ((l_reach * coax_p_st_sat(cx, l_share)) * coax_p_st_max(cx, (-0x1.000000p0f), coax_p_st_min(cx, 0x1.000000p0f, (l_theta / coax_p_st_max(cx, l_amp, 0x1.a36e2ep-14f)))));
}
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return ((l_x >= (-0x1.fffffep127f)) && (l_x <= 0x1.fffffep127f));
}
uint coax_p_render_noise_cell(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_bounded{};
  l_bounded = coax_p_fmin(cx, coax_p_fmax(cx, l_x, (-0x1.000000p25f)), 0x1.fffffep24f);
  return uint(int(floor((l_bounded * 0x1.000000p6f))));
}
uint coax_p_render_noise_mix3(CoaxResources cx, uint p_x, uint p_y, uint p_z) {
  uint l_x = p_x;
  uint l_y = p_y;
  uint l_z = p_z;
  return coax_p_render_noise_permute(cx, (((l_x * 1597334677u) ^ (l_y * 3812015801u)) ^ (l_z * 2654435761u)));
}
float coax_p_render_noise_unit(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  return (float((l_word >> uint(8u))) * 0x1.000000p-24f);
}
float coax_p_st_max(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a > l_b))
  {
    return l_a;
  }
  return l_b;
}
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, floor(l_p0.x), floor(l_p0.y));
}
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y));
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float2 coax_p_wg_mul_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a * l_b.x), (l_a * l_b.y));
}
float2 coax_p_wg_sub_ff2(CoaxResources cx, float p_a, float2 p_b) {
  float l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a - l_b.x), (l_a - l_b.y));
}
float coax_p_eg_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b) {
  uint l_a = p_a;
  uint l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float2 coax_p_scale2(CoaxResources cx, float2 p_a, float p_k) {
  float2 l_a = p_a;
  float l_k = p_k;
  return float2((l_a.x * l_k), (l_a.y * l_k));
}
float coax_p_verse_style_noise(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  float l_ix{};
  float l_iy{};
  float l_fx{};
  float l_fy{};
  float l_sx{};
  float l_sy{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  l_ix = floor(l_x);
  l_iy = floor(l_y);
  l_fx = (l_x - l_ix);
  l_fy = (l_y - l_iy);
  l_sx = ((l_fx * l_fx) * (0x1.800000p1f - (0x1.000000p1f * l_fx)));
  l_sy = ((l_fy * l_fy) * (0x1.800000p1f - (0x1.000000p1f * l_fy)));
  l_a = coax_p_verse_style_hash(cx, l_ix, l_iy);
  l_b = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), l_iy);
  l_c = coax_p_verse_style_hash(cx, l_ix, (l_iy + 0x1.000000p0f));
  l_d = coax_p_verse_style_hash(cx, (l_ix + 0x1.000000p0f), (l_iy + 0x1.000000p0f));
  return ((l_a + ((l_b - l_a) * l_sx)) + (((l_c + ((l_d - l_c) * l_sx)) - (l_a + ((l_b - l_a) * l_sx))) * l_sy));
}
float coax_p_st_sat(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_st_min(cx, 0x1.000000p0f, coax_p_st_max(cx, 0.0f, l_x));
}
float coax_p_st_min(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a < l_b))
  {
    return l_a;
  }
  return l_b;
}
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  uint l_h{};
  l_h = (l_word * 747796405u);
  l_h = ((l_h ^ (l_h >> uint(16u))) * 2246822519u);
  return (l_h ^ (l_h >> uint(13u)));
}
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  if (((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix2(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y)));
}
float coax_p_verse_style_hash(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return coax_p_render_noise2(cx, l_x, l_y);
}
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_p_render_noise_permute(cx, ((l_x * 1597334677u) ^ (l_y * 3812015801u)));
}
vertex coax_io_14 eg_shadow_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_shadow_vs(cx, coax_vid, coax_iid);
  return coax_io_14{coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4, coax_r.f5, coax_r.f6};
}
fragment void eg_shadow_fs(coax_io_14 coax_in [[stage_in]], CoaxResources cx) {
  coax_p_eg_shadow_fs(cx, coax_t14{coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4, coax_in.f5, coax_in.f6});
}
