// Coax Metal graphics; compile as Metal 2.3 or later, without fast math.
#include <metal_stdlib>
using namespace metal;
struct coax_t8 {
  float4 x;
  float4 y;
  float4 z;
  float4 w;
  float4 f4;
};
struct coax_io_8 {
  float4 x [[position]];
  float4 y [[user(locn0)]];
  float4 z [[user(locn1)]];
  float4 w [[user(locn2)]];
  float4 f4 [[user(locn3)]];
};
struct coax_t11 {
  alignas(16) packed_float3 x;
  float y;
  float z;
  float2 w;
  float f4;
};
struct coax_t16 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
  float z;
};
struct coax_t19 {
  int x;
  int y;
};
struct coax_t20 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
  float2 z;
  float4 w;
};
struct coax_t21 {
  uint x;
  uint y;
};
struct coax_t22 {
  uint x;
  uint y;
  uint z;
};
struct coax_t23 {
  int x;
  int y;
  int z;
};
struct coax_t24 {
  alignas(16) packed_float3 x;
  alignas(16) packed_float3 y;
  alignas(16) packed_float3 z;
  float w;
  float f4;
  float f5;
};
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(float) == 4, "portable storage stride");
static_assert(sizeof(float) == 4, "portable storage stride");
struct CoaxResources {
  device const float* r_u [[buffer(0)]];
  device const float* r_heights [[buffer(1)]];
  device const float* r_water_nodes [[buffer(2)]];
  depth2d<float> r_shadow_map [[texture(0)]];
  sampler r_shadow_cmp [[sampler(0)]];
  texture2d<float> r_water_scene [[texture(1)]];
  depth2d<float> r_water_scene_depth [[texture(2)]];
  constant uint* coax_lengths [[buffer(29)]];
};
inline float coax_metal_pow(float x, float y) {
  if (y == 0.0f) return 1.0f;
  if (x == 0.0f) return y > 0.0f ? 0.0f : as_type<float>(0x7f800000u);
  float r = pow(abs(x), y);
  if (!(x < 0.0f)) return r;
  if (floor(y) != y) return as_type<float>(0x7fc00000u);
  return fract(y * 0.5f) != 0.0f ? -r : r;
}
coax_t8 coax_p_eg_water_vs(CoaxResources cx, uint p_id, uint p_piece);
float4 coax_p_eg_water_emit_fs(CoaxResources cx, coax_t8 p_i);
uint coax_p_wg_u32_f(CoaxResources cx, float p_x);
coax_t8 coax_p_eg_fx_vertex(CoaxResources cx, uint p_id, uint p_f);
coax_t8 coax_p_eg_pond_vertex(CoaxResources cx, uint p_id, uint p_f);
coax_t8 coax_p_eg_fountain_vertex(CoaxResources cx, uint p_id, uint p_f);
float2 coax_p_eg_quad(CoaxResources cx, uint p_v);
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y);
coax_t11 coax_p_eg_water_rest(CoaxResources cx, float2 p_uv);
float coax_p_fmin(CoaxResources cx, float p_a, float p_b);
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w);
float4 coax_p_eg_water_gerstner(CoaxResources cx, float2 p_p0, float p_depth, float p_scale);
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z);
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w);
float4 coax_p_wg_make_f4_f2f2(CoaxResources cx, float2 p_p0, float2 p_p1);
bool coax_p_eg_water_surface_part(CoaxResources cx, uint p_part);
float3 coax_p_eg_water_whole(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1);
coax_t20 coax_p_eg_water_halves(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
coax_t8 coax_p_eg_weir_vertex(CoaxResources cx, uint p_id);
float4 coax_p_wg_at4(CoaxResources cx, int p_at);
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a);
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b);
bool coax_p_eg_pond_on(CoaxResources cx, uint p_p);
float4 coax_p_eg_pond_row(CoaxResources cx, uint p_p);
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_eg_ground_y(CoaxResources cx, float2 p_q);
float coax_p_fmax(CoaxResources cx, float p_a, float p_b);
bool coax_p_eg_fountain_on(CoaxResources cx);
float coax_p_eg_fountain_base(CoaxResources cx);
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t);
float coax_p_eg_fountain_floor(CoaxResources cx, float p_r);
float coax_p_wg_sign(CoaxResources cx, float p_x);
float coax_p_eg_fountain_stream_near(CoaxResources cx, float p_a);
coax_t16 coax_p_eg_fountain_fall(CoaxResources cx, uint p_k, bool p_jet, float p_v);
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x);
float coax_p_eg_fountain_stream_angle(CoaxResources cx, uint p_k);
float2 coax_p_wg_clamp_f2f2f2(CoaxResources cx, float2 p_p0, float2 p_p1, float2 p_p2);
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b);
float coax_p_eg_water_node(CoaxResources cx, uint p_k, uint p_f);
int coax_p_wg_i32_f(CoaxResources cx, float p_x);
float coax_p_eg_water_shoal(CoaxResources cx, float p_k, float p_depth);
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b);
coax_t19 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p);
float coax_p_eg_water_hull(CoaxResources cx, float2 p_p);
bool coax_p_eg_water_dry(CoaxResources cx, float2 p_p);
float3 coax_p_eg_water_scene_at(CoaxResources cx, coax_t19 p_px);
float coax_p_eg_water_thickness(CoaxResources cx, coax_t19 p_px, float3 p_world);
coax_t21 coax_p_wg_dims_2d(CoaxResources cx);
float coax_p_wg_length3(CoaxResources cx, float3 p_a);
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b);
float2 coax_p_wg_round_f2(CoaxResources cx, float2 p_p0);
coax_t19 coax_p_wg_add_i2i2(CoaxResources cx, coax_t19 p_a, coax_t19 p_b);
float coax_p_eg_water_scene_w(CoaxResources cx, coax_t19 p_px);
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b);
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a);
float3 coax_p_wg_reflect3(CoaxResources cx, float3 p_i, float3 p_n);
float4 coax_p_eg_water_ssr(CoaxResources cx, float3 p_p, float3 p_dir);
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y);
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1);
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p);
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high);
float3 coax_p_eg_water_host_light(CoaxResources cx, float3 p_world, float3 p_n, bool p_paint_leaf_far);
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2);
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
coax_t20 coax_p_eg_water_fragment(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b);
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v);
float3 coax_p_normalize3(CoaxResources cx, float3 p_a);
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0);
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0);
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z);
float3 coax_p_EG_F_JET(CoaxResources cx);
float2 coax_p_EG_F_JET_V(CoaxResources cx);
float2 coax_p_EG_F_LIP(CoaxResources cx);
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_saturate(CoaxResources cx, float p_x);
float coax_p_wg_tanh(CoaxResources cx, float p_x);
coax_t19 coax_p_i2(CoaxResources cx, int p_x, int p_y);
float coax_p_wg_length2(CoaxResources cx, float2 p_a);
coax_t19 coax_p_wg_cvt_i2u2(CoaxResources cx, coax_t21 p_p);
coax_t19 coax_p_wg_sub_i2i2(CoaxResources cx, coax_t19 p_a, coax_t19 p_b);
coax_t19 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t19 p_p0, coax_t19 p_p1, coax_t19 p_p2);
float4 coax_p_wg_load_2d(CoaxResources cx, coax_t19 p_c, int p_level);
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p);
coax_t21 coax_p_u2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_wg_round(CoaxResources cx, float p_x);
coax_t21 coax_p_wg_dims_depth(CoaxResources cx);
float coax_p_wg_load_depth(CoaxResources cx, coax_t19 p_c, int p_level);
float coax_p_eg_water_view_w(CoaxResources cx, float p_d);
float3 coax_p_reflect3(CoaxResources cx, float3 p_i, float3 p_n);
float2 coax_p_wg_cvt_f2u2(CoaxResources cx, coax_t21 p_p);
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float4 coax_p_eg_st(CoaxResources cx, uint p_i);
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff);
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0);
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b);
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b);
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p);
float coax_p_eg_shade_shadows(CoaxResources cx, float2 p_p);
float3 coax_p_eg_water_host_light_shaded(CoaxResources cx, float3 p_world, float3 p_n, float p_sh, bool p_paint_leaf_far);
coax_t20 coax_p_eg_weir_shade(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far);
coax_t20 coax_p_eg_fx_shade(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far);
coax_t20 coax_p_eg_fountain_fall_shade(CoaxResources cx, coax_t8 p_i, uint p_part, bool p_paint_leaf_far);
float coax_p_eg_water_footprint(CoaxResources cx, float3 p_v, float p_distance);
coax_t20 coax_p_eg_pond_shade(CoaxResources cx, coax_t8 p_i, float3 p_v, float p_eye_distance, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
coax_t20 coax_p_eg_fountain_pool_shade(CoaxResources cx, coax_t8 p_i, uint p_part, float3 p_v, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
float3 coax_p_eg_water_gerstner_slope(CoaxResources cx, float2 p_p0, float p_depth, float p_scale);
float3 coax_p_eg_water_flow_detail(CoaxResources cx, float2 p_p, float2 p_flow, float p_footprint);
float2 coax_p_eg_water_ripples(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam);
float2 coax_p_eg_weather_rain_slope(CoaxResources cx, float2 p_p);
coax_t20 coax_p_eg_water_below(CoaxResources cx, float3 p_n, float3 p_v, float p_path, float p_slope);
coax_t20 coax_p_eg_water_painted(CoaxResources cx, float3 p_world, float2 p_rest, float2 p_flow, float p_depth, float p_shore, float p_white, float3 p_n, float3 p_v, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_eg_water_fresnel(CoaxResources cx, float p_c);
float coax_p_eg_water_sky_roughness(CoaxResources cx, float p_roughness, float p_footprint);
float3 coax_p_eg_water_host_sky(CoaxResources cx, float3 p_dir, float p_level);
float4 coax_p_eg_water_host_sun(CoaxResources cx);
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p);
float3 coax_p_eg_water_host_sun_light(CoaxResources cx);
float coax_p_eg_water_glint(CoaxResources cx, float3 p_n, float3 p_v, float3 p_l, float p_roughness, float p_disc, float p_distance);
float3 coax_p_eg_water_crest_scatter(CoaxResources cx, float3 p_v, float3 p_l, float3 p_n, float p_height, float p_squeeze);
float coax_p_eg_water_foam_noise(CoaxResources cx, float2 p_p, float2 p_flow);
float coax_p_eg_water_foam(CoaxResources cx, float2 p_rest, float p_shore, float p_crest, float p_extra, float p_noise, thread array<float, 1>* p_wake_foam);
float3 coax_p_eg_water_transmittance(CoaxResources cx, float p_depth, float p_ci);
float3 coax_p_eg_water_inscatter(CoaxResources cx);
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap);
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t);
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl);
float coax_p_length3(CoaxResources cx, float3 p_a);
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k);
float coax_p_fract(CoaxResources cx, float p_x);
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high);
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b);
float3 coax_p_sub3(CoaxResources cx, float3 p_a, float3 p_b);
float coax_p_st_max(CoaxResources cx, float p_a, float p_b);
float coax_p_st_min(CoaxResources cx, float p_a, float p_b);
coax_t23 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p);
coax_t22 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t23 p_p);
coax_t22 coax_p_wg_mul_u3u(CoaxResources cx, coax_t22 p_a, uint p_b);
coax_t22 coax_p_wg_add_u3u(CoaxResources cx, coax_t22 p_a, uint p_b);
coax_t22 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z);
coax_t22 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t22 p_a, coax_t22 p_b);
coax_t22 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t22 p_a, coax_t22 p_b);
float coax_p_eg_shade_shadows_at(CoaxResources cx, float2 p_p, float p_y, bool p_level);
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale);
float coax_p_eg_map_lit(CoaxResources cx, float3 p_p, float3 p_n, bool p_paint_leaf_far);
float3 coax_p_EG_W_SHALLOW(CoaxResources cx);
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1);
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0);
float2 coax_p_wg_make_f2_f(CoaxResources cx, float p_p0);
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x);
coax_t20 coax_p_eg_water_painted_teal(CoaxResources cx, float3 p_world, float2 p_rest, float2 p_flow, float p_depth, float p_shore, float p_white, float3 p_n, float3 p_v, float p_footprint, float p_teal, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam);
float3 coax_p_eg_water_detail_waves(CoaxResources cx, float2 p_p, float p_footprint, float p_gain);
float2 coax_p_eg_water_wake(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam);
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p);
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b);
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0);
float coax_p_wg_log2(CoaxResources cx, float p_x);
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up);
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k);
float coax_p_eg_water_ggx(CoaxResources cx, float p_noh, float p_a2);
float coax_p_eg_water_smith(CoaxResources cx, float p_nov, float p_nol, float p_a2);
float coax_p_eg_water_ripple_foam(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam);
float coax_p_eg_water_cos_refracted(CoaxResources cx, float p_ci);
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch);
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x);
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx);
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx);
float coax_p_st_sat(CoaxResources cx, float p_x);
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b);
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b);
float coax_p_wg_trunc(CoaxResources cx, float p_x);
coax_t23 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z);
coax_t24 coax_p_eg_light_space(CoaxResources cx);
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t24 p_k);
coax_t21 coax_p_wg_dims_depth_1(CoaxResources cx);
float coax_p_verse_style_shadow_tap(CoaxResources cx, float p_k, float p_on_phone, float p_which);
bool coax_p_wg_all_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
bool coax_p_wg_all_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b);
float coax_p_wg_atan01(CoaxResources cx, float p_x);
float3 coax_p_EG_W_MID(CoaxResources cx);
float coax_p_eg_water_paint_ramp(CoaxResources cx, float p_edge, float p_x);
float3 coax_p_EG_W_DEEP(CoaxResources cx);
float3 coax_p_EG_W_TEAL(CoaxResources cx);
float coax_p_eg_water_paint_sparkle(CoaxResources cx, float p_rdl);
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y);
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone);
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size);
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach);
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach);
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x);
uint coax_p_render_noise_cell(CoaxResources cx, float p_x);
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y);
float coax_p_render_noise_unit(CoaxResources cx, uint p_word);
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word);
coax_t8 coax_p_eg_water_vs(CoaxResources cx, uint p_id, uint p_piece) {
  uint l_id = p_id;
  uint l_piece = p_piece;
  coax_t8 l_o{};
  uint l_patches{};
  uint l_qa{};
  uint l_ql{};
  uint l_quad_id{};
  float2 l_c{};
  uint l_qx{};
  uint l_qz{};
  float l_across{};
  float l_along{};
  float l_base{};
  float2 l_uv{};
  float l_low{};
  uint l_k{};
  float2 l_corner{};
  coax_t11 l_r{};
  float4 l_wave{};
  float3 l_world{};
  l_o = coax_t8{};
  l_patches = coax_p_wg_u32_f(cx, cx.r_u[1077]);
  if ((l_piece >= (l_patches + 64u)))
  {
    return coax_p_eg_fx_vertex(cx, l_id, ((l_piece - l_patches) - 64u));
  }
  if ((l_piece >= (l_patches + 32u)))
  {
    return coax_p_eg_pond_vertex(cx, l_id, ((l_piece - l_patches) - 32u));
  }
  if ((l_piece >= l_patches))
  {
    return coax_p_eg_fountain_vertex(cx, l_id, (l_piece - l_patches));
  }
  l_qa = coax_p_wg_u32_f(cx, cx.r_u[1074]);
  l_ql = coax_p_wg_u32_f(cx, cx.r_u[1075]);
  l_quad_id = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  l_qx = (l_quad_id % l_qa);
  l_qz = (l_quad_id / l_qa);
  l_across = ((cx.r_u[1072] - 0x1.000000p0f) / float(l_qa));
  l_along = (cx.r_u[1076] / float(l_ql));
  l_base = (float(l_piece) * cx.r_u[1076]);
  l_uv = coax_p_v2(cx, ((float(l_qx) + l_c.x) * l_across), (l_base + ((float(l_qz) + l_c.y) * l_along)));
  l_low = 0x1.f40000p9f;
  {
    l_k = 0u;
    while ((l_k < 4u))
    {
      l_corner = coax_p_v2(cx, (float((l_qx + (l_k & 1u))) * l_across), (l_base + (float((l_qz + (l_k >> uint(1u)))) * l_along)));
      l_low = coax_p_fmin(cx, l_low, (-(coax_p_eg_water_rest(cx, l_corner)).y));
      l_k = (l_k + 1u);
    }
  }
  l_r = coax_p_eg_water_rest(cx, l_uv);
  if ((((l_low - cx.r_u[1480]) > 0x1.333334p-1f) || (l_quad_id >= (l_qa * l_ql))))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_wave = coax_p_eg_water_gerstner(cx, coax_p_v2(cx, l_r.x.x, l_r.x.z), l_r.y, 0x1.000000p0f);
  l_world = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, l_r.x, coax_p_v3(cx, l_wave.x, l_wave.y, l_wave.z)), coax_p_v3(cx, 0.0f, cx.r_u[1480], 0.0f));
  l_o.x = coax_p_eg_clip(cx, l_world);
  l_o.y = coax_p_v4(cx, l_world.x, l_world.y, l_world.z, (l_r.y + cx.r_u[1480]));
  l_o.z = coax_p_wg_make_f4_f2f2(cx, coax_p_v2(cx, l_r.x.x, l_r.x.z), l_r.w);
  l_o.w = coax_p_v4(cx, l_r.f4, 0.0f, l_wave.w, l_r.z);
  l_o.f4 = coax_p_v4(cx, 0.0f, (l_world.y - l_r.x.y), 0.0f, 0.0f);
  return l_o;
}
float4 coax_p_eg_water_emit_fs(CoaxResources cx, coax_t8 p_i) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far{};
  array<float, 1> l_wake_foam_store{};
  l_paint_leaf_far = bool{};
  l_wake_foam_store = array<float, 1>{};
  if (coax_p_eg_water_surface_part(cx, coax_p_wg_u32_f(cx, (l_i.f4.x + 0x1.000000p-1f))))
  {
    return coax_p_wg_make_f4_f3f(cx, coax_p_eg_water_whole(cx, l_i, l_paint_leaf_far, &l_wake_foam_store), 0.0f);
  }
  return coax_p_wg_make_f4_f3f(cx, (coax_p_eg_water_halves(cx, l_i, l_paint_leaf_far, &l_wake_foam_store)).x, 0.0f);
}
uint coax_p_wg_u32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((!(l_x > 0.0f)))
  {
    return 0u;
  }
  if ((l_x >= 0x1.fffffep31f))
  {
    return 4294967040u;
  }
  return uint(l_x);
}
coax_t8 coax_p_eg_fx_vertex(CoaxResources cx, uint p_id, uint p_f) {
  uint l_id = p_id;
  uint l_f = p_f;
  coax_t8 l_o{};
  uint l_per{};
  uint l_k{};
  float4 l_p{};
  float4 l_q{};
  float2 l_c{};
  float3 l_right{};
  float3 l_up{};
  float3 l_world{};
  l_o = coax_t8{};
  if ((l_f == 0u))
  {
    return coax_p_eg_weir_vertex(cx, l_id);
  }
  l_per = (coax_p_wg_u32_f(cx, cx.r_u[1074]) * coax_p_wg_u32_f(cx, cx.r_u[1075]));
  l_k = (((l_f - 1u) * l_per) + (l_id / 6u));
  if ((((l_id / 6u) >= l_per) || (l_k >= 64u)))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_p = coax_p_wg_at4(cx, ((int((21u + (l_k * 2u))) * 4) + 1500));
  l_q = coax_p_wg_at4(cx, ((int(((21u + (l_k * 2u)) + 1u)) * 4) + 1500));
  if (((l_p.w <= 0.0f) || (l_q.y <= 0x1.0624dep-9f)))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_c = coax_p_wg_sub_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_eg_quad(cx, (l_id % 6u)), 0x1.000000p1f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f));
  l_right = coax_p_wg_normalize3(cx, coax_p_v3(cx, cx.r_u[8], cx.r_u[9], cx.r_u[10]));
  l_up = coax_p_wg_normalize3(cx, coax_p_v3(cx, cx.r_u[12], cx.r_u[13], cx.r_u[14]));
  l_world = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_v3(cx, l_p.x, l_p.y, l_p.z), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_right, l_c.x), l_p.w)), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_up, l_c.y), l_p.w), ((l_q.x < 0x1.000000p-1f) ? 0x1.800000p0f : 0x1.000000p0f)));
  l_o.x = coax_p_eg_clip(cx, l_world);
  l_o.y = coax_p_v4(cx, l_world.x, l_world.y, l_world.z, l_p.w);
  l_o.z = coax_p_v4(cx, l_c.x, l_c.y, 0.0f, 0.0f);
  l_o.w = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
  l_o.f4 = coax_p_v4(cx, float(8u), l_q.x, l_q.y, l_q.z);
  return l_o;
}
coax_t8 coax_p_eg_pond_vertex(CoaxResources cx, uint p_id, uint p_f) {
  uint l_id = p_id;
  uint l_f = p_f;
  coax_t8 l_o{};
  uint l_qa{};
  uint l_ql{};
  uint l_quad_id{};
  float2 l_c{};
  uint l_p{};
  float4 l_q{};
  uint l_qx{};
  uint l_qz{};
  float l_rim{};
  uint l_wedge{};
  float l_low{};
  uint l_k{};
  float l_ca{};
  float l_cr{};
  float l_a{};
  float l_r{};
  float2 l_xz{};
  float3 l_world{};
  float l_depth{};
  l_o = coax_t8{};
  l_qa = coax_p_wg_u32_f(cx, cx.r_u[1074]);
  l_ql = coax_p_wg_u32_f(cx, cx.r_u[1075]);
  l_quad_id = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  l_p = (l_f / 8u);
  if ((((l_f >= 32u) || (!coax_p_eg_pond_on(cx, l_p))) || (l_quad_id >= (l_qa * l_ql))))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_q = coax_p_eg_pond_row(cx, l_p);
  l_qx = (l_quad_id % l_qa);
  l_qz = (l_quad_id / l_qa);
  l_rim = (l_q.z + 0x1.333334p-2f);
  l_wedge = (l_f % 8u);
  l_low = 0x1.f40000p9f;
  {
    l_k = 0u;
    while ((l_k < 4u))
    {
      l_ca = ((float((((l_wedge * l_qa) + l_qx) + (l_k & 1u))) / (0x1.000000p3f * float(l_qa))) * 0x1.921fb6p2f);
      l_cr = ((l_rim * float((l_qz + (l_k >> uint(1u))))) / float(l_ql));
      l_low = coax_p_fmin(cx, l_low, (coax_p_eg_ground_y(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_q.x, l_q.y), coax_p_wg_mul_f2f(cx, coax_p_v2(cx, cos(l_ca), sin(l_ca)), l_cr))) - l_q.w));
      l_k = (l_k + 1u);
    }
  }
  if ((l_low > 0x1.333334p-1f))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_a = (((float(((l_wedge * l_qa) + l_qx)) + l_c.x) / (0x1.000000p3f * float(l_qa))) * 0x1.921fb6p2f);
  l_r = ((l_rim * (float(l_qz) + l_c.y)) / float(l_ql));
  l_xz = coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_q.x, l_q.y), coax_p_wg_mul_f2f(cx, coax_p_v2(cx, cos(l_a), sin(l_a)), l_r));
  l_world = coax_p_v3(cx, l_xz.x, l_q.w, l_xz.y);
  l_depth = (l_q.w - coax_p_eg_ground_y(cx, l_xz));
  l_o.x = coax_p_eg_clip(cx, l_world);
  l_o.y = coax_p_v4(cx, l_world.x, l_world.y, l_world.z, l_depth);
  l_o.z = coax_p_v4(cx, l_xz.x, l_xz.y, 0.0f, 0.0f);
  l_o.w = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, (coax_p_fmax(cx, l_depth, 0.0f) / 0x1.333334p-1f));
  l_o.f4 = coax_p_v4(cx, float(6u), 0.0f, l_r, 0.0f);
  return l_o;
}
coax_t8 coax_p_eg_fountain_vertex(CoaxResources cx, uint p_id, uint p_f) {
  uint l_id = p_id;
  uint l_f = p_f;
  coax_t8 l_o{};
  uint l_qa{};
  uint l_ql{};
  uint l_quad_id{};
  float2 l_c{};
  uint l_qx{};
  uint l_qz{};
  float l_base{};
  float l_time{};
  bool l_bowl{};
  float l_wedges{};
  uint l_w{};
  float l_a{};
  float l_s{};
  float2 l_dir{};
  float l_r{};
  float l_level{};
  float l_depth{};
  float l_shore{};
  float l_land{};
  float3 l_world{};
  float l_off{};
  float2 l_flow{};
  float l_white{};
  bool l_jet{};
  uint l_k{};
  float l_v{};
  float l_phi{};
  coax_t16 l_fall{};
  float3 l_side{};
  float3 l_up{};
  float l_wide{};
  float3 l_n{};
  float3 l_world_36{};
  uint l_k_37{};
  float l_a_38{};
  float3 l_at{};
  float l_phi_40{};
  float l_v_41{};
  float l_pulse{};
  float3 l_ring{};
  float3 l_world_44{};
  l_o = coax_t8{};
  l_qa = coax_p_wg_u32_f(cx, cx.r_u[1074]);
  l_ql = coax_p_wg_u32_f(cx, cx.r_u[1075]);
  l_quad_id = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  if ((((!coax_p_eg_fountain_on(cx)) || (l_quad_id >= (l_qa * l_ql))) || (l_f >= 32u)))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_qx = (l_quad_id % l_qa);
  l_qz = (l_quad_id / l_qa);
  l_base = coax_p_eg_fountain_base(cx);
  l_time = cx.r_u[1048];
  if ((l_f < 12u))
  {
    l_bowl = (l_f >= 8u);
    l_wedges = (l_bowl ? 0x1.000000p2f : 0x1.000000p3f);
    l_w = (l_bowl ? (l_f - 8u) : l_f);
    l_a = (((float(((l_w * l_qa) + l_qx)) + l_c.x) / (l_wedges * float(l_qa))) * 0x1.921fb6p2f);
    l_s = ((float(l_qz) + l_c.y) / float(l_ql));
    l_dir = coax_p_v2(cx, cos(l_a), sin(l_a));
    l_r = coax_p_mix(cx, 0x1.1eb852p-2f, 0x1.51eb86p1f, l_s);
    l_level = 0x1.3d70a4p-1f;
    l_depth = (0x1.3d70a4p-1f - coax_p_eg_fountain_floor(cx, l_r));
    l_shore = coax_p_fmin(cx, (0x1.4e147ap1f - l_r), (l_r - 0x1.3d70a4p-2f));
    l_land = 0x1.c51eb8p0f;
    if (l_bowl)
    {
      l_r = coax_p_mix(cx, 0x1.eb851ep-4f, 0x1.30a3d8p0f, l_s);
      l_level = 0x1.0b851ep1f;
      l_depth = ((l_r < 0x1.eb851ep-3f) ? (0x1.0b851ep1f - coax_p_mix(cx, 0x1.0cccccp1f, 0x1.eb851ep0f, ((l_r - 0x1.333334p-3f) / 0x1.70a3d8p-4f))) : (0x1.0b851ep1f - 0x1.e66666p0f));
      l_shore = coax_p_fmin(cx, (0x1.2b851ep0f - l_r), (l_r - 0x1.333334p-3f));
      l_land = 0x1.3d70a4p-2f;
    }
    l_world = coax_p_v3(cx, (l_dir.x * l_r), (l_base + l_level), (l_dir.y * l_r));
    l_off = (l_r - l_land);
    l_flow = coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_dir, coax_p_wg_sign(cx, l_off)), 0x1.1eb852p-2f), exp((((-l_off) * l_off) / 0x1.000000p-1f)));
    l_white = (exp((((-l_off) * l_off) / 0x1.eb851ep-6f)) * (l_bowl ? 0x1.99999ap-1f : (0x1.666666p-2f + (0x1.4cccccp-1f * coax_p_eg_fountain_stream_near(cx, l_a)))));
    l_o.x = coax_p_eg_clip(cx, l_world);
    l_o.y = coax_p_v4(cx, l_world.x, l_world.y, l_world.z, l_depth);
    l_o.z = coax_p_wg_make_f4_f2f2(cx, coax_p_v2(cx, l_world.x, l_world.z), l_flow);
    l_o.w = coax_p_v4(cx, l_white, 0.0f, 0.0f, l_shore);
    l_o.f4 = coax_p_v4(cx, (l_bowl ? 0x1.000000p1f : 0x1.000000p0f), 0.0f, l_r, l_land);
    return l_o;
  }
  if ((l_f < 24u))
  {
    l_jet = (l_f >= 20u);
    l_k = (l_jet ? (l_f - 20u) : (l_f - 12u));
    l_v = ((float(l_qz) + l_c.y) / float(l_ql));
    l_phi = (((float(l_qx) + l_c.x) / float(l_qa)) * 0x1.921fb6p2f);
    l_fall = coax_p_eg_fountain_fall(cx, l_k, l_jet, l_v);
    l_side = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_cross3(cx, l_fall.y, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f)), coax_p_v3(cx, 0x1.a36e2ep-14f, 0.0f, 0.0f)));
    l_up = coax_p_wg_normalize3(cx, coax_p_wg_cross3(cx, l_side, l_fall.y));
    l_wide = (l_jet ? 0x1.000000p0f : coax_p_mix(cx, 0x1.000000p1f, 0x1.000000p0f, coax_p_smoothstep(cx, 0.0f, 0x1.000000p-1f, l_v)));
    l_n = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_side, cos(l_phi)), coax_p_wg_mul_f3f(cx, l_up, sin(l_phi))));
    l_world_36 = coax_p_wg_add_f3f3(cx, l_fall.x, coax_p_wg_mul_f3f(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_side, cos(l_phi)), l_wide), coax_p_wg_mul_f3f(cx, l_up, sin(l_phi))), l_fall.z));
    l_o.x = coax_p_eg_clip(cx, l_world_36);
    l_o.y = coax_p_v4(cx, l_world_36.x, l_world_36.y, l_world_36.z, l_fall.z);
    l_o.z = coax_p_v4(cx, l_n.x, l_n.y, l_n.z, l_v);
    l_o.w = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
    l_o.f4 = coax_p_v4(cx, (l_jet ? 0x1.000000p2f : 0x1.800000p1f), (l_phi / 0x1.921fb6p2f), l_v, float(l_k));
    return l_o;
  }
  l_k_37 = (l_f - 24u);
  l_a_38 = coax_p_eg_fountain_stream_angle(cx, l_k_37);
  l_at = coax_p_v3(cx, (cos(l_a_38) * 0x1.c51eb8p0f), (l_base + 0x1.3d70a4p-1f), (sin(l_a_38) * 0x1.c51eb8p0f));
  l_phi_40 = (((float(l_qx) + l_c.x) / float(l_qa)) * 0x1.921fb6p2f);
  l_v_41 = ((float(l_qz) + l_c.y) / float(l_ql));
  l_pulse = (0x1.800000p-1f + (0x1.000000p-2f * sin((((l_time * 0x1.600000p3f) + (float(l_k_37) * 0x1.b33334p0f)) + (l_phi_40 * 0x1.000000p1f)))));
  l_ring = coax_p_v3(cx, cos(l_phi_40), 0.0f, sin(l_phi_40));
  l_world_44 = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, l_at, coax_p_wg_mul_f3f(cx, l_ring, coax_p_mix(cx, 0x1.eb851ep-5f, 0x1.99999ap-3f, l_v_41))), coax_p_v3(cx, 0.0f, (((l_v_41 * 0x1.47ae14p-3f) * l_pulse) - 0x1.47ae14p-7f), 0.0f));
  l_o.x = coax_p_eg_clip(cx, l_world_44);
  l_o.y = coax_p_v4(cx, l_world_44.x, l_world_44.y, l_world_44.z, 0x1.99999ap-5f);
  l_o.z = coax_p_wg_make_f4_f3f(cx, coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_ring, coax_p_v3(cx, 0.0f, 0x1.99999ap-1f, 0.0f))), l_v_41);
  l_o.w = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
  l_o.f4 = coax_p_v4(cx, 0x1.400000p2f, (l_phi_40 / 0x1.921fb6p2f), l_v_41, float(l_k_37));
  return l_o;
}
float2 coax_p_eg_quad(CoaxResources cx, uint p_v) {
  uint l_v = p_v;
  array<float2, 6> l_q{};
  l_q = array<float2, 6>{coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f), coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f), coax_p_v2(cx, 0.0f, 0x1.000000p0f)};
  return l_q[int(l_v)];
}
float2 coax_p_v2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  return float2(l_x, l_y);
}
coax_t11 coax_p_eg_water_rest(CoaxResources cx, float2 p_uv) {
  float2 l_uv = p_uv;
  uint l_cols{};
  uint l_rows{};
  float2 l_a{};
  uint l_i{};
  uint l_j{};
  float2 l_f{};
  uint l_k00{};
  uint l_k10{};
  uint l_k01{};
  uint l_k11{};
  coax_t11 l_o{};
  array<float, 8> l_v{};
  uint l_c{};
  l_cols = coax_p_wg_u32_f(cx, cx.r_u[1072]);
  l_rows = coax_p_wg_u32_f(cx, cx.r_u[1073]);
  l_a = coax_p_wg_clamp_f2f2f2(cx, l_uv, coax_p_v2(cx, 0.0f, 0.0f), coax_p_v2(cx, float((l_cols - 1u)), float((l_rows - 1u))));
  l_i = coax_p_wg_min_u(cx, coax_p_wg_u32_f(cx, floor(l_a.x)), (l_cols - 2u));
  l_j = coax_p_wg_min_u(cx, coax_p_wg_u32_f(cx, floor(l_a.y)), (l_rows - 2u));
  l_f = coax_p_wg_sub_f2f2(cx, l_a, coax_p_v2(cx, float(l_i), float(l_j)));
  l_k00 = ((l_j * l_cols) + l_i);
  l_k10 = (l_k00 + 1u);
  l_k01 = (l_k00 + l_cols);
  l_k11 = (l_k01 + 1u);
  l_o = coax_t11{};
  l_v = array<float, 8>{};
  {
    l_c = 0u;
    while ((l_c < 8u))
    {
      l_v[int(l_c)] = coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_water_node(cx, l_k00, l_c), coax_p_eg_water_node(cx, l_k10, l_c), l_f.x), coax_p_mix(cx, coax_p_eg_water_node(cx, l_k01, l_c), coax_p_eg_water_node(cx, l_k11, l_c), l_f.x), l_f.y);
      l_c = (l_c + 1u);
    }
  }
  l_o.x = coax_p_v3(cx, l_v[0], l_v[1], l_v[2]);
  l_o.y = l_v[3];
  l_o.z = l_v[4];
  l_o.w = coax_p_v2(cx, l_v[5], l_v[6]);
  l_o.f4 = l_v[7];
  return l_o;
}
float coax_p_fmin(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float4 coax_p_v4(CoaxResources cx, float p_x, float p_y, float p_z, float p_w) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  float l_w = p_w;
  return float4(l_x, l_y, l_z, l_w);
}
float4 coax_p_eg_water_gerstner(CoaxResources cx, float2 p_p0, float p_depth, float p_scale) {
  float2 l_p0 = p_p0;
  float l_depth = p_depth;
  float l_scale = p_scale;
  float3 l_d{};
  float l_squeeze{};
  int l_count{};
  float l_gain{};
  int l_i{};
  float4 l_a{};
  float4 l_c{};
  float l_k{};
  float l_amp{};
  float l_theta{};
  float l_co{};
  float l_s{};
  l_d = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_squeeze = 0.0f;
  l_count = coax_p_wg_i32_f(cx, cx.r_u[1051]);
  l_gain = (cx.r_u[1061] * l_scale);
  {
    l_i = 0;
    while ((l_i < 8))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_a = coax_p_wg_at4(cx, ((int((l_i * 2)) * 4) + 760));
      l_c = coax_p_wg_at4(cx, ((int(((l_i * 2) + 1)) * 4) + 760));
      l_k = l_a.z;
      l_amp = ((l_a.w * l_gain) * coax_p_eg_water_shoal(cx, l_k, l_depth));
      l_theta = ((l_k * coax_p_wg_dot2(cx, coax_p_v2(cx, l_a.x, l_a.y), l_p0)) + l_c.y);
      l_co = cos(l_theta);
      l_s = sin(l_theta);
      l_d.x = (l_d.x + (((l_c.x * l_amp) * l_a.x) * l_co));
      l_d.z = (l_d.z + (((l_c.x * l_amp) * l_a.y) * l_co));
      l_d.y = (l_d.y + (l_amp * l_s));
      l_squeeze = (l_squeeze + (((l_c.x * l_amp) * l_k) * l_s));
      l_i = (l_i + 1);
    }
  }
  return coax_p_v4(cx, l_d.x, l_d.y, l_d.z, l_squeeze);
}
float3 coax_p_v3(CoaxResources cx, float p_x, float p_y, float p_z) {
  float l_x = p_x;
  float l_y = p_y;
  float l_z = p_z;
  return float3(l_x, l_y, l_z);
}
float3 coax_p_wg_add_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x + l_b.x), (l_a.y + l_b.y), (l_a.z + l_b.z));
}
float4 coax_p_eg_clip(CoaxResources cx, float3 p_w) {
  float3 l_w = p_w;
  float4 l_p{};
  l_p = coax_p_v4(cx, l_w.x, l_w.y, l_w.z, 0x1.000000p0f);
  return coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), l_p), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), l_p));
}
float4 coax_p_wg_make_f4_f2f2(CoaxResources cx, float2 p_p0, float2 p_p1) {
  float2 l_p0 = p_p0;
  float2 l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p1.x, l_p1.y);
}
bool coax_p_eg_water_surface_part(CoaxResources cx, uint p_part) {
  uint l_part = p_part;
  return ((l_part < 3u) || (l_part == 6u));
}
float3 coax_p_eg_water_whole(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_world{};
  coax_t19 l_px{};
  coax_t20 l_s{};
  float l_w{};
  float l_thick{};
  float l_focal{};
  bool l_small{};
  float l_reach{};
  coax_t19 l_off{};
  coax_t19 l_at{};
  float3 l_behind{};
  float3 l_out{};
  float3 l_v{};
  float3 l_calm{};
  float4 l_hit{};
  float l_d{};
  uint l_part{};
  float l_bed{};
  float l_near{};
  float l_t{};
  float l_broken{};
  float l_foam{};
  float3 l_foam_rgb{};
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_px = coax_p_wg_cvt_i2f2(cx, coax_p_v2(cx, l_i.x.x, l_i.x.y));
  if (((coax_p_eg_water_hull(cx, coax_p_v2(cx, l_world.x, l_world.z)) > 0x1.000000p-1f) || coax_p_eg_water_dry(cx, coax_p_v2(cx, l_world.x, l_world.z))))
  {
    return coax_p_eg_water_scene_at(cx, l_px);
  }
  l_s = coax_p_eg_water_halves(cx, l_i, l_paint_leaf_far, p_wake_foam);
  l_w = coax_p_fmax(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), coax_p_v4(cx, l_world.x, l_world.y, l_world.z, 0x1.000000p0f)), 0x1.0624dep-10f);
  l_thick = coax_p_eg_water_thickness(cx, l_px, l_world);
  l_focal = ((0x1.000000p-1f * float((coax_p_wg_dims_2d(cx)).y)) * coax_p_wg_length3(cx, coax_p_v3(cx, cx.r_u[12], cx.r_u[13], cx.r_u[14])));
  l_small = (cx.r_u[1068] < 0x1.000000p3f);
  l_reach = ((l_small ? 0x1.eb851ep-4f : 0x1.47ae14p-3f) * coax_p_fmin(cx, l_thick, 0x1.333334p0f));
  l_off = coax_p_wg_cvt_i2f2(cx, coax_p_wg_round_f2(cx, coax_p_wg_div_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_s.z, l_reach), l_focal), l_w)));
  l_at = coax_p_wg_add_i2i2(cx, l_px, l_off);
  if ((coax_p_eg_water_scene_w(cx, l_at) < l_w))
  {
    l_at = l_px;
  }
  l_behind = coax_p_eg_water_scene_at(cx, l_at);
  l_out = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_behind, l_s.y), l_s.x);
  l_v = coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  if ((((!l_small) && (l_s.w.w > 0x1.47ae14p-7f)) && (cx.r_u[25] > l_world.y)))
  {
    l_calm = coax_p_wg_normalize3(cx, coax_p_v3(cx, (l_s.z.x * 0x1.eb851ep-5f), 0x1.000000p0f, (l_s.z.y * 0x1.eb851ep-5f)));
    l_hit = coax_p_eg_water_ssr(cx, l_world, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_v), l_calm));
    l_d = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
    l_out = coax_p_wg_add_f3f3(cx, l_out, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, l_hit.x, l_hit.y, l_hit.z), coax_p_v3(cx, l_s.w.x, l_s.w.y, l_s.w.z)), l_s.w.w), l_hit.w), (0x1.000000p0f - coax_p_eg_haze_share(cx, l_d, l_world.y))));
  }
  l_part = coax_p_wg_u32_f(cx, (l_i.f4.x + 0x1.000000p-1f));
  if ((cx.r_u[25] > l_world.y))
  {
    l_bed = (l_i.y.w / coax_p_fmax(cx, l_v.y, 0x1.47ae14p-4f));
    l_near = ((0x1.000000p0f - coax_p_smoothstep(cx, 0x1.eb851ep-6f, 0x1.99999ap-3f, l_thick)) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.666666p-2f, 0x1.666666p-1f, (l_thick / coax_p_fmax(cx, l_bed, 0x1.47ae14p-6f)))));
    if (((l_near > 0.0f) && coax_p_eg_water_surface_part(cx, l_part)))
    {
      l_t = cx.r_u[1048];
      l_broken = coax_p_smoothstep(cx, 0x1.000000p-2f, 0x1.333334p-1f, ((coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_i.z.x, l_i.z.y), 0x1.400000p2f), (l_t * 0x1.99999ap-1f))) + (0x1.000000p-1f * l_near)) - 0x1.99999ap-3f));
      l_foam = coax_p_clampf(cx, ((l_near * l_broken) * 0x1.666666p0f), 0.0f, 0x1.000000p0f);
      if ((l_foam > 0.0f))
      {
        l_foam_rgb = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.e66666p-1f, 0x1.f0a3d8p-1f, 0x1.eb851ep-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_eg_water_host_light(cx, l_world, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_paint_leaf_far), 0x1.ccccccp-1f), coax_p_v3(cx, 0x1.eb851ep-5f, 0x1.eb851ep-5f, 0x1.eb851ep-5f)));
        l_out = coax_p_wg_mix_f3f3f(cx, l_out, l_foam_rgb, l_foam);
      }
    }
  }
  l_out = coax_p_wg_mix_f3f3f(cx, coax_p_eg_water_scene_at(cx, l_px), l_out, coax_p_smoothstep(cx, 0.0f, 0x1.eb851ep-5f, l_thick));
  return coax_p_wg_max_f3f3(cx, l_out, coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
}
float4 coax_p_wg_make_f4_f3f(CoaxResources cx, float3 p_p0, float p_p1) {
  float3 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v4(cx, l_p0.x, l_p0.y, l_p0.z, l_p1);
}
coax_t20 coax_p_eg_water_halves(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far = p_paint_leaf_far;
  coax_t20 l_s{};
  float l_d{};
  float l_fog{};
  float3 l_emit{};
  coax_t20 l_o{};
  l_s = coax_p_eg_water_fragment(cx, l_i, l_paint_leaf_far, p_wake_foam);
  l_d = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z)));
  l_fog = coax_p_eg_haze_share(cx, l_d, l_i.y.y);
  l_emit = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_s.x, (0x1.000000p0f - l_fog)), coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_eg_haze_colour(cx, l_fog, coax_p_wg_div_f3f(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z), coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26])), coax_p_fmax(cx, l_d, 0x1.0624dep-10f))), l_fog), coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), l_s.y)));
  l_o = l_s;
  l_o.x = coax_p_wg_max_f3f3(cx, l_emit, coax_p_v3(cx, 0.0f, 0.0f, 0.0f));
  return l_o;
}
coax_t8 coax_p_eg_weir_vertex(CoaxResources cx, uint p_id) {
  uint l_id = p_id;
  coax_t8 l_o{};
  uint l_qa{};
  uint l_ql{};
  uint l_quad_id{};
  float2 l_c{};
  float4 l_w0{};
  float4 l_w1{};
  float l_a{};
  float l_v{};
  float l_rise{};
  float l_top{};
  float l_drop{};
  float l_fall{};
  float l_speed{};
  float l_tt{};
  float l_x{};
  float3 l_world{};
  float3 l_along{};
  float3 l_n{};
  l_o = coax_t8{};
  l_qa = coax_p_wg_u32_f(cx, cx.r_u[1074]);
  l_ql = coax_p_wg_u32_f(cx, cx.r_u[1075]);
  l_quad_id = (l_id / 6u);
  l_c = coax_p_eg_quad(cx, (l_id % 6u));
  l_w0 = coax_p_wg_at4(cx, 1500);
  l_w1 = coax_p_wg_at4(cx, 1504);
  if (((l_w0.w < 0x1.000000p-1f) || (l_quad_id >= (l_qa * l_ql))))
  {
    l_o.x = coax_p_v4(cx, 0.0f, 0.0f, 0x1.000000p1f, 0x1.000000p0f);
    return l_o;
  }
  l_a = ((float((l_quad_id % l_qa)) + l_c.x) / float(l_qa));
  l_v = ((float((l_quad_id / l_qa)) + l_c.y) / float(l_ql));
  l_rise = cx.r_u[1480];
  l_top = ((l_w1.x + l_rise) + 0x1.eb851ep-6f);
  l_drop = (coax_p_fmax(cx, (l_w1.x - l_w1.y), 0x1.99999ap-5f) + 0x1.1eb852p-3f);
  l_fall = sqrt(((0x1.000000p1f * l_drop) / 0x1.39eb86p3f));
  l_speed = coax_p_fmax(cx, l_w1.z, 0x1.99999ap-2f);
  l_tt = (l_v * l_fall);
  l_x = coax_p_mix(cx, l_w0.x, l_w0.y, l_a);
  l_world = coax_p_v3(cx, l_x, (l_top - ((0x1.39eb86p2f * l_tt) * l_tt)), (l_w0.z - (l_speed * l_tt)));
  l_along = coax_p_wg_normalize3(cx, coax_p_v3(cx, 0.0f, ((-0x1.39eb86p3f) * l_tt), (-l_speed)));
  l_n = coax_p_v3(cx, 0.0f, (-l_along.z), l_along.y);
  l_o.x = coax_p_eg_clip(cx, l_world);
  l_o.y = coax_p_v4(cx, l_world.x, l_world.y, l_world.z, 0x1.99999ap-5f);
  l_o.z = coax_p_v4(cx, l_n.x, l_n.y, l_n.z, l_v);
  l_o.w = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
  l_o.f4 = coax_p_v4(cx, float(7u), l_a, l_v, (l_w0.y - l_w0.x));
  return l_o;
}
float4 coax_p_wg_at4(CoaxResources cx, int p_at) {
  int l_at = p_at;
  return coax_p_v4(cx, cx.r_u[l_at], cx.r_u[(l_at + 1)], cx.r_u[(l_at + 2)], cx.r_u[(l_at + 3)]);
}
float2 coax_p_wg_mul_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b), (l_a.y * l_b));
}
float2 coax_p_wg_sub_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
float3 coax_p_wg_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_normalize3(cx, l_a);
}
float3 coax_p_wg_mul_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
bool coax_p_eg_pond_on(CoaxResources cx, uint p_p) {
  uint l_p = p_p;
  return (cx.r_u[((int(l_p) * 4) + 1486)] > 0x1.000000p-1f);
}
float4 coax_p_eg_pond_row(CoaxResources cx, uint p_p) {
  uint l_p = p_p;
  float4 l_q{};
  l_q = coax_p_wg_at4(cx, ((int(l_p) * 4) + 1484));
  l_q.w = (l_q.w + cx.r_u[1480]);
  return l_q;
}
float2 coax_p_wg_add_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_eg_ground_y(CoaxResources cx, float2 p_q) {
  float2 l_q = p_q;
  float2 l_g{};
  coax_t19 l_i{};
  float2 l_f{};
  l_g = coax_p_wg_div_f2f(cx, coax_p_wg_sub_f2f2(cx, l_q, coax_p_v2(cx, cx.r_u[34], cx.r_u[35])), cx.r_u[33]);
  l_i = coax_p_wg_cvt_i2f2(cx, coax_p_wg_floor_f2(cx, l_g));
  l_f = coax_p_wg_fract_f2(cx, l_g);
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_eg_height(cx, l_i.x, l_i.y), coax_p_eg_height(cx, (l_i.x + 1), l_i.y), l_f.x), coax_p_mix(cx, coax_p_eg_height(cx, l_i.x, (l_i.y + 1)), coax_p_eg_height(cx, (l_i.x + 1), (l_i.y + 1)), l_f.x), l_f.y);
}
float coax_p_fmax(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
bool coax_p_eg_fountain_on(CoaxResources cx) {
  return (cx.r_u[1079] > 0x1.000000p-1f);
}
float coax_p_eg_fountain_base(CoaxResources cx) {
  return cx.r_u[1078];
}
float coax_p_mix(CoaxResources cx, float p_a, float p_b, float p_t) {
  float l_a = p_a;
  float l_b = p_b;
  float l_t = p_t;
  return (l_a + ((l_b - l_a) * l_t));
}
float coax_p_eg_fountain_floor(CoaxResources cx, float p_r) {
  float l_r = p_r;
  if ((l_r < 0x1.333334p0f))
  {
    return coax_p_mix(cx, 0x1.99999ap-5f, 0x1.99999ap-4f, (l_r / 0x1.333334p0f));
  }
  if ((l_r < 0x1.000000p1f))
  {
    return coax_p_mix(cx, 0x1.99999ap-4f, 0x1.000000p-2f, ((l_r - 0x1.333334p0f) / 0x1.99999ap-1f));
  }
  if ((l_r < 0x1.333334p1f))
  {
    return coax_p_mix(cx, 0x1.000000p-2f, 0x1.851eb8p-2f, ((l_r - 0x1.000000p1f) / 0x1.99999ap-2f));
  }
  if ((l_r < 0x1.451eb8p1f))
  {
    return coax_p_mix(cx, 0x1.851eb8p-2f, 0x1.d70a3ep-2f, ((l_r - 0x1.333334p1f) / 0x1.1eb852p-3f));
  }
  return coax_p_mix(cx, 0x1.d70a3ep-2f, 0x1.1eb852p-1f, coax_p_clampf(cx, ((l_r - 0x1.451eb8p1f) / 0x1.eb851ep-5f), 0.0f, 0x1.000000p0f));
}
float coax_p_wg_sign(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x > 0.0f))
  {
    return 0x1.000000p0f;
  }
  if ((l_x < 0.0f))
  {
    return (-0x1.000000p0f);
  }
  return 0.0f;
}
float coax_p_eg_fountain_stream_near(CoaxResources cx, float p_a) {
  float l_a = p_a;
  return coax_metal_pow(coax_p_fmax(cx, (-cos((0x1.000000p3f * l_a))), 0.0f), 0x1.800000p2f);
}
coax_t16 coax_p_eg_fountain_fall(CoaxResources cx, uint p_k, bool p_jet, float p_v) {
  uint l_k = p_k;
  bool l_jet = p_jet;
  float l_v = p_v;
  coax_t16 l_f{};
  float l_base{};
  float l_a{};
  float3 l_dir{};
  float l_t{};
  float l_a_9{};
  float3 l_dir_10{};
  float l_t_11{};
  l_f = coax_t16{};
  l_base = coax_p_eg_fountain_base(cx);
  if (l_jet)
  {
    l_a = ((((float(l_k) + 0x1.000000p-1f) / 0x1.000000p2f) * 0x1.921fb6p2f) + (0x1.921fb6p2f / 0x1.000000p4f));
    l_dir = coax_p_v3(cx, cos(l_a), 0.0f, sin(l_a));
    l_t = (l_v * (coax_p_EG_F_JET(cx)).z);
    l_f.x = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_dir, ((coax_p_EG_F_JET(cx)).x + ((coax_p_EG_F_JET_V(cx)).x * l_t))), coax_p_v3(cx, 0.0f, (((l_base + (coax_p_EG_F_JET(cx)).y) + ((coax_p_EG_F_JET_V(cx)).y * l_t)) - (((0x1.000000p-1f * 0x1.39999ap3f) * l_t) * l_t)), 0.0f));
    l_f.y = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_dir, (coax_p_EG_F_JET_V(cx)).x), coax_p_v3(cx, 0.0f, ((coax_p_EG_F_JET_V(cx)).y - (0x1.39999ap3f * l_t)), 0.0f)));
    l_f.z = coax_p_mix(cx, 0x1.0624dep-5f, 0x1.47ae14p-6f, l_v);
    return l_f;
  }
  l_a_9 = coax_p_eg_fountain_stream_angle(cx, l_k);
  l_dir_10 = coax_p_v3(cx, cos(l_a_9), 0.0f, sin(l_a_9));
  l_t_11 = (l_v * 0x1.1c28f6p-1f);
  l_f.x = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_dir_10, ((coax_p_EG_F_LIP(cx)).x + (0x1.666666p-1f * l_t_11))), coax_p_v3(cx, 0.0f, ((l_base + (coax_p_EG_F_LIP(cx)).y) - (((0x1.000000p-1f * 0x1.39999ap3f) * l_t_11) * l_t_11)), 0.0f));
  l_f.y = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_dir_10, 0x1.666666p-1f), coax_p_v3(cx, 0.0f, ((-0x1.39999ap3f) * l_t_11), 0.0f)));
  l_f.z = coax_p_mix(cx, 0x1.333334p-4f, 0x1.99999ap-5f, l_v);
  return l_f;
}
float3 coax_p_wg_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_cross3(cx, l_a, l_b);
}
float coax_p_smoothstep(CoaxResources cx, float p_a, float p_b, float p_x) {
  float l_a = p_a;
  float l_b = p_b;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_saturate(cx, ((l_x - l_a) / (l_b - l_a)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float coax_p_eg_fountain_stream_angle(CoaxResources cx, uint p_k) {
  uint l_k = p_k;
  return (((float(l_k) + 0x1.000000p-1f) / 0x1.000000p3f) * 0x1.921fb6p2f);
}
float2 coax_p_wg_clamp_f2f2f2(CoaxResources cx, float2 p_p0, float2 p_p1, float2 p_p2) {
  float2 l_p0 = p_p0;
  float2 l_p1 = p_p1;
  float2 l_p2 = p_p2;
  return coax_p_v2(cx, coax_p_clampf(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_clampf(cx, l_p0.y, l_p1.y, l_p2.y));
}
uint coax_p_wg_min_u(CoaxResources cx, uint p_a, uint p_b) {
  uint l_a = p_a;
  uint l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_eg_water_node(CoaxResources cx, uint p_k, uint p_f) {
  uint l_k = p_k;
  uint l_f = p_f;
  return cx.r_water_nodes[int(((l_k * 8u) + l_f))];
}
int coax_p_wg_i32_f(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x != l_x))
  {
    return 0;
  }
  if ((l_x <= (-0x1.000000p31f)))
  {
    return (-2147483647 - 1);
  }
  if ((l_x >= 0x1.fffffep30f))
  {
    return 2147483520;
  }
  return int(l_x);
}
float coax_p_eg_water_shoal(CoaxResources cx, float p_k, float p_depth) {
  float l_k = p_k;
  float l_depth = p_depth;
  return sqrt(coax_p_wg_tanh(cx, coax_p_clampf(cx, (l_k * l_depth), 0.0f, 0x1.400000p3f)));
}
float coax_p_wg_dot2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_wg_dot4(CoaxResources cx, float4 p_a, float4 p_b) {
  float4 l_a = p_a;
  float4 l_b = p_b;
  return dot(l_a, l_b);
}
coax_t19 coax_p_wg_cvt_i2f2(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_i2(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y));
}
float coax_p_eg_water_hull(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  uint l_k{};
  float4 l_h{};
  float2 l_d{};
  float l_ax{};
  float l_az{};
  {
    l_k = 0u;
    while ((l_k < 3u))
    {
      l_h = coax_p_wg_at4(cx, ((int((2u + l_k)) * 4) + 1500));
      if ((l_h.w < 0x1.000000p-1f))
      {
        {
          l_k = (l_k + 1u);
          continue;
        }
      }
      l_d = coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_h.x, l_h.y));
      l_ax = sin(l_h.z);
      l_az = cos(l_h.z);
      if (((abs(((l_d.x * l_az) - (l_d.y * l_ax))) < 0x1.000000p-1f) && (abs(((l_d.x * l_ax) + (l_d.y * l_az))) < 0x1.8a3d70p0f)))
      {
        return 0x1.000000p0f;
      }
      l_k = (l_k + 1u);
    }
  }
  return 0.0f;
}
bool coax_p_eg_water_dry(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float l_w{};
  float2 l_a{};
  float2 l_e{};
  float l_t{};
  float l_r{};
  l_w = cx.r_u[2100];
  if ((l_w > 0.0f))
  {
    l_a = coax_p_v2(cx, cx.r_u[2096], cx.r_u[2097]);
    l_e = coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, cx.r_u[2098], cx.r_u[2099]), l_a);
    l_t = (coax_p_wg_dot2(cx, coax_p_wg_sub_f2f2(cx, l_p, l_a), l_e) / coax_p_fmax(cx, coax_p_wg_dot2(cx, l_e, l_e), 0x1.a36e2ep-14f));
    if ((((l_t > 0.0f) && (l_t < 0x1.000000p0f)) && (coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, coax_p_wg_sub_f2f2(cx, l_p, l_a), coax_p_wg_mul_f2f(cx, l_e, l_t))) < l_w)))
    {
      return true;
    }
  }
  l_r = cx.r_u[2103];
  return ((l_r > 0.0f) && (coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, cx.r_u[2101], cx.r_u[2102]))) < l_r));
}
float3 coax_p_eg_water_scene_at(CoaxResources cx, coax_t19 p_px) {
  coax_t19 l_px = p_px;
  coax_t19 l_size{};
  l_size = coax_p_wg_cvt_i2u2(cx, coax_p_wg_dims_2d(cx));
  return coax_p_wg_sw_rgb_f4(cx, coax_p_wg_load_2d(cx, coax_p_wg_clamp_i2i2i2(cx, l_px, coax_p_i2(cx, 0, 0), coax_p_wg_sub_i2i2(cx, l_size, coax_p_i2(cx, 1, 1))), 0));
}
float coax_p_eg_water_thickness(CoaxResources cx, coax_t19 p_px, float3 p_world) {
  coax_t19 l_px = p_px;
  float3 l_world = p_world;
  float l_w{};
  l_w = coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), coax_p_v4(cx, l_world.x, l_world.y, l_world.z, 0x1.000000p0f));
  return ((coax_p_fmax(cx, (coax_p_eg_water_scene_w(cx, l_px) - l_w), 0.0f) * coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world))) / coax_p_fmax(cx, l_w, 0x1.0624dep-10f));
}
coax_t21 coax_p_wg_dims_2d(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_water_scene).get_width(), (cx.r_water_scene).get_height());
}
float coax_p_wg_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float2 coax_p_wg_div_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x / l_b), (l_a.y / l_b));
}
float2 coax_p_wg_round_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_wg_round(cx, l_p0.x), coax_p_wg_round(cx, l_p0.y));
}
coax_t19 coax_p_wg_add_i2i2(CoaxResources cx, coax_t19 p_a, coax_t19 p_b) {
  coax_t19 l_a = p_a;
  coax_t19 l_b = p_b;
  return coax_p_i2(cx, (l_a.x + l_b.x), (l_a.y + l_b.y));
}
float coax_p_eg_water_scene_w(CoaxResources cx, coax_t19 p_px) {
  coax_t19 l_px = p_px;
  coax_t19 l_size{};
  l_size = coax_p_wg_cvt_i2u2(cx, coax_p_wg_dims_depth(cx));
  return coax_p_eg_water_view_w(cx, coax_p_wg_load_depth(cx, coax_p_wg_clamp_i2i2i2(cx, l_px, coax_p_i2(cx, 0, 0), coax_p_wg_sub_i2i2(cx, l_size, coax_p_i2(cx, 1, 1))), 0));
}
float3 coax_p_wg_mul_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x * l_b.x), (l_a.y * l_b.y), (l_a.z * l_b.z));
}
float3 coax_p_wg_sub_f3f3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float3 coax_p_wg_neg_f3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_v3(cx, (-l_a.x), (-l_a.y), (-l_a.z));
}
float3 coax_p_wg_reflect3(CoaxResources cx, float3 p_i, float3 p_n) {
  float3 l_i = p_i;
  float3 l_n = p_n;
  return coax_p_reflect3(cx, l_i, l_n);
}
float4 coax_p_eg_water_ssr(CoaxResources cx, float3 p_p, float3 p_dir) {
  float3 l_p = p_p;
  float3 l_dir = p_dir;
  float2 l_size{};
  float l_t{};
  float l_last{};
  int l_k{};
  float3 l_q{};
  float4 l_c{};
  float2 l_ndc{};
  coax_t19 l_px{};
  float l_sw{};
  float l_edge{};
  float l_sure{};
  if ((l_dir.y < 0x1.eb851ep-6f))
  {
    return coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
  }
  l_size = coax_p_wg_cvt_f2u2(cx, coax_p_wg_dims_2d(cx));
  l_t = 0x1.000000p-2f;
  l_last = 0.0f;
  {
    l_k = 0;
    while ((l_k < 20))
    {
      l_q = coax_p_wg_add_f3f3(cx, l_p, coax_p_wg_mul_f3f(cx, l_dir, l_t));
      l_c = coax_p_v4(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 8), coax_p_v4(cx, l_q.x, l_q.y, l_q.z, 0x1.000000p0f)), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 12), coax_p_v4(cx, l_q.x, l_q.y, l_q.z, 0x1.000000p0f)), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 16), coax_p_v4(cx, l_q.x, l_q.y, l_q.z, 0x1.000000p0f)), coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), coax_p_v4(cx, l_q.x, l_q.y, l_q.z, 0x1.000000p0f)));
      if ((l_c.w <= 0x1.99999ap-5f))
      {
        return coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
      }
      l_ndc = coax_p_wg_div_f2f(cx, coax_p_v2(cx, l_c.x, l_c.y), l_c.w);
      if (((abs(l_ndc.x) > 0x1.000000p0f) || (abs(l_ndc.y) > 0x1.000000p0f)))
      {
        return coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
      }
      l_px = coax_p_wg_cvt_i2f2(cx, coax_p_wg_mul_f2f2(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f2(cx, l_ndc, coax_p_v2(cx, 0x1.000000p-1f, (-0x1.000000p-1f))), coax_p_v2(cx, 0x1.000000p-1f, 0x1.000000p-1f)), l_size));
      l_sw = coax_p_eg_water_scene_w(cx, l_px);
      if (((l_sw < l_c.w) && ((l_c.w - l_sw) < (((l_t - l_last) * 0x1.800000p0f) + 0x1.333334p-2f))))
      {
        l_edge = coax_p_fmin(cx, (0x1.000000p0f - abs(l_ndc.x)), (0x1.000000p0f - abs(l_ndc.y)));
        l_sure = (((coax_p_smoothstep(cx, 0.0f, 0x1.eb851ep-4f, l_edge) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.c00000p3f, 0x1.400000p4f, float(l_k)))) * coax_p_smoothstep(cx, 0x1.eb851ep-6f, 0x1.eb851ep-4f, l_dir.y)) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.800000p3f, 0x1.e00000p4f, l_t)));
        return coax_p_wg_make_f4_f3f(cx, coax_p_eg_water_scene_at(cx, l_px), l_sure);
      }
      l_last = l_t;
      l_t = ((l_t * 0x1.51eb86p0f) + 0x1.99999ap-4f);
      l_k = (l_k + 1);
    }
  }
  return coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
}
float coax_p_eg_haze_share(CoaxResources cx, float p_d, float p_y) {
  float l_d = p_d;
  float l_y = p_y;
  return coax_p_verse_style_haze(cx, l_d, l_y, (cx.r_u[25] - 0x1.400000p1f), cx.r_u[31], cx.r_u[27], (coax_p_eg_st(cx, 9u)).z, (coax_p_eg_st(cx, 9u)).w);
}
float3 coax_p_wg_make_f3_f2f(CoaxResources cx, float2 p_p0, float p_p1) {
  float2 l_p0 = p_p0;
  float l_p1 = p_p1;
  return coax_p_v3(cx, l_p0.x, l_p0.y, l_p1);
}
float coax_p_eg_water_noise(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  float3 l_i{};
  float3 l_f{};
  float3 l_s{};
  float l_a{};
  float l_b{};
  float l_c{};
  float l_d{};
  float l_e{};
  float l_g{};
  float l_h{};
  float l_k{};
  l_i = coax_p_wg_floor_f3(cx, l_p);
  l_f = coax_p_wg_fract_f3(cx, l_p);
  l_s = coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f3(cx, l_f, l_f), coax_p_wg_sub_ff3(cx, 0x1.800000p1f, coax_p_wg_mul_ff3(cx, 0x1.000000p1f, l_f)));
  l_a = coax_p_eg_water_hash(cx, l_i);
  l_b = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f)));
  l_c = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f)));
  l_d = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0.0f)));
  l_e = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0.0f, 0x1.000000p0f)));
  l_g = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0x1.000000p0f)));
  l_h = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0x1.000000p0f)));
  l_k = coax_p_eg_water_hash(cx, coax_p_wg_add_f3f3(cx, l_i, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f)));
  return coax_p_mix(cx, coax_p_mix(cx, coax_p_mix(cx, l_a, l_b, l_s.x), coax_p_mix(cx, l_c, l_d, l_s.x), l_s.y), coax_p_mix(cx, coax_p_mix(cx, l_e, l_g, l_s.x), coax_p_mix(cx, l_h, l_k, l_s.x), l_s.y), l_s.z);
}
float coax_p_clampf(CoaxResources cx, float p_x, float p_low, float p_high) {
  float l_x = p_x;
  float l_low = p_low;
  float l_high = p_high;
  return coax_p_fmin(cx, coax_p_fmax(cx, l_x, l_low), l_high);
}
float3 coax_p_eg_water_host_light(CoaxResources cx, float3 p_world, float3 p_n, bool p_paint_leaf_far) {
  float3 l_world = p_world;
  float3 l_n = p_n;
  bool l_paint_leaf_far = p_paint_leaf_far;
  return coax_p_eg_water_host_light_shaded(cx, l_world, l_n, coax_p_eg_shade_shadows(cx, coax_p_v2(cx, l_world.x, l_world.z)), l_paint_leaf_far);
}
float3 coax_p_wg_mix_f3f3f(CoaxResources cx, float3 p_p0, float3 p_p1, float p_p2) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  float l_p2 = p_p2;
  return coax_p_v3(cx, coax_p_mix(cx, l_p0.x, l_p1.x, l_p2), coax_p_mix(cx, l_p0.y, l_p1.y, l_p2), coax_p_mix(cx, l_p0.z, l_p1.z, l_p2));
}
float3 coax_p_wg_max_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_p_fmax(cx, l_p0.x, l_p1.x), coax_p_fmax(cx, l_p0.y, l_p1.y), coax_p_fmax(cx, l_p0.z, l_p1.z));
}
coax_t20 coax_p_eg_water_fragment(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far = p_paint_leaf_far;
  uint l_part{};
  float3 l_world{};
  float2 l_rest{};
  float2 l_flow{};
  float l_depth{};
  float3 l_v{};
  float l_eye_distance{};
  float l_footprint{};
  float3 l_swell{};
  float3 l_detail{};
  float2 l_slope{};
  float3 l_n{};
  float l_roughness{};
  coax_t20 l_none{};
  coax_t20 l_o{};
  float l_nov{};
  float l_fresnel{};
  float3 l_sky{};
  float3 l_l{};
  float3 l_light{};
  float3 l_glint{};
  float3 l_crest{};
  float l_noise{};
  float l_foam{};
  float3 l_foam_rgb{};
  float l_ci{};
  float3 l_through{};
  float3 l_body{};
  float3 l_clear{};
  float l_edge{};
  float l_cover{};
  l_part = coax_p_wg_u32_f(cx, (l_i.f4.x + 0x1.000000p-1f));
  if ((l_part == 7u))
  {
    return coax_p_eg_weir_shade(cx, l_i, l_paint_leaf_far);
  }
  if ((l_part == 8u))
  {
    return coax_p_eg_fx_shade(cx, l_i, l_paint_leaf_far);
  }
  if ((!coax_p_eg_water_surface_part(cx, l_part)))
  {
    return coax_p_eg_fountain_fall_shade(cx, l_i, l_part, l_paint_leaf_far);
  }
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_rest = coax_p_v2(cx, l_i.z.x, l_i.z.y);
  l_flow = coax_p_v2(cx, l_i.z.z, l_i.z.w);
  l_depth = l_i.y.w;
  l_v = coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_eye_distance = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_footprint = coax_p_eg_water_footprint(cx, l_v, l_eye_distance);
  if ((l_part == 6u))
  {
    return coax_p_eg_pond_shade(cx, l_i, l_v, l_eye_distance, l_footprint, l_paint_leaf_far, p_wake_foam);
  }
  if ((l_part >= 1u))
  {
    return coax_p_eg_fountain_pool_shade(cx, l_i, l_part, l_v, l_footprint, l_paint_leaf_far, p_wake_foam);
  }
  l_swell = coax_p_eg_water_gerstner_slope(cx, l_rest, l_depth, 0x1.000000p0f);
  l_detail = coax_p_eg_water_flow_detail(cx, l_rest, l_flow, l_footprint);
  l_slope = coax_p_wg_add_f2f2(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_swell.x, l_swell.y), coax_p_v2(cx, l_detail.x, l_detail.y)), coax_p_eg_water_ripples(cx, l_rest, p_wake_foam)), coax_p_eg_weather_rain_slope(cx, coax_p_v2(cx, l_world.x, l_world.z)));
  l_n = coax_p_wg_normalize3(cx, coax_p_v3(cx, (-l_slope.x), (0x1.000000p0f - l_swell.z), (-l_slope.y)));
  l_roughness = coax_p_clampf(cx, sqrt(((cx.r_u[1060] * cx.r_u[1060]) + l_detail.z)), 0x1.47ae14p-6f, 0x1.333334p-1f);
  if ((cx.r_u[25] < l_world.y))
  {
    if ((cx.r_u[1062] > 0x1.000000p-1f))
    {
      return coax_p_eg_water_below(cx, l_n, l_v, l_eye_distance, coax_p_wg_length2(cx, l_slope));
    }
    l_none = coax_t20{};
    l_none.x = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
    l_none.y = coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f);
    return l_none;
  }
  if ((cx.r_u[1055] > 0x1.000000p-1f))
  {
    return coax_p_eg_water_painted(cx, l_world, l_rest, l_flow, l_depth, l_i.w.w, l_i.w.x, l_n, l_v, l_footprint, l_paint_leaf_far, p_wake_foam);
  }
  l_o = coax_t20{};
  l_nov = coax_p_fmax(cx, coax_p_wg_dot3(cx, l_n, l_v), 0x1.0624dep-10f);
  l_fresnel = coax_p_eg_water_fresnel(cx, l_nov);
  l_sky = coax_p_eg_water_host_sky(cx, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_v), l_n), coax_p_eg_water_sky_roughness(cx, l_roughness, l_footprint));
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_water_host_sun(cx));
  l_light = coax_p_wg_mul_f3f(cx, coax_p_eg_water_host_sun_light(cx), coax_p_eg_shade_shadows(cx, coax_p_v2(cx, l_world.x, l_world.z)));
  l_glint = coax_p_wg_mul_ff3(cx, coax_p_eg_water_glint(cx, l_n, l_v, l_l, l_roughness, cx.r_u[1066], l_eye_distance), l_light);
  l_crest = coax_p_wg_mul_f3f3(cx, coax_p_eg_water_crest_scatter(cx, l_v, l_l, l_n, l_i.f4.y, l_i.w.z), l_light);
  l_noise = coax_p_eg_water_foam_noise(cx, l_rest, l_flow);
  l_foam = coax_p_eg_water_foam(cx, l_rest, l_i.w.w, l_i.w.z, l_i.w.x, l_noise, p_wake_foam);
  l_foam_rgb = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.ccccccp-1f, 0x1.e147aep-1f, 0x1.e66666p-1f), coax_p_eg_water_host_light(cx, l_world, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_paint_leaf_far));
  l_ci = coax_p_clampf(cx, l_v.y, 0.0f, 0x1.000000p0f);
  l_through = coax_p_eg_water_transmittance(cx, l_depth, l_ci);
  l_body = coax_p_wg_mul_f3f3(cx, coax_p_eg_water_inscatter(cx), coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), l_through));
  l_clear = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_sky, l_fresnel), l_glint), l_crest), coax_p_wg_mul_f3f(cx, l_body, (0x1.000000p0f - l_fresnel)));
  l_edge = coax_p_smoothstep(cx, (-0x1.99999ap-5f), 0x1.eb851ep-4f, l_depth);
  l_cover = (l_foam * coax_p_smoothstep(cx, (-0x1.47ae14p-4f), 0.0f, l_depth));
  l_o.x = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_clear, l_edge), (0x1.000000p0f - l_cover)), coax_p_wg_mul_f3f(cx, l_foam_rgb, l_cover));
  l_o.y = coax_p_wg_mul_f3f(cx, coax_p_wg_mix_f3f3f(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), coax_p_wg_mul_f3f(cx, l_through, (0x1.000000p0f - l_fresnel)), l_edge), (0x1.000000p0f - l_cover));
  l_o.z = coax_p_v2(cx, l_n.x, l_n.z);
  l_o.w = coax_p_v4(cx, l_sky.x, l_sky.y, l_sky.z, ((l_fresnel * l_edge) * (0x1.000000p0f - l_cover)));
  return l_o;
}
float3 coax_p_wg_div_f3f(CoaxResources cx, float3 p_a, float p_b) {
  float3 l_a = p_a;
  float l_b = p_b;
  return coax_p_v3(cx, (l_a.x / l_b), (l_a.y / l_b), (l_a.z / l_b));
}
float3 coax_p_eg_haze_colour(CoaxResources cx, float p_f, float3 p_v) {
  float l_f = p_f;
  float3 l_v = p_v;
  float3 l_hz{};
  float l_cap{};
  float3 l_h{};
  float3 l_green{};
  float l_level{};
  float l_glow{};
  l_hz = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u));
  l_cap = (coax_p_eg_st(cx, 9u)).z;
  l_h = coax_p_v3(cx, coax_p_verse_style_haze_hue(cx, l_hz.x, 0.0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.y, 0x1.000000p0f, l_f, l_cap), coax_p_verse_style_haze_hue(cx, l_hz.z, 0x1.000000p1f, l_f, l_cap));
  l_green = coax_p_wg_div_f3f(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_wg_dot3(cx, coax_p_eg_meadow_srgb(cx, 0x1.000000p-1f), coax_p_v3(cx, 0x1.554c98p-2f, 0x1.554c98p-2f, 0x1.554c98p-2f)));
  l_level = (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.666666p-2f, abs(l_v.y)));
  l_h = coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_mul_f3f3(cx, l_h, l_green), ((0x1.851eb8p-2f * l_level) * (0x1.000000p0f - (coax_p_eg_st(cx, 14u)).w)));
  l_glow = coax_p_verse_style_haze_glow(cx, coax_p_wg_dot3(cx, l_v, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u))));
  if (((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f))
  {
    return coax_p_wg_add_f3f3(cx, l_h, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (((coax_p_eg_st(cx, 0u)).w * l_glow) * 0x1.000000p-1f)));
  }
  return coax_p_wg_mix_f3f3f(cx, l_h, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u)), l_glow);
}
float3 coax_p_normalize3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return coax_p_scale3(cx, l_a, (0x1.000000p0f / coax_p_length3(cx, l_a)));
}
float2 coax_p_wg_floor_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, floor(l_p0.x), floor(l_p0.y));
}
float2 coax_p_wg_fract_f2(CoaxResources cx, float2 p_p0) {
  float2 l_p0 = p_p0;
  return coax_p_v2(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y));
}
float coax_p_eg_height(CoaxResources cx, int p_x, int p_z) {
  int l_x = p_x;
  int l_z = p_z;
  int l_n{};
  int l_cx{};
  int l_cz{};
  l_n = coax_p_wg_i32_f(cx, cx.r_u[32]);
  l_cx = coax_p_wg_clamp_i(cx, l_x, 0, l_n);
  l_cz = coax_p_wg_clamp_i(cx, l_z, 0, l_n);
  return cx.r_heights[int(uint(((l_cz * (l_n + 1)) + l_cx)))];
}
float3 coax_p_EG_F_JET(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.eb851ep-6f, 0x1.4cccccp1f, 0x1.1eb852p-1f);
}
float2 coax_p_EG_F_JET_V(CoaxResources cx) {
  return coax_p_v2(cx, 0x1.000000p-1f, 0x1.ccccccp0f);
}
float2 coax_p_EG_F_LIP(CoaxResources cx) {
  return coax_p_v2(cx, 0x1.6147aep0f, 0x1.10a3d8p1f);
}
float3 coax_p_cross3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3(((l_a.y * l_b.z) - (l_a.z * l_b.y)), ((l_a.z * l_b.x) - (l_a.x * l_b.z)), ((l_a.x * l_b.y) - (l_a.y * l_b.x)));
}
float coax_p_saturate(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_clampf(cx, l_x, 0.0f, 0x1.000000p0f);
}
float coax_p_wg_tanh(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_e{};
  if ((l_x > 0x1.400000p3f))
  {
    return 0x1.000000p0f;
  }
  if ((l_x < (-0x1.400000p3f)))
  {
    return (-0x1.000000p0f);
  }
  l_e = exp((0x1.000000p1f * l_x));
  return ((l_e - 0x1.000000p0f) / (l_e + 0x1.000000p0f));
}
coax_t19 coax_p_i2(CoaxResources cx, int p_x, int p_y) {
  int l_x = p_x;
  int l_y = p_y;
  return coax_t19{l_x, l_y};
}
float coax_p_wg_length2(CoaxResources cx, float2 p_a) {
  float2 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
coax_t19 coax_p_wg_cvt_i2u2(CoaxResources cx, coax_t21 p_p) {
  coax_t21 l_p = p_p;
  return coax_p_i2(cx, int(l_p.x), int(l_p.y));
}
coax_t19 coax_p_wg_sub_i2i2(CoaxResources cx, coax_t19 p_a, coax_t19 p_b) {
  coax_t19 l_a = p_a;
  coax_t19 l_b = p_b;
  return coax_p_i2(cx, (l_a.x - l_b.x), (l_a.y - l_b.y));
}
coax_t19 coax_p_wg_clamp_i2i2i2(CoaxResources cx, coax_t19 p_p0, coax_t19 p_p1, coax_t19 p_p2) {
  coax_t19 l_p0 = p_p0;
  coax_t19 l_p1 = p_p1;
  coax_t19 l_p2 = p_p2;
  return coax_p_i2(cx, coax_p_wg_clamp_i(cx, l_p0.x, l_p1.x, l_p2.x), coax_p_wg_clamp_i(cx, l_p0.y, l_p1.y, l_p2.y));
}
float4 coax_p_wg_load_2d(CoaxResources cx, coax_t19 p_c, int p_level) {
  coax_t19 l_c = p_c;
  int l_level = p_level;
  return (cx.r_water_scene).read(uint2(l_c.x, l_c.y), uint(l_level));
}
float3 coax_p_wg_sw_rgb_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
coax_t21 coax_p_u2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_t21{l_x, l_y};
}
float coax_p_wg_round(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_r{};
  l_r = floor((l_x + 0x1.000000p-1f));
  if ((((l_r - l_x) == 0x1.000000p-1f) && (coax_p_wg_fmod(cx, l_r, 0x1.000000p1f) != 0.0f)))
  {
    return (l_r - 0x1.000000p0f);
  }
  return l_r;
}
coax_t21 coax_p_wg_dims_depth(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_water_scene_depth).get_width(), (cx.r_water_scene_depth).get_height());
}
float coax_p_wg_load_depth(CoaxResources cx, coax_t19 p_c, int p_level) {
  coax_t19 l_c = p_c;
  int l_level = p_level;
  return (cx.r_water_scene_depth).read(uint2(l_c.x, l_c.y), uint(l_level));
}
float coax_p_eg_water_view_w(CoaxResources cx, float p_d) {
  float l_d = p_d;
  float l_a{};
  float l_b{};
  float l_w{};
  l_a = (coax_p_wg_dot3(cx, coax_p_v3(cx, cx.r_u[16], cx.r_u[17], cx.r_u[18]), coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22])) / coax_p_fmax(cx, coax_p_wg_dot3(cx, coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22]), coax_p_v3(cx, cx.r_u[20], cx.r_u[21], cx.r_u[22])), 0x1.0c6f7ap-20f));
  l_b = (cx.r_u[19] - (l_a * cx.r_u[23]));
  l_w = (l_b / coax_p_fmin(cx, (l_d - l_a), (-0x1.ad7f2ap-24f)));
  return (((l_d < 0x1.ffffdep-1f) && (l_w > 0.0f)) ? l_w : 0x1.e84800p19f);
}
float3 coax_p_reflect3(CoaxResources cx, float3 p_i, float3 p_n) {
  float3 l_i = p_i;
  float3 l_n = p_n;
  return coax_p_sub3(cx, l_i, coax_p_scale3(cx, l_n, (0x1.000000p1f * dot(l_n, l_i))));
}
float2 coax_p_wg_cvt_f2u2(CoaxResources cx, coax_t21 p_p) {
  coax_t21 l_p = p_p;
  return coax_p_v2(cx, float(l_p.x), float(l_p.y));
}
float2 coax_p_wg_mul_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return coax_p_v2(cx, (l_a.x * l_b.x), (l_a.y * l_b.y));
}
float4 coax_p_eg_st(CoaxResources cx, uint p_i) {
  uint l_i = p_i;
  return coax_p_wg_at4(cx, ((int(l_i) * 4) + 1084));
}
float coax_p_verse_style_haze(CoaxResources cx, float p_d, float p_y, float p_base_y, float p_start, float p_density, float p_cap, float p_falloff) {
  float l_d = p_d;
  float l_y = p_y;
  float l_base_y = p_base_y;
  float l_start = p_start;
  float l_density = p_density;
  float l_cap = p_cap;
  float l_falloff = p_falloff;
  float l_dist{};
  float l_height{};
  l_dist = (0x1.000000p0f - exp(((-l_density) * coax_p_st_max(cx, (l_d - l_start), 0.0f))));
  l_height = exp(((-coax_p_st_max(cx, (l_y - l_base_y), 0.0f)) / coax_p_st_max(cx, l_falloff, 0x1.0624dep-10f)));
  return coax_p_st_min(cx, (l_dist * (0x1.000000p0f + ((l_height - 0x1.000000p0f) * 0x1.333334p-1f))), l_cap);
}
float3 coax_p_wg_floor_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, floor(l_p0.x), floor(l_p0.y), floor(l_p0.z));
}
float3 coax_p_wg_fract_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, coax_p_fract(cx, l_p0.x), coax_p_fract(cx, l_p0.y), coax_p_fract(cx, l_p0.z));
}
float3 coax_p_wg_mul_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a * l_b.x), (l_a * l_b.y), (l_a * l_b.z));
}
float3 coax_p_wg_sub_ff3(CoaxResources cx, float p_a, float3 p_b) {
  float l_a = p_a;
  float3 l_b = p_b;
  return coax_p_v3(cx, (l_a - l_b.x), (l_a - l_b.y), (l_a - l_b.z));
}
float coax_p_eg_water_hash(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  coax_t22 l_v{};
  l_v = coax_p_wg_add_u3u(cx, coax_p_wg_mul_u3u(cx, coax_p_wg_bits_u3i3(cx, coax_p_wg_cvt_i3f3(cx, l_p)), 1664525u), 1013904223u);
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  l_v.y = (l_v.y + (l_v.z * l_v.x));
  l_v.z = (l_v.z + (l_v.x * l_v.y));
  l_v = coax_p_wg_xor_u3u3(cx, l_v, coax_p_wg_shr_u3u3(cx, l_v, coax_p_u3(cx, 16u, 16u, 16u)));
  l_v.x = (l_v.x + (l_v.y * l_v.z));
  return (float((l_v.x >> uint(8u))) / 0x1.fffffep23f);
}
float coax_p_eg_shade_shadows(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_eg_shade_shadows_at(cx, l_p, 0.0f, false);
}
float3 coax_p_eg_water_host_light_shaded(CoaxResources cx, float3 p_world, float3 p_n, float p_sh, bool p_paint_leaf_far) {
  float3 l_world = p_world;
  float3 l_n = p_n;
  float l_sh = p_sh;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_amb{};
  l_amb = coax_p_v3(cx, coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).x, (coax_p_eg_st(cx, 6u)).x, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).y, (coax_p_eg_st(cx, 6u)).y, (coax_p_eg_st(cx, 5u)).w), coax_p_verse_style_ambient(cx, l_n.y, (coax_p_eg_st(cx, 5u)).z, (coax_p_eg_st(cx, 6u)).z, (coax_p_eg_st(cx, 5u)).w));
  return coax_p_wg_add_f3f3(cx, l_amb, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w), coax_p_fmax(cx, coax_p_wg_dot3(cx, l_n, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u))), 0.0f)), coax_p_eg_map_lit(cx, l_world, l_n, l_paint_leaf_far)), l_sh));
}
coax_t20 coax_p_eg_weir_shade(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far = p_paint_leaf_far;
  coax_t20 l_o{};
  float3 l_world{};
  float3 l_n{};
  float l_v_along{};
  float l_a{};
  float l_width{};
  float3 l_to_eye{};
  float l_t{};
  float3 l_light{};
  float l_facing{};
  float l_fresnel{};
  float3 l_sky{};
  float l_x{};
  float l_streak{};
  float l_sides{};
  float l_torn{};
  float l_white{};
  float l_alpha{};
  float l_lip{};
  float3 l_body{};
  float3 l_foam{};
  float3 l_c{};
  l_o = coax_t20{};
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_n = coax_p_wg_normalize3(cx, coax_p_v3(cx, l_i.z.x, l_i.z.y, l_i.z.z));
  l_v_along = l_i.z.w;
  l_a = l_i.f4.y;
  l_width = l_i.f4.w;
  l_to_eye = coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_t = cx.r_u[1048];
  l_light = coax_p_eg_water_host_light(cx, l_world, coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_n, coax_p_v3(cx, 0.0f, 0x1.000000p-1f, 0.0f))), l_paint_leaf_far);
  l_facing = abs(coax_p_wg_dot3(cx, l_n, l_to_eye));
  l_fresnel = coax_p_eg_water_fresnel(cx, coax_p_fmax(cx, l_facing, 0x1.99999ap-5f));
  l_sky = coax_p_eg_water_host_sky(cx, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_to_eye), l_n), 0.0f);
  l_x = (l_a * l_width);
  l_streak = coax_p_eg_water_noise(cx, coax_p_v3(cx, (l_x * 0x1.c00000p2f), ((l_v_along * 0x1.800000p1f) - (l_t * 0x1.200000p2f)), 0x1.000000p0f));
  l_streak = ((l_streak * 0x1.333334p-1f) + (0x1.99999ap-2f * coax_p_eg_water_noise(cx, coax_p_v3(cx, (l_x * 0x1.300000p4f), ((l_v_along * 0x1.000000p3f) - (l_t * 0x1.000000p3f)), 0x1.400000p2f))));
  l_sides = (coax_p_smoothstep(cx, 0.0f, 0x1.eb851ep-5f, l_a) * coax_p_smoothstep(cx, 0.0f, 0x1.eb851ep-5f, (0x1.000000p0f - l_a)));
  l_torn = coax_p_smoothstep(cx, 0x1.333334p-3f, 0x1.ccccccp-2f, ((l_streak + (0x1.000000p-1f * l_sides)) - (0x1.333334p-2f * (0x1.000000p0f - l_sides))));
  l_white = coax_p_clampf(cx, ((0x1.333334p-2f + (0x1.333334p-1f * coax_p_smoothstep(cx, 0x1.666666p-2f, 0x1.e66666p-1f, l_v_along))) + (0x1.ccccccp-2f * coax_p_smoothstep(cx, 0x1.19999ap-1f, 0x1.b33334p-1f, l_streak))), 0.0f, 0x1.000000p0f);
  l_alpha = coax_p_clampf(cx, ((((0x1.3d70a4p-1f + (0x1.333334p-2f * l_v_along)) + (0x1.333334p-3f * l_streak)) * l_torn) * coax_p_smoothstep(cx, 0.0f, 0x1.47ae14p-4f, (l_v_along + 0x1.99999ap-5f))), 0.0f, 0x1.f0a3d8p-1f);
  l_lip = (exp((((-l_v_along) * l_v_along) / 0x1.0624dep-8f)) * 0x1.000000p-1f);
  l_body = coax_p_wg_mul_f3f3(cx, coax_p_wg_pow_f3f3(cx, coax_p_EG_W_SHALLOW(cx), coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f)), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.ccccccp-1f), coax_p_v3(cx, 0x1.99999ap-5f, 0x1.99999ap-5f, 0x1.99999ap-5f)));
  l_foam = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.e66666p-1f, 0x1.f0a3d8p-1f, 0x1.eb851ep-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.e66666p-1f), coax_p_v3(cx, 0x1.47ae14p-4f, 0x1.47ae14p-4f, 0x1.47ae14p-4f)));
  l_c = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mix_f3f3f(cx, l_body, l_foam, l_white), (0x1.000000p0f - (l_fresnel * 0x1.000000p-1f))), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_sky, l_fresnel), 0x1.000000p-1f)), coax_p_wg_mul_f3f(cx, l_foam, l_lip));
  l_o.x = coax_p_wg_mul_f3f(cx, l_c, l_alpha);
  l_o.y = coax_p_wg_make_f3_f(cx, (0x1.000000p0f - l_alpha));
  return l_o;
}
coax_t20 coax_p_eg_fx_shade(CoaxResources cx, coax_t8 p_i, bool p_paint_leaf_far) {
  coax_t8 l_i = p_i;
  bool l_paint_leaf_far = p_paint_leaf_far;
  coax_t20 l_o{};
  uint l_kind{};
  float3 l_world{};
  float l_r{};
  float3 l_light{};
  float l_near{};
  float l_alpha{};
  float3 l_c{};
  float l_puff{};
  float l_w{};
  l_o = coax_t20{};
  l_kind = coax_p_wg_u32_f(cx, (l_i.f4.y + 0x1.000000p-1f));
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_r = coax_p_wg_length2(cx, coax_p_v2(cx, l_i.z.x, l_i.z.y));
  l_light = coax_p_eg_water_host_light(cx, l_world, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_paint_leaf_far);
  l_near = coax_p_wg_length3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_alpha = l_i.f4.z;
  l_c = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  if (((l_kind == 0u) || (l_kind == 2u)))
  {
    l_alpha = (l_alpha * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.19999ap-1f, 0x1.000000p0f, l_r)));
    l_c = coax_p_wg_mul_f3f3(cx, coax_p_wg_mix_f3f3f(cx, coax_p_wg_pow_f3f3(cx, coax_p_EG_W_SHALLOW(cx), coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f)), coax_p_v3(cx, 0x1.e66666p-1f, 0x1.f0a3d8p-1f, 0x1.f5c290p-1f), 0x1.666666p-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.e66666p-1f), coax_p_v3(cx, 0x1.99999ap-4f, 0x1.99999ap-4f, 0x1.99999ap-4f)));
  }
  else
  {
    l_puff = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_i.z.x, l_i.z.y), 0x1.99999ap0f), coax_p_wg_make_f2_f(cx, (l_i.f4.w * 0x1.000000p1f))), (l_i.f4.w * 0x1.800000p1f)));
    l_alpha = (l_alpha * (((0x1.000000p0f - coax_p_smoothstep(cx, 0x1.99999ap-3f, 0x1.000000p0f, l_r)) * (0x1.333334p-1f + (0x1.333334p-1f * l_puff))) * coax_p_smoothstep(cx, 0x1.333334p0f, 0x1.c00000p1f, l_near)));
    l_c = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.d70a3ep-1f, 0x1.e147aep-1f, 0x1.e66666p-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.99999ap-1f), coax_p_v3(cx, 0x1.70a3d8p-3f, 0x1.70a3d8p-3f, 0x1.70a3d8p-3f)));
  }
  l_w = coax_p_fmax(cx, coax_p_wg_dot4(cx, coax_p_wg_at4(cx, 20), coax_p_v4(cx, l_world.x, l_world.y, l_world.z, 0x1.000000p0f)), 0x1.0624dep-10f);
  l_alpha = (l_alpha * coax_p_smoothstep(cx, 0.0f, coax_p_fmax(cx, l_i.y.w, 0x1.99999ap-5f), (coax_p_eg_water_scene_w(cx, coax_p_wg_cvt_i2f2(cx, coax_p_v2(cx, l_i.x.x, l_i.x.y))) - l_w)));
  l_alpha = coax_p_clampf(cx, l_alpha, 0.0f, 0x1.000000p0f);
  l_o.x = coax_p_wg_mul_f3f(cx, l_c, l_alpha);
  l_o.y = coax_p_wg_make_f3_f(cx, (0x1.000000p0f - l_alpha));
  return l_o;
}
coax_t20 coax_p_eg_fountain_fall_shade(CoaxResources cx, coax_t8 p_i, uint p_part, bool p_paint_leaf_far) {
  coax_t8 l_i = p_i;
  uint l_part = p_part;
  bool l_paint_leaf_far = p_paint_leaf_far;
  coax_t20 l_o{};
  float3 l_world{};
  float3 l_n{};
  float l_v_along{};
  float l_around{};
  float l_k{};
  float3 l_to_eye{};
  float l_t{};
  float3 l_light{};
  float l_facing{};
  float l_fresnel{};
  float3 l_sky{};
  float l_streak{};
  float l_alpha{};
  float l_white{};
  float l_froth{};
  float l_thick{};
  float3 l_body{};
  float3 l_foam{};
  float3 l_c{};
  l_o = coax_t20{};
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_n = coax_p_wg_normalize3(cx, coax_p_v3(cx, l_i.z.x, l_i.z.y, l_i.z.z));
  l_v_along = l_i.z.w;
  l_around = l_i.f4.y;
  l_k = l_i.f4.w;
  l_to_eye = coax_p_wg_normalize3(cx, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, cx.r_u[24], cx.r_u[25], cx.r_u[26]), l_world));
  l_t = cx.r_u[1048];
  l_light = coax_p_eg_water_host_light(cx, l_world, coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_n, coax_p_v3(cx, 0.0f, 0x1.333334p-1f, 0.0f))), l_paint_leaf_far);
  l_facing = abs(coax_p_wg_dot3(cx, l_n, l_to_eye));
  l_fresnel = coax_p_eg_water_fresnel(cx, coax_p_fmax(cx, l_facing, 0x1.99999ap-5f));
  l_sky = coax_p_eg_water_host_sky(cx, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_to_eye), l_n), 0.0f);
  l_streak = coax_p_eg_water_noise(cx, coax_p_v3(cx, ((l_around * 0x1.200000p3f) + (l_k * 0x1.8cccccp1f)), ((l_v_along * 0x1.c00000p2f) - (l_t * 0x1.600000p2f)), l_k));
  l_streak = ((l_streak * 0x1.333334p-1f) + (0x1.99999ap-2f * coax_p_eg_water_noise(cx, coax_p_v3(cx, ((l_around * 0x1.700000p4f) + l_k), ((l_v_along * 0x1.000000p4f) - (l_t * 0x1.200000p3f)), (l_k + 0x1.000000p2f)))));
  l_alpha = 0.0f;
  l_white = 0.0f;
  if ((l_part == 5u))
  {
    l_froth = coax_p_eg_water_noise(cx, coax_p_v3(cx, ((l_around * 0x1.c00000p3f) + (l_k * 0x1.000000p1f)), ((l_v_along * 0x1.800000p1f) - (l_t * 0x1.000000p2f)), ((l_t * 0x1.000000p1f) + l_k)));
    l_alpha = ((coax_p_smoothstep(cx, 0x1.666666p-2f, 0x1.666666p-1f, (l_froth + (0x1.666666p-2f * (0x1.000000p0f - l_v_along)))) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.19999ap-1f, 0x1.000000p0f, l_v_along))) * 0x1.ccccccp-1f);
    l_white = 0x1.b33334p-1f;
  }
  else
  {
    l_thick = coax_p_mix(cx, 0x1.19999ap-1f, 0x1.d70a3ep-1f, (0x1.000000p0f - l_facing));
    l_alpha = ((l_thick * (0x1.70a3d8p-1f + (0x1.99999ap-2f * l_streak))) * (0x1.000000p0f - ((0x1.ccccccp-2f * coax_p_smoothstep(cx, 0x1.333334p-1f, 0x1.000000p0f, l_v_along)) * (0x1.000000p0f - l_streak))));
    l_white = coax_p_clampf(cx, ((0x1.000000p-2f + (0x1.19999ap-1f * coax_p_smoothstep(cx, 0x1.ccccccp-2f, 0x1.b33334p-1f, l_streak))) + (0x1.333334p-2f * l_v_along)), 0.0f, 0x1.000000p0f);
    if ((l_part == 4u))
    {
      l_white = (0x1.19999ap-1f + (0x1.666666p-2f * l_streak));
    }
  }
  l_alpha = coax_p_clampf(cx, l_alpha, 0.0f, 0x1.000000p0f);
  l_body = coax_p_wg_mul_f3f3(cx, coax_p_wg_pow_f3f3(cx, coax_p_EG_W_SHALLOW(cx), coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f)), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.ccccccp-1f), coax_p_v3(cx, 0x1.99999ap-5f, 0x1.99999ap-5f, 0x1.99999ap-5f)));
  l_foam = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.e66666p-1f, 0x1.f0a3d8p-1f, 0x1.eb851ep-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.e66666p-1f), coax_p_v3(cx, 0x1.47ae14p-4f, 0x1.47ae14p-4f, 0x1.47ae14p-4f)));
  l_c = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mix_f3f3f(cx, l_body, l_foam, l_white), (0x1.000000p0f - (l_fresnel * 0x1.000000p-1f))), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_sky, l_fresnel), 0x1.000000p-1f));
  l_o.x = coax_p_wg_mul_f3f(cx, l_c, l_alpha);
  l_o.y = coax_p_wg_make_f3_f(cx, (0x1.000000p0f - l_alpha));
  return l_o;
}
float coax_p_eg_water_footprint(CoaxResources cx, float3 p_v, float p_distance) {
  float3 l_v = p_v;
  float l_distance = p_distance;
  float l_size{};
  l_size = coax_p_fmax(cx, (l_distance * cx.r_u[1065]), 0x1.a36e2ep-14f);
  return (l_size * sqrt((0x1.000000p0f / coax_p_fmax(cx, abs(l_v.y), 0x1.47ae14p-4f))));
}
coax_t20 coax_p_eg_pond_shade(CoaxResources cx, coax_t8 p_i, float3 p_v, float p_eye_distance, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  coax_t8 l_i = p_i;
  float3 l_v = p_v;
  float l_eye_distance = p_eye_distance;
  float l_footprint = p_footprint;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_world{};
  float2 l_rest{};
  float3 l_detail{};
  float2 l_slope{};
  float3 l_n{};
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_rest = coax_p_v2(cx, l_i.z.x, l_i.z.y);
  l_detail = coax_p_eg_water_flow_detail(cx, l_rest, coax_p_v2(cx, 0.0f, 0.0f), l_footprint);
  l_slope = coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_detail.x, l_detail.y), 0x1.000000p-1f), coax_p_eg_water_ripples(cx, l_rest, p_wake_foam));
  l_n = coax_p_wg_normalize3(cx, coax_p_v3(cx, (-l_slope.x), 0x1.000000p0f, (-l_slope.y)));
  if ((cx.r_u[25] < l_world.y))
  {
    return coax_p_eg_water_below(cx, l_n, l_v, l_eye_distance, coax_p_wg_length2(cx, l_slope));
  }
  return coax_p_eg_water_painted(cx, l_world, l_rest, coax_p_v2(cx, 0.0f, 0.0f), l_i.y.w, l_i.w.w, 0.0f, l_n, l_v, l_footprint, l_paint_leaf_far, p_wake_foam);
}
coax_t20 coax_p_eg_fountain_pool_shade(CoaxResources cx, coax_t8 p_i, uint p_part, float3 p_v, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  coax_t8 l_i = p_i;
  uint l_part = p_part;
  float3 l_v = p_v;
  float l_footprint = p_footprint;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_world{};
  float2 l_rest{};
  float2 l_flow{};
  float l_r{};
  float l_land{};
  float l_t{};
  float3 l_detail{};
  float l_off{};
  float l_d{};
  float l_k{};
  float l_a{};
  float l_near{};
  float l_amp{};
  float2 l_ring{};
  float2 l_slope{};
  float3 l_n{};
  float l_deep{};
  l_world = coax_p_v3(cx, l_i.y.x, l_i.y.y, l_i.y.z);
  l_rest = coax_p_v2(cx, l_i.z.x, l_i.z.y);
  l_flow = coax_p_v2(cx, l_i.z.z, l_i.z.w);
  l_r = l_i.f4.z;
  l_land = l_i.f4.w;
  l_t = cx.r_u[1048];
  l_detail = coax_p_eg_water_flow_detail(cx, coax_p_wg_mul_f2f(cx, l_rest, 0x1.99999ap0f), l_flow, l_footprint);
  l_off = (l_r - l_land);
  l_d = abs(l_off);
  l_k = (0x1.921fb6p2f / ((l_part == 2u) ? 0x1.eb851ep-4f : 0x1.99999ap-3f));
  l_a = coax_p_wg_atan2(cx, l_rest.y, l_rest.x);
  l_near = ((l_part == 2u) ? 0x1.000000p0f : (0x1.ccccccp-2f + (0x1.19999ap-1f * coax_p_eg_fountain_stream_near(cx, l_a))));
  l_amp = ((((l_part == 2u) ? 0x1.89374cp-9f : 0x1.89374cp-8f) * l_near) * exp(((-l_d) * 0x1.666666p0f)));
  l_ring = coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, l_rest, coax_p_fmax(cx, l_r, 0x1.0624dep-10f)), coax_p_wg_sign(cx, l_off)), l_amp), l_k), cos(((l_k * l_d) - (l_t * 0x1.200000p3f))));
  l_slope = coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_detail.x, l_detail.y), 0x1.666666p-1f), l_ring);
  l_n = coax_p_wg_normalize3(cx, coax_p_v3(cx, (-l_slope.x), 0x1.000000p0f, (-l_slope.y)));
  l_deep = ((l_part == 2u) ? 0x1.666666p0f : 0x1.333334p0f);
  return coax_p_eg_water_painted_teal(cx, l_world, l_rest, l_flow, (l_i.y.w * l_deep), (l_i.w.w * 0x1.000000p1f), l_i.w.x, l_n, l_v, l_footprint, 0x1.b33334p-1f, l_paint_leaf_far, p_wake_foam);
}
float3 coax_p_eg_water_gerstner_slope(CoaxResources cx, float2 p_p0, float p_depth, float p_scale) {
  float2 l_p0 = p_p0;
  float l_depth = p_depth;
  float l_scale = p_scale;
  float3 l_g{};
  int l_count{};
  float l_gain{};
  int l_i{};
  float4 l_a{};
  float4 l_c{};
  float l_k{};
  float l_wa{};
  float l_theta{};
  float l_co{};
  l_g = coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  l_count = coax_p_wg_i32_f(cx, cx.r_u[1051]);
  l_gain = (cx.r_u[1061] * l_scale);
  {
    l_i = 0;
    while ((l_i < 8))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_a = coax_p_wg_at4(cx, ((int((l_i * 2)) * 4) + 760));
      l_c = coax_p_wg_at4(cx, ((int(((l_i * 2) + 1)) * 4) + 760));
      l_k = l_a.z;
      l_wa = (((l_k * l_a.w) * l_gain) * coax_p_eg_water_shoal(cx, l_k, l_depth));
      l_theta = ((l_k * coax_p_wg_dot2(cx, coax_p_v2(cx, l_a.x, l_a.y), l_p0)) + l_c.y);
      l_co = cos(l_theta);
      l_g.x = (l_g.x + ((l_a.x * l_wa) * l_co));
      l_g.y = (l_g.y + ((l_a.y * l_wa) * l_co));
      l_g.z = (l_g.z + ((l_c.x * l_wa) * sin(l_theta)));
      l_i = (l_i + 1);
    }
  }
  return l_g;
}
float3 coax_p_eg_water_flow_detail(CoaxResources cx, float2 p_p, float2 p_flow, float p_footprint) {
  float2 l_p = p_p;
  float2 l_flow = p_flow;
  float l_footprint = p_footprint;
  float l_t{};
  float l_phase_a{};
  float l_phase_b{};
  float3 l_da{};
  float3 l_db{};
  float l_wa{};
  if ((coax_p_wg_length2(cx, l_flow) <= 0x1.47ae14p-6f))
  {
    return coax_p_eg_water_detail_waves(cx, l_p, l_footprint, 0x1.000000p0f);
  }
  l_t = cx.r_u[1048];
  l_phase_a = coax_p_fract(cx, (l_t / 0x1.99999ap0f));
  l_phase_b = coax_p_fract(cx, ((l_t / 0x1.99999ap0f) + 0x1.000000p-1f));
  l_da = coax_p_eg_water_detail_waves(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_flow, l_phase_a), 0x1.99999ap0f)), l_footprint, 0x1.666666p0f);
  l_db = coax_p_eg_water_detail_waves(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_flow, l_phase_b), 0x1.99999ap0f)), coax_p_v2(cx, 0x1.d9999ap1f, 0x1.4cccccp0f)), l_footprint, 0x1.666666p0f);
  l_wa = (0x1.000000p0f - abs(((0x1.000000p1f * l_phase_a) - 0x1.000000p0f)));
  return coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_da, l_wa), coax_p_wg_mul_f3f(cx, l_db, (0x1.000000p0f - l_wa)));
}
float2 coax_p_eg_water_ripples(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam) {
  float2 l_p = p_p;
  float2 l_g{};
  float l_t{};
  int l_count{};
  float l_k{};
  int l_i{};
  float4 l_r{};
  float l_age{};
  float2 l_to{};
  float l_dist{};
  float l_x{};
  float l_envelope{};
  l_g = coax_p_eg_water_wake(cx, l_p, p_wake_foam);
  l_t = cx.r_u[1048];
  l_count = coax_p_wg_i32_f(cx, cx.r_u[1050]);
  l_k = (0x1.921fb6p2f / 0x1.ccccccp-2f);
  {
    l_i = 0;
    while ((l_i < 24))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_r = coax_p_wg_at4(cx, ((int(l_i) * 4) + 952));
      l_age = (l_t - l_r.z);
      l_to = coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_r.x, l_r.y));
      l_dist = coax_p_wg_length2(cx, l_to);
      l_x = (l_dist - (0x1.19999ap0f * l_age));
      l_envelope = ((exp((((-l_x) * l_x) / 0x1.70a3d8p-3f)) * exp(((-l_age) * 0x1.19999ap0f))) / (0x1.000000p0f + (0x1.800000p0f * l_dist)));
      l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, l_to, coax_p_fmax(cx, l_dist, 0x1.0624dep-10f)), (((l_r.w * l_envelope) * l_k) * cos((l_k * l_x)))));
      l_i = (l_i + 1);
    }
  }
  return l_g;
}
float2 coax_p_eg_weather_rain_slope(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  float l_rain{};
  float l_cell{};
  float2 l_base{};
  float l_t{};
  float2 l_g{};
  int l_j{};
  int l_i{};
  float2 l_c{};
  float l_h{};
  float l_clock{};
  float l_phase{};
  float l_turn{};
  float2 l_at{};
  float2 l_to{};
  float l_dist{};
  float l_x{};
  float l_env{};
  l_rain = cx.r_u[1472];
  if ((l_rain <= 0x1.47ae14p-7f))
  {
    return coax_p_v2(cx, 0.0f, 0.0f);
  }
  l_cell = 0x1.19999ap-1f;
  l_base = coax_p_wg_floor_f2(cx, coax_p_wg_div_f2f(cx, l_p, l_cell));
  l_t = cx.r_u[1048];
  l_g = coax_p_v2(cx, 0.0f, 0.0f);
  {
    l_j = (-1);
    while ((l_j <= 1))
    {
      {
        l_i = (-1);
        while ((l_i <= 1))
        {
          l_c = coax_p_wg_add_f2f2(cx, l_base, coax_p_v2(cx, float(l_i), float(l_j)));
          l_h = coax_p_eg_weather_hash(cx, l_c);
          if ((l_h > (0x1.000000p-2f + (0x1.800000p-1f * l_rain))))
          {
            {
              l_i = (l_i + 1);
              continue;
            }
          }
          l_clock = ((l_t / 0x1.666666p-1f) + (l_h * 0x1.c851ecp2f));
          l_phase = coax_p_fract(cx, l_clock);
          l_turn = floor(l_clock);
          l_at = coax_p_wg_mul_f2f(cx, coax_p_wg_add_f2f2(cx, l_c, coax_p_v2(cx, coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, l_c, (l_turn * 0x1.5eb852p0f))), coax_p_eg_weather_hash(cx, coax_p_wg_add_f2f(cx, coax_p_wg_add_f2f(cx, l_c, 0x1.533334p2f), (l_turn * 0x1.0e147ap1f))))), l_cell);
          l_to = coax_p_wg_sub_f2f2(cx, l_p, l_at);
          l_dist = coax_p_wg_length2(cx, l_to);
          l_x = (l_dist - (l_phase * 0x1.333334p-2f));
          l_env = ((exp((((-l_x) * l_x) / 0x1.a36e2ep-10f)) * (0x1.000000p0f - l_phase)) * (0x1.000000p0f - l_phase));
          l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_div_f2f(cx, l_to, coax_p_fmax(cx, l_dist, 0x1.0624dep-10f)), l_env), cos((l_x * 0x1.b80000p5f))), 0x1.666666p0f));
          l_i = (l_i + 1);
        }
      }
      l_j = (l_j + 1);
    }
  }
  return coax_p_wg_mul_f2f(cx, l_g, l_rain);
}
coax_t20 coax_p_eg_water_below(CoaxResources cx, float3 p_n, float3 p_v, float p_path, float p_slope) {
  float3 l_n = p_n;
  float3 l_v = p_v;
  float l_path = p_path;
  float l_slope = p_slope;
  coax_t20 l_o{};
  float l_ci{};
  float l_st2{};
  float l_reflectance{};
  float3 l_fog{};
  float l_shimmer{};
  float3 l_trans{};
  l_o = coax_t20{};
  l_ci = coax_p_clampf(cx, coax_p_wg_dot3(cx, l_v, coax_p_wg_neg_f3(cx, l_n)), 0.0f, 0x1.000000p0f);
  l_st2 = ((0x1.547ae2p0f * 0x1.547ae2p0f) * (0x1.000000p0f - (l_ci * l_ci)));
  l_reflectance = 0x1.000000p0f;
  if ((l_st2 < 0x1.000000p0f))
  {
    l_reflectance = coax_p_eg_water_fresnel(cx, sqrt((0x1.000000p0f - l_st2)));
  }
  l_fog = coax_p_wg_mul_f3f(cx, coax_p_eg_water_inscatter(cx), 0x1.333334p1f);
  l_shimmer = (0x1.19999ap0f + (0x1.99999ap0f * coax_p_clampf(cx, l_slope, 0.0f, 0x1.333334p-1f)));
  l_trans = coax_p_wg_exp_f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_v3(cx, cx.r_u[1052], cx.r_u[1053], cx.r_u[1054])), l_path));
  l_o.x = coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_fog, l_shimmer), l_reflectance), l_trans), coax_p_wg_mul_f3f3(cx, l_fog, coax_p_wg_sub_f3f3(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.000000p0f, 0x1.000000p0f), l_trans)));
  l_o.y = coax_p_wg_mul_f3f(cx, l_trans, (0x1.000000p0f - l_reflectance));
  return l_o;
}
coax_t20 coax_p_eg_water_painted(CoaxResources cx, float3 p_world, float2 p_rest, float2 p_flow, float p_depth, float p_shore, float p_white, float3 p_n, float3 p_v, float p_footprint, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  float3 l_world = p_world;
  float2 l_rest = p_rest;
  float2 l_flow = p_flow;
  float l_depth = p_depth;
  float l_shore = p_shore;
  float l_white = p_white;
  float3 l_n = p_n;
  float3 l_v = p_v;
  float l_footprint = p_footprint;
  bool l_paint_leaf_far = p_paint_leaf_far;
  return coax_p_eg_water_painted_teal(cx, l_world, l_rest, l_flow, l_depth, l_shore, l_white, l_n, l_v, l_footprint, 0.0f, l_paint_leaf_far, p_wake_foam);
}
float coax_p_wg_dot3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return dot(l_a, l_b);
}
float coax_p_eg_water_fresnel(CoaxResources cx, float p_c) {
  float l_c = p_c;
  float l_m{};
  float l_m2{};
  l_m = coax_p_clampf(cx, (0x1.000000p0f - l_c), 0.0f, 0x1.000000p0f);
  l_m2 = (l_m * l_m);
  return (0x1.48a6cep-6f + ((((0x1.000000p0f - 0x1.48a6cep-6f) * l_m2) * l_m2) * l_m));
}
float coax_p_eg_water_sky_roughness(CoaxResources cx, float p_roughness, float p_footprint) {
  float l_roughness = p_roughness;
  float l_footprint = p_footprint;
  return coax_p_clampf(cx, (sqrt(l_roughness) + (0x1.333334p-3f * coax_p_wg_log2(cx, (0x1.000000p0f + (l_footprint * 0x1.000000p2f))))), 0.0f, 0x1.000000p0f);
}
float3 coax_p_eg_water_host_sky(CoaxResources cx, float3 p_dir, float p_level) {
  float3 l_dir = p_dir;
  float l_level = p_level;
  float3 l_l{};
  float3 l_d{};
  float3 l_sharp{};
  float3 l_blurred{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_d = coax_p_wg_normalize3(cx, coax_p_v3(cx, l_dir.x, coax_p_fmax(cx, l_dir.y, 0.0f), l_dir.z));
  l_sharp = coax_p_wg_mix_f3f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u)), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 12u)), coax_p_verse_style_sky_t(cx, l_d.y));
  l_blurred = coax_p_wg_mix_f3f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 10u)), coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 12u)), 0x1.19999ap-1f);
  return coax_p_wg_add_f3f3(cx, coax_p_wg_mix_f3f3f(cx, l_sharp, l_blurred, (l_level * l_level)), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, (((coax_p_eg_st(cx, 1u)).w > 0x1.000000p-1f) ? coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)) : coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 11u))), coax_p_verse_style_halo(cx, coax_p_wg_dot3(cx, l_d, l_l), (coax_p_eg_st(cx, 14u)).z)), 0x1.000000p-2f));
}
float4 coax_p_eg_water_host_sun(CoaxResources cx) {
  return coax_p_wg_make_f4_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u)), (((coax_p_eg_st(cx, 0u)).w <= 0.0f) ? 0.0f : 0x1.000000p0f));
}
float3 coax_p_wg_sw_xyz_f4(CoaxResources cx, float4 p_p) {
  float4 l_p = p_p;
  return coax_p_v3(cx, l_p.x, l_p.y, l_p.z);
}
float3 coax_p_eg_water_host_sun_light(CoaxResources cx) {
  return coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 0u)), (coax_p_eg_st(cx, 0u)).w), 0x1.69e83ep1f);
}
float coax_p_eg_water_glint(CoaxResources cx, float3 p_n, float3 p_v, float3 p_l, float p_roughness, float p_disc, float p_distance) {
  float3 l_n = p_n;
  float3 l_v = p_v;
  float3 l_l = p_l;
  float l_roughness = p_roughness;
  float l_disc = p_disc;
  float l_distance = p_distance;
  float l_nol{};
  float l_nov{};
  float3 l_h{};
  float l_fade_at{};
  float l_far{};
  float l_a{};
  float l_a2{};
  float l_spec{};
  l_nol = coax_p_wg_dot3(cx, l_n, l_l);
  l_nov = coax_p_fmax(cx, coax_p_wg_dot3(cx, l_n, l_v), 0x1.0624dep-10f);
  if ((l_nol <= 0.0f))
  {
    return 0.0f;
  }
  l_h = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_l, l_v));
  l_fade_at = coax_p_fmax(cx, cx.r_u[1069], 0x1.000000p0f);
  l_far = coax_p_smoothstep(cx, (0x1.99999ap-2f * l_fade_at), l_fade_at, l_distance);
  l_a = coax_p_fmin(cx, (((l_roughness * l_roughness) + (l_disc * 0x1.000000p-1f)) + (l_far * 0x1.47ae14p-4f)), 0x1.000000p0f);
  l_a2 = (l_a * l_a);
  l_spec = ((coax_p_eg_water_ggx(cx, coax_p_fmax(cx, coax_p_wg_dot3(cx, l_n, l_h), 0.0f), l_a2) * coax_p_eg_water_smith(cx, l_nov, l_nol, l_a2)) * coax_p_eg_water_fresnel(cx, coax_p_fmax(cx, coax_p_wg_dot3(cx, l_v, l_h), 0.0f)));
  return ((l_spec * l_nol) * (0x1.000000p0f - (0x1.800000p-1f * l_far)));
}
float3 coax_p_eg_water_crest_scatter(CoaxResources cx, float3 p_v, float3 p_l, float3 p_n, float p_height, float p_squeeze) {
  float3 l_v = p_v;
  float3 l_l = p_l;
  float3 l_n = p_n;
  float l_height = p_height;
  float l_squeeze = p_squeeze;
  float l_strength{};
  float l_g{};
  float l_cos_theta{};
  float l_hg{};
  float l_thin{};
  float l_side{};
  float3 l_through{};
  l_strength = cx.r_u[1063];
  if ((l_strength <= 0.0f))
  {
    return coax_p_v3(cx, 0.0f, 0.0f, 0.0f);
  }
  l_g = 0x1.333334p-1f;
  l_cos_theta = coax_p_wg_dot3(cx, coax_p_wg_neg_f3(cx, l_l), l_v);
  l_hg = ((0x1.000000p0f - (l_g * l_g)) / ((0x1.000000p2f * 0x1.921fb6p1f) * coax_metal_pow(((0x1.000000p0f + (l_g * l_g)) - ((0x1.000000p1f * l_g) * l_cos_theta)), 0x1.800000p0f)));
  l_thin = (coax_p_clampf(cx, (l_height * 0x1.000000p1f), 0.0f, 0x1.000000p0f) * coax_p_clampf(cx, ((l_squeeze * 0x1.800000p0f) + 0x1.99999ap-3f), 0.0f, 0x1.000000p0f));
  l_side = coax_p_clampf(cx, ((0x1.000000p0f - (l_n.y * 0x1.333334p-1f)) + (coax_p_wg_dot3(cx, l_n, l_v) * 0x1.99999ap-2f)), 0.0f, 0x1.000000p0f);
  l_through = coax_p_wg_exp_f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_v3(cx, cx.r_u[1052], cx.r_u[1053], cx.r_u[1054])), (0x1.000000p0f - (0x1.333334p-1f * l_thin))));
  return coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, cx.r_u[1056], cx.r_u[1057], cx.r_u[1058]), l_through), l_hg), l_thin), l_side), l_strength), 0x1.800000p3f);
}
float coax_p_eg_water_foam_noise(CoaxResources cx, float2 p_p, float2 p_flow) {
  float2 l_p = p_p;
  float2 l_flow = p_flow;
  float l_t{};
  float l_phase_a{};
  float l_phase_b{};
  float l_wa{};
  float2 l_pa{};
  float2 l_pb{};
  float l_a{};
  float l_b{};
  l_t = cx.r_u[1048];
  l_phase_a = coax_p_fract(cx, (l_t / 0x1.99999ap0f));
  l_phase_b = coax_p_fract(cx, ((l_t / 0x1.99999ap0f) + 0x1.000000p-1f));
  l_wa = (0x1.000000p0f - abs(((0x1.000000p1f * l_phase_a) - 0x1.000000p0f)));
  l_pa = coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_flow, l_phase_a), 0x1.99999ap0f));
  l_pb = coax_p_wg_add_f2f2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_flow, l_phase_b), 0x1.99999ap0f)), coax_p_v2(cx, 0x1.533334p2f, 0x1.733334p1f));
  l_a = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_pa, 0x1.4cccccp0f), (l_t * 0x1.000000p-2f)));
  l_b = coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_pb, 0x1.4cccccp0f), (l_t * 0x1.000000p-2f)));
  if ((cx.r_u[1070] > 0x1.800000p0f))
  {
    l_a = ((l_a * 0x1.333334p-1f) + (0x1.99999ap-2f * coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_pa, 0x1.066666p2f), coax_p_v2(cx, (l_t * 0x1.1eb852p-4f), 0.0f)), (l_t * 0x1.000000p-1f)))));
    l_b = ((l_b * 0x1.333334p-1f) + (0x1.99999ap-2f * coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_mul_f2f(cx, l_pb, 0x1.066666p2f), coax_p_v2(cx, (l_t * 0x1.1eb852p-4f), 0.0f)), (l_t * 0x1.000000p-1f)))));
  }
  return ((l_a * l_wa) + (l_b * (0x1.000000p0f - l_wa)));
}
float coax_p_eg_water_foam(CoaxResources cx, float2 p_rest, float p_shore, float p_crest, float p_extra, float p_noise, thread array<float, 1>* p_wake_foam) {
  float2 l_rest = p_rest;
  float l_shore = p_shore;
  float l_crest = p_crest;
  float l_extra = p_extra;
  float l_noise = p_noise;
  float l_band{};
  float l_foam{};
  l_band = coax_p_fmax(cx, cx.r_u[1064], 0x1.99999ap-5f);
  l_foam = ((0x1.000000p0f - coax_p_smoothstep(cx, 0.0f, l_band, l_shore)) * coax_p_smoothstep(cx, 0x1.333334p-2f, 0x1.3d70a4p-1f, (l_noise + (0x1.333334p-3f * (0x1.000000p0f - (l_shore / l_band))))));
  l_foam = coax_p_fmax(cx, l_foam, (coax_p_smoothstep(cx, 0x1.3d70a4p-1f, 0x1.e66666p-1f, l_crest) * coax_p_smoothstep(cx, 0x1.666666p-2f, 0x1.666666p-1f, l_noise)));
  l_foam = coax_p_fmax(cx, l_foam, (coax_p_clampf(cx, l_extra, 0.0f, 0x1.000000p0f) * coax_p_smoothstep(cx, 0x1.000000p-2f, 0x1.4cccccp-1f, (l_noise + (0x1.000000p-2f * l_extra)))));
  l_foam = coax_p_fmax(cx, l_foam, (coax_p_eg_water_ripple_foam(cx, l_rest, p_wake_foam) * coax_p_smoothstep(cx, 0x1.99999ap-3f, 0x1.333334p-1f, l_noise)));
  return coax_p_clampf(cx, (l_foam * cx.r_u[1059]), 0.0f, 0x1.000000p0f);
}
float3 coax_p_eg_water_transmittance(CoaxResources cx, float p_depth, float p_ci) {
  float l_depth = p_depth;
  float l_ci = p_ci;
  float l_path{};
  l_path = (coax_p_fmax(cx, l_depth, 0.0f) / coax_p_fmax(cx, coax_p_eg_water_cos_refracted(cx, l_ci), 0x1.99999ap-5f));
  return coax_p_wg_exp_f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_neg_f3(cx, coax_p_v3(cx, cx.r_u[1052], cx.r_u[1053], cx.r_u[1054])), l_path));
}
float3 coax_p_eg_water_inscatter(CoaxResources cx) {
  float4 l_sun{};
  float3 l_sky{};
  float3 l_lit{};
  l_sun = coax_p_eg_water_host_sun(cx);
  l_sky = coax_p_eg_water_host_sky(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), 0x1.000000p0f);
  l_lit = coax_p_wg_mul_f3f(cx, coax_p_eg_water_host_sun_light(cx), ((l_sun.w * coax_p_fmax(cx, l_sun.y, 0.0f)) / 0x1.921fb6p1f));
  return coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, cx.r_u[1056], cx.r_u[1057], cx.r_u[1058]), coax_p_wg_add_f3f3(cx, l_lit, l_sky));
}
float coax_p_verse_style_haze_hue(CoaxResources cx, float p_h, float p_ch, float p_f, float p_cap) {
  float l_h = p_h;
  float l_ch = p_ch;
  float l_f = p_f;
  float l_cap = p_cap;
  float l_t{};
  float l_far{};
  l_t = coax_p_verse_style_haze_teal(cx, l_ch);
  l_far = coax_p_verse_style_soft_step(cx, ((0x1.333334p-3f + l_cap) * 0x1.000000p-1f), ((l_cap - 0x1.333334p-3f) * 0x1.000000p-1f), l_f);
  return (l_h * (l_t + ((0x1.000000p0f - l_t) * l_far)));
}
float3 coax_p_eg_meadow_srgb(CoaxResources cx, float p_t) {
  float l_t = p_t;
  return coax_p_wg_mix_f3f3f(cx, coax_p_EG_MEADOW_COOL(cx), coax_p_EG_MEADOW_WARM(cx), l_t);
}
float coax_p_verse_style_haze_glow(CoaxResources cx, float p_vdl) {
  float l_vdl = p_vdl;
  float l_a{};
  float l_a2{};
  float l_a4{};
  l_a = coax_p_st_sat(cx, l_vdl);
  l_a2 = (l_a * l_a);
  l_a4 = (l_a2 * l_a2);
  return ((l_a4 * l_a4) * 0x1.ccccccp-2f);
}
float coax_p_length3(CoaxResources cx, float3 p_a) {
  float3 l_a = p_a;
  return sqrt(dot(l_a, l_a));
}
float3 coax_p_scale3(CoaxResources cx, float3 p_a, float p_k) {
  float3 l_a = p_a;
  float l_k = p_k;
  return float3((l_a.x * l_k), (l_a.y * l_k), (l_a.z * l_k));
}
float coax_p_fract(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (l_x - floor(l_x));
}
int coax_p_wg_clamp_i(CoaxResources cx, int p_x, int p_low, int p_high) {
  int l_x = p_x;
  int l_low = p_low;
  int l_high = p_high;
  return coax_p_wg_min_i(cx, coax_p_wg_max_i(cx, l_x, l_low), l_high);
}
float coax_p_wg_fmod(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  return (l_a - (l_b * coax_p_wg_trunc(cx, (l_a / l_b))));
}
float3 coax_p_sub3(CoaxResources cx, float3 p_a, float3 p_b) {
  float3 l_a = p_a;
  float3 l_b = p_b;
  return float3((l_a.x - l_b.x), (l_a.y - l_b.y), (l_a.z - l_b.z));
}
float coax_p_st_max(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a > l_b))
  {
    return l_a;
  }
  return l_b;
}
float coax_p_st_min(CoaxResources cx, float p_a, float p_b) {
  float l_a = p_a;
  float l_b = p_b;
  if ((l_a < l_b))
  {
    return l_a;
  }
  return l_b;
}
coax_t23 coax_p_wg_cvt_i3f3(CoaxResources cx, float3 p_p) {
  float3 l_p = p_p;
  return coax_p_i3(cx, coax_p_wg_i32_f(cx, l_p.x), coax_p_wg_i32_f(cx, l_p.y), coax_p_wg_i32_f(cx, l_p.z));
}
coax_t22 coax_p_wg_bits_u3i3(CoaxResources cx, coax_t23 p_p) {
  coax_t23 l_p = p_p;
  return coax_p_u3(cx, uint(l_p.x), uint(l_p.y), uint(l_p.z));
}
coax_t22 coax_p_wg_mul_u3u(CoaxResources cx, coax_t22 p_a, uint p_b) {
  coax_t22 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x * l_b), (l_a.y * l_b), (l_a.z * l_b));
}
coax_t22 coax_p_wg_add_u3u(CoaxResources cx, coax_t22 p_a, uint p_b) {
  coax_t22 l_a = p_a;
  uint l_b = p_b;
  return coax_p_u3(cx, (l_a.x + l_b), (l_a.y + l_b), (l_a.z + l_b));
}
coax_t22 coax_p_u3(CoaxResources cx, uint p_x, uint p_y, uint p_z) {
  uint l_x = p_x;
  uint l_y = p_y;
  uint l_z = p_z;
  return coax_t22{l_x, l_y, l_z};
}
coax_t22 coax_p_wg_shr_u3u3(CoaxResources cx, coax_t22 p_a, coax_t22 p_b) {
  coax_t22 l_a = p_a;
  coax_t22 l_b = p_b;
  return coax_p_u3(cx, (l_a.x >> uint(l_b.x)), (l_a.y >> uint(l_b.y)), (l_a.z >> uint(l_b.z)));
}
coax_t22 coax_p_wg_xor_u3u3(CoaxResources cx, coax_t22 p_a, coax_t22 p_b) {
  coax_t22 l_a = p_a;
  coax_t22 l_b = p_b;
  return coax_p_u3(cx, (l_a.x ^ l_b.x), (l_a.y ^ l_b.y), (l_a.z ^ l_b.z));
}
float coax_p_eg_shade_shadows_at(CoaxResources cx, float2 p_p, float p_y, bool p_level) {
  float2 l_p = p_p;
  float l_y = p_y;
  bool l_level = p_level;
  float l_s{};
  int l_i{};
  float4 l_b{};
  float l_cm{};
  float l_strength{};
  float l_d{};
  l_s = 0x1.000000p0f;
  {
    l_i = 0;
    while ((l_i < 16))
    {
      l_b = coax_p_wg_at4(cx, ((int(l_i) * 4) + 36));
      if ((l_b.z <= 0.0f))
      {
        break;
      }
      l_cm = floor((l_b.w * 0x1.000000p-1f));
      l_strength = (l_b.w - (l_cm * 0x1.000000p1f));
      if ((l_level && (abs((l_y - ((l_cm * 0x1.47ae14p-7f) - 0x1.900000p6f))) > 0x1.666666p-2f)))
      {
        {
          l_i = (l_i + 1);
          continue;
        }
      }
      l_d = (coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_b.x, l_b.y))) / l_b.z);
      l_s = (l_s * (0x1.000000p0f - (l_strength * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.666666p-2f, 0x1.000000p0f, l_d)))));
      l_i = (l_i + 1);
    }
  }
  return l_s;
}
float coax_p_verse_style_ambient(CoaxResources cx, float p_ny, float p_sky, float p_ground, float p_scale) {
  float l_ny = p_ny;
  float l_sky = p_sky;
  float l_ground = p_ground;
  float l_scale = p_scale;
  return ((l_ground + ((l_sky - l_ground) * coax_p_st_sat(cx, ((l_ny * 0x1.000000p-1f) + 0x1.000000p-1f)))) * l_scale);
}
float coax_p_eg_map_lit(CoaxResources cx, float3 p_p, float3 p_n, bool p_paint_leaf_far) {
  float3 l_p = p_p;
  float3 l_n = p_n;
  bool l_paint_leaf_far = p_paint_leaf_far;
  float3 l_q{};
  float2 l_uv{};
  float l_texel_2{};
  float l_phone{};
  float l_taps{};
  float l_r{};
  float l_lit{};
  float l_k{};
  float2 l_o{};
  bool l_inside{};
  if (((coax_p_eg_st(cx, 21u)).x < 0x1.000000p0f))
  {
    return 0x1.000000p0f;
  }
  l_q = coax_p_eg_shadow_place(cx, coax_p_wg_add_f3f3(cx, l_p, coax_p_wg_mul_f3f(cx, l_n, 0x1.47ae14p-4f)), coax_p_eg_light_space(cx));
  l_uv = coax_p_v2(cx, (0x1.000000p-1f + (0x1.000000p-1f * l_q.x)), (0x1.000000p-1f - (0x1.000000p-1f * l_q.y)));
  l_texel_2 = (0x1.000000p0f / float((coax_p_wg_dims_depth_1(cx)).x));
  l_phone = (coax_p_eg_st(cx, 31u)).z;
  l_taps = (l_paint_leaf_far ? 0x1.000000p0f : (coax_p_eg_st(cx, 21u)).y);
  l_r = (coax_p_eg_st(cx, 21u)).z;
  l_lit = 0.0f;
  {
    l_k = 0.0f;
    while ((l_k < 0x1.200000p3f))
    {
      if ((l_k >= l_taps))
      {
        break;
      }
      l_o = coax_p_v2(cx, coax_p_verse_style_shadow_tap(cx, l_k, l_phone, 0.0f), coax_p_verse_style_shadow_tap(cx, l_k, l_phone, 0x1.000000p0f));
      l_lit = (l_lit + (cx.r_shadow_map).sample_compare(cx.r_shadow_cmp, coax_p_wg_add_f2f2(cx, l_uv, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_o, l_r), 0x1.99999ap0f), l_texel_2)), (l_q.z - 0x1.3a92a4p-11f), level(0.0f)));
      l_k = (l_k + 0x1.000000p0f);
    }
  }
  l_inside = (coax_p_wg_all_gt_f2f2(cx, l_uv, coax_p_v2(cx, 0.0f, 0.0f)) && coax_p_wg_all_lt_f2f2(cx, l_uv, coax_p_v2(cx, 0x1.000000p0f, 0x1.000000p0f)));
  return (l_inside ? coax_p_smoothstep(cx, 0x1.99999ap-4f, 0x1.800000p-1f, (l_lit / coax_p_fmax(cx, l_taps, 0x1.000000p0f))) : 0x1.000000p0f);
}
float3 coax_p_EG_W_SHALLOW(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.333334p-2f, 0x1.70a3d8p-1f, 0x1.7ae148p-1f);
}
float3 coax_p_wg_pow_f3f3(CoaxResources cx, float3 p_p0, float3 p_p1) {
  float3 l_p0 = p_p0;
  float3 l_p1 = p_p1;
  return coax_p_v3(cx, coax_metal_pow(l_p0.x, l_p1.x), coax_metal_pow(l_p0.y, l_p1.y), coax_metal_pow(l_p0.z, l_p1.z));
}
float3 coax_p_wg_make_f3_f(CoaxResources cx, float p_p0) {
  float l_p0 = p_p0;
  return coax_p_v3(cx, l_p0, l_p0, l_p0);
}
float2 coax_p_wg_make_f2_f(CoaxResources cx, float p_p0) {
  float l_p0 = p_p0;
  return coax_p_v2(cx, l_p0, l_p0);
}
float coax_p_wg_atan2(CoaxResources cx, float p_y, float p_x) {
  float l_y = p_y;
  float l_x = p_x;
  float l_ax{};
  float l_ay{};
  float l_high{};
  float l_r{};
  l_ax = abs(l_x);
  l_ay = abs(l_y);
  l_high = coax_p_fmax(cx, l_ax, l_ay);
  if ((l_high == 0.0f))
  {
    return 0.0f;
  }
  l_r = coax_p_wg_atan01(cx, (coax_p_fmin(cx, l_ax, l_ay) / l_high));
  if ((l_ay > l_ax))
  {
    l_r = ((0x1.921fb6p1f * 0x1.000000p-1f) - l_r);
  }
  if ((l_x < 0.0f))
  {
    l_r = (0x1.921fb6p1f - l_r);
  }
  if ((l_y < 0.0f))
  {
    l_r = (-l_r);
  }
  return l_r;
}
coax_t20 coax_p_eg_water_painted_teal(CoaxResources cx, float3 p_world, float2 p_rest, float2 p_flow, float p_depth, float p_shore, float p_white, float3 p_n, float3 p_v, float p_footprint, float p_teal, bool p_paint_leaf_far, thread array<float, 1>* p_wake_foam) {
  float3 l_world = p_world;
  float2 l_rest = p_rest;
  float2 l_flow = p_flow;
  float l_depth = p_depth;
  float l_shore = p_shore;
  float l_white = p_white;
  float3 l_n = p_n;
  float3 l_v = p_v;
  float l_footprint = p_footprint;
  float l_teal = p_teal;
  bool l_paint_leaf_far = p_paint_leaf_far;
  coax_t20 l_o{};
  float3 l_l{};
  float3 l_band{};
  float l_sh{};
  float3 l_light{};
  float3 l_body{};
  float3 l_calm{};
  float l_fresnel{};
  float3 l_refl{};
  float l_grid{};
  float2 l_cell{};
  float2 l_jitter{};
  float3 l_tilt{};
  float l_rdl{};
  float l_twinkle{};
  float2 l_centre{};
  float l_dot_{};
  float l_sparkle{};
  float l_line{};
  float l_broken{};
  float l_churn{};
  float l_noise{};
  float l_rings{};
  float l_speed{};
  float l_streak{};
  float2 l_along{};
  float2 l_q{};
  float l_ridge{};
  float l_broken_by{};
  float l_foam{};
  float l_alpha{};
  float l_edge{};
  float3 l_foam_rgb{};
  float3 l_emit{};
  l_o = coax_t20{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_water_host_sun(cx));
  l_band = coax_p_wg_mix_f3f3f(cx, coax_p_wg_mix_f3f3f(cx, coax_p_wg_mix_f3f3f(cx, coax_p_EG_W_SHALLOW(cx), coax_p_EG_W_MID(cx), coax_p_eg_water_paint_ramp(cx, 0x1.99999ap-2f, l_depth)), coax_p_EG_W_DEEP(cx), coax_p_eg_water_paint_ramp(cx, 0x1.800000p0f, l_depth)), coax_p_EG_W_TEAL(cx), l_teal);
  l_sh = coax_p_eg_shade_shadows(cx, coax_p_v2(cx, l_world.x, l_world.z));
  l_light = coax_p_eg_water_host_light_shaded(cx, l_world, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_sh, l_paint_leaf_far);
  l_body = coax_p_wg_mul_f3f3(cx, coax_p_wg_pow_f3f3(cx, l_band, coax_p_v3(cx, 0x1.19999ap1f, 0x1.19999ap1f, 0x1.19999ap1f)), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.a3d70ap-1f), coax_p_v3(cx, 0x1.99999ap-5f, 0x1.99999ap-5f, 0x1.99999ap-5f)));
  l_calm = coax_p_wg_normalize3(cx, coax_p_wg_mix_f3f3f(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_n, 0x1.666666p-2f));
  l_fresnel = coax_p_fmin(cx, coax_p_eg_water_fresnel(cx, coax_p_fmax(cx, coax_p_wg_dot3(cx, l_calm, l_v), 0x1.0624dep-10f)), (0x1.000000p-1f - (0x1.99999ap-3f * l_teal)));
  l_refl = coax_p_eg_water_host_sky(cx, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_v), l_calm), 0.0f);
  l_grid = ((cx.r_u[1068] < 0x1.000000p3f) ? 0x1.000000p-2f : 0x1.333334p-3f);
  l_cell = coax_p_wg_floor_f2(cx, coax_p_wg_div_f2f(cx, l_rest, l_grid));
  l_jitter = coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, coax_p_eg_water_hash(cx, coax_p_v3(cx, l_cell.x, l_cell.y, 0x1.000000p0f)), coax_p_eg_water_hash(cx, coax_p_v3(cx, l_cell.x, l_cell.y, 0x1.000000p1f))), coax_p_v2(cx, 0x1.000000p-1f, 0x1.000000p-1f));
  l_tilt = coax_p_wg_normalize3(cx, coax_p_wg_add_f3f3(cx, l_n, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, l_jitter.x, 0.0f, l_jitter.y), 0x1.666666p-2f)));
  l_rdl = coax_p_wg_dot3(cx, coax_p_wg_reflect3(cx, coax_p_wg_neg_f3(cx, l_v), l_tilt), l_l);
  l_twinkle = (0x1.000000p-1f + (0x1.000000p-1f * sin((((cx.r_u[2] * (0x1.000000p0f - cx.r_u[4])) * 0x1.500000p4f) + (coax_p_eg_water_hash(cx, coax_p_v3(cx, l_cell.x, l_cell.y, 0x1.800000p1f)) * 0x1.91eb86p2f)))));
  l_centre = coax_p_wg_mul_f2f(cx, coax_p_wg_add_f2f2(cx, coax_p_wg_add_f2f2(cx, l_cell, coax_p_v2(cx, 0x1.000000p-1f, 0x1.000000p-1f)), coax_p_wg_mul_f2f(cx, l_jitter, 0x1.000000p-1f)), l_grid);
  l_dot_ = (0x1.000000p0f - coax_p_smoothstep(cx, (l_footprint * 0x1.333334p0f), (l_footprint * 0x1.19999ap1f), coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_rest, l_centre))));
  l_sparkle = ((((coax_p_eg_water_paint_sparkle(cx, l_rdl) * l_twinkle) * l_dot_) * (coax_p_eg_water_host_sun(cx)).w) * l_sh);
  l_line = 0.0f;
  if (((l_shore < 0x1.5c28f6p-2f) && (l_depth > (-0x1.47ae14p-6f))))
  {
    l_broken = ((coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_rest, 0x1.800000p1f), (cx.r_u[2] * 0x1.333334p-2f))) - 0x1.000000p-1f) * 0x1.eb851ep-4f);
    l_line = ((0x1.000000p0f - coax_p_smoothstep(cx, (0x1.5c28f6p-3f + l_broken), (0x1.147ae2p-2f + l_broken), l_shore)) * coax_p_smoothstep(cx, (-0x1.47ae14p-6f), 0x1.47ae14p-5f, l_depth));
  }
  l_churn = 0.0f;
  if ((l_white > 0.0f))
  {
    l_noise = coax_p_eg_water_foam_noise(cx, l_rest, l_flow);
    l_churn = (coax_p_clampf(cx, l_white, 0.0f, 0x1.000000p0f) * coax_p_smoothstep(cx, 0x1.333334p-2f, 0x1.333334p-1f, (l_noise + (0x1.333334p-2f * l_white))));
  }
  l_rings = coax_p_clampf(cx, (coax_p_eg_water_ripple_foam(cx, l_rest, p_wake_foam) * 0x1.99999ap0f), 0.0f, 0x1.000000p0f);
  l_speed = coax_p_wg_length2(cx, l_flow);
  l_streak = 0.0f;
  if ((((l_speed > 0x1.99999ap-5f) && (l_depth > 0x1.99999ap-4f)) && (l_footprint < 0x1.000000p-2f)))
  {
    l_along = coax_p_wg_div_f2f(cx, l_flow, coax_p_fmax(cx, l_speed, 0x1.0624dep-10f));
    l_q = coax_p_v2(cx, (coax_p_wg_dot2(cx, l_rest, coax_p_v2(cx, (-l_along.y), l_along.x)) * 0x1.333334p1f), ((coax_p_wg_dot2(cx, l_rest, l_along) * 0x1.333334p-2f) - ((cx.r_u[1048] * l_speed) * 0x1.333334p-2f)));
    l_ridge = (0x1.000000p0f - abs(((0x1.000000p1f * coax_p_eg_water_noise(cx, coax_p_v3(cx, l_q.x, l_q.y, (cx.r_u[1048] * 0x1.333334p-3f)))) - 0x1.000000p0f)));
    l_broken_by = coax_p_smoothstep(cx, 0x1.99999ap-2f, 0x1.666666p-1f, coax_p_eg_water_noise(cx, coax_p_wg_make_f3_f2f(cx, coax_p_wg_mul_f2f(cx, l_rest, 0x1.333334p-1f), (cx.r_u[1048] * 0x1.99999ap-4f))));
    l_streak = (((((coax_p_smoothstep(cx, 0x1.e66666p-1f, 0x1.fd70a4p-1f, l_ridge) * l_broken_by) * coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.99999ap-2f, l_speed)) * 0x1.666666p-2f) * coax_p_smoothstep(cx, 0x1.99999ap-4f, 0x1.000000p-1f, l_depth)) * (0x1.000000p0f - coax_p_smoothstep(cx, 0x1.47ae14p-4f, 0x1.000000p-2f, l_footprint)));
  }
  l_foam = coax_p_clampf(cx, (coax_p_fmax(cx, coax_p_fmax(cx, l_line, l_churn), l_rings) + l_streak), 0.0f, 0x1.000000p0f);
  l_alpha = (((0x1.000000p-1f + (0x1.99999ap-3f * l_teal)) + (0x1.ae147ap-2f * coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.333334p0f, l_depth))) * coax_p_smoothstep(cx, (-0x1.99999ap-5f), 0x1.99999ap-4f, l_depth));
  l_edge = coax_p_smoothstep(cx, (-0x1.99999ap-5f), 0x1.99999ap-4f, l_depth);
  l_foam_rgb = coax_p_wg_mul_f3f3(cx, coax_p_v3(cx, 0x1.e66666p-1f, 0x1.f0a3d8p-1f, 0x1.eb851ep-1f), coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, l_light, 0x1.ccccccp-1f), coax_p_v3(cx, 0x1.eb851ep-5f, 0x1.eb851ep-5f, 0x1.eb851ep-5f)));
  l_emit = coax_p_wg_add_f3f3(cx, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_body, l_alpha), (0x1.000000p0f - l_fresnel)), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f(cx, l_refl, l_fresnel), l_edge)), coax_p_wg_mul_f3f(cx, coax_p_wg_mul_f3f3(cx, coax_p_wg_mul_f3f(cx, coax_p_v3(cx, 0x1.000000p0f, 0x1.f0a3d8p-1f, 0x1.c28f5cp-1f), l_sparkle), coax_p_eg_water_host_sun_light(cx)), 0x1.333334p0f));
  l_emit = coax_p_wg_mix_f3f3f(cx, l_emit, l_foam_rgb, l_foam);
  l_o.x = l_emit;
  l_o.y = coax_p_wg_make_f3_f(cx, (((0x1.000000p0f - l_alpha) * (0x1.000000p0f - (l_fresnel * l_edge))) * (0x1.000000p0f - l_foam)));
  l_o.z = coax_p_v2(cx, l_n.x, l_n.z);
  l_o.w = coax_p_v4(cx, l_refl.x, l_refl.y, l_refl.z, ((l_fresnel * l_edge) * (0x1.000000p0f - l_foam)));
  return l_o;
}
float3 coax_p_eg_water_detail_waves(CoaxResources cx, float2 p_p, float p_footprint, float p_gain) {
  float2 l_p = p_p;
  float l_footprint = p_footprint;
  float l_gain = p_gain;
  float2 l_g{};
  float l_lost{};
  float l_t{};
  int l_n{};
  int l_i{};
  float4 l_a{};
  float4 l_b{};
  float l_k{};
  float l_slope{};
  float l_keep{};
  float l_theta{};
  l_g = coax_p_v2(cx, 0.0f, 0.0f);
  l_lost = 0.0f;
  l_t = cx.r_u[1048];
  l_n = coax_p_wg_min_i(cx, coax_p_wg_i32_f(cx, cx.r_u[1068]), coax_p_wg_i32_f(cx, cx.r_u[1049]));
  {
    l_i = 0;
    while ((l_i < 16))
    {
      if ((l_i >= l_n))
      {
        break;
      }
      l_a = coax_p_wg_at4(cx, ((int((l_i * 2)) * 4) + 824));
      l_b = coax_p_wg_at4(cx, ((int(((l_i * 2) + 1)) * 4) + 824));
      l_k = l_a.z;
      l_slope = ((l_a.w * l_k) * l_gain);
      l_keep = coax_p_clampf(cx, ((l_b.z / (0x1.800000p2f * coax_p_fmax(cx, l_footprint, 0x1.a36e2ep-14f))) - 0x1.000000p-1f), 0.0f, 0x1.000000p0f);
      l_theta = (((l_k * coax_p_wg_dot2(cx, coax_p_v2(cx, l_a.x, l_a.y), l_p)) - (l_b.x * l_t)) + l_b.y);
      l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_v2(cx, l_a.x, l_a.y), ((l_slope * l_keep) * cos(l_theta))));
      l_lost = (l_lost + (((0x1.000000p-1f * l_slope) * l_slope) * (0x1.000000p0f - (l_keep * l_keep))));
      l_i = (l_i + 1);
    }
  }
  return coax_p_v3(cx, l_g.x, l_g.y, l_lost);
}
float2 coax_p_eg_water_wake(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam) {
  float2 l_p = p_p;
  float2 l_g{};
  float l_t{};
  uint l_m{};
  uint l_base{};
  float4 l_head{};
  float l_behind{};
  float l_best{};
  float4 l_at{};
  float2 l_dir{};
  uint l_k{};
  float4 l_a{};
  float4 l_b{};
  float2 l_seg{};
  float l_len_2{};
  float2 l_d{};
  float l_s{};
  float2 l_off{};
  float l_lat{};
  float l_v{};
  float l_age{};
  float l_fade{};
  float l_side{};
  float2 l_across{};
  float l_l{};
  float l_wave{};
  float l_feather{};
  float l_arm{};
  float l_w{};
  float l_x{};
  float l_amp{};
  float l_inside{};
  float l_trail{};
  l_g = coax_p_v2(cx, 0.0f, 0.0f);
  l_t = cx.r_u[1048];
  {
    l_m = 0u;
    while ((l_m < 2u))
    {
      l_base = (5u + (l_m * 8u));
      l_head = coax_p_wg_at4(cx, ((int(l_base) * 4) + 1500));
      if (((l_head.x == 0.0f) && (l_head.y == 0.0f)))
      {
        {
          l_m = (l_m + 1u);
          continue;
        }
      }
      if (((l_head.w < 0x1.99999ap-5f) && ((l_t - cx.r_u[((int((l_base + 1u)) * 4) + 1502)]) > 0x1.000000p3f)))
      {
        {
          l_m = (l_m + 1u);
          continue;
        }
      }
      if ((coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_head.x, l_head.y))) > 0x1.c00000p3f))
      {
        {
          l_m = (l_m + 1u);
          continue;
        }
      }
      l_behind = 0.0f;
      l_best = 0x1.dcd650p29f;
      l_at = coax_p_v4(cx, 0.0f, 0.0f, 0.0f, 0.0f);
      l_dir = coax_p_v2(cx, 0.0f, 0.0f);
      {
        l_k = 0u;
        while ((l_k < 7u))
        {
          l_a = coax_p_wg_at4(cx, ((int((l_base + l_k)) * 4) + 1500));
          l_b = coax_p_wg_at4(cx, ((int(((l_base + l_k) + 1u)) * 4) + 1500));
          if (((l_b.x == 0.0f) && (l_b.y == 0.0f)))
          {
            break;
          }
          l_seg = coax_p_wg_sub_f2f2(cx, coax_p_v2(cx, l_b.x, l_b.y), coax_p_v2(cx, l_a.x, l_a.y));
          l_len_2 = coax_p_wg_length2(cx, l_seg);
          if ((l_len_2 < 0x1.47ae14p-7f))
          {
            {
              l_k = (l_k + 1u);
              continue;
            }
          }
          l_d = coax_p_wg_div_f2f(cx, l_seg, l_len_2);
          l_s = coax_p_clampf(cx, coax_p_wg_dot2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_a.x, l_a.y)), l_d), 0.0f, l_len_2);
          l_off = coax_p_wg_sub_f2f2(cx, l_p, coax_p_wg_add_f2f2(cx, coax_p_v2(cx, l_a.x, l_a.y), coax_p_wg_mul_f2f(cx, l_d, l_s)));
          l_lat = coax_p_wg_length2(cx, l_off);
          if ((l_lat < l_best))
          {
            l_best = l_lat;
            l_at = coax_p_v4(cx, (l_behind + l_s), ((((l_d.x * l_off.y) - (l_d.y * l_off.x)) > 0.0f) ? l_lat : (-l_lat)), (l_t - coax_p_mix(cx, l_a.z, l_b.z, (l_s / l_len_2))), coax_p_fmax(cx, l_a.w, l_b.w));
            l_dir = l_d;
          }
          l_behind = (l_behind + l_len_2);
          l_k = (l_k + 1u);
        }
      }
      if (((l_best > 0x1.400000p4f) || (l_at.w < 0x1.99999ap-5f)))
      {
        {
          l_m = (l_m + 1u);
          continue;
        }
      }
      l_v = coax_p_fmin(cx, l_at.w, 0x1.400000p1f);
      l_age = coax_p_fmax(cx, l_at.z, 0.0f);
      l_fade = ((exp(((-l_at.x) / 0x1.000000p3f)) * exp(((-l_age) * 0x1.333334p-2f))) * coax_p_smoothstep(cx, 0x1.99999ap-5f, 0x1.99999ap-2f, l_v));
      if ((l_fade < 0x1.47ae14p-7f))
      {
        {
          l_m = (l_m + 1u);
          continue;
        }
      }
      l_side = ((l_at.y > 0.0f) ? 0x1.000000p0f : (-0x1.000000p0f));
      l_across = coax_p_wg_mul_f2f(cx, coax_p_v2(cx, (-l_dir.y), l_dir.x), l_side);
      l_l = abs(l_at.y);
      l_wave = coax_p_fmax(cx, (((0x1.921fb6p2f * l_v) * l_v) / 0x1.39eb86p3f), 0x1.333334p-2f);
      l_feather = (0x1.4cccccp-1f + (0x1.666666p-2f * cos(((0x1.921fb6p2f * l_at.x) / l_wave))));
      l_arm = (0x1.333334p-2f + (0x1.6a161ep-2f * l_at.x));
      l_w = (0x1.47ae14p-3f + (0x1.99999ap-5f * l_at.x));
      l_x = (l_l - l_arm);
      l_amp = ((0x1.70a3d8p-4f * l_fade) * coax_p_fmin(cx, (l_v / 0x1.333334p0f), 0x1.666666p0f));
      l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_across, (((-0x1.000000p1f) * l_x) / (l_w * l_w))), exp((((-l_x) * l_x) / (l_w * l_w)))), l_amp), l_w), l_feather));
      l_inside = (0x1.000000p0f - coax_p_smoothstep(cx, (l_arm * 0x1.666666p-1f), l_arm, l_l));
      l_g = coax_p_wg_add_f2f2(cx, l_g, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, coax_p_wg_mul_f2f(cx, l_dir, sin(((0x1.921fb6p2f * l_at.x) / l_wave))), l_amp), 0x1.000000p-1f), l_inside));
      l_trail = (0x1.c28f5cp-3f + (0x1.1eb852p-4f * l_at.x));
      (*p_wake_foam)[0] = coax_p_fmax(cx, (*p_wake_foam)[0], ((((0x1.000000p0f - coax_p_smoothstep(cx, (l_trail * 0x1.666666p-2f), l_trail, l_l)) * l_fade) * coax_p_fmin(cx, (l_v * 0x1.333334p0f), 0x1.000000p0f)) * exp(((-l_age) * 0x1.000000p-2f))));
      (*p_wake_foam)[0] = coax_p_fmax(cx, (*p_wake_foam)[0], (((exp((((-l_x) * l_x) / ((l_w * l_w) * 0x1.000000p-2f))) * l_fade) * coax_p_clampf(cx, (l_v - 0x1.333334p-1f), 0.0f, 0x1.000000p0f)) * 0x1.333334p-1f));
      l_m = (l_m + 1u);
    }
  }
  return l_g;
}
float coax_p_eg_weather_hash(CoaxResources cx, float2 p_p) {
  float2 l_p = p_p;
  return coax_p_render_noise2(cx, l_p.x, l_p.y);
}
float2 coax_p_wg_add_f2f(CoaxResources cx, float2 p_a, float p_b) {
  float2 l_a = p_a;
  float l_b = p_b;
  return coax_p_v2(cx, (l_a.x + l_b), (l_a.y + l_b));
}
float3 coax_p_wg_exp_f3(CoaxResources cx, float3 p_p0) {
  float3 l_p0 = p_p0;
  return coax_p_v3(cx, exp(l_p0.x), exp(l_p0.y), exp(l_p0.z));
}
float coax_p_wg_log2(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return (log(l_x) / 0x1.62e430p-1f);
}
float coax_p_verse_style_sky_t(CoaxResources cx, float p_up) {
  float l_up = p_up;
  return coax_metal_pow(coax_p_st_max(cx, l_up, 0x1.0c6f7ap-20f), 0x1.19999ap-1f);
}
float coax_p_verse_style_halo(CoaxResources cx, float p_cos_t, float p_k) {
  float l_cos_t = p_cos_t;
  float l_k = p_k;
  return exp(((-l_k) * coax_p_st_max(cx, (0x1.000000p0f - l_cos_t), 0.0f)));
}
float coax_p_eg_water_ggx(CoaxResources cx, float p_noh, float p_a2) {
  float l_noh = p_noh;
  float l_a2 = p_a2;
  float l_d{};
  l_d = (((l_noh * l_noh) * (l_a2 - 0x1.000000p0f)) + 0x1.000000p0f);
  return (l_a2 / ((0x1.921fb6p1f * l_d) * l_d));
}
float coax_p_eg_water_smith(CoaxResources cx, float p_nov, float p_nol, float p_a2) {
  float l_nov = p_nov;
  float l_nol = p_nol;
  float l_a2 = p_a2;
  float l_gv{};
  float l_gl{};
  l_gv = (l_nol * sqrt((((l_nov * l_nov) * (0x1.000000p0f - l_a2)) + l_a2)));
  l_gl = (l_nov * sqrt((((l_nol * l_nol) * (0x1.000000p0f - l_a2)) + l_a2)));
  return (0x1.000000p-1f / coax_p_fmax(cx, (l_gv + l_gl), 0x1.0c6f7ap-20f));
}
float coax_p_eg_water_ripple_foam(CoaxResources cx, float2 p_p, thread array<float, 1>* p_wake_foam) {
  float2 l_p = p_p;
  float l_foam{};
  float l_t{};
  int l_count{};
  int l_i{};
  float4 l_r{};
  float l_age{};
  float l_x{};
  l_foam = (*p_wake_foam)[0];
  l_t = cx.r_u[1048];
  l_count = coax_p_wg_i32_f(cx, cx.r_u[1050]);
  {
    l_i = 0;
    while ((l_i < 24))
    {
      if ((l_i >= l_count))
      {
        break;
      }
      l_r = coax_p_wg_at4(cx, ((int(l_i) * 4) + 952));
      l_age = (l_t - l_r.z);
      l_x = (coax_p_wg_length2(cx, coax_p_wg_sub_f2f2(cx, l_p, coax_p_v2(cx, l_r.x, l_r.y))) - (0x1.19999ap0f * l_age));
      l_foam = coax_p_fmax(cx, l_foam, ((exp((((-l_x) * l_x) / 0x1.47ae14p-4f)) * exp(((-l_age) * 0x1.99999ap0f))) * coax_p_clampf(cx, (l_r.w * 0x1.900000p4f), 0.0f, 0x1.000000p0f)));
      l_i = (l_i + 1);
    }
  }
  return l_foam;
}
float coax_p_eg_water_cos_refracted(CoaxResources cx, float p_ci) {
  float l_ci = p_ci;
  return sqrt(coax_p_fmax(cx, (0x1.000000p0f - ((0x1.000000p0f - (l_ci * l_ci)) / (0x1.547ae2p0f * 0x1.547ae2p0f))), 0.0f));
}
float coax_p_verse_style_haze_teal(CoaxResources cx, float p_ch) {
  float l_ch = p_ch;
  if ((l_ch < 0x1.000000p-1f))
  {
    return 0x1.666666p-1f;
  }
  if ((l_ch < 0x1.800000p0f))
  {
    return 0x1.000000p0f;
  }
  return 0x1.ae147ap-1f;
}
float coax_p_verse_style_soft_step(CoaxResources cx, float p_e, float p_s, float p_x) {
  float l_e = p_e;
  float l_s = p_s;
  float l_x = p_x;
  float l_t{};
  l_t = coax_p_st_sat(cx, ((l_x - (l_e - l_s)) / coax_p_st_max(cx, (0x1.000000p1f * l_s), 0x1.0c6f7ap-20f)));
  return ((l_t * l_t) * (0x1.800000p1f - (0x1.000000p1f * l_t)));
}
float3 coax_p_EG_MEADOW_COOL(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.000000p-2f, 0x1.851eb8p-2f, 0x1.c28f5cp-3f);
}
float3 coax_p_EG_MEADOW_WARM(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.a3d70ap-2f, 0x1.f5c290p-2f, 0x1.000000p-2f);
}
float coax_p_st_sat(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return coax_p_st_min(cx, 0x1.000000p0f, coax_p_st_max(cx, 0.0f, l_x));
}
int coax_p_wg_max_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b > l_a))
  {
    return l_b;
  }
  return l_a;
}
int coax_p_wg_min_i(CoaxResources cx, int p_a, int p_b) {
  int l_a = p_a;
  int l_b = p_b;
  if ((l_b < l_a))
  {
    return l_b;
  }
  return l_a;
}
float coax_p_wg_trunc(CoaxResources cx, float p_x) {
  float l_x = p_x;
  if ((l_x < 0.0f))
  {
    return (-floor((-l_x)));
  }
  return floor(l_x);
}
coax_t23 coax_p_i3(CoaxResources cx, int p_x, int p_y, int p_z) {
  int l_x = p_x;
  int l_y = p_y;
  int l_z = p_z;
  return coax_t23{l_x, l_y, l_z};
}
coax_t24 coax_p_eg_light_space(CoaxResources cx) {
  float3 l_l{};
  float3 l_ax{};
  float3 l_ay{};
  float l_reach{};
  float l_size{};
  float3 l_c{};
  l_l = coax_p_wg_sw_xyz_f4(cx, coax_p_eg_st(cx, 1u));
  l_ax = ((abs(l_l.y) < 0x1.ff7ceep-1f) ? coax_p_wg_normalize3(cx, coax_p_wg_cross3(cx, coax_p_v3(cx, 0.0f, 0x1.000000p0f, 0.0f), l_l)) : coax_p_v3(cx, 0x1.000000p0f, 0.0f, 0.0f));
  l_ay = coax_p_wg_cross3(cx, l_l, l_ax);
  l_reach = coax_p_verse_style_shadow_reach(cx, (coax_p_eg_st(cx, 31u)).z);
  l_size = coax_p_fmax(cx, (coax_p_eg_st(cx, 21u)).x, 0x1.000000p0f);
  l_c = coax_p_v3(cx, cx.r_u[24], 0.0f, cx.r_u[26]);
  return coax_t24{l_ax, l_ay, l_l, coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ax), l_reach, l_size), coax_p_verse_style_shadow_snap(cx, coax_p_wg_dot3(cx, l_c, l_ay), l_reach, l_size), l_reach};
}
float3 coax_p_eg_shadow_place(CoaxResources cx, float3 p_w, coax_t24 p_k) {
  float3 l_w = p_w;
  coax_t24 l_k = p_k;
  return coax_p_v3(cx, coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.x) - l_k.w), l_k.f5), coax_p_verse_style_shadow_across(cx, (coax_p_wg_dot3(cx, l_w, l_k.y) - l_k.f4), l_k.f5), coax_p_verse_style_shadow_depth(cx, coax_p_wg_dot3(cx, coax_p_wg_sub_f3f3(cx, l_w, coax_p_wg_add_f3f3(cx, coax_p_wg_mul_ff3(cx, l_k.w, l_k.x), coax_p_wg_mul_ff3(cx, l_k.f4, l_k.y))), l_k.z), l_k.f5));
}
coax_t21 coax_p_wg_dims_depth_1(CoaxResources cx) {
  return coax_p_u2(cx, (cx.r_shadow_map).get_width(), (cx.r_shadow_map).get_height());
}
float coax_p_verse_style_shadow_tap(CoaxResources cx, float p_k, float p_on_phone, float p_which) {
  float l_k = p_k;
  float l_on_phone = p_on_phone;
  float l_which = p_which;
  float l_x{};
  float l_y{};
  l_x = 0.0f;
  l_y = 0.0f;
  if ((l_on_phone > 0x1.000000p-1f))
  {
    if ((l_k < 0x1.000000p-1f))
    {
      l_x = (-0x1.333334p-1f);
      l_y = (-0x1.000000p-2f);
    }
    else
    {
      if ((l_k < 0x1.800000p0f))
      {
        l_x = 0x1.000000p-2f;
        l_y = (-0x1.333334p-1f);
      }
      else
      {
        if ((l_k < 0x1.400000p1f))
        {
          l_x = 0x1.333334p-1f;
          l_y = 0x1.000000p-2f;
        }
        else
        {
          l_x = (-0x1.000000p-2f);
          l_y = 0x1.333334p-1f;
        }
      }
    }
  }
  else
  {
    if ((l_k < 0x1.000000p-1f))
    {
      l_x = 0.0f;
      l_y = 0.0f;
    }
    else
    {
      if ((l_k < 0x1.800000p0f))
      {
        l_x = (-0x1.4dd2f2p-2f);
        l_y = (-0x1.9fbe76p-2f);
      }
      else
      {
        if ((l_k < 0x1.400000p1f))
        {
          l_x = (-0x1.ae147ap-1f);
          l_y = (-0x1.2f1aa0p-4f);
        }
        else
        {
          if ((l_k < 0x1.c00000p1f))
          {
            l_x = (-0x1.645a1cp-1f);
            l_y = 0x1.d3f7cep-2f;
          }
          else
          {
            if ((l_k < 0x1.200000p2f))
            {
              l_x = (-0x1.9fbe76p-3f);
              l_y = 0x1.3df3b6p-1f;
            }
            else
            {
              if ((l_k < 0x1.600000p2f))
              {
                l_x = 0x1.ec8b44p-1f;
                l_y = (-0x1.8f5c28p-3f);
              }
              else
              {
                if ((l_k < 0x1.a00000p2f))
                {
                  l_x = 0x1.e45a1cp-2f;
                  l_y = (-0x1.eb851ep-2f);
                }
                else
                {
                  if ((l_k < 0x1.e00000p2f))
                  {
                    l_x = 0x1.09ba5ep-1f;
                    l_y = 0x1.88b43ap-1f;
                  }
                  else
                  {
                    l_x = 0x1.7ae148p-3f;
                    l_y = (-0x1.c9374cp-1f);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((l_which > 0x1.000000p-1f))
  {
    return l_y;
  }
  return l_x;
}
bool coax_p_wg_all_gt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x > l_b.x) && (l_a.y > l_b.y));
}
bool coax_p_wg_all_lt_f2f2(CoaxResources cx, float2 p_a, float2 p_b) {
  float2 l_a = p_a;
  float2 l_b = p_b;
  return ((l_a.x < l_b.x) && (l_a.y < l_b.y));
}
float coax_p_wg_atan01(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_z{};
  float l_p{};
  l_z = (l_x * l_x);
  l_p = (-0x1.09afcep-8f);
  l_p = ((l_p * l_z) + 0x1.662ca4p-6f);
  l_p = ((l_p * l_z) - 0x1.ca0388p-5f);
  l_p = ((l_p * l_z) + 0x1.8aefbep-4f);
  l_p = ((l_p * l_z) - 0x1.1cd8c6p-3f);
  l_p = ((l_p * l_z) + 0x1.98814cp-3f);
  l_p = ((l_p * l_z) - 0x1.554c38p-2f);
  l_p = ((l_p * l_z) + 0x1.ffffeap-1f);
  return (l_x * l_p);
}
float3 coax_p_EG_W_MID(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.99999ap-4f, 0x1.ccccccp-2f, 0x1.19999ap-1f);
}
float coax_p_eg_water_paint_ramp(CoaxResources cx, float p_edge, float p_x) {
  float l_edge = p_edge;
  float l_x = p_x;
  return coax_p_smoothstep(cx, (l_edge - 0x1.333334p-4f), (l_edge + 0x1.333334p-4f), l_x);
}
float3 coax_p_EG_W_DEEP(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.99999ap-5f, 0x1.c28f5cp-3f, 0x1.70a3d8p-2f);
}
float3 coax_p_EG_W_TEAL(CoaxResources cx) {
  return coax_p_v3(cx, 0x1.eb851ep-4f, 0x1.666666p-1f, 0x1.47ae14p-1f);
}
float coax_p_eg_water_paint_sparkle(CoaxResources cx, float p_rdl) {
  float l_rdl = p_rdl;
  return coax_p_smoothstep(cx, 0x1.fec030p-1f, 0x1.ffb00cp-1f, l_rdl);
}
float coax_p_render_noise2(CoaxResources cx, float p_x, float p_y) {
  float l_x = p_x;
  float l_y = p_y;
  if (((!coax_p_render_noise_coordinate_ok(cx, l_x)) || (!coax_p_render_noise_coordinate_ok(cx, l_y))))
  {
    return 0.0f;
  }
  return coax_p_render_noise_unit(cx, coax_p_render_noise_mix2(cx, coax_p_render_noise_cell(cx, l_x), coax_p_render_noise_cell(cx, l_y)));
}
float coax_p_verse_style_shadow_reach(CoaxResources cx, float p_on_phone) {
  float l_on_phone = p_on_phone;
  if ((l_on_phone > 0x1.000000p-1f))
  {
    return 0x1.400000p5f;
  }
  return 0x1.e00000p5f;
}
float coax_p_verse_style_shadow_snap(CoaxResources cx, float p_x, float p_reach, float p_size) {
  float l_x = p_x;
  float l_reach = p_reach;
  float l_size = p_size;
  float l_texel{};
  l_texel = ((0x1.000000p1f * l_reach) / coax_p_st_max(cx, l_size, 0x1.000000p0f));
  return (floor(((l_x / l_texel) + 0x1.000000p-1f)) * l_texel);
}
float coax_p_verse_style_shadow_across(CoaxResources cx, float p_x, float p_reach) {
  float l_x = p_x;
  float l_reach = p_reach;
  return (l_x / coax_p_st_max(cx, l_reach, 0x1.0624dep-10f));
}
float coax_p_verse_style_shadow_depth(CoaxResources cx, float p_along, float p_reach) {
  float l_along = p_along;
  float l_reach = p_reach;
  return (0x1.000000p-1f - (l_along / (0x1.000000p2f * coax_p_st_max(cx, l_reach, 0x1.0624dep-10f))));
}
bool coax_p_render_noise_coordinate_ok(CoaxResources cx, float p_x) {
  float l_x = p_x;
  return ((l_x >= (-0x1.fffffep127f)) && (l_x <= 0x1.fffffep127f));
}
uint coax_p_render_noise_cell(CoaxResources cx, float p_x) {
  float l_x = p_x;
  float l_bounded{};
  l_bounded = coax_p_fmin(cx, coax_p_fmax(cx, l_x, (-0x1.000000p25f)), 0x1.fffffep24f);
  return uint(int(floor((l_bounded * 0x1.000000p6f))));
}
uint coax_p_render_noise_mix2(CoaxResources cx, uint p_x, uint p_y) {
  uint l_x = p_x;
  uint l_y = p_y;
  return coax_p_render_noise_permute(cx, ((l_x * 1597334677u) ^ (l_y * 3812015801u)));
}
float coax_p_render_noise_unit(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  return (float((l_word >> uint(8u))) * 0x1.000000p-24f);
}
uint coax_p_render_noise_permute(CoaxResources cx, uint p_word) {
  uint l_word = p_word;
  uint l_h{};
  l_h = (l_word * 747796405u);
  l_h = ((l_h ^ (l_h >> uint(16u))) * 2246822519u);
  return (l_h ^ (l_h >> uint(13u)));
}
vertex coax_io_8 eg_water_vs(uint coax_vid [[vertex_id]], uint coax_iid [[instance_id]], CoaxResources cx) {
  auto coax_r = coax_p_eg_water_vs(cx, coax_vid, coax_iid);
  return coax_io_8{coax_r.x, coax_r.y, coax_r.z, coax_r.w, coax_r.f4};
}
fragment float4 eg_water_emit_fs(coax_io_8 coax_in [[stage_in]], CoaxResources cx) {
  auto coax_r = coax_p_eg_water_emit_fs(cx, coax_t8{coax_in.x, coax_in.y, coax_in.z, coax_in.w, coax_in.f4});
  return coax_r;
}
