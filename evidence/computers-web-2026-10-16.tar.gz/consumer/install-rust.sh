set -eu
if ! command -v rustc >/dev/null 2>&1; then
 sudo -n env DEBIAN_FRONTEND=noninteractive apt-get update -qq
 sudo -n env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rustc
fi
rustc --version
find . -maxdepth 5 -name sdk_11806.rs -type f -print
printf 'SDK11806 TOOLCHAIN READY\n'
