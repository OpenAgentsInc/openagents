set -eu
printf 'HOME=%s\n' "$HOME"
pwd
find / -path /proc -prune -o -path /sys -prune -o -path /dev -prune -o -type f -name sdk_11806.rs -print 2>/dev/null || true
