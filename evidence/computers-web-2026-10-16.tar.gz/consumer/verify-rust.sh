set -eu
qdir="$HOME/workspace/sdk-qa"
mkdir -p "$qdir"
git -C /home/user/repo merge-base --is-ancestor af4f497 1dfbeaf
git -C /home/user/repo rev-parse af4f497 1dfbeaf
git -C /home/user/repo show af4f497:sdk_11806.rs > "$qdir/first.rs"
git -C /home/user/repo show 1dfbeaf:sdk_11806.rs > "$qdir/followup.rs"
rustc --test --crate-name sdk_qa_first "$qdir/first.rs" -o "$qdir/first-tests"
"$qdir/first-tests" > "$qdir/first-results.txt"
cat "$qdir/first-results.txt"
grep -q 'test result: ok. 2 passed' "$qdir/first-results.txt"
rustc --test --crate-name sdk_qa_followup "$qdir/followup.rs" -o "$qdir/followup-tests"
"$qdir/followup-tests" > "$qdir/followup-results.txt"
cat "$qdir/followup-results.txt"
grep -q 'test result: ok. 3 passed' "$qdir/followup-results.txt"
printf 'SDK11806 INDEPENDENT TWO AND THREE TESTS VERIFIED\n'
