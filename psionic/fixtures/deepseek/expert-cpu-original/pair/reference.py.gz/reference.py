#!/usr/bin/env python3
"""Opt-in independent NumPy original-expert comparison; no upstream runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from deepseek_expert_oracle import scalar,quantize,activate,f32
ROOT=Path(__file__).resolve().parents[2]


def main():
    p=argparse.ArgumentParser();p.add_argument('original',type=Path);p.add_argument('capture',type=Path);a=p.parse_args()
    record=json.loads((ROOT/'psionic/fixtures/deepseek/expert-original.json').read_text());assert a.original.stat().st_size==record['pin']['bytes']
    with a.original.open('rb') as f:n=struct.unpack('<Q',f.read(8))[0];raw=f.read(n)
    assert hashlib.sha256(raw).hexdigest()==record['raw_header_sha256'];header=json.loads(raw);payload=n+8;mm=np.memmap(a.original,mode='r',dtype='u1')
    def tensor(name):
        h=header[name];assert h==record['reviewed'][name];lo,hi=h['data_offsets'];return np.asarray(mm[payload+lo:payload+hi]).reshape(h['shape'])
    def matrix(prefix,branch,shared):
        data=tensor(prefix+branch+'.weight');scales=tensor(prefix+branch+'.scale');assert np.all(scales!=255)
        if shared:
            assert np.all((data&127)!=127);lut=np.array([scalar('fp8',c,127) if c&127!=127 else np.nan for c in range(256)],dtype='f8');values=lut[data]
            factors=np.exp2(scales.astype('f8')-127);factors=np.repeat(np.repeat(factors,32,axis=0),32,axis=1)[:values.shape[0],:values.shape[1]]
        else:
            codes=np.empty((data.shape[0],data.shape[1]*2),'u1');codes[:,::2]=data&15;codes[:,1::2]=data>>4
            values=np.array([scalar('fp4',c,127) for c in range(16)],'f8')[codes];factors=np.repeat(np.exp2(scales.astype('f8')-127),32,axis=1)
        return values*factors
    policy=(ROOT/'psionic/tests/expert-qualification-policy.json').read_bytes();rule=json.loads(policy)['intermediate_and_output'];reports={}
    for shared in [False,True]:
        begin=time.monotonic();tag='shared' if shared else 'routed';meta=json.loads((a.capture/f'{tag}.json').read_text());prefix='layers.0.ffn.'+('shared_experts.' if shared else 'experts.0.')
        x=np.fromfile(a.capture/f'{tag}-input.f32',dtype='<f4');expected=np.array([f32(((i*17)%29-14)/8) for i in range(5120)],'f4');assert np.array_equal(x,expected)
        q=np.array(quantize(x.tolist())['values'],'f8');gate=(matrix(prefix,'w1',shared)@q).astype('f4');up=(matrix(prefix,'w3',shared)@q).astype('f4')
        act=activate(gate.tolist(),up.tolist(),f32(meta['route']),10);weighted=np.array(act['values'],'f4');down_grid=np.array(quantize(weighted.tolist())['values'],'f8');out=(matrix(prefix,'w2',shared)@down_grid).astype('f4')
        report={}
        for name,reference in [('gate',gate),('up',up),('activation',weighted),('output',out)]:
            actual=np.fromfile(a.capture/f'{tag}-{name}.f32',dtype='<f4');assert actual.shape==reference.shape
            error=np.abs(actual.astype('f8')-reference.astype('f8'));bound=rule['atol']+rule['rtol']*np.abs(reference.astype('f8'))
            report[name]=dict(values=reference.size,max_abs=float(np.max(error)),max_bound_ratio=float(np.max(error/bound)),bit_identical=actual.tobytes()==reference.tobytes(),passed=bool(np.all(np.isfinite(actual)) and np.all(error<=bound)))
            reference.astype('<f4').tofile(a.capture/f'{tag}-reference-{name}.f32')
        actual_grid=np.fromfile(a.capture/f'{tag}-down-grid.f64',dtype='<f8');report['down_grid_exact']=actual_grid.tobytes()==down_grid.astype('<f8').tobytes();down_grid.astype('<f8').tofile(a.capture/f'{tag}-reference-down-grid.f64')
        report['clamp_counts_exact']=meta['gate_clamped']==act['gate_clamped'] and meta['up_clamped']==act['up_clamped'];report['reference_seconds']=time.monotonic()-begin
        report['passed']=all(report[k]['passed'] for k in ['gate','up','activation','output']) and report['down_grid_exact'] and report['clamp_counts_exact'];reports[tag]=report
        (a.capture/f'{tag}-comparison.json').write_text(json.dumps(report,indent=2)+'\n');assert report['passed'],report
    (a.capture/'comparison.json').write_text(json.dumps(dict(policy_sha256=hashlib.sha256(policy).hexdigest(),experts=reports),indent=2)+'\n');print(json.dumps(reports,indent=2))


if __name__=='__main__':main()
